<?php
/**
 * Header logo loading: make the logo part of the first paint.
 *
 * The logo is the first thing in the server-rendered header, but nothing told
 * the browser to fetch it early, and WordPress marks content images
 * `decoding="async"`. The header therefore painted without its logo, and the
 * logo flashed in a moment later. Two fixes, both for the visible logo only:
 * a preload in <head>, and synchronous decoding with high fetch priority.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_header_logo_eager' ) ) {
	/**
	 * Mark the visible header logo as decode-with-the-page and fetch-first.
	 *
	 * Only the first `img.rh-logo` that is not the hidden megamenu copy, and
	 * only once (idempotent). Runs on the finished header HTML, so the markup
	 * the React-parity fixtures pin is not involved.
	 *
	 * @param string $html Server-rendered header HTML.
	 * @return string
	 */
	function cb_header_logo_eager( string $html ): string {
		return (string) preg_replace(
			'/<img (?![^>]*\bdecoding=)(?![^>]*\brh-logo-mega\b)(?=[^>]*\bclass="rh-logo")/',
			'<img decoding="sync" fetchpriority="high" ',
			$html,
			1
		);
	}
}

if ( ! function_exists( 'cb_header_logo_preload_tag' ) ) {
	/**
	 * `<link rel="preload">` for the logo.
	 *
	 * @param string $url Logo URL.
	 * @return string The tag, or '' for an empty or disallowed URL.
	 */
	function cb_header_logo_preload_tag( string $url ): string {
		$href = esc_url( trim( $url ) );
		if ( '' === $href ) {
			return '';
		}
		return '<link rel="preload" as="image" href="' . $href . '" fetchpriority="high" />' . "\n";
	}
}

if ( ! function_exists( 'cb_header_logo_preload' ) ) {
	/**
	 * Print the preload in <head>. A block theme renders its template (and so
	 * the header block) before wp_head runs, which is what lets the header
	 * block ask for this.
	 *
	 * @param string $url Logo URL.
	 */
	function cb_header_logo_preload( string $url ): void {
		static $done = false;
		if ( $done || '' === trim( $url ) || did_action( 'wp_head' ) ) {
			return;
		}
		$done = true;
		add_action(
			'wp_head',
			static function () use ( $url ) {
				echo cb_header_logo_preload_tag( $url ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in cb_header_logo_preload_tag()
			},
			1
		);
	}
}
