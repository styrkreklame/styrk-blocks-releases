<?php
/**
 * Media folders — folders, a folder filter and sorting for the Media Library.
 *
 * WordPress keeps every upload in one flat list. This module adds:
 *  1. Folders: a hierarchical taxonomy on attachments, managed under
 *     Media → Folders. A file can sit in one folder or none.
 *  2. A folder filter in both Media Library views (list and grid) and in the
 *     media picker of the block editor, including "Not in a folder".
 *  3. Sorting in the grid view and the media picker (newest, oldest, name).
 *  4. A folder select on each file, and "Move to folder" as a bulk action in
 *     the list view.
 *
 * Purely additive: nothing is moved on disk, no URL changes, and a site that
 * never creates a folder sees one extra, empty dropdown.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard — see header-settings.php for the rationale.
if ( defined( 'CB_MEDIA_FOLDERS_LOADED' ) ) return;
define( 'CB_MEDIA_FOLDERS_LOADED', true );

define( 'CB_MEDIA_FOLDER_TAX', 'cb_media_folder' );

/* ── Taxonomy ──────────────────────────────────────────────────────────────── */

function cb_media_folders_register(): void {
	register_taxonomy(
		CB_MEDIA_FOLDER_TAX,
		'attachment',
		[
			'labels'                => [
				'name'          => __( 'Mapper', 'styrk-blocks' ),
				'singular_name' => __( 'Mappe', 'styrk-blocks' ),
				'menu_name'     => __( 'Mapper', 'styrk-blocks' ),
				'all_items'     => __( 'Alle mapper', 'styrk-blocks' ),
				'edit_item'     => __( 'Rediger mappe', 'styrk-blocks' ),
				'add_new_item'  => __( 'Legg til ny mappe', 'styrk-blocks' ),
				'new_item_name' => __( 'Navn på ny mappe', 'styrk-blocks' ),
				'parent_item'   => __( 'Overordnet mappe', 'styrk-blocks' ),
				'search_items'  => __( 'Søk i mapper', 'styrk-blocks' ),
				'not_found'     => __( 'Ingen mapper ennå.', 'styrk-blocks' ),
			],
			'hierarchical'          => true,
			'public'                => false,
			'show_ui'               => true,
			'show_in_menu'          => true,
			'show_admin_column'     => true,
			'show_in_rest'          => true,
			'rewrite'               => false,
			'query_var'             => false,
			// Attachments have the status "inherit", which the default counter
			// ignores: without this every folder would show 0 files.
			'update_count_callback' => '_update_generic_term_count',
		]
	);
}
add_action( 'init', 'cb_media_folders_register' );

/**
 * Folders as a flat list in tree order: [ [ id, name, depth ], … ].
 *
 * @return array<int, array{id:int,name:string,depth:int}>
 */
function cb_media_folders_list(): array {
	$terms = get_terms(
		[
			'taxonomy'   => CB_MEDIA_FOLDER_TAX,
			'hide_empty' => false,
			'orderby'    => 'name',
		]
	);
	if ( is_wp_error( $terms ) || ! $terms ) {
		return [];
	}
	$by_parent = [];
	foreach ( $terms as $term ) {
		$by_parent[ (int) $term->parent ][] = $term;
	}
	$out  = [];
	$walk = static function ( int $parent, int $depth ) use ( &$walk, &$out, $by_parent ): void {
		foreach ( $by_parent[ $parent ] ?? [] as $term ) {
			$out[] = [
				'id'    => (int) $term->term_id,
				'name'  => (string) $term->name,
				'depth' => $depth,
			];
			$walk( (int) $term->term_id, $depth + 1 );
		}
	};
	$walk( 0, 0 );
	return $out;
}

/**
 * The tax_query for a folder choice: a folder id (with its sub-folders), or
 * 'none' for files that are in no folder. Empty array = no restriction.
 *
 * @param string $choice Folder id or 'none'.
 * @return array<int, array<string, mixed>>
 */
function cb_media_folders_tax_query( string $choice ): array {
	if ( 'none' === $choice ) {
		return [
			[
				'taxonomy' => CB_MEDIA_FOLDER_TAX,
				'operator' => 'NOT EXISTS',
			],
		];
	}
	$id = absint( $choice );
	if ( ! $id ) {
		return [];
	}
	return [
		[
			'taxonomy'         => CB_MEDIA_FOLDER_TAX,
			'field'            => 'term_id',
			'terms'            => [ $id ],
			'include_children' => true,
		],
	];
}

/* ── List view: filter dropdown ────────────────────────────────────────────── */

function cb_media_folders_list_filter(): void {
	$screen = get_current_screen();
	if ( ! $screen || 'upload' !== $screen->id ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filter.
	$current = isset( $_GET['cb_folder'] ) ? sanitize_key( wp_unslash( $_GET['cb_folder'] ) ) : '';

	echo '<label class="screen-reader-text" for="cb-folder-filter">' . esc_html__( 'Filtrer etter mappe', 'styrk-blocks' ) . '</label>';
	echo '<select name="cb_folder" id="cb-folder-filter">';
	echo '<option value="">' . esc_html__( 'Alle mapper', 'styrk-blocks' ) . '</option>';
	printf( '<option value="none" %s>%s</option>', selected( $current, 'none', false ), esc_html__( 'Ikke i en mappe', 'styrk-blocks' ) );
	foreach ( cb_media_folders_list() as $folder ) {
		printf(
			'<option value="%d" %s>%s%s</option>',
			(int) $folder['id'],
			selected( $current, (string) $folder['id'], false ),
			esc_html( str_repeat( '— ', $folder['depth'] ) ),
			esc_html( $folder['name'] )
		);
	}
	echo '</select>';
}
add_action( 'restrict_manage_posts', 'cb_media_folders_list_filter' );

/**
 * Apply the list-view filter to the Media Library's main query.
 *
 * @param WP_Query $query Query being built.
 */
function cb_media_folders_list_query( $query ): void {
	if ( ! is_admin() || ! $query->is_main_query() || 'attachment' !== $query->get( 'post_type' ) ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only list filter.
	$choice = isset( $_GET['cb_folder'] ) ? sanitize_key( wp_unslash( $_GET['cb_folder'] ) ) : '';
	$tax    = cb_media_folders_tax_query( $choice );
	if ( $tax ) {
		$query->set( 'tax_query', array_merge( (array) $query->get( 'tax_query' ), $tax ) );
	}
}
add_action( 'pre_get_posts', 'cb_media_folders_list_query' );

/* ── List view: "Move to folder" bulk actions ──────────────────────────────── */

/**
 * @param array<string, string> $actions Bulk actions.
 * @return array<string, string>
 */
function cb_media_folders_bulk_actions( array $actions ): array {
	foreach ( cb_media_folders_list() as $folder ) {
		/* translators: %s: folder name. */
		$actions[ 'cb_move_to_' . $folder['id'] ] = sprintf( __( 'Flytt til mappe: %s', 'styrk-blocks' ), str_repeat( '— ', $folder['depth'] ) . $folder['name'] );
	}
	if ( cb_media_folders_list() ) {
		$actions['cb_move_to_none'] = __( 'Fjern fra mappe', 'styrk-blocks' );
	}
	return $actions;
}
add_filter( 'bulk_actions-upload', 'cb_media_folders_bulk_actions' );

/**
 * @param string     $redirect Redirect URL.
 * @param string     $action   Chosen bulk action.
 * @param array<int> $ids      Selected attachment ids.
 * @return string
 */
function cb_media_folders_bulk_handle( $redirect, $action, $ids ) {
	if ( 0 !== strpos( (string) $action, 'cb_move_to_' ) ) {
		return $redirect;
	}
	$target = substr( (string) $action, strlen( 'cb_move_to_' ) );
	$terms  = 'none' === $target ? [] : [ absint( $target ) ];
	$moved  = 0;
	foreach ( (array) $ids as $id ) {
		$id = absint( $id );
		if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
			continue;
		}
		wp_set_object_terms( $id, $terms, CB_MEDIA_FOLDER_TAX );
		++$moved;
	}
	return add_query_arg( 'cb_moved', $moved, remove_query_arg( 'cb_moved', $redirect ) );
}
add_filter( 'handle_bulk_actions-upload', 'cb_media_folders_bulk_handle', 10, 3 );

function cb_media_folders_bulk_notice(): void {
	$screen = get_current_screen();
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
	if ( ! $screen || 'upload' !== $screen->id || ! isset( $_GET['cb_moved'] ) ) {
		return;
	}
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display only.
	$moved = absint( $_GET['cb_moved'] );
	/* translators: %d: number of files. */
	$text = sprintf( _n( '%d fil flyttet.', '%d filer flyttet.', $moved, 'styrk-blocks' ), $moved );
	echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $text ) . '</p></div>';
}
add_action( 'admin_notices', 'cb_media_folders_bulk_notice' );

/* ── Folder select on each file ────────────────────────────────────────────── */

/**
 * Replace core's comma-separated slug field with a plain select.
 *
 * @param array<string, mixed> $fields Attachment fields.
 * @param WP_Post              $post   Attachment.
 * @return array<string, mixed>
 */
function cb_media_folders_field( $fields, $post ) {
	// The full "Edit media" screen already has the taxonomy's own checkbox
	// box, and that box is what the screen saves; a second control there would
	// be overruled by it. The select is for the grid's details panel and the
	// media picker, which have no such box.
	$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
	if ( $screen && 'attachment' === $screen->id ) {
		unset( $fields[ CB_MEDIA_FOLDER_TAX ] );
		return $fields;
	}
	$current = wp_get_object_terms( $post->ID, CB_MEDIA_FOLDER_TAX, [ 'fields' => 'ids' ] );
	$current = is_wp_error( $current ) || ! $current ? 0 : (int) $current[0];

	// The field is named cb_folder, NOT after the taxonomy: core saves any
	// field named like a taxonomy as a comma-separated list of term NAMES, so
	// a submitted id "35" would create and assign a folder called "35".
	$html  = '<select name="attachments[' . (int) $post->ID . '][cb_folder]" id="attachments-' . (int) $post->ID . '-cb_folder">';
	$html .= '<option value="0">' . esc_html__( '— Ingen mappe —', 'styrk-blocks' ) . '</option>';
	foreach ( cb_media_folders_list() as $folder ) {
		$html .= sprintf(
			'<option value="%d" %s>%s%s</option>',
			(int) $folder['id'],
			selected( $current, $folder['id'], false ),
			esc_html( str_repeat( '— ', $folder['depth'] ) ),
			esc_html( $folder['name'] )
		);
	}
	$html .= '</select>';

	// Drop core's own text field for the taxonomy; the select replaces it.
	unset( $fields[ CB_MEDIA_FOLDER_TAX ] );
	$fields['cb_folder'] = [
		'label' => __( 'Mappe', 'styrk-blocks' ),
		'input' => 'html',
		'html'  => $html,
	];
	return $fields;
}
add_filter( 'attachment_fields_to_edit', 'cb_media_folders_field', 10, 2 );

/**
 * @param array<string, mixed> $post       Attachment data being saved.
 * @param array<string, mixed> $attachment Submitted fields.
 * @return array<string, mixed>
 */
function cb_media_folders_field_save( $post, $attachment ) {
	if ( isset( $attachment['cb_folder'] ) && ! empty( $post['ID'] ) && current_user_can( 'edit_post', (int) $post['ID'] ) ) {
		$id = absint( $attachment['cb_folder'] );
		if ( $id && ! term_exists( $id, CB_MEDIA_FOLDER_TAX ) ) {
			return $post;
		}
		wp_set_object_terms( (int) $post['ID'], $id ? [ $id ] : [], CB_MEDIA_FOLDER_TAX );
	}
	return $post;
}
add_filter( 'attachment_fields_to_save', 'cb_media_folders_field_save', 10, 2 );

/* ── Grid view and media picker ────────────────────────────────────────────── */

/**
 * Translate the grid's folder choice into a tax_query. Sorting needs nothing
 * here: the grid sends core's own orderby/order.
 *
 * @param array<string, mixed> $args Query args for the attachments request.
 * @return array<string, mixed>
 */
function cb_media_folders_ajax_query( $args ) {
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- core verifies the request.
	$choice = isset( $_REQUEST['query']['cb_folder'] ) ? sanitize_key( wp_unslash( $_REQUEST['query']['cb_folder'] ) ) : '';
	$tax    = cb_media_folders_tax_query( $choice );
	if ( $tax ) {
		$args['tax_query'] = array_merge( (array) ( $args['tax_query'] ?? [] ), $tax ); // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
	}
	return $args;
}
add_filter( 'ajax_query_attachments_args', 'cb_media_folders_ajax_query' );

function cb_media_folders_grid_script(): void {
	if ( ! wp_script_is( 'media-views', 'registered' ) ) {
		return;
	}
	$data = [
		'folders' => cb_media_folders_list(),
		'l10n'    => [
			'allFolders' => __( 'Alle mapper', 'styrk-blocks' ),
			'noFolder'   => __( 'Ikke i en mappe', 'styrk-blocks' ),
			'filterBy'   => __( 'Filtrer etter mappe', 'styrk-blocks' ),
			'sortBy'     => __( 'Sorter etter', 'styrk-blocks' ),
			'newest'     => __( 'Nyeste først', 'styrk-blocks' ),
			'oldest'     => __( 'Eldste først', 'styrk-blocks' ),
			'nameAz'     => __( 'Navn A–Å', 'styrk-blocks' ),
			'nameZa'     => __( 'Navn Å–A', 'styrk-blocks' ),
		],
	];
	$js = <<<'JS'
( function ( wp, cfg ) {
	if ( ! wp || ! wp.media || ! wp.media.view || ! wp.media.view.AttachmentFilters ) { return; }
	var Filters = wp.media.view.AttachmentFilters;

	var FolderFilter = Filters.extend( {
		id: 'cb-media-folder-filter',
		createFilters: function () {
			var filters = {
				all: { text: cfg.l10n.allFolders, props: { cb_folder: '' }, priority: 10 },
				none: { text: cfg.l10n.noFolder, props: { cb_folder: 'none' }, priority: 20 }
			};
			cfg.folders.forEach( function ( f, i ) {
				filters[ 'f' + f.id ] = {
					text: new Array( f.depth + 1 ).join( '— ' ) + f.name,
					props: { cb_folder: String( f.id ) },
					priority: 30 + i
				};
			} );
			this.filters = filters;
		}
	} );

	var SortFilter = Filters.extend( {
		id: 'cb-media-sort',
		createFilters: function () {
			this.filters = {
				newest: { text: cfg.l10n.newest, props: { orderby: 'date', order: 'DESC' }, priority: 10 },
				oldest: { text: cfg.l10n.oldest, props: { orderby: 'date', order: 'ASC' }, priority: 20 },
				az: { text: cfg.l10n.nameAz, props: { orderby: 'title', order: 'ASC' }, priority: 30 },
				za: { text: cfg.l10n.nameZa, props: { orderby: 'title', order: 'DESC' }, priority: 40 }
			};
		},
		// A library that has not been sorted yet carries no order at all, which
		// matches none of the options and left the dropdown blank. That state
		// IS newest first, so show it.
		select: function () {
			Filters.prototype.select.apply( this, arguments );
			if ( ! this.$el.val() ) { this.$el.val( 'newest' ); }
		}
	} );

	var Browser = wp.media.view.AttachmentsBrowser;
	wp.media.view.AttachmentsBrowser = Browser.extend( {
		createToolbar: function () {
			Browser.prototype.createToolbar.apply( this, arguments );
			var add = function ( toolbar, key, View, label, priority, model ) {
				toolbar.set( key + 'Label', new wp.media.view.Label( {
					value: label,
					attributes: { 'for': View.prototype.id },
					priority: priority
				} ).render() );
				toolbar.set( key, new View( { controller: toolbar.controller, model: model, priority: priority } ).render() );
			};
			add( this.toolbar, 'cbFolder', FolderFilter, cfg.l10n.filterBy, -72, this.collection.props );
			add( this.toolbar, 'cbSort', SortFilter, cfg.l10n.sortBy, -71, this.collection.props );
		}
	} );
} )( window.wp, window.cbMediaFolders );
JS;
	wp_add_inline_script( 'media-views', 'window.cbMediaFolders = ' . wp_json_encode( $data ) . ';' . $js, 'after' );
}
add_action( 'wp_enqueue_media', 'cb_media_folders_grid_script' );
