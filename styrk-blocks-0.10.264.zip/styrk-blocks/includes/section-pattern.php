<?php
/**
 * Section pattern: an optional fine texture over a section's background.
 *
 * `pattern: dots` draws a grid of 1px dots in the section's text colour
 * ("tiles"). The author sets the grid size and the strength; both reach the
 * CSS as custom properties on the block wrapper, and `.cb-pattern--dots`
 * (style.css) paints them on ::after, under the content.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_section_pattern' ) ) {
	/**
	 * Class and style fragment for a block wrapper.
	 *
	 * @param array $attributes Block attributes (pattern, patternSize, patternOpacity).
	 * @return array{class:string,style:string} Both '' when no pattern is set.
	 */
	function cb_section_pattern( array $attributes ): array {
		if ( 'dots' !== ( $attributes['pattern'] ?? 'none' ) ) {
			return [ 'class' => '', 'style' => '' ];
		}
		// Grid size in px (3–16) and dot strength in percent (1–20).
		$size  = max( 3, min( 16, (int) ( $attributes['patternSize'] ?? 5 ) ) );
		$alpha = max( 1, min( 20, (int) ( $attributes['patternOpacity'] ?? 4 ) ) );
		return [
			'class' => 'cb-pattern cb-pattern--dots',
			'style' => '--cb-pattern-size:' . $size . 'px;--cb-pattern-alpha:' . $alpha . '%;',
		];
	}
}
