<?php
/**
 * SVG icon library for custom blocks.
 *
 * Single-colour, 24×24 viewBox, stroke-based line icons.
 * Each icon uses currentColor so it inherits the parent text colour.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard — see header-settings.php for the rationale.
if ( defined( 'CB_ICONS_LOADED' ) ) return;
define( 'CB_ICONS_LOADED', true );

/**
 * Return an associative array of slug → SVG markup.
 *
 * Icons are intentionally minimal line-art to feel modern and professional.
 * Each SVG has role="img" stripped because the surrounding element carries
 * aria-hidden="true" — the icon is decorative.
 */
function cb_get_icon_map(): array {
	$attr = 'xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"';

	return [
		/* ── Finance / Accounting ─────────────────────────────────────────── */
		'chart'       => "<svg {$attr}><path d=\"M3 3v18h18\"/><path d=\"M7 16l4-8 4 4 5-9\"/></svg>",
		'bar-chart'   => "<svg {$attr}><rect x=\"3\" y=\"12\" width=\"4\" height=\"9\"/><rect x=\"10\" y=\"7\" width=\"4\" height=\"14\"/><rect x=\"17\" y=\"3\" width=\"4\" height=\"18\"/></svg>",
		'calculator'  => "<svg {$attr}><rect x=\"4\" y=\"2\" width=\"16\" height=\"20\" rx=\"2\"/><line x1=\"8\" y1=\"6\" x2=\"16\" y2=\"6\"/><line x1=\"8\" y1=\"10\" x2=\"8\" y2=\"10.01\"/><line x1=\"12\" y1=\"10\" x2=\"12\" y2=\"10.01\"/><line x1=\"16\" y1=\"10\" x2=\"16\" y2=\"10.01\"/><line x1=\"8\" y1=\"14\" x2=\"8\" y2=\"14.01\"/><line x1=\"12\" y1=\"14\" x2=\"12\" y2=\"14.01\"/><line x1=\"16\" y1=\"14\" x2=\"16\" y2=\"14.01\"/><line x1=\"8\" y1=\"18\" x2=\"16\" y2=\"18\"/></svg>",
		'wallet'      => "<svg {$attr}><rect x=\"2\" y=\"6\" width=\"20\" height=\"14\" rx=\"2\"/><path d=\"M2 10h20\"/><circle cx=\"17\" cy=\"14\" r=\"1\"/></svg>",
		'coins'       => "<svg {$attr}><circle cx=\"9\" cy=\"9\" r=\"7\"/><path d=\"M15.46 7A7 7 0 1 1 17 14.54\"/></svg>",

		/* ── Documents / Paperwork ────────────────────────────────────────── */
		'file-text'   => "<svg {$attr}><path d=\"M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z\"/><polyline points=\"14 2 14 8 20 8\"/><line x1=\"8\" y1=\"13\" x2=\"16\" y2=\"13\"/><line x1=\"8\" y1=\"17\" x2=\"16\" y2=\"17\"/></svg>",
		'clipboard'   => "<svg {$attr}><rect x=\"8\" y=\"2\" width=\"8\" height=\"4\" rx=\"1\"/><path d=\"M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2\"/><line x1=\"8\" y1=\"12\" x2=\"16\" y2=\"12\"/><line x1=\"8\" y1=\"16\" x2=\"12\" y2=\"16\"/></svg>",
		'receipt'     => "<svg {$attr}><path d=\"M4 2v20l3-2 3 2 3-2 3 2 3-2 3 2V2l-3 2-3-2-3 2-3-2-3 2-3-2z\"/><line x1=\"8\" y1=\"8\" x2=\"16\" y2=\"8\"/><line x1=\"8\" y1=\"12\" x2=\"16\" y2=\"12\"/><line x1=\"8\" y1=\"16\" x2=\"12\" y2=\"16\"/></svg>",

		/* ── People / Team ────────────────────────────────────────────────── */
		'users'       => "<svg {$attr}><path d=\"M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2\"/><circle cx=\"9\" cy=\"7\" r=\"4\"/><path d=\"M23 21v-2a4 4 0 0 0-3-3.87\"/><path d=\"M16 3.13a4 4 0 0 1 0 7.75\"/></svg>",
		'handshake'   => "<svg {$attr}><path d=\"M11 17l-1.5 1.5a2.12 2.12 0 0 1-3 0l-.5-.5a2.12 2.12 0 0 1 0-3L11 10\"/><path d=\"M13 7l1.5-1.5a2.12 2.12 0 0 1 3 0l.5.5a2.12 2.12 0 0 1 0 3L13 14\"/><path d=\"M3 19l2-2\"/><path d=\"M19 5l2-2\"/><path d=\"M10 14l4-4\"/></svg>",
		'user-check'  => "<svg {$attr}><path d=\"M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2\"/><circle cx=\"8.5\" cy=\"7\" r=\"4\"/><polyline points=\"17 11 19 13 23 9\"/></svg>",

		/* ── Security / Trust ─────────────────────────────────────────────── */
		'shield'      => "<svg {$attr}><path d=\"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z\"/></svg>",
		'shield-check'=> "<svg {$attr}><path d=\"M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z\"/><polyline points=\"9 12 11 14 15 10\"/></svg>",
		'lock'        => "<svg {$attr}><rect x=\"3\" y=\"11\" width=\"18\" height=\"11\" rx=\"2\"/><path d=\"M7 11V7a5 5 0 0 1 10 0v4\"/></svg>",
		'key'         => "<svg {$attr}><path d=\"M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4\"/></svg>",

		/* ── Communication ────────────────────────────────────────────────── */
		'phone'       => "<svg {$attr}><path d=\"M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z\"/></svg>",
		'mail'        => "<svg {$attr}><rect x=\"2\" y=\"4\" width=\"20\" height=\"16\" rx=\"2\"/><polyline points=\"22,4 12,13 2,4\"/></svg>",

		/* ── Time / Schedule ──────────────────────────────────────────────── */
		'clock'       => "<svg {$attr}><circle cx=\"12\" cy=\"12\" r=\"10\"/><polyline points=\"12 6 12 12 16 14\"/></svg>",
		'calendar'    => "<svg {$attr}><rect x=\"3\" y=\"4\" width=\"18\" height=\"18\" rx=\"2\"/><line x1=\"16\" y1=\"2\" x2=\"16\" y2=\"6\"/><line x1=\"8\" y1=\"2\" x2=\"8\" y2=\"6\"/><line x1=\"3\" y1=\"10\" x2=\"21\" y2=\"10\"/></svg>",

		/* ── Media ────────────────────────────────────────────────────────── */
		'upload'      => "<svg {$attr}><path d=\"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4\"/><polyline points=\"17 8 12 3 7 8\"/><line x1=\"12\" y1=\"3\" x2=\"12\" y2=\"15\"/></svg>",
		'film'        => "<svg {$attr}><rect x=\"2\" y=\"2\" width=\"20\" height=\"20\" rx=\"2.18\" ry=\"2.18\"/><line x1=\"7\" y1=\"2\" x2=\"7\" y2=\"22\"/><line x1=\"17\" y1=\"2\" x2=\"17\" y2=\"22\"/><line x1=\"2\" y1=\"12\" x2=\"22\" y2=\"12\"/><line x1=\"2\" y1=\"7\" x2=\"7\" y2=\"7\"/><line x1=\"2\" y1=\"17\" x2=\"7\" y2=\"17\"/><line x1=\"17\" y1=\"17\" x2=\"22\" y2=\"17\"/><line x1=\"17\" y1=\"7\" x2=\"22\" y2=\"7\"/></svg>",

		/* ── Navigation ───────────────────────────────────────────────────── */
		'arrow-right' => "<svg {$attr}><line x1=\"5\" y1=\"12\" x2=\"19\" y2=\"12\"/><polyline points=\"12 5 19 12 12 19\"/></svg>",

		/* ── Misc ─────────────────────────────────────────────────────────── */
		'zap'         => "<svg {$attr}><polygon points=\"13 2 3 14 12 14 11 22 21 10 12 10 13 2\"/></svg>",
		'check'       => "<svg {$attr}><polyline points=\"20 6 9 17 4 12\"/></svg>",
		'check-circle'=> "<svg {$attr}><path d=\"M22 11.08V12a10 10 0 1 1-5.93-9.14\"/><polyline points=\"22 4 12 14.01 9 11.01\"/></svg>",
		'heart'       => "<svg {$attr}><path d=\"M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l8.84-8.84a5.5 5.5 0 0 0 0-7.78z\"/></svg>",
		'star'        => "<svg {$attr}><polygon points=\"12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2\"/></svg>",
		'award'       => "<svg {$attr}><circle cx=\"12\" cy=\"8\" r=\"6\"/><path d=\"M15.477 12.89L17 22l-5-3-5 3 1.523-9.11\"/></svg>",
		'target'      => "<svg {$attr}><circle cx=\"12\" cy=\"12\" r=\"10\"/><circle cx=\"12\" cy=\"12\" r=\"6\"/><circle cx=\"12\" cy=\"12\" r=\"2\"/></svg>",
		'trending-up' => "<svg {$attr}><polyline points=\"23 6 13.5 15.5 8.5 10.5 1 18\"/><polyline points=\"17 6 23 6 23 12\"/></svg>",
		'globe'       => "<svg {$attr}><circle cx=\"12\" cy=\"12\" r=\"10\"/><line x1=\"2\" y1=\"12\" x2=\"22\" y2=\"12\"/><path d=\"M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z\"/></svg>",
		'settings'    => "<svg {$attr}><circle cx=\"12\" cy=\"12\" r=\"3\"/><path d=\"M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z\"/></svg>",
	];
}

/**
 * Map an emoji string to the best matching SVG icon slug.
 *
 * Used as a bridge so existing block content with emoji icons
 * automatically gets modern SVG rendering.
 */
function cb_emoji_to_icon_slug( string $emoji ): string {
	$map = [
		'📊' => 'chart',
		'📈' => 'trending-up',
		'📋' => 'clipboard',
		'📝' => 'file-text',
		'💰' => 'coins',
		'🤝' => 'handshake',
		'👥' => 'users',
		'⚡' => 'zap',
		'✓'  => 'check-circle',
		'✔'  => 'check-circle',
		'♡'  => 'heart',
		'❤'  => 'heart',
		'🔑' => 'key',
		'🛡' => 'shield-check',
		'⭐' => 'star',
		'🏆' => 'award',
		'🎯' => 'target',
		'📞' => 'phone',
		'📧' => 'mail',
		'⏰' => 'clock',
		'📅' => 'calendar',
		'🌍' => 'globe',
		'⚙'  => 'settings',
	];

	return $map[ trim( $emoji ) ] ?? '';
}

/**
 * Render an icon — prefers SVG slug, falls back to emoji-to-SVG mapping.
 *
 * @param string $icon_value  Either an SVG slug (e.g. "chart") or an emoji.
 * @return string             SVG markup or empty string.
 */
function cb_render_icon( string $icon_value ): string {
	$icons = cb_get_icon_map();
	$slug  = trim( $icon_value );

	// Direct slug match
	if ( isset( $icons[ $slug ] ) ) {
		return $icons[ $slug ];
	}

	// Emoji → slug mapping
	$mapped = cb_emoji_to_icon_slug( $slug );
	if ( $mapped && isset( $icons[ $mapped ] ) ) {
		return $icons[ $mapped ];
	}

	// No match — return empty (template can decide to hide icon area)
	return '';
}
