<?php
/**
 * Search Settings — admin page for the search results hero + copy.
 *
 * Settings → Search lets admins manage the editable Norwegian copy
 * surfaced by `[styrk_search_results]` (see search-render.php):
 *  - Eyebrow text above the heading
 *  - Heading templates (with-query / no-query)
 *  - Empty-state copy
 *  - Form placeholder + button label
 *  - Number of results per page
 *
 * Deliberately content-only — no color or typography pickers. The
 * hero's visual style (navy bg, Fraunces display, orange accent)
 * comes from the design system tokens in theme.json + style.css and
 * applies globally. Per-instance styling controls would encourage
 * brand drift; copy-only keeps the page brand-locked.
 *
 * Mirrors the structure of header-settings.php / footer-settings.php
 * so the three "global" settings pages (Header, Footer, Search) stay
 * consistent under WP's Settings menu.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_SEARCH_SETTINGS_LOADED' ) ) return;
define( 'CB_SEARCH_SETTINGS_LOADED', true );

/* ── Option key ─────────────────────────────────────────────────────────────── */
define( 'CB_SEARCH_OPTION', 'cb_search_settings' );

/**
 * Default values for search settings. The {query} token in heading
 * and empty-line templates is replaced at render time with the
 * user's actual search term (already escaped).
 */
function cb_search_defaults(): array {
	return [
		'eyebrow_text'        => 'SØKERESULTATER',
		'heading_with_query'  => 'Søkeresultater for «{query}»',
		'heading_no_query'    => 'Søk på siden',
		'hint_no_query'       => 'Skriv et søkeord over for å finne sider, ansatte eller innlegg.',
		'empty_line'          => 'Ingen treff for «{query}».',
		'empty_hint'          => 'Sjekk stavemåten eller prøv et annet søkeord.',
		'empty_back_label'    => 'gå tilbake til forsiden',
		'form_placeholder'    => 'Søk på siden…',
		'form_button'         => 'Søk',
		'posts_per_page'      => 20,
	];
}

/**
 * Return merged (saved + defaults) search settings.
 */
function cb_get_search_settings(): array {
	$saved = get_option( CB_SEARCH_OPTION, [] );
	return wp_parse_args( $saved, cb_search_defaults() );
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_search_settings_menu(): void {
	add_options_page(
		__( 'Search Settings', 'styrk-blocks' ),
		__( 'Search', 'styrk-blocks' ),
		'manage_options',
		'cb-search-settings',
		'cb_search_settings_page'
	);
}
add_action( 'admin_menu', 'cb_search_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

function cb_search_settings_init(): void {
	register_setting( 'cb_search_group', CB_SEARCH_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_search_sanitize',
		'default'           => cb_search_defaults(),
	] );

	/* ── Section: Heading & eyebrow ──────────────────────────────────────────── */
	add_settings_section(
		'cb_search_heading',
		__( 'Heading & eyebrow', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Copy shown in the navy hero band at the top of the search results page. Use {query} as a placeholder for the user\'s search term — it is replaced safely at render time.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_eyebrow_text', __( 'Eyebrow text', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'eyebrow_text', 'description' => __( 'Small all-caps label above the heading.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_heading_with_query', __( 'Heading (with query)', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'heading_with_query', 'description' => __( 'Shown when the visitor has a search term. Use {query} for the term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_heading_no_query', __( 'Heading (no query)', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'heading_no_query', 'description' => __( 'Shown when the visitor lands on /?s= with no term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_hint_no_query', __( 'Hint (no query)', 'styrk-blocks' ), 'cb_search_render_textarea_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'hint_no_query', 'description' => __( 'Helper paragraph below the heading when no term is entered yet.', 'styrk-blocks' ) ] );

	/* ── Section: Empty state ────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_empty',
		__( 'No-results state', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Copy shown when the search returns zero results. Keep it warm — visitors are mid-task.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_empty_line', __( 'Headline', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_line', 'description' => __( 'Use {query} for the searched term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_empty_hint', __( 'Hint', 'styrk-blocks' ), 'cb_search_render_textarea_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_hint', 'description' => __( 'Suggestion paragraph (without the home link — that is rendered separately).', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_empty_back_label', __( 'Back-to-home link label', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_back_label', 'description' => __( 'Visible label of the inline link back to the home page.', 'styrk-blocks' ) ] );

	/* ── Section: Search form ────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_form',
		__( 'Search form', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Strings shown inside the inline search-again form in the hero.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_form_placeholder', __( 'Input placeholder', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_form',
		[ 'key' => 'form_placeholder' ] );

	add_settings_field( 'cb_search_form_button', __( 'Button label', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_form',
		[ 'key' => 'form_button' ] );

	/* ── Section: Behaviour ──────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_behaviour',
		__( 'Behaviour', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Pagination size and other non-content options.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_posts_per_page', __( 'Results per page', 'styrk-blocks' ), 'cb_search_render_number_field', 'cb-search-settings', 'cb_search_behaviour',
		[ 'key' => 'posts_per_page', 'min' => 1, 'max' => 100, 'description' => __( 'How many hits to show per results page (1–100).', 'styrk-blocks' ) ] );
}
add_action( 'admin_init', 'cb_search_settings_init' );

/* ── Field renderers ────────────────────────────────────────────────────────── */

function cb_search_render_text_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<input type="text" id="%s" name="%s" value="%s" class="regular-text" style="max-width:520px;" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_attr( $value )
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

function cb_search_render_textarea_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<textarea id="%s" name="%s" rows="3" class="large-text" style="max-width:520px;">%s</textarea>',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_textarea( $value )
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

function cb_search_render_number_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (int) ( $settings[ $key ] ?? 0 );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';
	$min         = (int) ( $args['min'] ?? 1 );
	$max         = (int) ( $args['max'] ?? 100 );

	printf(
		'<input type="number" id="%s" name="%s" value="%d" min="%d" max="%d" step="1" style="width:90px;" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		$value,
		$min,
		$max
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

function cb_search_sanitize( $input ): array {
	$defaults  = cb_search_defaults();
	$sanitized = [];

	$text_keys = [
		'eyebrow_text', 'heading_with_query', 'heading_no_query',
		'empty_line', 'empty_back_label', 'form_placeholder', 'form_button',
	];
	foreach ( $text_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) $input[ $k ] : '';
		$clean = sanitize_text_field( wp_unslash( $raw ) );
		$sanitized[ $k ] = $clean !== '' ? $clean : $defaults[ $k ];
	}

	$textarea_keys = [ 'hint_no_query', 'empty_hint' ];
	foreach ( $textarea_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) $input[ $k ] : '';
		$clean = sanitize_textarea_field( wp_unslash( $raw ) );
		$sanitized[ $k ] = $clean !== '' ? $clean : $defaults[ $k ];
	}

	$ppp = isset( $input['posts_per_page'] ) ? (int) $input['posts_per_page'] : $defaults['posts_per_page'];
	$sanitized['posts_per_page'] = max( 1, min( 100, $ppp ) );

	return $sanitized;
}

/* ── Admin page template ────────────────────────────────────────────────────── */

function cb_search_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) return;
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Search Settings', 'styrk-blocks' ); ?></h1>
		<p class="description" style="max-width:720px;">
			<?php esc_html_e( 'These strings appear on the /?s= search results page. Visual styling (navy hero, Fraunces display heading, orange button) comes from the design system and is intentionally not editable here — keep brand consistency.', 'styrk-blocks' ); ?>
		</p>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'cb_search_group' );
			do_settings_sections( 'cb-search-settings' );
			submit_button();
			?>
		</form>
	</div>
	<?php
}

/* ── Seed defaults on first load ────────────────────────────────────────────── */

function cb_search_seed_defaults(): void {
	if ( get_option( CB_SEARCH_OPTION ) ) return;
	update_option( CB_SEARCH_OPTION, cb_search_defaults() );
}
add_action( 'admin_init', 'cb_search_seed_defaults' );
