<?php
/**
 * Footer shortcodes — dynamic footer content from Settings → Footer / Header.
 *
 * [footer_logo]         → White logo for the footer
 * [footer_description]  → Company description
 * [footer_contact]      → Address, email, phones
 * [footer_copyright]    → Copyright line
 *
 * Social links are handled by [social_links] in styrk-blocks.php.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard — see header-settings.php for the rationale.
if ( defined( 'CB_FOOTER_SHORTCODES_LOADED' ) ) return;
define( 'CB_FOOTER_SHORTCODES_LOADED', true );

/**
 * [footer_logo] — outputs the white footer logo.
 *
 * Priority: Header Settings → logo_white_id → custom_logo → theme asset fallback.
 */
function cb_footer_logo_shortcode(): string {
	$footer    = function_exists( 'cb_get_footer_settings' ) ? cb_get_footer_settings() : [];
	$header    = function_exists( 'cb_get_header_settings' ) ? cb_get_header_settings() : [];
	$site_name = get_bloginfo( 'name' );

	/* 1. White logo from FOOTER Settings (new home since v1.6.5). Falls back
	 *    to the legacy Header-Settings key for client sites that have set it
	 *    there and haven't been through the migration yet — cb_footer_migrate
	 *    _white_logo_from_header moves existing values on admin_init, but
	 *    reading both here makes the render robust regardless. */
	$white_id = (int) ( $footer['logo_white_id'] ?? 0 );
	if ( ! $white_id ) {
		$white_id = (int) ( $header['logo_white_id'] ?? 0 );
	}
	// Small helper — every branch below returns the same <a>/<img> shape,
	// wrapped in a <div> so WP's wpautop doesn't enclose the inline <a>
	// in a <p> (which was collapsing to height:0 when the inner SVG had
	// no intrinsic dimensions). The CSS on .site-footer__logo-img also
	// pins an explicit 200×64 footprint with object-fit:contain so the
	// logo renders correctly regardless of the asset's intrinsic size.
	$render_logo = function ( string $url, string $alt, bool $invert = false ) use ( $site_name ): string {
		$img_class = 'site-footer__logo-img' . ( $invert ? ' site-footer__logo-img--invert' : '' );
		return sprintf(
			'<div class="site-footer__logo"><a href="%s" class="site-footer__logo-link" aria-label="%s"><img src="%s" alt="%s" class="%s" width="200" height="64" loading="lazy" /></a></div>',
			esc_url( home_url( '/' ) ),
			esc_attr( $alt ),
			esc_url( $url ),
			esc_attr( $alt ),
			esc_attr( $img_class )
		);
	};

	if ( $white_id ) {
		$url = wp_get_attachment_image_url( $white_id, 'full' );
		if ( $url ) {
			return $render_logo( $url, $site_name );
		}
	}

	/* 2. Main logo from Header Settings (with CSS invert) */
	$main_id = (int) ( $header['logo_id'] ?? 0 );
	if ( ! $main_id ) {
		$main_id = (int) get_theme_mod( 'custom_logo', 0 );
	}
	if ( $main_id ) {
		$url = wp_get_attachment_image_url( $main_id, 'full' );
		if ( $url ) {
			return $render_logo( $url, $site_name, /* invert = */ true );
		}
	}

	/* 3. Theme asset fallback — logo-hvit.svg */
	$fallback = get_theme_file_uri( 'assets/logo-hvit.svg' );
	return $render_logo( $fallback, $site_name );
}
add_shortcode( 'footer_logo', 'cb_footer_logo_shortcode' );

/**
 * [footer_description] — outputs the company description.
 */
function cb_footer_description_shortcode(): string {
	$settings = cb_get_footer_settings();
	$desc     = $settings['description'] ?? '';

	if ( ! $desc ) {
		return '';
	}

	return '<p>' . esc_html( $desc ) . '</p>';
}
add_shortcode( 'footer_description', 'cb_footer_description_shortcode' );

/**
 * Format a 9-digit Norwegian org number as "NNN NNN NNN". Accepts any
 * mix of digits + separators; strips non-digits first. Returns an empty
 * string for anything that doesn't parse to 9 digits so the footer
 * shortcode doesn't render a malformed label.
 */
function cb_format_org_number( string $raw ): string {
	$digits = preg_replace( '/\D+/', '', $raw );
	if ( strlen( (string) $digits ) !== 9 ) return '';
	return trim( chunk_split( (string) $digits, 3, ' ' ) );
}

/**
 * [footer_contact] — outputs address, email, phone numbers, and org number.
 *
 * Order: address → email → phones → org nr. Org nr sits last in its own
 * visually muted line because it's regulatory context, not a contact
 * action — users scan phone/email first.
 */
function cb_footer_contact_shortcode(): string {
	$s    = cb_get_footer_settings();
	$html = '';

	if ( ! empty( $s['address'] ) ) {
		$lines   = array_map( 'esc_html', explode( "\n", $s['address'] ) );
		$address = implode( '<br/>', $lines );
		$html   .= '<address class="site-footer__address">' . $address . '</address>';
	}

	$contact_lines = [];
	if ( ! empty( $s['email'] ) ) {
		$contact_lines[] = '<a href="mailto:' . esc_attr( $s['email'] ) . '">'
			. esc_html( $s['email'] ) . '</a>';
	}
	if ( ! empty( $s['phone_1'] ) ) {
		$tel = preg_replace( '/\s+/', '', $s['phone_1'] );
		$contact_lines[] = '<a href="tel:+47' . esc_attr( $tel ) . '">'
			. esc_html( $s['phone_1'] ) . '</a>';
	}
	if ( ! empty( $s['phone_2'] ) ) {
		$tel = preg_replace( '/\s+/', '', $s['phone_2'] );
		$contact_lines[] = '<a href="tel:+47' . esc_attr( $tel ) . '">'
			. esc_html( $s['phone_2'] ) . '</a>';
	}

	if ( $contact_lines ) {
		$html .= '<p class="site-footer__contact-info">'
			. implode( '<br/>', $contact_lines ) . '</p>';
	}

	$org_formatted = cb_format_org_number( (string) ( $s['org_number'] ?? '' ) );
	if ( $org_formatted !== '' ) {
		$html .= sprintf(
			'<p class="site-footer__org-number">%s <span>%s</span></p>',
			esc_html__( 'Org.nr.', 'styrk-blocks' ),
			esc_html( $org_formatted )
		);
	}

	return $html;
}
add_shortcode( 'footer_contact', 'cb_footer_contact_shortcode' );

/**
 * [footer_org_number] — standalone shortcode for the org number, for sites
 * that want to place it outside the Kontakt column (e.g. inline with the
 * copyright line). Silently renders nothing when the field is unset or
 * malformed.
 */
function cb_footer_org_number_shortcode(): string {
	$s             = cb_get_footer_settings();
	$org_formatted = cb_format_org_number( (string) ( $s['org_number'] ?? '' ) );
	if ( $org_formatted === '' ) return '';
	return sprintf(
		'<span class="site-footer__org-number-inline">%s %s</span>',
		esc_html__( 'Org.nr.', 'styrk-blocks' ),
		esc_html( $org_formatted )
	);
}
add_shortcode( 'footer_org_number', 'cb_footer_org_number_shortcode' );

/**
 * [footer_social_heading] — outputs the "Følg oss" heading (editable from Settings).
 *
 * Emits an <h2> so the column heading is part of the page heading outline —
 * lets screen-reader users navigate to the footer columns via heading nav.
 */
function cb_footer_social_heading_shortcode(): string {
	$settings = cb_get_footer_settings();
	$heading  = $settings['social_heading'] ?? 'Følg oss';

	if ( ! $heading ) {
		return '';
	}

	return '<h2 class="wp-block-heading site-footer__col-heading">' . esc_html( $heading ) . '</h2>';
}
add_shortcode( 'footer_social_heading', 'cb_footer_social_heading_shortcode' );

/**
 * [footer_copyright] — outputs the copyright text.
 */
function cb_footer_copyright_shortcode(): string {
	$settings  = cb_get_footer_settings();
	$copyright = $settings['copyright'] ?? '';

	if ( ! $copyright ) {
		return '';
	}

	return '<p>' . esc_html( $copyright ) . '</p>';
}
add_shortcode( 'footer_copyright', 'cb_footer_copyright_shortcode' );

/**
 * [footer_site_name] — outputs the site name as an <h2> footer-column heading.
 *
 * Matches the Kontakt / Følg oss heading levels so the footer has a
 * consistent <h2>-per-column heading outline.
 */
function cb_footer_site_name_shortcode(): string {
	return '<h2 class="wp-block-heading site-footer__col-heading">' . esc_html( get_bloginfo( 'name' ) ) . '</h2>';
}
add_shortcode( 'footer_site_name', 'cb_footer_site_name_shortcode' );

/**
 * [footer_credits] — outputs the credits line.
 * Editable from Settings → Footer → Bottom Bar → Credits.
 */
function cb_footer_credits_shortcode(): string {
	$settings = cb_get_footer_settings();
	$credits  = $settings['credits'] ?? '';
	if ( ! $credits ) return '';
	return '<p class="site-footer__credits">' . esc_html( $credits ) . '</p>';
}
add_shortcode( 'footer_credits', 'cb_footer_credits_shortcode' );

/**
 * [footer_legal] — outputs the inline legal-links nav (privacy, terms, etc).
 *
 * Reads the raw Settings → Footer → Legal Links textarea (one "Label|URL"
 * per line). Returns an empty string when no links are configured — the
 * bottom bar just collapses to copyright + credits on sites that don't
 * need a legal-nav row.
 *
 * URL handling:
 * - Relative URLs ("/personvern") are preserved as-is.
 * - Absolute URLs (https://…) are validated via esc_url so javascript:
 *   or data: schemes can't slip through.
 *
 * a11y: wraps the links in <nav aria-label="Juridisk"> so the links
 * register as a landmark for screen-reader users, distinct from the main
 * footer content.
 */
function cb_footer_legal_shortcode(): string {
	$settings = cb_get_footer_settings();
	$raw      = (string) ( $settings['legal_links'] ?? '' );
	if ( $raw === '' ) return '';

	$links = [];
	foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
		$line = trim( $line );
		if ( $line === '' ) continue;
		// Split on the first pipe only — labels may contain pipes, URLs
		// normally do not.
		$parts = explode( '|', $line, 2 );
		if ( count( $parts ) !== 2 ) continue;

		$label = trim( $parts[0] );
		$url   = trim( $parts[1] );
		if ( $label === '' || $url === '' ) continue;

		$links[] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $url ),
			esc_html( $label )
		);
	}

	if ( ! $links ) return '';

	return '<nav class="site-footer__legal" aria-label="' . esc_attr__( 'Juridisk', 'styrk-blocks' ) . '">'
		. implode( '', $links )
		. '</nav>';
}
add_shortcode( 'footer_legal', 'cb_footer_legal_shortcode' );
