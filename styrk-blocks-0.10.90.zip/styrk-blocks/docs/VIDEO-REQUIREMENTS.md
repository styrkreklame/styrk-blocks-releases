# Video Requirements & Optimization

How to prepare video before uploading it to a Styrk Blocks site. Web video is
heavy — an un-optimized phone/4K export is 30–200 MB and will tank LCP and
mobile data budgets. Every video that goes into a block **must** be optimized
first, and the right settings depend on **how the video is used**.

> TL;DR — **Always MP4 / H.264, 1080p max, `yuv420p`, `+faststart`, with a
> poster image. Embedded video: aim 5–10 MB, hard cap 25 MB.** Background loops
> get _no audio_ and go smaller still. Add a WebM/VP9 sibling for extra savings.

---

## 1. Pick the use case first

The blocks fall into two groups. Encode for the group, not the file.

| Use case | Blocks | Audio? | Controls? | Behaviour | Size target |
|----------|--------|--------|-----------|-----------|-------------|
| **A — Background / decorative loop** | `hero` (bg video), `media-grid` (autoplay slot) | **No — strip it** | No | Autoplay, muted, loop, no chrome | **≤ 5 MB** (2–3 MB ideal) |
| **B — Watch video (audio / speech)** | `video-section`, `video-reels` | **Yes — keep** | Yes | Click/scroll to play, sound on | **5–10 MB** (≤ 25 MB hard cap) |

Why it matters: a muted background loop carrying a stereo AAC track is shipping
~0.5 MB of bytes no one ever hears, and browsers can't autoplay videos with
sound anyway. A testimonial film with the audio stripped is broken content.

---

## 2. Global rules (both use cases)

- **Format: MP4 with the H.264 (AVC) codec.** This is the only format every
  browser and iOS plays. It is always the primary file.
- **Resolution: 1080p max.** `1080×1920` for portrait (9:16), `1920×1080` for
  landscape (16:9). **Never upload 4K** — it's invisible quality at web sizes
  and 4× the bytes. 720p is plenty for most background loops.
- **`-pix_fmt yuv420p`** — required, or Safari/iOS shows a black frame.
- **`-movflags +faststart`** — moves the index to the front so the video
  streams (starts playing) before it has fully downloaded.
- **Frame rate: 25 or 30 fps.** Don't ship 50/60 fps to the web.
- **Always provide a poster image** (`videoPoster` / first-frame JPG). It paints
  instantly, prevents layout shift (CLS), and is the LCP element. Export it from
  ~1 s in, quality ~80, same dimensions as the video.
- **File naming: lowercase-kebab, ASCII only.** No spaces, no `å/ø/æ`. Rename
  `Hywer – Skurdalsåa.mp4` → `hywer-skurdalsaa.mp4` (æøå and spaces break some
  CDNs and URL-encoding).
- **Size budget:** embedded video 5–10 MB is the sweet spot, **25 MB is the
  absolute ceiling**. Above that, playback stutters and the page load suffers.

---

## 3. Use case A — Background / decorative loop

Hero background videos and autoplay `media-grid` slots. These exist to set a
mood behind text, so quality tolerance is high and **smaller is always better**.

Rules on top of the globals:

- **Strip the audio entirely** (`-an`). Muted autoplay needs no track.
- **Keep it short** — a 6–15 s loop that tiles seamlessly beats a 60 s clip.
- **Provide MP4 + WebM + poster.** The `hero` block has three slots for exactly
  this: `videoMp4`, `videoWebm`, `videoPoster`.
- Lean on quality-based CRF (no fixed bitrate needed) and push it harder than
  for watch video — artefacts read as "texture" behind copy.

```bash
# MP4 (H.264) — muted background loop, ~1080p
ffmpeg -i input.mov \
  -an \
  -c:v libx264 -preset slow -crf 28 -pix_fmt yuv420p \
  -movflags +faststart \
  hywer-hero.mp4

# WebM (VP9) sibling — smaller again on modern browsers
ffmpeg -i input.mov \
  -an \
  -c:v libvpx-vp9 -crf 36 -b:v 0 -row-mt 1 \
  hywer-hero.webm

# Poster (first-frame JPG)
ffmpeg -ss 1 -i input.mov -frames:v 1 -q:v 4 hywer-hero-poster.jpg
```

In the editor: upload the MP4 to `videoMp4`, the WebM to `videoWebm`, the JPG to
`videoPoster`, and turn **Autoplay** on. The block renders `muted loop playsinline`.

---

## 4. Use case B — Watch video (audio / speech)

`video-section` (single film with controls) and `video-reels` (portfolio clips).
The visitor chooses to watch and **hears the audio**, so audio fidelity and clean
motion matter — but the 5–10 MB budget still applies.

Rules on top of the globals:

- **Keep the audio.** AAC, stereo for music/ambience, **mono is fine for pure
  speech** and saves bytes. 96–128 kbps is plenty.
- **Use two-pass at a target bitrate** to land predictably in budget. CRF is
  unpredictable on high-motion outdoor footage (water, drone) and can balloon
  past 25 MB. Roughly **1700 kbps video + 96–128 kbps audio ≈ 8–9 MB for 40 s.**
- **Accessibility (WCAG):** speech/dialogue needs **captions or a transcript**.
  Put a transcript or `.vtt` caption track alongside, and write a descriptive
  `caption` / `eyebrow` so the content isn't audio-only.

```bash
# Two-pass H.264, keeps audio, lands ~8–9 MB for a ~40 s 1080p clip
ffmpeg -y -i input.mp4 -c:v libx264 -preset slow -b:v 1700k -pix_fmt yuv420p \
  -pass 1 -an -f mp4 /dev/null
ffmpeg -y -i input.mp4 -c:v libx264 -preset slow -b:v 1700k -pix_fmt yuv420p \
  -pass 2 -c:a aac -b:a 128k -movflags +faststart hywer-film.mp4

# Optional WebM/VP9 sibling (≈20–30 % smaller), two-pass at lower bitrate
ffmpeg -y -i input.mp4 -c:v libvpx-vp9 -b:v 1400k -row-mt 1 -pass 1 -an -f null /dev/null
ffmpeg -y -i input.mp4 -c:v libvpx-vp9 -b:v 1400k -row-mt 1 -pass 2 \
  -c:a libopus -b:a 96k hywer-film.webm
```

> For **pure speech** (interview, voiceover) use `-c:a aac -b:a 96k -ac 1` (mono)
> and you can usually drop the video bitrate to ~1200k — talking heads have
> little motion, so the file gets smaller with no visible loss.

`video-section` orientation: set `portrait` (9:16) for phone-shot reels,
`landscape` (16:9) for widescreen film.

---

## 5. No FFmpeg? Use HandBrake (free, GUI)

[HandBrake](https://handbrake.fr) gives the same results without the terminal:

- **Background loop (A):** preset **Web → Gmail Medium**, then Video tab → set
  **Quality RF ≈ 28**, Audio tab → **remove all tracks**, dimensions ≤ 1080p.
- **Watch video (B):** preset **Web → Vimeo YouTube HD 1080p60** → change
  framerate to 30, Video tab → **Avg Bitrate (2-Pass) ≈ 1700 kbps**, Audio tab →
  **AAC 128 kbps** (or mono for speech).
- Always tick **Web Optimized** (= `+faststart`) in the Summary tab.
- Export a poster: scrub to ~1 s, right-click the preview → save still, or grab
  it in any image tool.

---

## 6. Pre-upload checklist

- [ ] Correct use case chosen (A background vs B watch)
- [ ] MP4 / H.264, `yuv420p`, web-optimized (faststart)
- [ ] ≤ 1080p, 25/30 fps
- [ ] Background loop: **audio stripped**; Watch video: **audio kept** (mono for speech)
- [ ] File size in budget (A ≤ 5 MB · B 5–10 MB, never > 25 MB)
- [ ] Poster image exported and assigned
- [ ] WebM/VP9 sibling provided where the block accepts one (`hero`)
- [ ] Filename lowercase-kebab, ASCII (no `æøå`, no spaces)
- [ ] Watch video with speech: captions / transcript available (WCAG)
