# Editor-controlled section colors — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make per-block background/text colors the source of truth across Skotnes section blocks — set in-canvas, rendering identically in editor and frontend — by stopping the theme and dark skin from overriding them, and by filling the two real gaps (`split-section` lacks color attributes; `tjenester` is a `core/group`).

**Architecture:** The in-canvas color system already exists in styrk-blocks `HEAD` (commit `7605508`) and is deployed to Local. The blockers are CSS `!important` overrides in `skotnes-theme/style.css` (~77 decls) and `skotnes-theme/rough.css`. We demote those to non-`!important` defaults so each block's inline color wins, then add missing color attributes to `split-section` and convert `tjenester` to a block.

**Tech Stack:** WordPress block editor (React/TS), `@wordpress/scripts` build, dynamic blocks (`template.php`), Tailwind utility CSS, plain CSS theme sheets. Verification via a headless Playwright harness driving the live editor + frontend screenshots.

**Environment (Local):** Plugin = repo `HEAD` build (separate copy at `~/Local Sites/skotnes-bygg/app/public/wp-content/plugins/styrk-blocks`). Theme at `…/themes/skotnes-theme`. WP Defender **off**. Admin: `web@styrkreklame.no` / `admin`. Site: `http://localhost:10018`. Repo is canonical → build in repo, rsync `build/`+`includes/`+`styrk-blocks.php` to Local for QA.

**Deploy/QA helpers (used by multiple tasks):**
- Build + deploy plugin to Local:
  ```bash
  cd ~/Documents/nettsider/_shared/styrk-blocks && pnpm build && \
  L=~/Local\ Sites/skotnes-bygg/app/public/wp-content/plugins/styrk-blocks && \
  rsync -a --delete build/ "$L/build/" && rsync -a includes/ "$L/includes/" && rsync -a styrk-blocks.php "$L/"
  ```
- Editor color-binding check (set attrs via store, read computed style). Reuse `/tmp/verify2.mjs` (already written this session) or recreate from Task 0.
- Frontend screenshot at a width: a Playwright script using the Google Chrome binary (`/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`), `fullPage:true`, GDPR bar removed.

---

## Task 0: Verification harness (reusable)

**Files:**
- Create: `/tmp/wp-editor-check.mjs` (throwaway test tool, not committed)

- [ ] **Step 1: Write the harness** — logs in, opens a post editor, sets attributes on a named block via the block-editor store, reads back computed styles from the canvas iframe.

```js
import { createRequire } from 'module';
const require = createRequire('/tmp/');
const { chromium } = require('/Users/anders/.npm/_npx/e41f203b7505f1fb/node_modules/playwright/index.js');
// argv: postId, blockName, attrsJson, selectorsJson
const [postId, blockName, attrsJson, selectorsJson] = process.argv.slice(2);
const b = await chromium.launch({ executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' });
const p = await b.newPage({ viewport:{width:1440,height:1000} });
await p.goto('http://localhost:10018/wp-login.php',{waitUntil:'domcontentloaded'});
await p.fill('#user_login','Master Styrk'); await p.fill('#user_pass','admin'); await p.click('#wp-submit');
await p.waitForURL('**/wp-admin/**',{timeout:20000}).catch(()=>{});
await p.goto(`http://localhost:10018/wp-admin/post.php?post=${postId}&action=edit`,{waitUntil:'domcontentloaded'});
await p.waitForFunction(()=>window.wp&&wp.data&&wp.data.select('core/block-editor').getBlocks().length>0,{timeout:30000});
await p.waitForTimeout(2000);
const found = await p.evaluate(({blockName,attrs})=>{
  const sel=wp.data.select('core/block-editor'),dis=wp.data.dispatch('core/block-editor');
  const find=(bs)=>{for(const bl of bs){if(bl.name===blockName)return bl;const f=find(bl.innerBlocks||[]);if(f)return f;}return null;};
  const blk=find(sel.getBlocks()); if(!blk)return false; dis.updateBlockAttributes(blk.clientId,attrs); return true;
},{blockName,attrs:JSON.parse(attrsJson)});
await p.waitForTimeout(1500);
const c=p.frames().find(f=>f.name()==='editor-canvas')||p.mainFrame();
const out=await c.evaluate((sels)=>Object.fromEntries(Object.entries(sels).map(([k,s])=>{const el=document.querySelector(s);return [k, el?{color:getComputedStyle(el).color,bg:getComputedStyle(el).backgroundColor}:'NO_EL'];})),JSON.parse(selectorsJson));
console.log(JSON.stringify({found,out}));
await b.close();
```

- [ ] **Step 2: Smoke-test it** against the already-fixed employee-grid.

Run:
```bash
PW=/Users/anders/.npm/_npx/e41f203b7505f1fb/node_modules/playwright node /tmp/wp-editor-check.mjs 19 styrk-blocks/employee-grid '{"introColor":"#ff0000","cardBgColor":"#00ff00"}' '{"intro":".cb-employee-grid__intro","card":".cb-employee-card"}'
```
Expected: `{"found":true,"out":{"intro":{"color":"rgb(255, 0, 0)",…},"card":{…,"bg":"rgb(0, 255, 0)"}}}`

---

## Task 1: Theme `!important` color/bg sweep (`skotnes-theme/style.css`)

**Files:**
- Modify: `~/Local Sites/skotnes-bygg/app/public/wp-content/themes/skotnes-theme/style.css`

**Rule:** For every declaration where the property is `color`, `background`, or `background-color`, the value is a color, AND the selector targets a styrk block element (`.cb-*`, `.wp-block-styrk-blocks-*`, `.skotnes-*` that maps to a block the editor exposes a color control for) — **remove `!important`**. Keep `!important` on layout/typography (font, spacing, display, border geometry) and on truly-decorative elements with no block control (e.g. `.cb-site-header` chrome, search page). The child sheet loads after the plugin, so non-important defaults still win over the plugin's defaults.

**Already done this session (verified):** `.cb-employee-grid__heading` color, `.cb-employee-grid__intro` color, `.cb-employee-card__role` color, and the shared `.cb-feature-card,.cb-project-card,.skotnes-services-editorial__item,.cb-call-card,.cb-employee-card,.cb-faq-accordion-item,.skotnes-team-card` `background-color`+`color` group.

- [ ] **Step 1: Enumerate remaining candidates**

Run:
```bash
CT=~/Local\ Sites/skotnes-bygg/app/public/wp-content/themes/skotnes-theme/style.css
grep -nE "(color|background)[^;:]*:[^;]*!important" "$CT"
```
Expected: ~70 lines. Triage each into KEEP (chrome/layout) vs DEMOTE (block-controllable color).

- [ ] **Step 2: For each block with an editor color control, demote its color/bg `!important`**, one block-group of rules at a time. Blocks/selectors to cover (cross-reference each block's `block.json` color attributes in `src/blocks/<name>/block.json`):
  - `feature-cards`: `.cb-feature-card` text/icon/heading colors, eyebrow.
  - `split-section`: `.wp-block-styrk-blocks-split-section` eyebrow/heading/body/button colors (5 `!important` rules found).
  - `process`, `stats-row`, `cta-section`, `testimonials`, `logo-strip`, `page-header`, `featured-projects`: section/eyebrow/heading/body color `!important`.
  - `services-editorial` items: title/body/num/cta color (theme classes `.skotnes-services-editorial__*`).
  Demote pattern (example): `color: var(--wp--preset--color--primary) !important;` → `color: var(--wp--preset--color--primary);` with a comment `/* default only — block control overrides */`.

- [ ] **Step 3: Verify each demoted block with the harness** (Task 0). For a block on a known page, set a distinctive color and assert the computed style matches. Example (split-section eyebrow, once attrs exist — see Task 3):
```bash
PW=… node /tmp/wp-editor-check.mjs <postId> styrk-blocks/split-section '{"eyebrowTextColor":"#ff0000"}' '{"eyebrow":".wp-block-styrk-blocks-split-section .cb-eyebrow"}'
```
Expected: eyebrow `color: rgb(255, 0, 0)`.

- [ ] **Step 4: Frontend regression check** — screenshot home + om-oss + tjenester at 1440/768/375; confirm the default (no per-block color set) Skotnes look is unchanged. NOTE: frontend still forced dark by `rough.css` until Task 2.

- [ ] **Step 5: Commit** (theme repo, wherever skotnes-theme is tracked)
```bash
git add skotnes-theme/style.css && git commit -m "fix(theme): demote !important color/bg rules so block color controls win"
```

---

## Task 2: Demote `rough.css` to texture + type only

**Files:**
- Modify: `~/Local Sites/skotnes-bygg/app/public/wp-content/themes/skotnes-theme/rough.css`

**Keep:** font-family (Oswald/Space Mono/Archivo), `text-transform`, `letter-spacing`, `line-height`, `border-radius:0`, stamped box-shadows, grayscale photo `filter`, grain `::after`. **Remove:** every rule that sets `background`/`background-color`/`color` (the `html[data-dark="on"]` surface flips, `.has-*-background-color` overrides, card/section/text color forcing, the straggler-flip block).

- [ ] **Step 1: Strip the color/background rules**, leaving the type/texture rules. The dark look now comes from per-block colors set on the pages (Task 5/rebuild), not from forced overrides.

- [ ] **Step 2: Set dark page defaults in tokens, not overrides** — so the page canvas is dark by default without `!important`: in `skotnes-theme/theme.json` set `styles.color.background` to `#0B0C0E` and `styles.color.text` to `#E9E7E1` (replaces `#FAFBFC`/`#0F1B2D`). This makes the editor canvas and frontend default dark, while block colors override per-section.

- [ ] **Step 3: Verify** — frontend home at 1440: sections that have a per-block dark/accent color show it; the page canvas is dark. Editor canvas now matches (dark) because theme.json drives it.

- [ ] **Step 4: Set a per-card color in the editor and confirm it now shows on the FRONTEND** (the gap this task closes):
```bash
# In editor set a card bg, save, then screenshot frontend and confirm the card renders that color.
```

- [ ] **Step 5: Commit**
```bash
git add skotnes-theme/rough.css skotnes-theme/theme.json && git commit -m "refactor(theme): rough.css = texture+type only; dark canvas via theme.json tokens"
```

---

## Task 3: `split-section` — add section background + text color attributes (styrk-blocks)

**Files:**
- Modify: `src/blocks/split-section/block.json` (add attributes)
- Modify: `src/blocks/split-section/edit.tsx` (in-canvas chips + apply styles)
- Modify: `src/blocks/split-section/template.php` (emit inline styles)
- Reference pattern: `src/blocks/feature-cards/{block.json,edit.tsx,template.php}` and `src/components/{SectionBgChip,InlineColorChip}.tsx`

- [ ] **Step 1: Add attributes to `block.json`** (alongside existing `eyebrowBgColor` etc.):
```json
"sectionBgColor": { "type": "string", "default": "" },
"sectionTextColor": { "type": "string", "default": "" },
"headingColor": { "type": "string", "default": "" },
"bodyColor": { "type": "string", "default": "" }
```

- [ ] **Step 2: In `edit.tsx`, render `SectionBgChip` and apply colors** — mirror `feature-cards/edit.tsx:156-164`:
```tsx
import SectionBgChip from '../../components/SectionBgChip';
// inside the section blockProps style:
backgroundColor: attributes.sectionBgColor || undefined,
color: attributes.sectionTextColor || undefined,
// near top of the section JSX:
<SectionBgChip value={ attributes.sectionBgColor ?? '' }
  onChange={ ( v ) => setAttributes( { sectionBgColor: v } ) }
  themeColors={ themeColors } />
// heading/body RichText get style={ attributes.headingColor ? { color: attributes.headingColor } : undefined } etc.
```

- [ ] **Step 3: In `template.php`, emit the inline styles** — mirror `feature-cards/template.php` / `employee-grid/template.php:116-119,149,156`:
```php
$section_bg   = sanitize_hex_color( (string) ( $attributes['sectionBgColor']   ?? '' ) );
$section_text = sanitize_hex_color( (string) ( $attributes['sectionTextColor'] ?? '' ) );
$heading_color= sanitize_hex_color( (string) ( $attributes['headingColor']     ?? '' ) );
$body_color   = sanitize_hex_color( (string) ( $attributes['bodyColor']        ?? '' ) );
// build a style string for the section wrapper; gate each with if(...)
```
**WARNING:** `sanitize_hex_color()` returns empty for non-hex. The palette returns hex, so OK — but confirm `SectionBgChip` emits hex (it does via `ColorPalette` over the hex palette).

- [ ] **Step 4: Build + deploy** (use the helper command in the header).

- [ ] **Step 5: Verify with harness**
```bash
PW=… node /tmp/wp-editor-check.mjs <splitSectionPostId> styrk-blocks/split-section '{"sectionBgColor":"#123456","headingColor":"#ff0000"}' '{"sec":".wp-block-styrk-blocks-split-section","h":".wp-block-styrk-blocks-split-section h2"}'
```
Expected: section bg `rgb(18, 52, 86)`, heading `rgb(255, 0, 0)`.

- [ ] **Step 6: Deprecation check** — split-section has `save.tsx`; if `save` markup changed, add a deprecation in `index.ts` so existing instances don't invalidate. If only `template.php` (dynamic render) changed and `save` is unchanged, no deprecation needed. Verify by opening an existing split-section instance — no "block contains unexpected content" error.

- [ ] **Step 7: Commit**
```bash
git add src/blocks/split-section build/blocks/split-section && git commit -m "feat(split-section): in-canvas section background + text color controls"
```

---

## Task 4: Convert `tjenester` (services) from `core/group` to a block

**Files:**
- Decision: either (a) promote the existing theme block `skotnes-theme/services-editorial` into a styrk-blocks block, or (b) add an "editorial/numbered" layout variant to `feature-cards`. **Recommend (a)** — it already has the 01–05 + icon + "Les mer →" structure; port it to `src/blocks/services-editorial/` in styrk-blocks with `SectionBgChip` + per-item color, then deregister the theme version.
- Create: `src/blocks/services-editorial/{block.json,edit.tsx,save.tsx,template.php,index.ts,style.css}`
- Modify: `skotnes-theme/functions.php` (remove `register_block_type('skotnes-theme/services-editorial')` once ported)
- Rebuild page: tjenester (post id from `wp post list --post_type=page` — the page whose content has the services group)

- [ ] **Step 1: Scaffold the block** from `feature-cards` as the closest sibling (eyebrow+heading+items). Add per-item fields: `num` (auto-index), `icon`, `heading`, `body`, `url`, plus `bgColor`/`textColor`; section `sectionBgColor`/`sectionTextColor`.
- [ ] **Step 2: Port the render** from the theme's `services-editorial` render callback (in `skotnes-theme/functions.php` around the `register_block_type('skotnes-theme/services-editorial')` block) into `template.php`, emitting sanitized inline colors.
- [ ] **Step 3: Build + deploy.**
- [ ] **Step 4: Rebuild the tjenester page** in the editor: replace the `core/group` services section with the new `styrk-blocks/services-editorial` block; re-enter the 5 services + colors. Save.
- [ ] **Step 5: Deregister the theme block** in `functions.php` (so there's one canonical block). Verify the page still renders.
- [ ] **Step 6: Verify** front + editor at 1440/768/375; harness check on a color attr.
- [ ] **Step 7: Commit** (plugin + theme).

---

## Self-Review

- **Spec coverage:** Task 1 ↔ theme `!important` sweep; Task 2 ↔ rough.css demotion; Task 3 ↔ split-section missing attrs; Task 4 ↔ tjenester group→block. All four revised work items covered. ✓
- **Placeholders:** Step bodies contain concrete commands/code; CSS sweep is mechanical and enumerated by grep (the ~70 lines are discoverable, not inventable — listing each verbatim would go stale). ✓
- **Type/name consistency:** split-section attr names (`sectionBgColor`, `sectionTextColor`, `headingColor`, `bodyColor`) used identically in block.json, edit.tsx, template.php. ✓
- **Risk:** Tasks 1–2 are site-wide CSS — each has a frontend regression screenshot step. Task 3/4 touch `save.tsx` blocks — deprecation check included (Task 3 Step 6).
