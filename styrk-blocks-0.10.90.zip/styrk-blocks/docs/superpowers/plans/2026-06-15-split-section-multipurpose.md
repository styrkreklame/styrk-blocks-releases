# Split Section → multipurpose (per-side Text / Image / Employee)

Date: 2026-06-15 · Repo: `_shared/styrk-blocks` · Block: `split-section` (edit.tsx ~1152 lines)

## Goal
Today the block is a fixed media-side (image/video/employee + stat-badge) + text-side, swapped by `imageRight`. Make EACH of the two sides independently selectable as **Text**, **Image** (incl. video), or **Employee** card — supporting text+text, text+image, image+image, employee+text, etc.

## Data model
Add `leftType` / `rightType` ∈ {`text`,`image`,`employee`} (default `''` = legacy).
Per-side content is namespaced so two of the same type can coexist:
- text:     `{ eyebrow, heading, body, ctas, *Align, *Color }`
- image:    `{ mediaUrl, mediaAlt, mediaType, video urls, imageRadius }`
- employee: `{ employeeId, statBadge*, employeeRoleColor }`

New attributes: `leftContent` (object), `rightContent` (object). Existing flat attrs stay for back-compat.

## Back-compat (critical — must not break existing splits)
When `leftType`/`rightType` are empty (all legacy content), derive:
- media side type = `employee` if `mediaSource==='employee'` else `image`
- text side type  = `text`
- order from `imageRight` → which side is left/right
- map the existing flat attrs into the matching side's content
Render path for legacy = exactly today's markup. A one-time editor migration copies flat attrs → `leftContent`/`rightContent` + sets the types (deprecation entry so saved markup validates).

## Files
- `block.json` — add `leftType`,`rightType`,`leftContent`,`rightContent`.
- `edit.tsx` — extract the existing text-panel and media-panel JSX into `<TextPanel>` / `<ImagePanel>` / `<EmployeePanel>` components taking a side's content + onChange; render side A and side B by their type; add a per-side type switcher (segmented Text/Bilde/Ansatt) in each column's in-canvas chrome.
- `template.php` — replace the fixed media-side/text-side branches with a `render_side($type, $content)` helper called twice (left, right); keep the legacy derivation up top.
- `style.css` — generalise `.cb-split-image-wrap` / text column rules to work on either side.
- `deprecations` — add a v1 deprecation so existing saved blocks validate post-migration.

## QA (mandatory before merge)
- php -l, tsc, eslint (baseline), build.
- Browser: open 3+ existing split sections (image+text, employee+text, video) → render unchanged. Then build each new combo (text+text, image+image, employee+image) and verify editor+frontend parity at 1440/768/375 + XXL.
- Needs the Playwright restart (or manual eyeballing) — do NOT merge unverified.

## Estimate
Large: ~300–500 lines across edit.tsx + template.php + CSS + a deprecation. Highest regression risk of the batch → its own branch + full visual QA.
