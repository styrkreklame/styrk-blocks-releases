# In-editor control kit — shared, branded in-block controls

**Date:** 2026-06-10
**Branch:** fix/hero-slider-editor-consistency
**Status:** approved (kit + 2 reference blocks, dashed-stipple +label buttons)

## Problem

Every block hand-rolls its own in-block (WP editor) controls. 14 blocks use raw
`@wordpress/components` `<Button>` → WP-admin blue leaks in ("Set portrait video",
"Add link"). 11+ blocks define their own inline dashed panel. No shared buttons /
panel / editor stylesheet → inconsistent, unbranded, misaligned, hover-less.
The user wants ONE branded control system reused by every block
([[in-block-controls-design-system]]).

## The kit (src/components + styles in src/style.css)

1. **`EditorPanel`** — the stippled control container. Props: `children`,
   `layout?: 'row' | 'stack'`, `className?`. Stops pointer events +
   `contentEditable={false}` so clicks don't drag/select the block.
2. **`ActionButton`** — dashed-stipple outline, circled `+` glyph, descriptive
   label, branded (navy default, accent on hover/focus). Props: `label`,
   `onClick`, `icon?`, `disabled?`. Replaces raw `<Button variant="secondary">`.
3. **`MediaSetButton`** — wraps `MediaUploadCheck`/`MediaUpload`, renders an
   `ActionButton` with the "+ Set …/Insert …" convention; optional remove
   (TrashIcon). Props: `allowedTypes`, `value`, `onSelect`, `label`,
   `replaceLabel?`, `hasValue?`, `onRemove?`, `removeLabel?`.

### Styles (`src/style.css`, `.cb-ed-*` prefix; loaded in the editor like the
existing `InlineColorChip`/`cb-hero__accent-toggle` styles)
- `.cb-ed-panel` (+ `--stack`) — dashed border, radius 10, subtle bg, gap.
- `.cb-ed-label` — uppercase 11px field label.
- `.cb-ed-action` (+ `__icon`, `__label`) — dashed outline button; uses
  `var(--wp--preset--color--primary/accent, …)` so it auto-brands per site
  (Hywer navy #00354F / plomme #AA6486); real hover + focus-visible states.
- Kill WP-admin blue inside our panels.

### Docs
- `design-system/editor-controls.md` — the canonical convention so it stays
  consistent across this and future projects.

## Reference conversions (lock the look before mass rollout)

- **split-section** — replace the blue "Set portrait/landscape video" `<Button>`s
  with `MediaSetButton`; wrap `renderVideoOptions`/`renderImageOptions` in
  `EditorPanel`.
- **services-selector** — move the controls cluster into `EditorPanel`.

After sign-off, roll the same kit across the remaining ~12 blocks (own pass).

## Backwards compatibility

Editor-only chrome; no attribute/schema/`save()` changes, no frontend impact.
Purely swaps how controls are rendered in `edit.tsx`.

## QA

`tsc --noEmit`, `pnpm build`, deploy to Hywer local, verify in the WP editor:
branded dashed `+` buttons (no WP blue), consistent panels, hover/focus visible,
fields aligned; both reference blocks identical in feel.
