# Editor-controlled section colors (in-canvas) for Skotnes sections

**Date:** 2026-06-09
**Status:** Approved design — ready for implementation planning
**Repo:** `styrk-blocks` (shared plugin) · **Test site:** Local `skotnes-bygg` (`http://localhost:10018`, separate plugin copy — not symlinked)

## Problem

The Skotnes homepage/about/contact sections are built as nested `core/group`
blocks (`.skotnes-section`, `.skotnes-values`, `.skotnes-certs-section`) and two
theme-only dynamic blocks (`skotnes-theme/services-editorial`,
`skotnes-theme/contact-section`). These have **no editor-visible background/text
controls**, and the **editor canvas does not reflect the frontend look** (the
canvas background is `theme.json` `styles.color.background: #FAFBFC`; the rough
dark skin is enqueued frontend-only). The client redesign ("tougher / darker")
is currently delivered by `skotnes-theme/rough.css`, which forces dark
backgrounds globally with `!important`.

## Goal

Section background + text colors are the **source of truth, edited in-canvas**
(not the right-hand Inspector sidebar). What an editor sets renders identically
in the editor and on the frontend. Colors live on **reusable styrk-blocks
blocks** (brand-agnostic, token-driven), so every client site benefits; the
Skotnes pages are rebuilt to use them with their existing content preserved.

## Key decisions (from brainstorming)

1. **Per-block colors = source of truth**, controls rendered **in-canvas inside
   the block**, never in the Inspector sidebar.
2. **Adopt + extend existing styrk-blocks blocks**, do not build duplicates.
   `feature-cards` already implements the target pattern: a `SectionBgChip`
   (section bg/text) + per-card `bgColor`/`textColor` chips, with an explicit
   "In-canvas controls (no right-pane panel)" design. `contact-section` already
   exists in styrk-blocks with full color attributes.
3. **Demote `rough.css` to texture + type only** — keep Oswald/Space Mono,
   zero-radius, stamped shadows, grayscale photos, grain; **remove all
   background/text forcing**. Backgrounds come from per-block colors.
4. **Dark palette** added so in-canvas chips can pick dark: `ink #16181C`,
   `slab #0B0C0E`, `panel #14161A`, alongside existing navy/blue/surface/white.
   Lives in the token layer (theme.json palette / styrk-blocks tokens),
   brand-agnostic.
5. **Migration = manual page rebuild** in the editor (no migration script). Old
   `core/group` / theme-block sections are retired as pages are rebuilt.
6. **Phased**: ship one block end-to-end first (Values), then replicate.
7. In-canvas color UX = **swatch strip on select**: palette swatches + a
   light/dark "A" text toggle, on the section and on each card (the existing
   `SectionBgChip` pattern, extended with the text toggle where missing).

## Architecture

```
theme.json / token layer
  palette: navy, blue, surface, white  +  ink, slab, panel   (new dark swatches)
        │
styrk-blocks blocks (dynamic, render=template.php)
  feature-cards   — eyebrow + heading + card items
                    section: sectionBgColor / (new) sectionTextColor
                    per card: bgColor / textColor  (already present)
                    (new) layout variant: "plain" (no-icon, text-only)  ← Values
        │  edit.tsx renders SectionBgChip + per-card chips IN-CANVAS
        │  template.php renders identical markup on frontend
        ▼
Skotnes pages (rebuilt manually)
  om-oss: Values section  = feature-cards instance, per-card colors set in canvas
        │
rough.css (demoted): type + shadows + grain + grayscale ONLY — no bg/text rules
editor canvas: rough.css + Bunny fonts enqueued + data-skin/data-dark on root
        → backend matches frontend
```

### Source of truth & parity
Because color is a real block attribute rendered by the same logic in `edit.tsx`
and `template.php`, editor and frontend agree by construction. The remaining
parity gap (type/texture) is closed by enqueuing the demoted `rough.css` + fonts
into the editor canvas and stamping `data-skin="rough"` / `data-dark` on the
canvas document root.

## Slice 1 — Values via `feature-cards` (the proven pattern)

**Scope of slice 1 (this is what the first implementation plan covers):**

1. **Token/palette:** add `ink`/`slab`/`panel` dark swatches to the palette
   surfaced by the in-canvas color chips (brand-agnostic).
2. **`feature-cards` extension:** add a **"plain" card layout variant**
   (no icon, text-only: heading + body), selectable via the existing in-canvas
   layout switch. Add a section-level **text-color** control to `SectionBgChip`
   if not already present, and a per-card light/dark text toggle.
3. **Demote `rough.css`:** remove background/text `!important` rules; keep type,
   zero-radius, stamped shadows, grayscale, grain. (Global change — see Risks.)
4. **Editor parity:** enqueue demoted `rough.css` + Bunny fonts into the editor
   canvas; set `data-skin`/`data-dark` on the canvas root.
5. **Rebuild the om-oss Values section** as a `feature-cards` instance: eyebrow
   "Verdier" (or current), heading, 4 value cards (Lokal / Tilgjengelig /
   Kunnskapsrik / Løsningsorientert) with their per-card colors chosen in-canvas
   (mix of dark + accent for the "rugged dark" look).
6. **QA:** editor screenshot == frontend screenshot at 1440 / 768 / 375; colors
   set in canvas render identically; no console errors; `tsc`/lint clean; build
   committed; synced to the Local copy for browser verification.

**Done = ** editing a Value card's color in the editor visibly changes it in the
canvas and matches the frontend exactly, with no sidebar panel involved.

## Slices 2–4 (sketched; separate spec/plan each, after slice 1 review)

- **Certifications:** extend `feature-cards` with an optional per-card **image**
  (logo) — or a thin `cert-grid` if image handling is too divergent — then
  rebuild the certs section.
- **Services (editorial):** add a **numbered/editorial layout variant** to
  `feature-cards` (01–05 index, icon, title, body, "Les mer →" link), or port
  `skotnes-theme/services-editorial` into styrk-blocks. Rebuild the services
  section.
- **Contact:** switch Skotnes to the existing styrk-blocks `contact-section`;
  verify/convert its color controls to in-canvas; wire the employee picker +
  Forminator form. Retire `skotnes-theme/contact-section`.

## Risks & mitigations

- **Demoting `rough.css` is global**: un-rebuilt sections lose their forced dark
  bg and revert to saved (lighter) colors until migrated. Mitigation: rebuild
  the visible homepage sections in the same pass, or temporarily set a dark
  default section color where needed; accept transient lightness on inner pages
  during the phased rollout.
- **`feature-cards` has both `save.tsx` and `template.php`** (dynamic render
  with stored save markup). Editing attributes/markup risks block-validation
  errors on existing instances. Mitigation: follow the block's existing
  save/deprecation conventions; Skotnes instances are newly inserted so no
  legacy validation burden for slice 1.
- **Editor-canvas attribute stamping** (`data-skin` on the iframe root) needs a
  small editor JS hook, not just an enqueue. Mitigation: handle in the plan.
- **Dev/test sync**: repo is canonical; the Local plugin is a separate copy.
  Build in repo → rsync `build/` (+ `src/`) to the Local plugin for browser QA.
- **Shared plugin**: keep all additions brand-agnostic (tokens, no Skotnes
  hardcoding) per the styrk-blocks-shared rule.

## Out of scope

- Migration scripts (manual rebuild chosen).
- Touching other client sites' content.
- Redesigning blocks beyond the color/in-canvas/parity goal.

---

## REVISED understanding (2026-06-09, after debugging the live site)

Debugging the "options don't work" report on Local changed the picture materially:

- **The in-canvas color system already EXISTS** in styrk-blocks at repo `HEAD`
  (commit `7605508 "feat(blocks): background + text color options on every
  section block"`). Local was running v0.10.18 (pre-feature); HEAD is now
  **deployed to Local**. `feature-cards`, `employee-grid`, etc. already expose
  `SectionBgChip` + per-card `InlineColorChip` controls (no sidebar).
- **The blocks were never the problem — the theme was.** `skotnes-theme/style.css`
  forces colours on the block elements with `!important` (~77 declarations),
  overriding the blocks' inline colour attributes in BOTH editor canvas and
  frontend. Confirmed: setting `introColor`/`cardBgColor` updated the attributes
  but a theme `!important` rule kept the rendered colour fixed.
- **`rough.css` (the dark skin) does the same on the frontend** — it forces
  dark backgrounds/text with `!important`, so per-block colours can't win there.

### Real work items (supersede the slices above)

1. **Theme `!important` colour/bg sweep** (`skotnes-theme/style.css`): demote the
   ~77 forced colour/background declarations on block selectors to **defaults**
   (no `!important`), so each block's inline colour wins while the Skotnes look
   stays the default. Pattern proven: child sheet loads after the plugin, so a
   non-important default still beats the plugin default. **Done so far (verified):**
   `.cb-employee-grid__heading/__intro` colour, `.cb-employee-card__role` colour,
   and the shared `.cb-feature-card,.cb-project-card,…,.cb-employee-card` group
   `background/color` (unblocks per-card bg on 7 card blocks in the editor).
2. **Demote `rough.css`** to texture + type only (Oswald/Space Mono, zero-radius,
   stamped shadows, grayscale, grain) — remove all background/text `!important`
   forcing so per-block colours render on the frontend too.
3. **`split-section`** (styrk-blocks): genuinely lacks section background + body/
   heading text-colour attributes (only has `eyebrow*`, button, `employeeRoleColor`).
   Add `sectionBgColor` + text-colour attributes + in-canvas controls, matching
   the `feature-cards` pattern.
4. **`tjenester`/services**: currently a `core/group` (+ `services-editorial`
   theme block). Convert to a proper styrk-blocks block (per original plan) and
   rebuild the page.

### Local environment state (for whoever implements)

- Plugin on Local = repo `HEAD` build (ahead of prod 0.10.18; includes hero-slider).
- **WP Defender deactivated** on Local (was blocking logins); keep off for dev.
- Admin login: `web@styrkreklame.no` / `admin` (temporary dev password).
- Repo is canonical; Local plugin is a **separate copy** — build in repo, rsync
  `build/` + `includes/` + `styrk-blocks.php` to the Local plugin for browser QA.
- The theme (`skotnes-theme`) lives only on the Local site (site-specific child);
  ensure edits there are tracked wherever that theme is version-controlled.

### Sequencing note

Items 1 + 2 are the highest-impact and lowest-new-code (CSS demotion) but are
site-wide and regression-prone → verify the frontend at 1440/768/375 after each.
Items 3 + 4 are additive block work. Recommend order: 1 → 2 (verify dark look
still holds via per-block colours) → 3 → 4.
