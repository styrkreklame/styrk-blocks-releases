# Video Section — parity with sibling section blocks

**Date:** 2026-06-10
**Branch:** fix/hero-slider-editor-consistency
**Status:** approved scope (full parity), implementing

## Problem

`styrk-blocks/video-section` is an architectural outlier. Every other section
block (services-editorial, split-section, feature-cards, testimonials, …) uses
the shared `SectionHeader` (eyebrow + heading + ingress) and the standard
in-canvas chrome (SectionBgChip + section text chip). Video Section instead has
a bespoke `eyebrow` + `caption` only — **no heading, no ingress/explaining
text**, and no section-colour options. Reported as "controllers/options are
busted" + "need additional explaining text/ingress".

## Goal

Bring Video Section to full parity, **additively** (it's a dynamic block — render
via `template.php`, no `save()`, so no deprecation needed). Preserve the existing
dark "video shell" look for current instances.

## Changes

### block.json — add attributes (all additive, neutral defaults)
`heading` "", `subtext` "" (the ingress), `eyebrowAlign` "left",
`headingAlign` "left", `subtextAlign` "left", `eyebrowRadius` 50,
`headingColor` "", `subtextColor` "", `sectionBgColor` "", `sectionTextColor` "".
Keep all existing attrs (`eyebrow`, `caption`, `eyebrowBgColor`,
`eyebrowTextColor`, `videoId`, `videoUrl`, `orientation`, `autoplay`).

### edit.tsx
- Adopt `<SectionHeader {...useSectionHeaderProps(attributes, setAttributes)} subtext … />`.
- Add `<SectionBgChip>` (corner) + an `InlineColorChip` for section text.
- `blockProps` style: `backgroundColor: sectionBgColor || 'var(--wp--preset--color--primary,#00486A)'`,
  `color: sectionTextColor || '#fff'`, `position: relative`.
- Keep the orientation segmented control + autoplay toggle + video uploader + caption.

### template.php
- Render the standard `cb-section-header` markup (eyebrow + heading + subtext),
  mirroring services-editorial, escaped (`wp_kses_post`).
- Add `sectionBgColor` / `sectionTextColor` overrides to the wrapper (only when set).
- Keep the video element + caption unchanged.

### style.css
- Add `color: #fff;` default to `.cb-block-video` so the new heading/ingress are
  legible on the dark shell (eyebrow/caption already carry their own colours).

## Backwards compatibility

Existing instances (eyebrow + caption only) render identically. Only cosmetic
deltas: eyebrow corner radius 9999px → 50px (still a pill at 8px tall), and the
section gains a default white text colour (harmless — prior text elements set
their own colours). No schema removals/renames; no `save()` change.

## QA

`tsc --noEmit`, `pnpm build`, then browser-verify on Hywer (localhost:10003):
insert Video Section → confirm eyebrow/heading/ingress edit, section colour
chips work, video controls intact, caption intact, dark shell preserved by default.
