# Services Selector → directory of direct links, live from the mega menu

**Date:** 2026-06-10
**Branch:** fix/hero-slider-editor-consistency
**Status:** approved (directory layout + live-from-menu), implementing

## Problem (Hywer)

The `styrk-blocks/services-selector` block ("Produktene & tjenestene våre"):
1. Has **manually typed** categories/links that are already **stale** vs the real
   mega menu (shows "Vannveiskomponenter" etc., which aren't in the menu).
2. Uses **tab-toggling chips** — clicking a category opens a panel, then you click
   a sub-link to navigate. The client wants **one click straight to the page**.

The mega menu is a `wp_navigation` post (Hywer = ID 4), already parsed by
react-header via `rh_blocks_to_links()` / `rh_resolve_nav_url()`. Structure:
top-level submenu (category, has URL) → navigation-link children (have URLs).

## Decision

- **Layout:** directory of direct links — each top-level category is a heading that
  links to its page, with its child pages listed as direct links beneath. All
  categories visible at once. No tabs, no JS toggling. Every label is one click.
- **Data source:** live from the menu. Read the `wp_navigation` post at render time
  so it always matches the mega menu.

## Changes

### includes/nav-menu.php (new, always loaded)
Shared helpers so services-selector doesn't depend on react-header having rendered:
- `cb_nav_resolve_url($attrs)` — render-time URL resolution (mirrors `rh_resolve_nav_url`).
- `cb_nav_blocks_to_tree($blocks)` — recursive label/href/children (mirrors `rh_blocks_to_links`).
- `cb_nav_get_tree($nav_ref = 0)` — find the nav post (pinned ref, else newest
  non-empty published `wp_navigation`) and return the tree.
Require in `styrk-blocks.php`. (react-header keeps its own guarded copies — untouched.)

### block.json
- Add `navigationRef` (number, 0 = auto-detect newest non-empty menu).
- Add `includeTopLevel` (string, "" = all; comma-separated top-level labels to show,
  e.g. "Tjenester, Produkt").
- Keep `heading`, `sectionBgColor`, `align`, and `items` (render fallback only).
- **Remove `viewScript`** — directory needs no JS. Delete `view.tsx` (+ its CSS reliance on tabs).

### template.php
- Build `$columns`: from `cb_nav_get_tree(navigationRef)` filtered by `includeTopLevel`;
  if the tree is empty, fall back to legacy `items` (also rendered as a directory).
- Render `.cb-services-selector__directory` → per-category `.__col` with a heading
  link (`__col-head`, → category URL) + child `.__col-link` direct links. Escaped
  (`esc_url`, `esc_html`). No tablist/tabpanel/hidden panels.

### edit.tsx (menu-driven, in-canvas)
- Keep heading (RichText) + BG chip.
- Controls cluster: navigation picker (SelectControl from `getEntityRecords('postType','wp_navigation')`,
  "Auto" = 0) + `includeTopLevel` TextControl.
- Preview: fetch the selected nav, `parse()` its content with `@wordpress/blocks`,
  walk submenus/links, render the same directory read-only so admins see it reflect
  the menu. Drop the manual chip/panel editor.

### style.css
- Replace tab/panel styles usage with a responsive directory grid
  (`__directory`, `__col`, `__col-head`, `__col-link`). Keep the arrow affordance.

## Backwards compatibility

Dynamic block (no `save()`), so no deprecation. New attrs default neutral. Existing
instances: with a menu present they render the live directory (desired on Hywer);
with no menu they fall back to their saved `items`, now shown as a directory of
direct links (still an improvement, no data loss). `items` retained in schema.

## QA

`tsc --noEmit`, `pnpm build`, deploy to Hywer local, browser-verify: directory
reflects menu (Tjenester/Produkt + children), every label is a direct link, heading
+ BG editable, picker + include-filter work; check frontend render + a published page.
