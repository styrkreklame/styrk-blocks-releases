# Styrk Blocks

A WordPress plugin that ships ~17 custom Gutenberg blocks, two CPTs
(`employee`, `social_link`), admin settings pages for header + footer
branding, footer shortcodes, a WebP auto-converter, and a WCAG contrast
helper.

Intended to be distributed across multiple client sites as a shared
"template" engine — brand colors, copy, and imagery vary per site; the
block catalog and admin UX are shared.

---

## Install (client site)

1. Upload the plugin zip via **Plugins → Add New → Upload Plugin**.
2. Activate.
3. Visit **Settings → Header** and **Settings → Footer** to set brand logo, contact info, social links.
4. If using the companion theme, activate it after the plugin. Otherwise, drag the `styrk-blocks/react-header` block + footer shortcodes into your theme's header/footer template parts once via the Site Editor.

That's it. No build step on the client side — `build/` is shipped pre-compiled.

---

## How updates work

The plugin uses a **self-hosted update channel** backed by a single
public JSON manifest + a zip per version. Every client site pings the
manifest URL (no auth, no token) and shows the standard WordPress
"Update now" badge in **Plugins** when a newer version is available —
within ~12 hours of a publish, or instantly via *Check for updates*.

- Manifest (default): `https://raw.githubusercontent.com/styrkreklame/styrk-blocks-releases/main/manifest.json`
  Overridable per-site by defining `CB_UPDATE_MANIFEST_URL` in `wp-config.php`.
- Wiring: [`includes/updater.php`](includes/updater.php) (uses
  yahnis-elsts/plugin-update-checker in JSON-metadata mode — no GitHub
  API, no PAT).
- Release flow: [`CONTRIBUTING.md`](CONTRIBUTING.md) and
  [`scripts/release-publish.js`](scripts/release-publish.js).
  `pnpm run release:publish` builds the zip, writes `manifest.json`,
  tags + pushes, and rsyncs both files to the public host (target
  configured via `STYRK_UPDATE_SSH_TARGET` env var).

**Client content is never wiped on update.** All blocks are *dynamic* —
they save only their attributes, and `template.php` re-renders fresh on
every page load. See `CONTRIBUTING.md` for the full list of safe vs. unsafe
changes.

---

## Dev setup

Requirements: Node 18+, pnpm 10.x, PHP 8.1+.

```bash
pnpm install
pnpm build          # one-off build
pnpm start          # watch mode for development
```

Build output lands in `build/` and is committed to Git (no CI required —
`git pull` on the server is the deploy). `styrk-blocks.php` registers
blocks from `build/blocks/*`, not `src/`.

---

## Directory map

```
styrk-blocks.php          ← plugin entry, CPT registration, block registration
includes/                  ← admin pages, shortcodes, icons, WebP converter,
                             a11y helpers, updater wiring
src/blocks/<block>/        ← block sources (edit.tsx, template.php, block.json)
src/components/            ← shared React components (MultiCtaRow, SectionHeader…)
src/style.css              ← shared Tailwind-compiled styles
types/wordpress.d.ts       ← ambient TS shims for @wordpress/* packages
build/                     ← compiled output (shipped to clients)
scripts/copy-templates.js  ← postbuild: copies template.php into build/blocks/
```

---

## Adding a new block

1. Copy `src/blocks/<existing-block>/` to `src/blocks/<new-block>/`.
2. Edit `block.json` — change `name`, `title`, define attributes (all with `default`).
3. Edit `edit.tsx` — the editor UI.
4. Edit `template.php` — the frontend render.
5. Add `src/blocks/<new-block>/index.ts` with a `registerBlockType` call.
6. `pnpm build`. Verify `build/blocks/<new-block>/` exists.
7. Commit, update CHANGELOG, tag release. See `CONTRIBUTING.md`.

---

## Preparing media (video)

Video blocks (`hero` bg video, `video-section`, `video-reels`, `media-grid`)
need optimized source files. **Read [`docs/VIDEO-REQUIREMENTS.md`](docs/VIDEO-REQUIREMENTS.md)**
before uploading — it gives exact specs and ffmpeg/HandBrake recipes per use
case (muted background loops vs. watch-video with audio/speech).

---

## For AI assistants working on this plugin

- **Dynamic blocks only.** Never convert a block to static `save.tsx` — it breaks client content.
- **Additive schema changes only.** Never rename or remove block attributes. See `CONTRIBUTING.md` for the enforced rules.
- **Attribute shape migrations** use the one-shot `useEffect` pattern — example: `src/blocks/hero/edit.tsx` migrating legacy single-CTA fields into `ctas[]`.
- **Escape everything** in `template.php`: `esc_html` / `esc_attr` / `esc_url` / `wp_kses*`. Inline styles must run through `esc_attr`.
- **Theme colors** come from `theme.json` via CSS custom properties like `var(--wp--preset--color--primary, #00486A)`. Always include a hex fallback.
- **WCAG contrast** for any user-picked bg + text pair: use `cb_best_contrast_text( $bg, $preferred, 4.5 )` from `includes/a11y-color.php`.
- **Build output is the source of truth at runtime.** Editing `build/` directly will be overwritten on next `pnpm build`. Always edit `src/`.
- Project-wide conventions live in `public/CLAUDE.md`.

---

## Support / ownership

Built and maintained by **Styrk Reklame AS**. Client sites get updates via
the self-hosted channel — no action needed from the client beyond clicking
"Update" in **Plugins**.
