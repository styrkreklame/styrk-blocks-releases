<?php
/**
 * Shared WP-navigation reader.
 *
 * Lets any block render content that mirrors the site's block-based navigation
 * (the "mega menu") — a `wp_navigation` post built from core/navigation-submenu
 * + core/navigation-link blocks. react-header has its own guarded `rh_*` copies
 * of this logic; these `cb_nav_*` helpers are always loaded so blocks that may
 * render without the header present (e.g. services-selector) can reuse it.
 *
 * @package styrk-blocks
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_nav_resolve_url' ) ) {
	/**
	 * Resolve a nav item's URL at render time rather than trusting the URL the
	 * admin froze into the navigation block — pages get renamed/reparented and
	 * the stored string goes stale (404s). Prefer the live permalink when the
	 * page-picker attrs (id + kind + type) are present; fall back to the stored
	 * URL for custom links.
	 *
	 * @param array $attrs Navigation block attributes.
	 * @return string Resolved URL (or '#').
	 */
	function cb_nav_resolve_url( array $attrs ): string {
		$id   = (int) ( $attrs['id'] ?? 0 );
		$kind = (string) ( $attrs['kind'] ?? '' );
		$type = (string) ( $attrs['type'] ?? '' );
		$url  = (string) ( $attrs['url'] ?? '' );

		if ( $id > 0 && 'post-type' === $kind ) {
			$permalink = get_permalink( $id );
			if ( $permalink ) {
				return (string) $permalink;
			}
		}
		if ( $id > 0 && 'taxonomy' === $kind && '' !== $type ) {
			$term_link = get_term_link( $id, $type );
			if ( ! is_wp_error( $term_link ) && $term_link ) {
				return (string) $term_link;
			}
		}
		return '' !== $url ? $url : '#';
	}
}

if ( ! function_exists( 'cb_nav_blocks_to_tree' ) ) {
	/**
	 * Recursively extract { label, href, children } from parsed navigation
	 * blocks.
	 *
	 * @param array $blocks Parsed blocks (from parse_blocks()).
	 * @return array<int, array{label:string,href:string,children:array}>
	 */
	function cb_nav_blocks_to_tree( array $blocks ): array {
		$items = [];
		foreach ( $blocks as $block ) {
			$name  = $block['blockName'] ?? '';
			$attrs = is_array( $block['attrs'] ?? null ) ? $block['attrs'] : [];

			if ( 'core/navigation-link' === $name || 'core/navigation-submenu' === $name ) {
				$label = (string) ( $attrs['label'] ?? '' );
				if ( '' === $label ) {
					continue;
				}
				$items[] = [
					'label'    => $label,
					'href'     => cb_nav_resolve_url( $attrs ),
					'children' => cb_nav_blocks_to_tree( $block['innerBlocks'] ?? [] ),
				];
			}
		}
		return $items;
	}
}

if ( ! function_exists( 'cb_nav_get_tree' ) ) {
	/**
	 * Return the navigation tree for a `wp_navigation` post.
	 *
	 * @param int $nav_ref Explicit wp_navigation post ID, or 0 to auto-detect
	 *                     the newest published nav post that yields links.
	 * @return array<int, array{label:string,href:string,children:array}>
	 */
	function cb_nav_get_tree( int $nav_ref = 0 ): array {
		if ( $nav_ref > 0 ) {
			$pinned = get_posts(
				[
					'post_type'      => 'wp_navigation',
					'post_status'    => 'publish',
					'posts_per_page' => 1,
					'p'              => $nav_ref,
				]
			);
			if ( ! empty( $pinned ) ) {
				return cb_nav_blocks_to_tree( parse_blocks( $pinned[0]->post_content ) );
			}
			return [];
		}

		// Auto-detect: newest published nav post that actually yields links
		// (skips the empty placeholder nav posts WP creates on template edits).
		$candidates = get_posts(
			[
				'post_type'      => 'wp_navigation',
				'post_status'    => 'publish',
				'posts_per_page' => -1,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			]
		);
		foreach ( $candidates as $candidate ) {
			$tree = cb_nav_blocks_to_tree( parse_blocks( $candidate->post_content ) );
			if ( ! empty( $tree ) ) {
				return $tree;
			}
		}
		return [];
	}
}
