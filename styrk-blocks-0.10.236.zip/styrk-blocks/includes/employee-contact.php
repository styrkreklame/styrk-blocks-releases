<?php
/**
 * Employee card contacts: phone / e-mail cleanup and the icon-link row.
 *
 * The icon row (employee-grid `contactStyle: icons`) replaces the text list
 * with large tel: / mailto: / LinkedIn icon links. Each link names its target
 * for assistive tech and reveals the number or address for sighted users on
 * hover and keyboard focus; on touch a tap simply calls or writes.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_employee_phone_display' ) ) {
	/**
	 * Phone as typed, minus stray separators at either end ("… 236 |").
	 *
	 * @param string $phone Raw meta value.
	 * @return string
	 */
	function cb_employee_phone_display( string $phone ): string {
		return trim( $phone, " \t\n\r\0\x0B|/,;:-" );
	}
}

if ( ! function_exists( 'cb_employee_tel_href' ) ) {
	/**
	 * `tel:` URL: digits only, a leading + kept.
	 *
	 * @param string $phone Raw meta value.
	 * @return string '' when there are no digits.
	 */
	function cb_employee_tel_href( string $phone ): string {
		$digits = (string) preg_replace( '/\D+/', '', $phone );
		if ( '' === $digits ) {
			return '';
		}
		$plus = str_starts_with( ltrim( cb_employee_phone_display( $phone ) ), '+' ) ? '+' : '';
		return 'tel:' . $plus . $digits;
	}
}

if ( ! function_exists( 'cb_employee_contact_icons_html' ) ) {
	/**
	 * The icon-link row.
	 *
	 * @param string $phone    Phone meta.
	 * @param string $email    E-mail meta.
	 * @param string $linkedin LinkedIn URL.
	 * @param string $name     Employee name (for accessible names).
	 * @return string HTML, or '' when there is nothing to show.
	 */
	function cb_employee_contact_icons_html( string $phone, string $email, string $linkedin, string $name ): string {
		$name  = wp_strip_all_tags( $name );
		$links = [];

		$tel = cb_employee_tel_href( $phone );
		if ( '' !== $tel ) {
			$shown   = cb_employee_phone_display( $phone );
			$links[] = [
				'href'   => $tel,
				'label'  => sprintf( 'Ring %s: %s', $name, $shown ),
				'reveal' => $shown,
				'icon'   => '<path d="M222.37 158.46l-47.11-21.11-.13-.06a16 16 0 0 0-15.17 1.4 8.12 8.12 0 0 0-.75.56L134.87 160c-15.42-7.49-31.34-23.29-38.83-38.51l20.78-24.71c.2-.25.39-.5.57-.77a16 16 0 0 0 1.32-15.06v-.12L97.54 33.64a16 16 0 0 0-16.62-9.52A56.26 56.26 0 0 0 32 80c0 79.4 64.6 144 144 144a56.26 56.26 0 0 0 55.88-48.92 16 16 0 0 0-9.51-16.62Z"/>',
				'ext'    => false,
			];
		}
		$email = trim( $email );
		if ( '' !== $email && is_email( $email ) ) {
			$links[] = [
				'href'   => 'mailto:' . $email,
				'label'  => sprintf( 'Send e-post til %s: %s', $name, $email ),
				'reveal' => $email,
				'icon'   => '<path d="M224 48H32a8 8 0 0 0-8 8v136a16 16 0 0 0 16 16h176a16 16 0 0 0 16-16V56a8 8 0 0 0-8-8Zm-20.57 16L128 133.15 52.57 64ZM216 192H40V74.19l82.59 75.71a8 8 0 0 0 10.82 0L216 74.19V192Z"/>',
				'ext'    => false,
			];
		}
		if ( '' !== $linkedin ) {
			$links[] = [
				'href'   => $linkedin,
				'label'  => sprintf( '%s på LinkedIn', $name ),
				'reveal' => 'LinkedIn',
				'icon'   => '<path d="M216 24H40a16 16 0 0 0-16 16v176a16 16 0 0 0 16 16h176a16 16 0 0 0 16-16V40a16 16 0 0 0-16-16ZM96 176a8 8 0 0 1-16 0v-64a8 8 0 0 1 16 0Zm-8-84a12 12 0 1 1 12-12 12 12 0 0 1-12 12Zm96 84a8 8 0 0 1-16 0v-36a20 20 0 0 0-40 0v36a8 8 0 0 1-16 0v-64a8 8 0 0 1 15.79-1.78A36 36 0 0 1 184 140Z"/>',
				'ext'    => true,
			];
		}
		if ( ! $links ) {
			return '';
		}

		$h = '<div class="cb-employee-icon-links">';
		foreach ( $links as $l ) {
			$h .= sprintf(
				'<a class="cb-employee-icon-link" href="%1$s" aria-label="%2$s"%3$s><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" fill="currentColor" viewBox="0 0 256 256" aria-hidden="true" focusable="false">%4$s</svg><span class="cb-employee-icon-link__reveal" aria-hidden="true">%5$s</span></a>',
				esc_url( $l['href'], [ 'tel', 'mailto', 'http', 'https' ] ),
				esc_attr( $l['label'] ),
				$l['ext'] ? ' target="_blank" rel="noopener noreferrer"' : '',
				$l['icon'],
				esc_html( $l['reveal'] )
			);
		}
		return $h . '</div>';
	}
}
