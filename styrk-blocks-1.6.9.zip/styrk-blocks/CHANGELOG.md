# Changelog

All notable changes to this plugin are documented here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/). This plugin
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [Unreleased]

---

## [1.6.9] - 2026-04-24

- fix(react-header): pick most-recent nav post, skip stale empties

---

## [1.6.8] - 2026-04-24

- fix(react-header): build hierarchical nav fallback instead of flat dump

---

## [1.6.7] - 2026-04-24

- fix(footer-logo): render at 200×64 regardless of SVG intrinsic dims

---

## [1.6.6] - 2026-04-24

- docs(claude): align CLAUDE.md with official brand book palette

---

## [1.6.5] - 2026-04-24

- fix(footer-logo): move white-logo setting to Footer Settings + fallback

---

## [1.6.4] - 2026-04-24

- fix(footer): align to header — match max-width + side padding

---

## [1.6.3] - 2026-04-24

- fix(a11y): employee-grid — split card into semantic button + sibling links

---

## [1.6.2] - 2026-04-24

- fix(a11y): clear WAVE-reported errors + video alerts on every page

---

## [1.6.1] - 2026-04-23

- fix(design-system): retune --surface from iced-teal to warm off-white

---

## [1.6.0] — 2026-04-23

### Changed
- **Global footer redesigned end-to-end against the design system.**
  - Palette: was `color: --cb-secondary` (teal on navy — **1.9:1**,
    a WCAG AA failure). Now: headings white (9.9:1 AAA), body
    `rgba(255,255,255,0.85)` (6.7:1 AA), muted bottom-bar
    `rgba(255,255,255,0.70)` (5.8:1 AA). All three verified ≥ 4.5:1
    against the navy primary.
  - Typography: documented eyebrow spec for column headings (14px
    Inter 600, 0.14em tracking, UPPERCASE) — was 18px 700 0.08em.
    Body 16px 1.65 line-height; bottom bar 14px 1.5.
  - Content width: `max-w-site-md` (1200px) — was 1280px (off-token).
  - Focus ring on every interactive element: 2px
    `var(--wp--preset--color--accent)` at 3px offset (design-system
    spec). Previously invisible to keyboard nav.
  - Link hover: underline appears at 2px thickness, 4px offset, no
    colour change (matches design-system CTA spec). Previously
    swapped colour to `--cb-surface`, breaking consistency.
  - `prefers-reduced-motion: reduce` killswitch on the entire footer
    subtree. Zero motion-respect previously.
  - Minimum 44×44 px tap targets on all links and social circles
    (logo link, legal nav, social buttons).

### Added
- **`[footer_legal]` shortcode + Settings → Footer → Legal Links
  field.** Admin enters one `Label|URL` per line (e.g.
  `Personvern|/personvern`); shortcode renders an inline `<nav
  aria-label="Juridisk">` list with hairline `·` separators between
  items. Empty setting collapses the row — sites without legal
  links keep their existing two-slot bottom bar.
- **Semantic heading hierarchy in the footer.** Column labels are
  now `<h2>` elements (site-name, Kontakt, Følg oss), so screen
  readers can navigate the footer via heading shortcuts, not just
  landmark nav. Updated shortcodes `[footer_site_name]` /
  `[footer_social_heading]` + hardcoded "Kontakt" in
  `styrk-theme/parts/footer.html`.
- **Focus-ring + reduced-motion killswitch on social circles** in
  the companion theme (previously invisible to keyboard users).

### Fixed
- **Specificity conflict between plugin and theme CSS.**
  `styrk-theme/style.css` carried a duplicated copy of the footer
  stylesheet that fought the plugin's rules on source order.
  Removed from theme — plugin's `src/style.css` is now the single
  source of truth. Theme keeps only the social-icon chrome and the
  `wp:site-logo` fallback invert.
- **WP `:where(.is-layout-flow) > * { margin-block: 0 }` was
  zeroing column-heading bottom margins.** Plugin selector raised
  to `.site-footer h2.site-footer__col-heading` (0,2,1) so the
  20px gap to the first line in each column survives.

### Companion theme
- **`styrk-theme` 1.2.0 → 1.3.0.** Footer template-part uses
  semantic `<h2>` column heading and adds `[footer_legal]`
  placeholder in the bottom bar. Client sites see the usual
  "Update Styrk Theme" admin notice after the plugin refreshes.

---

## [1.5.0] — 2026-04-23

### Fixed (design-system conformance — audit round 2)

- **`hero` block** — English placeholder copy ("We craft bold digital
  experiences." / "A senior team of designers and engineers…") replaced
  with neutral Norwegian bokmål defaults. Plugin ships as a reusable
  shell, so the defaults are generic enough to fit any vertical.
  Also: CTA button arrow was the same inline Phosphor-filled 256×256
  SVG we replaced in rich-text-section — now uses
  `cb_render_icon('arrow-right')` at 18×18.
- **`feature-cards`** — `addItem()` no longer seeds a `★` emoji on new
  cards. The design system reserves the star glyph for testimonial
  ratings; new items now default to an empty icon so the editor
  prompts a catalog pick directly.
- **`testimonial`** — `.cb-block-testimonial` section background had a
  `linear-gradient(180deg, var(--cb-surface) 0%, #fff 100%)`, which
  violates the "no gradients on backgrounds" rule (stat numbers are
  the one documented exception). Now uses solid
  `var(--wp--preset--color--surface, …)` which preserves the
  alternating-section rhythm.
- **`react-header`** — six inline `transition: …` styles in `view.tsx`
  were not respecting `prefers-reduced-motion`. Added a CSS killswitch
  in `src/style.css` that zeroes `transition` and `animation` for
  everything inside `.site-header-react` / `.react-header-live-wrapper`
  under the reduce-motion media query. Also: admin-picked header
  `bg_color + text_color` pair now routes through
  `cb_best_contrast_text($bg, $preferred, 4.5)` in `render.php` so a
  bad colour choice in Settings → Header can't ship unreadable
  navigation to every page.

### Clean on audit (no changes)

- `cta-section`, `employee-card` (Phosphor-filled contact icons at
  20×20 are a documented exception in `design-system/README.md`, not
  a deviation), `employee-grid`, `split-section`, `faq-accordion`,
  `stats-row`, `page-header`.

---

## [1.4.1] - 2026-04-23

- fix(ci): configure git identity once for all release-workflow steps

---

## [1.4.0] — 2026-04-23

### Added
- **Canonical design system at `/design-system/`** — single source of
  truth for palette, typography, spacing, iconography, motion, and
  content conventions. Contains `README.md`, `SKILL.md` (invokable as
  `/styrk-blocks-design`), `colors_and_type.css` (every token as a
  CSS custom property), asset references, HTML specimens, and JSX
  ui-kit components. Not shipped to client sites (`/design-system`
  excluded via `.distignore`).
- **Plugin-root `CLAUDE.md`** — tells Claude sessions to load the
  design system before any design/UI/copy work and enumerates the
  non-negotiable rules so the guidance survives across sessions.
- **Three new Feather-style icons** in the catalog: `arrow-right`,
  `upload`, `film`. Registered in both `IconPicker.tsx` (editor) and
  `includes/icons.php` (PHP render via `cb_render_icon`). Catalog
  count 27 → 30.
- **`IconRenderer` now accepts an optional `size` prop** (default 24).
  Lets callers override the 24×24 default without hand-rolling SVGs.

### Changed
- **Tailwind config palette fallbacks re-aligned to brand hexes.**
  `bg-primary` / `text-accent` / `surface` / `muted` had been
  resolving to Tailwind's stock slate / indigo / slate-50 defaults
  when `theme.json` hadn't loaded (static previews, editor pre-init).
  Now fallbacks are the actual brand hexes (`#00486A`, `#0084AF`,
  `#F5833C`, `#f0f7fa`, `#d6eef5`).

### Fixed (design-system conformance audit)
- **`rich-text-section` container widths.** Outer container was
  `max-w-site` (1440px); now uses the purpose-built `max-w-screen-rts`
  (1024px). Body prose was `max-w-[780px]`; now `max-w-prose` (720px /
  ≈64ch). Matches the documented reading-shell cap.
- **`rich-text-section` CTA arrow** replaced an inline Phosphor-filled
  256×256 SVG with `cb_render_icon('arrow-right')` at 18×18.
- **`rich-text-section` Inspector copy.** "Link N" panels → "CTA N"
  (they render as filled buttons, not text links). "Section Settings"
  → "Button styling" (the panel only contained button-radius).
- **`logo-strip` WCAG AA** — eyebrow `bg+text` pair now routed through
  `cb_best_contrast_text($bg, $preferred, 4.5)` so editor-picked
  colour combinations can't produce unreadable pills.
- **`media-grid`** — empty-slot background `#1a1a2e` (off-palette) →
  `var(--wp--preset--color--primary, #00486A)`. Active-slot focus
  ring `3px solid #5c60f5` (off-palette purple, wrong thickness) →
  `2px solid var(--wp--preset--color--accent, #F5833C)` with 3px
  offset, matching the documented focus-ring spec. Inline `UploadIcon`
  / `VideoIcon` React components → catalog `upload` / `film`.
- **`video-section`** editor preview background `#0f172a` (Tailwind
  slate-900) → `var(--wp--preset--color--primary, #00486A)`.
- **`contact-section`** Inspector hint text switched from an inline
  `color: '#757575'` to the standard `.components-base-control__help`
  class so it inherits WP's Gutenberg chrome muted-text colour.
- **`call-card`** phone glyph + hint chevron replaced with
  `cb_render_icon('phone')` at 48px and `cb_render_icon('arrow-right')`
  at 14px respectively (editor side uses `IconRenderer` with the new
  `size` prop). Drops two duplicated inline SVGs.

---

## [1.3.8] - 2026-04-21

- fix(drag): stop Gutenberg from sticking parent block at scale 0.24 / opacity 0.9 after fast card drag

---

## [1.3.7] - 2026-04-21

- fix(ci): add workflow_dispatch trigger to release workflow

---

## [1.3.6] — 2026-04-21

### Fixed
- **Eyebrow text/background color pickers were empty on sites whose
  theme.json has no `color.palette`.** SectionHeader's `<ColorPalette>`
  was passing `disableCustomColors` *and* relying on `useSetting('color
  .palette')` for the swatch list — if the palette was empty (default
  on a fresh theme), the panel rendered just a "Clear" button with no
  way to set a colour. Removed `disableCustomColors` so the standard
  WP custom-colour picker is always available, and theme-palette
  swatches still appear when present.

- **User-authored hero (and any first block) was silently hidden on
  every inner page** by the bundled styrk-theme. The theme's
  `templates/page.html` auto-injected a `<div class="cb-page-hero">`
  wrapper containing only `wp:post-title`, AND its stylesheet had a
  rule `.cb-page-hero ~ main … .cb-hero:first-child { display: none
  !important }`. So pages /services, /contact, etc. always rendered
  the theme's stripped-down title bar instead of whatever block the
  editor showed at the top. Removed both the auto-injection and the
  `display: none` rule — the user's first block (hero, page-header, or
  anything else) now renders as authored. Companion theme bumped to
  v1.2.0; the plugin's existing companion-theme installer detects the
  version delta and prompts to update on each client site.

- **Cards stayed visually collapsed (opacity 0.4, dashed outline)
  forever after a fast drag that released outside the iframe.** The
  v1.3.5 fix to the drop-commit bug removed the iframe-document
  pointerup listener entirely — which closed the commit hole but
  reopened a stuck-state hole: if the pointer left the iframe before
  release, neither React's bubble-phase handler nor the outer-document
  capture-phase handler ever fired, so `dragRef.current` and
  `dragIndex` state stayed set indefinitely. The hook now binds
  pointerup/pointercancel to the iframe document in BUBBLE phase
  (after React commits), restoring the safety-net reset without
  pre-empting the commit. Verified end-to-end: long-press + drag
  reorders the array, AND a release outside the card resets opacity
  to 1.

### Added
- **`.github/workflows/ci.yml` — GitHub Actions pipeline.** Required
  status check before any merge to main. Runs `php -l` on every
  shipped `.php` file (would have caught the v1.3.4 fatal), then
  `tsc --noEmit`, `eslint`, `stylelint`, and `pnpm build`, and
  finally fails if `build/` differs from what's committed (i.e.
  someone forgot to rebuild). Set the branch protection rule on
  GitHub once: Settings → Branches → main → Require status checks →
  select "ci / lint-and-build".

---

## [1.3.5] — 2026-04-20

### Fixed
- **v1.3.4 was unactivatable (fatal parse error) on any site that
  tried to install it.** The v1.3.3 regex that removed the
  `/* one-time patch */ add_action( 'init', ... }, 99 );` block from
  `styrk-blocks.php` only matched the opening half — it stopped at the
  first `}, 99 );` inside the self-destruct code's *string* literal
  (`"}, 99 );\n"`), leaving the tail (`\n", $s ); if ( $e !== false )
  { ... }, 99 );`) orphan and unparseable. Every v1.3.4 zip had a PHP
  parse error at `styrk-blocks.php` line 845. Removed the dangling
  tail, verified `php -l` clean, shipping v1.3.5 with the corrected
  file.

---

## [1.3.4] — 2026-04-20

### Changed
- **Update channel rewritten to use a JSON manifest, no GitHub API.**
  `includes/updater.php` used to point PUC at the private GitHub repo
  and ask every client site to set `CB_UPDATE_AUTH_TOKEN` to a personal
  access token. That was a deal-breaker for distribution — every new
  customer install would otherwise nag in wp-admin with GitHub 404s.
  The new config is a single public URL (default
  `https://raw.githubusercontent.com/styrkreklame/styrk-blocks-releases/main/manifest.json`) that
  PUC reads on each check; the manifest points at the zip download URL.
  No tokens anywhere. Source stays in the existing private GitHub repo.

### Added
- `scripts/write-manifest.js` — emits `release/manifest.json` from the
  current plugin header + CHANGELOG section.
- `scripts/release-publish.js` — rewritten. Now builds zip, writes
  manifest, tags + pushes, and (optionally) rsyncs zip + manifest to
  the public host via `STYRK_UPDATE_SSH_TARGET`. If that env var is
  unset, it stops after the local build and prints the two files to
  upload manually.

### Removed
- `CB_UPDATE_REPO`, `CB_UPDATE_AUTH_TOKEN`, `CB_UPDATE_BRANCH` constants
  — replaced by the single `CB_UPDATE_MANIFEST_URL`. Client sites that
  were previously setting the old constants can remove them from
  `wp-config.php`; they are no-ops now.

---

## [1.3.3] — 2026-04-20

### Removed
- **Malicious `init`-hook patch block in `styrk-blocks.php`.** A
  `/* one-time patch */` block was overwriting
  `src/blocks/feature-cards/edit.tsx` with a base64-encoded copy of
  the buggy overlay version on *every* WordPress request, then trying
  to self-remove. The self-removal regex searched for `}, 99 );\n`,
  but `styrk-blocks.php` uses CRLF line endings (`}, 99 );\r\n`), so
  `strpos` never found the pattern and the block re-ran on every init.
  That's what was silently reverting the source file every ~4 seconds
  during development and will have been firing on the live site too.
  Block removed; reverter confirmed dead (20-second write-and-wait
  test — file stays intact).

---

## [1.3.2] — 2026-04-20

### Fixed
- **Drag-and-drop reorder broken in v1.3.1.** The iframe-doc `pointerup`
  capture-phase listener (added in v1.3.1 to fix the parent-block drag
  bug) was nulling `dragRef.current` via `hardReset` *before* React's
  bubble-phase `handlePointerUp` could read it. `wasDrag` was always
  `false` at commit time, so the reorder never persisted. The hook
  now binds `pointerup` / `pointercancel` / `visibilitychange` to the
  outer document only (their original behaviour); only `dragstart`
  binds to both the outer and the editor-canvas iframe document, since
  that's the only listener that needs to defend against Gutenberg's
  parent `draggable=true` block wrapper.

---

## [1.3.1] — 2026-04-20

### Fixed
- **`feature-cards` editor regression** — clicking a card heading or
  body in the Gutenberg editor again focuses the correct RichText field
  (v1.2.0 re-introduced the editability bug by putting an absolute
  `position: absolute; inset: 0; z-index: 5` overlay over the whole
  card that caught every pointer event). Pointer handlers are back on
  the `<li>` itself (v1.1.9 pattern); the visible drag-dots badge is
  the explicit, immediate drag trigger via `[data-drag-handle]`.
- **Parent-block drag triggered by fast card flick** — a quick
  pointerdown-plus-drag on a card used to start an HTML5 drag of the
  entire Feature Cards block, because the `useDragSort` `dragstart`
  capture listener was bound only to the outer document, and the
  Gutenberg editor canvas runs in an iframe whose events don't bubble
  to the parent. The hook now also binds to the editor-canvas iframe
  document and matches both descendant and ancestor relationships
  between the event target and any `[data-drag-index]` element.

### Added
- **Editor-only reorder hint** above the Feature Cards grid —
  "Tips: hold ned i et kort eller bruk håndtaket øverst til høyre for
  å sortere kortene." — addresses the zero-affordance UX complaint
  from production.

---

## [1.3.0] — 2026-04-20

### Added
- **`page-header` block** — editorial band for inner pages ("Atelier"
  direction). Light `surface` background, Fraunces display serif title
  at 104 px, teal hairline rule under the title, Inter subtitle, and an
  auto-generated breadcrumb with orange `•` separators. Reads as a
  "reading room" mood — the deliberate inversion of the homepage's
  dark marketing hero. Dynamic block (PHP render); title defaults to
  the current post title; breadcrumb walks `get_post_ancestors()`.
- **`styrk-blocks/page-header-default` block pattern** for quick
  insertion from the inserter.
- **Fraunces variable serif**, lazy-loaded from Bunny Fonts only on
  pages that render the block (and in the editor iframe so previews
  match). ~60 KB woff2, privacy-respecting CDN, no Google.
- **`body.has-page-header` class** set by the block's view script,
  used by the shared stylesheet to flip the site header's
  white-on-transparent default to navy-on-light when a page-header is
  present — prevents the existing header from going invisible against
  the new light band.

### Fixed
- **`react-header` now renders correctly on non-frontpage pages.**
  Previously the header was always `position: absolute` with a
  transparent background and white text — designed for the dark
  homepage hero. On inner pages (made light by the v1.2.0 reskin) the
  white header text was invisible and the header floated over content.
  `render.php` now detects `is_front_page()` and forces solid-navy
  mode with `position: relative` on non-frontpage pages. Frontpage
  keeps its transparent overlay for the dark hero.
- **`react-header` hidden from the block inserter** (`inserter: false`).
  The header is a global component managed via Settings → Header and
  rendered by the theme's `parts/header.html` template part; editors
  should never insert it per-page.
- **Post-title visibility + spacing reset scoped correctly.**
  `.wp-block-post-title { display: none }` is now scoped to `body.home`
  only, so inner pages show their H1 by default. The shared spacing
  reset on `.wp-site-blocks > main` now exempts `.cb-page-main` so the
  page template's own padding applies, and the selector matches the
  page-header block's wrapper class.

### Design commitments (for the page-header block)
- Palette: reuses `--cb-surface`, `--cb-primary`, `--cb-secondary`
  (teal), `--cb-accent` (orange). No off-palette colours. Teal —
  previously underused — now anchors the signature hairline rule.
- Typography: Fraunces for display title (400 weight, opsz 144 via
  font-variation-settings), Inter for body text, eyebrow, breadcrumb,
  subtitle. The font mix itself is the strongest red-thread break
  from the all-Inter homepage hero.
- Responsive: 3 breakpoints (desktop / 1024 / 640); title scales
  104 → 72 → 44 px, padding tightens, layout stays single-column.

### Notes for theme integrators
- **Do not** auto-insert the page-header block from `templates/page.html`.
  On pages that already have a hero block, the result is two stacked
  full-width bands. Instead, editors insert the Page Header block (or
  its pattern) manually at the top of each inner page, replacing the
  hero.

---

## [1.2.0] — 2026-04-20

### Added
- **Reskin v2.** New visual pass across hero, CTA section, employee card
  + grid, FAQ accordion, feature cards, rich-text section, split section,
  stats row, testimonial, and `SectionHeader`. Backed by refreshed
  Tailwind theme tokens and `style.css` base layer. Follows the design
  system + process docs merged in v1.1.9 (PRs #4, #5).
- **Companion theme source in-repo.** The Styrk Theme source now lives
  at `/styrk-theme/` inside the plugin repo and ships as a bundled
  `assets/styrk-theme.zip` on each release (installable from the
  plugin's admin notice). Bumps theme to **1.1.0** to match the reskin.

### Changed
- **`scripts/release-zip.js`** — reads companion theme from the in-repo
  `./styrk-theme/` instead of the sibling `../../themes/styrk-theme/`.
  Release output unchanged on the consumer side.
- **`.distignore`** — excludes `/styrk-theme` from the plugin zip so
  the theme source isn't double-shipped alongside `assets/styrk-theme.zip`.

### Dev workflow
- Local dev: `wp-content/themes/styrk-theme` now symlinks to
  `../plugins/styrk-blocks/styrk-theme`, so theme edits are versioned
  in the same repo + PR as the plugin.

---

## [1.1.9] — 2026-04-15

### Fixed
- **Card RichText stays editable after drag-reorder.** v1.1.8 introduced
  a regression where the dragged card could land with
  `contenteditable="false"` on its heading + body, making the text
  un-editable until the user clicked elsewhere and clicked back. Root
  cause in `useDragSort.handlePointerUp`: `stopPropagation()` was
  preventing Gutenberg's pointerup focus manager from reconciling
  RichText state, and pointer capture was being released **after**
  `commit()` triggered `setAttributes` → re-render. Fix: release
  pointer capture before commit, and drop the `stopPropagation` (keep
  `preventDefault` to suppress the synthesized click on the drop
  target).

---

## [1.1.8] — 2026-04-15

### Added
- **Long-press drag engagement** (500 ms) for card-style child items
  inside parent blocks. Drag now starts without requiring a 5 px movement
  threshold — better on touch devices.
- **Explicit drag handle support.** Any element with `[data-drag-handle]`
  engages drag immediately on pointerdown (no threshold, no long-press
  wait).
- **Editor hover affordance.** Outline on `[data-drag-index]` elements
  and an emphasised state on `[data-drag-handle]`, visible only in the
  editor.

### Changed
- **`useDragSort.ts`** — accepts three engagement triggers: movement
  ≥ 5 px, long-press ≥ 500 ms, or handle-initiated pointerdown.
- **`feature-cards/edit.tsx`** — integrates the new handle pattern,
  removes duplicated drag plumbing (~200 LOC simplification).

### Fixed
- **HTML5 `dragstart` killed globally on `[data-drag-index]`** —
  prevents Gutenberg's parent-block drag from stealing a pointer that
  started inside a child card.

---

## [1.1.7] — 2026-04-14

### Fixed
- **CTA button underline on hover now applies everywhere**, including
  Split Section's primary action. Earlier rule was losing the cascade
  to Tailwind's `.no-underline` utility on some templates; now forced
  via `!important` on the four text-decoration longhands. Uniform
  hover affordance across hero, rich-text-section, cta-section,
  split-section, and feature-cards.

---

## [1.1.6] — 2026-04-14

### Added
- **Header nav link hover / focus underline.** Desktop and mobile menu
  anchors now show a 2 px underline with 4 px offset on hover and
  keyboard focus, matching the rest of the site's link hover
  convention. Focus outline removed in favour of the underline for a
  cleaner visual.

---

## [1.1.5] — 2026-04-14

### Changed
- **Styrk Theme bumped to 1.0.2** with a proper `screenshot.png` (1200×900)
  showing the Styrk Reklame logo centered on a clean white canvas.
  Appears as the tile in **Appearance → Themes** instead of the previous
  empty checkered placeholder.
- Plugin carries the new theme bundle; sites with the "Update Styrk
  Theme" notice get the updated screenshot on next reinstall.

---

## [1.1.4] — 2026-04-14

### Fixed
- **Backward-compat for the `custom-blocks/*` namespace.** Sites that had
  saved page content before the plugin was renamed from "Custom Blocks"
  to "Styrk Blocks" were showing *"Your site doesn't include support for
  the custom-blocks/hero block"* errors because the block namespace
  changed from `custom-blocks/*` → `styrk-blocks/*`. Each block is now
  registered under BOTH names; old posts render without a DB migration,
  new posts save under the new namespace.
- Same fix also recovers footer template parts that used
  `wp:custom-blocks/react-header` markup from the pre-rename era.

### Notes
- If the plugin's *folder* on disk was renamed from `plugins/custom-blocks/`
  to `plugins/styrk-blocks/` while WP was running, WP silently drops the
  plugin from `active_plugins` because it can't find the old path. Users
  need to re-activate the plugin once via **Plugins** admin. This
  release's namespace backward-compat only kicks in once the plugin is
  active again.

---

## [1.1.3] — 2026-04-14

### Added
- **Block-level background + text color pickers** now appear in the
  WordPress sidebar for 15 blocks (everything except `react-header`,
  which has its own colour controls via Settings → Header). Users can
  pick any theme-palette colour for the block's outer container; WP
  renders the generated `has-X-background-color` / `has-X-color` classes
  via the block wrapper attributes.
- **Companion theme auto-upgrade detection.** The plugin now compares
  the bundled `styrk-theme.zip`'s version header against the theme
  installed on disk. If the bundled copy is newer, an admin notice
  prompts the user to click a single button that overwrites the on-disk
  theme with the bundled version (keeping it active if it was).
  Eliminates the stale-assets bug where updating the plugin left the
  theme files unchanged on disk.

### Changed
- Styrk Theme bumped to **1.0.1** — first version to exercise the
  auto-upgrade path. Any existing client site with theme 1.0.0 on disk
  will see the new "Update Styrk Theme" notice after this plugin update.

### Fixed
- Previously every block shipped with `supports.color: false`, which
  meant WP's color UI never rendered for our blocks. Users who saw a
  color picker when a custom block was selected were actually editing
  an *inner* core block (Row / Columns). That's now resolved — picking
  a colour in the sidebar applies to the block itself.
- The companion-theme installer used to be a one-shot: once the theme
  was on disk, subsequent plugin updates never refreshed it. Now fixed
  via the auto-upgrade notice above.

---

## [1.1.2] — 2026-04-14

### Changed
- **Companion theme** ships with neutral baseline logos:
  - `assets/logo.svg` — color version for the header
  - `assets/logo-hvit.svg` — all-white version for footers / dark
    backgrounds
- `parts/header.html` alt text neutralized to "Bedriftslogo".

### Added
- `pnpm run release:publish` — single-command release: builds the zip,
  pushes the tag, creates the GitHub release with notes pulled from
  CHANGELOG. Replaces the manual copy-paste flow.

---

## [1.1.1] — 2026-04-14

### Changed
- **All Viken Regnskap content removed from defaults, fallbacks, patterns,
  and seeders.** Plugin now ships with brand-neutral Norwegian
  placeholder copy that demonstrates each block's purpose without leaking
  another company's content. Affects:
  - `contact-section` block defaults + template fallbacks (companyName,
    address, email, phone, etc.)
  - `react-header` empty-logo fallback (now uses `bloginfo('name')` or
    "Bedriftsnavn")
  - All 12 registered block patterns in the inserter
  - Auto-seeded homepage, "Tjenester", and "Kontakt" pages
  - `cb_footer_defaults()` (description, address, email, phone,
    copyright)
  - Default social-link CPT entries (URLs blank — admin must fill in)
  - Pattern category renamed `studio-nord` → `styrk-blocks`
- **Existing installs unaffected.** Seeders use option-key guards
  (`viken_pages_v8`, `viken_homepage_v3`, etc.) — sites that have
  already run them skip the new content. Only fresh installs see the
  neutral defaults.

---

## [1.1.0] — 2026-04-14

### Added
- **Companion theme installer**: the plugin now bundles a current copy of
  the Styrk Theme zip at `assets/styrk-theme.zip` and shows an admin
  notice on every screen until the theme is installed and active.
  Single-click "Install &amp; activate" button uses WP's native
  `Theme_Upgrader` to install offline (no network round-trip needed).
  Eliminates the "I forgot to install the theme" failure mode for
  manual installs that bypass the Rocket.net template workflow.
- Notice can be dismissed per-user; activating the plugin again
  resets the dismiss flag so future versions can re-prompt.
- Release script now builds the companion theme zip as part of every
  `pnpm run release` so the bundled copy is always in sync with
  `themes/styrk-theme/`.

### Notes
- Plugin zip grew by ~140 KB to accommodate the bundled theme — still
  ~500 KB total, well under any host's upload limit.

---

## [1.0.1] — 2026-04-14

### Fixed
- **Feature Cards**: card body text was not editable in the canvas — a
  full-card invisible drag overlay was intercepting all clicks. Drag is
  now constrained to the visible handle in the top-right corner; the rest
  of the card is freely click-and-edit-able (heading + body RichText both
  responsive).
- **Feature Cards**: removed Viken-specific default content
  ("Fast delivery / Quality work / Client focused"). Block now ships with
  three blank cards so it's brand-neutral out of the box.

### Notes
- First update delivered through the self-hosted update channel — proves
  the GitHub release → plugin-update-checker → client site round-trip.


### Added
- Self-hosted update channel via `yahnis-elsts/plugin-update-checker`
  (see [`includes/updater.php`](includes/updater.php)).
- `README.md`, `CONTRIBUTING.md`, `CHANGELOG.md` documenting ship +
  release workflow and the additive-only schema rule.
- `types/wordpress.d.ts` ambient shims so TypeScript resolves
  `@wordpress/*` imports in the IDE.
- WCAG AA auto-contrast helper (`includes/a11y-color.php`) applied to
  eyebrow pills + CTA buttons across rich-text-section, split-section,
  hero, cta-section, contact-section submit + column text.
- Employee modal focus trap — Tab / Shift+Tab now cycle within the open
  dialog; Escape closes.
- Media Grid: autoplay mutex (only one video slot can autoplay at a time);
  play-button overlay on non-autoplay videos with gradient backdrop;
  optional "Border around video slots" toggle; captions moved under the
  cell so clicking caption no longer opens the media picker.

### Changed
- `feature-cards` items now carry a stable `id` for React keys during
  drag-reorder (one-shot migration backfills `id` on existing items).
- Testimonial: removed decorative `::before` on `.cb-testimonial-quote`;
  `::after` decoration repositioned under the author line.
- `styrk-blocks.php` + all `includes/*.php` now use file-level
  idempotency guards (`defined()/return` pattern) to protect against
  double-load redeclaration fatals.

### Fixed
- `call-card/template.php`: defensive escaping on inline styles and href
  (`esc_url`/`esc_attr`/`(int)`).
- Testimonial block: fallback initial-letter avatar removed (showed stray
  letter when no image was set); editor gained a "Remove avatar" action.
- Missing `align` attribute in the TypeScript `Attributes` types for
  `employee-grid`, `faq-accordion`, and `contact-section`.

### Notes
- Ships for WordPress 6.5+, PHP 8.1+. Requires a block theme for
  `parts/header.html` auto-placement of the `react-header` block;
  otherwise insert it manually via the Site Editor.

---

## [1.0.0] — 2026-04-13

Initial release by **Styrk Reklame AS**. Reference deployment: Viken
Regnskap og rådgivning AS.

### Blocks shipped
`call-card`, `contact-section`, `cta-section`, `employee-card`,
`employee-grid`, `faq-accordion`, `feature-cards`, `hero`, `logo-strip`,
`media-grid`, `react-header`, `rich-text-section`, `split-section`,
`stats-row`, `testimonial`, `video-section`.

### Platform features
- Custom post types: `employee`, `social_link`.
- Admin pages: **Settings → Header**, **Settings → Footer**.
- Footer shortcodes: `[footer_logo]`, `[footer_description]`,
  `[footer_contact]`, `[footer_copyright]`, `[social_links]`.
- WebP auto-converter for uploaded JPEG/PNG media.
- Tailwind-compiled shared stylesheet (`build/style-index.css`).
