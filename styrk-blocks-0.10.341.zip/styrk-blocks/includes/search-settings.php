<?php
/**
 * Search Settings — admin page for the search results hero + copy.
 *
 * Settings → Search lets admins manage the editable Norwegian copy
 * surfaced by `[styrk_search_results]` (see search-render.php):
 *  - Eyebrow text above the heading
 *  - Heading templates (with-query / no-query)
 *  - Empty-state copy
 *  - Form placeholder + button label
 *  - Number of results per page
 *
 * Deliberately content-only — no color or typography pickers. The
 * hero's visual style (theme colours and display font)
 * comes from the design system tokens in theme.json + style.css and
 * applies globally. Per-instance styling controls would encourage
 * brand drift; copy-only keeps the page brand-locked.
 *
 * Mirrors the structure of header-settings.php / footer-settings.php
 * so the three "global" settings pages (Header, Footer, Search) stay
 * consistent under WP's Settings menu.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_SEARCH_SETTINGS_LOADED' ) ) return;
define( 'CB_SEARCH_SETTINGS_LOADED', true );

require_once __DIR__ . '/admin-ui.php';

/* ── Option key ─────────────────────────────────────────────────────────────── */
define( 'CB_SEARCH_OPTION', 'cb_search_settings' );

/**
 * Default values for search settings. The {query} token in heading
 * and empty-line templates is replaced at render time with the
 * user's actual search term (already escaped).
 */
function cb_search_defaults(): array {
	return [
		'eyebrow_text'        => 'SØKERESULTATER',
		'heading_with_query'  => 'Søkeresultater for «{query}»',
		'heading_no_query'    => 'Søk på siden',
		'hint_no_query'       => 'Skriv et søkeord over for å finne sider, ansatte eller innlegg.',
		'empty_line'          => 'Ingen treff for «{query}».',
		'empty_hint'          => 'Sjekk stavemåten eller prøv et annet søkeord.',
		'empty_back_label'    => 'gå tilbake til forsiden',
		'form_placeholder'    => 'Søk på siden…',
		'form_button'         => 'Søk',
		'posts_per_page'      => 20,
		'radius'              => 16,
		'pill_radius'         => 999,
		'card_radius'         => 12,

	] + cb_search_default_color_slugs();
}

/**
 * Default theme-palette slugs for every search color setting. These are
 * filterable so child themes can ship sensible defaults that fit their
 * page background (e.g. Skotnes has a dark page body, so it filters in
 * 'surface' for text colors instead of the light-bg-default 'primary').
 *
 *   add_filter( 'styrk_blocks_search_default_colors', function( $defaults ) {
 *       $defaults['results_text']    = 'surface';
 *       $defaults['results_heading_color'] = 'surface';
 *       return $defaults;
 *   } );
 *
 * Plugin-side defaults assume a LIGHT page bg + a 4-slug palette
 * (primary, accent, surface, white) — the lowest common denominator
 * across our themes. Anything else is the child theme's job.
 */
function cb_search_default_color_slugs(): array {
	$defaults = [
		// Overlay (header dropdown — light card on translucent dark backdrop).
		'overlay_panel_bg'              => 'surface',
		'overlay_panel_text'            => 'primary',
		'overlay_panel_muted'           => 'primary',
		'overlay_panel_placeholder'     => 'primary',
		'overlay_icon_color'            => 'primary',
		'overlay_close_hover_bg'        => 'surface',
		'overlay_result_hover_bg'       => 'surface',
		'overlay_all_results_color'        => 'primary',
		'overlay_all_results_hover_color'  => 'primary',
		'overlay_all_results_hover_bg'     => 'surface',
		'overlay_backdrop_color'        => 'primary',
		'overlay_backdrop_opacity'      => 55,

		// Result-card type pill/tag (shared by dropdown + /?s= page).
		// Current look: accent text on an accent tint background.
		'pill_text'                     => 'accent',
		'pill_bg'                       => 'accent',

		// Standalone results page (/?s=…) — assumes light page bg.
		'results_eyebrow_color'      => 'primary',
		'results_heading_color'      => 'primary',
		'results_text'               => 'primary',
		'results_muted'              => 'primary',
		'results_input_bg'           => 'surface',
		'results_input_text'         => 'primary',
		'results_input_border'       => 'primary',
		'results_link_hover'         => 'accent',
		'results_submit_bg'          => 'accent',
		'results_submit_text'        => 'white',
		'results_submit_hover_bg'    => 'primary',
	];
	return (array) apply_filters( 'styrk_blocks_search_default_colors', $defaults );
}

/**
 * Read the active theme's color palette from theme.json. Returns an array of
 * `[ slug, name, color ]` entries. This is the SINGLE source of truth for
 * what colors admins can pick in Settings → Search — there is no free-form
 * hex input, the picker is locked to brand swatches. To change what colors
 * appear, edit theme.json's `settings.color.palette`.
 */
function cb_get_theme_palette(): array {
	$palette = wp_get_global_settings( [ 'color', 'palette' ] );
	if ( isset( $palette['theme'] ) && is_array( $palette['theme'] ) ) {
		return $palette['theme'];
	}
	if ( isset( $palette['default'] ) && is_array( $palette['default'] ) ) {
		return $palette['default'];
	}
	if ( is_array( $palette ) && isset( $palette[0]['slug'] ) ) {
		return $palette;
	}
	return [];
}

/**
 * Resolve a saved color value (slug or legacy hex) to a CSS string suitable
 * for emitting into a custom property. Slugs become `var(--wp--preset--color--SLUG, HEX)`
 * with a hex fallback so the value remains valid even if the slug is later
 * removed from theme.json. Legacy hex values are passed through unchanged so
 * sites that haven't yet run the migration keep rendering.
 */
function cb_search_resolve_color_to_css( string $value, array $palette ): string {
	if ( $value === '' ) return 'transparent';
	if ( $value[0] === '#' ) return $value; // legacy hex
	$hex = '';
	foreach ( $palette as $entry ) {
		if ( ( $entry['slug'] ?? '' ) === $value ) {
			$hex = (string) ( $entry['color'] ?? '' );
			break;
		}
	}
	if ( $hex === '' ) return 'currentColor'; // unknown slug — safe inert fallback
	return "var(--wp--preset--color--{$value}, {$hex})";
}

/**
 * Resolve a saved color value to its raw hex (for server-side rgba composition,
 * e.g. the backdrop opacity slider). Returns empty string if unresolvable.
 */
function cb_search_resolve_color_to_hex( string $value, array $palette ): string {
	if ( $value === '' ) return '';
	if ( $value[0] === '#' ) return $value;
	foreach ( $palette as $entry ) {
		if ( ( $entry['slug'] ?? '' ) === $value ) {
			return (string) ( $entry['color'] ?? '' );
		}
	}
	return '';
}

/**
 * Return effective search settings — saved values merged with defaults,
 * with derived keys auto-filled from cores when the admin hasn't explicitly
 * set them. The cores (7 swatches admin actually sees) drive everything
 * else via `cb_search_derivations()`.
 *
 * Backwards compat: if a derived key has an explicit saved value (from
 * pre-v0.10.0 when admin could set each individually), that value is
 * respected. Only unsaved/empty derived keys get auto-filled.
 */
function cb_get_search_settings(): array {
	$saved    = get_option( CB_SEARCH_OPTION, [] );
	if ( ! is_array( $saved ) ) $saved = [];
	$defaults = cb_search_defaults();
	$merged   = wp_parse_args( $saved, $defaults );

	// Cores ALWAYS drive derived keys. The simplified admin UI doesn't
	// expose individual control for the 16 derived keys, so any
	// pre-v0.10 explicit saves were band-aids for a buggy cascade —
	// not intentional design choices we should preserve. Overriding
	// them universally restores a single source of truth.
	foreach ( cb_search_derivations() as $derived_key => $core_key ) {
		$merged[ $derived_key ] = $merged[ $core_key ] ?? '';
	}
	return $merged;
}

/**
 * Mapping: derived key → core key it inherits from when not explicitly
 * set. The 7 cores (panel_bg, panel_text, overlay_all_results_color,
 * overlay_backdrop_color, results_heading_color, results_text,
 * results_link_hover) drive every other colour.
 */
function cb_search_derivations(): array {
	return [
		// Overlay derivations from panel-text core
		'overlay_panel_muted'             => 'overlay_panel_text',
		'overlay_panel_placeholder'       => 'overlay_panel_text',
		'overlay_icon_color'              => 'overlay_panel_text',
		'overlay_all_results_hover_color' => 'overlay_panel_text',
		// Overlay derivations from accent core (drive hover tints)
		'overlay_close_hover_bg'          => 'overlay_all_results_color',
		'overlay_result_hover_bg'         => 'overlay_all_results_color',
		'overlay_all_results_hover_bg'    => 'overlay_all_results_color',
		// Results-page derivations from heading core
		'results_eyebrow_color'           => 'results_heading_color',
		// Results-page derivations from text core
		'results_muted'                   => 'results_text',
		'results_input_text'              => 'results_text',
		'results_input_border'            => 'results_text',
		// Results-page derivations from page-accent core
		'results_submit_bg'               => 'results_link_hover',
		'results_submit_hover_bg'         => 'results_link_hover',
		// Results-page input bg defaults to panel bg (light surface look)
		'results_input_bg'                => 'overlay_panel_bg',
		// Submit text contrasts the accent — falls back to panel bg
		// (which is usually the light/surface slug)
		'results_submit_text'             => 'overlay_panel_bg',
	];
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_search_settings_menu(): void {
	add_options_page(
		__( 'Search Settings', 'styrk-blocks' ),
		__( 'Search', 'styrk-blocks' ),
		'manage_options',
		'cb-search-settings',
		'cb_search_settings_page'
	);
}
add_action( 'admin_menu', 'cb_search_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

/**
 * The page is built from the Settings API: every SECTION is one named part of
 * the panel, every FIELD one row of it, laid out by sb_ui_render_parts()
 * (includes/admin-ui.php). Every saved option key, type and sanitizer is
 * unchanged; see cb_search_sanitize() for how the shared colour and corner
 * choices map onto the stored keys.
 */
function cb_search_settings_init(): void {
	register_setting( 'cb_search_group', CB_SEARCH_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_search_sanitize',
		'default'           => cb_search_defaults(),
	] );

	$page = 'cb-search-settings';

	add_settings_section( 'cb_search_texts', __( 'Texts', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_search_row_heading', __( 'Heading', 'styrk-blocks' ), 'cb_search_row_heading', $page, 'cb_search_texts' );
	add_settings_field( 'cb_search_row_form', __( 'Search field', 'styrk-blocks' ), 'cb_search_row_form', $page, 'cb_search_texts' );
	add_settings_field( 'cb_search_row_empty', __( 'No results', 'styrk-blocks' ), 'cb_search_row_empty', $page, 'cb_search_texts' );
	add_settings_field( 'cb_search_row_per_page', __( 'Results per page', 'styrk-blocks' ), 'cb_search_row_per_page', $page, 'cb_search_texts' );

	add_settings_section( 'cb_search_look', __( 'Appearance', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_search_row_colours', __( 'Colours', 'styrk-blocks' ), 'cb_search_row_colours', $page, 'cb_search_look' );
	add_settings_field( 'cb_search_row_corners', __( 'Corners', 'styrk-blocks' ), 'cb_search_row_corners', $page, 'cb_search_look' );

	add_settings_section( 'cb_search_advanced', __( 'Advanced', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_search_row_backdrop', __( 'Behind the search box', 'styrk-blocks' ), 'cb_search_row_backdrop', $page, 'cb_search_advanced' );
	add_settings_field( 'cb_search_row_heading_colour', __( 'Heading colour', 'styrk-blocks' ), 'cb_search_row_heading_colour', $page, 'cb_search_advanced' );
	add_settings_field( 'cb_search_row_labels', __( 'Type labels', 'styrk-blocks' ), 'cb_search_row_labels', $page, 'cb_search_advanced' );
	add_settings_field( 'cb_search_row_px', __( 'Corners in pixels', 'styrk-blocks' ), 'cb_search_row_px', $page, 'cb_search_advanced' );
}
add_action( 'admin_init', 'cb_search_settings_init' );

/** The kit's styles and script on this screen. */
add_filter(
	'sb_ui_pages',
	static function ( $pages ) {
		$pages   = (array) $pages;
		$pages[] = 'settings_page_cb-search-settings';
		return $pages;
	}
);

/* ── Corner, opacity and shared-colour presets ──────────────────────────────── */

/**
 * The three corner choices and the stored radii each one writes
 * (search box + panel, result cards, type labels). "soft" is the stock look.
 *
 * @return array<string,array<string,int>>
 */
function cb_search_corner_presets(): array {
	return [
		'sharp' => [ 'radius' => 0, 'card_radius' => 0, 'pill_radius' => 0 ],
		'soft'  => [ 'radius' => 16, 'card_radius' => 12, 'pill_radius' => 999 ],
		'round' => [ 'radius' => 32, 'card_radius' => 24, 'pill_radius' => 999 ],
	];
}

/**
 * Which corner choice the saved radii add up to ('' = set one by one).
 *
 * @param array $s Search settings.
 */
function cb_search_current_corners( array $s ): string {
	foreach ( cb_search_corner_presets() as $kind => $radii ) {
		$same = true;
		foreach ( $radii as $key => $value ) {
			$same = $same && (int) ( $s[ $key ] ?? -1 ) === $value;
		}
		if ( $same ) {
			return $kind;
		}
	}
	return '';
}

/**
 * Backdrop strength choices (light / medium / dark) → stored opacity 0–100.
 * Medium is the stock 55.
 *
 * @return array<string,int>
 */
function cb_search_opacity_presets(): array {
	return [
		'light'  => 35,
		'medium' => 55,
		'dark'   => 75,
	];
}

/**
 * Shared colour choices → the stored keys each one writes. The first key is
 * the one whose value the button shows.
 *
 * @return array<string,string[]>
 */
function cb_search_shared_colours(): array {
	return [
		'ui_bg'     => [ 'overlay_panel_bg' ],
		'ui_text'   => [ 'overlay_panel_text', 'overlay_all_results_color', 'results_text' ],
		'ui_accent' => [ 'results_link_hover', 'pill_text', 'pill_bg' ],
	];
}

/* ── Row helpers ────────────────────────────────────────────────────────────── */

/**
 * Name attribute of one field inside the stored array.
 *
 * @param string $key Option key (or a shared-choice name).
 */
function cb_search_name( string $key ): string {
	return CB_SEARCH_OPTION . '[' . $key . ']';
}

/**
 * One text field (or small textarea) of the saved settings.
 *
 * @param string $key   Option key.
 * @param string $label Visible label, or '' for none (then $aria names it).
 * @param string $aria  Accessible name when there is no visible label.
 * @param bool   $area  Use a textarea.
 */
function cb_search_text_input( string $key, string $label, string $aria = '', bool $area = false ): void {
	$s     = cb_get_search_settings();
	$value = (string) ( $s[ $key ] ?? '' );
	$id    = 'cb_search_' . $key;
	$name  = cb_search_name( $key );
	$aria  = '' === $aria ? '' : ' aria-label="' . esc_attr( $aria ) . '"';

	echo '<label class="sb-inline" for="' . esc_attr( $id ) . '">';
	if ( '' !== $label ) {
		echo '<span>' . esc_html( $label ) . '</span>';
	}
	if ( $area ) {
		echo '<textarea class="sb-input sb-input--wide" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="2"' . $aria . '>' . esc_textarea( $value ) . '</textarea>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $aria is escaped above.
	} else {
		echo '<input type="text" class="sb-input' . ( '' === $label ? ' sb-input--wide' : '' ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '"' . $aria . ' />'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $aria is escaped above.
	}
	echo '</label>';
}

/**
 * A colour button for one stored key (theme palette, slug saved).
 *
 * @param string $name  Input name.
 * @param string $value Saved slug.
 * @param string $label Button text.
 */
function cb_search_colour_button( string $name, string $value, string $label ): void {
	sb_ui_color( $name, $value, $label, cb_get_theme_palette(), 'slug', false );
}

/* ── Rows: Texts ────────────────────────────────────────────────────────────── */

function cb_search_row_heading(): void {
	sb_ui_stack(
		static function (): void {
			cb_search_text_input( 'eyebrow_text', __( 'Small text above', 'styrk-blocks' ) );
			cb_search_text_input( 'heading_with_query', '', __( 'Heading after a search', 'styrk-blocks' ) );
			cb_search_text_input( 'heading_no_query', '', __( 'Heading before anyone has searched', 'styrk-blocks' ) );
			cb_search_text_input( 'hint_no_query', '', __( 'Help text before anyone has searched', 'styrk-blocks' ), true );
		}
	);
	sb_ui_help( __( 'The first line shows after a search. The second line shows before anyone has searched, with the help text under it. The word that was searched for is put in by itself where it says {query}.', 'styrk-blocks' ) );
}

function cb_search_row_form(): void {
	sb_ui_line(
		static function (): void {
			cb_search_text_input( 'form_placeholder', __( 'In the field', 'styrk-blocks' ) );
			cb_search_text_input( 'form_button', __( 'The button', 'styrk-blocks' ) );
		}
	);
}

function cb_search_row_empty(): void {
	sb_ui_stack(
		static function (): void {
			cb_search_text_input( 'empty_line', '', __( 'Headline when nothing is found', 'styrk-blocks' ) );
			cb_search_text_input( 'empty_hint', '', __( 'Hint when nothing is found', 'styrk-blocks' ), true );
			cb_search_text_input( 'empty_back_label', __( 'Link home', 'styrk-blocks' ) );
		}
	);
	sb_ui_help( __( 'Shown when a search finds nothing. The word that was searched for is put in by itself where it says {query}.', 'styrk-blocks' ) );
}

function cb_search_row_per_page(): void {
	$s = cb_get_search_settings();
	sb_ui_stepper(
		cb_search_name( 'posts_per_page' ),
		(string) (int) $s['posts_per_page'],
		1,
		100,
		20,
		[
			'less'  => __( 'Less', 'styrk-blocks' ),
			'more'  => __( 'More', 'styrk-blocks' ),
			'label' => __( 'Results per page', 'styrk-blocks' ),
		]
	);
}

/* ── Rows: Appearance ───────────────────────────────────────────────────────── */

function cb_search_row_colours(): void {
	$s = cb_get_search_settings();
	sb_ui_line(
		static function () use ( $s ): void {
			cb_search_colour_button( cb_search_name( 'ui_bg' ), (string) $s['overlay_panel_bg'], __( 'Background', 'styrk-blocks' ) );
			cb_search_colour_button( cb_search_name( 'ui_text' ), (string) $s['overlay_panel_text'], __( 'Text', 'styrk-blocks' ) );
			cb_search_colour_button( cb_search_name( 'ui_accent' ), (string) $s['results_link_hover'], _x( 'Accent', 'search colours', 'styrk-blocks' ) );
		}
	);
	sb_ui_help( __( 'The accent is used on the button and on the labels on the hits.', 'styrk-blocks' ) );
}

function cb_search_row_corners(): void {
	$s       = cb_get_search_settings();
	$current = cb_search_current_corners( $s );
	$options = [
		'sharp' => [
			'label' => __( 'Squared', 'styrk-blocks' ),
			'svg'   => sb_ui_corner_svg( 'sharp' ),
		],
		'soft'  => [
			'label' => __( 'Soft', 'styrk-blocks' ),
			'svg'   => sb_ui_corner_svg( 'soft' ),
		],
		'round' => [
			'label' => __( 'Round', 'styrk-blocks' ),
			'svg'   => sb_ui_corner_svg( 'round' ),
		],
	];
	sb_ui_tiles( cb_search_name( 'ui_corners' ), $current, $options, __( 'Corners', 'styrk-blocks' ), 'corners', '' !== $current );
	if ( '' !== $current ) {
		sb_ui_help( __( 'Applies to the search box, the hits and the labels.', 'styrk-blocks' ) );
	} else {
		sb_ui_help( __( 'The corners are set one by one under Advanced. Pick one to replace them.', 'styrk-blocks' ) );
	}
}

/* ── Rows: Advanced ─────────────────────────────────────────────────────────── */

function cb_search_row_backdrop(): void {
	$s       = cb_get_search_settings();
	$presets = cb_search_opacity_presets();
	sb_ui_line(
		static function () use ( $s, $presets ): void {
			cb_search_colour_button( cb_search_name( 'overlay_backdrop_color' ), (string) $s['overlay_backdrop_color'], __( 'Colour', 'styrk-blocks' ) );
			sb_ui_segmented(
				cb_search_name( 'overlay_backdrop_opacity' ),
				(string) (int) $s['overlay_backdrop_opacity'],
				[
					(string) $presets['light']  => _x( 'Light', 'backdrop strength', 'styrk-blocks' ),
					(string) $presets['medium'] => _x( 'Middle', 'backdrop strength', 'styrk-blocks' ),
					(string) $presets['dark']   => _x( 'Dark', 'backdrop strength', 'styrk-blocks' ),
				],
				__( 'How much of the page behind is hidden', 'styrk-blocks' )
			);
		}
	);
	sb_ui_help( __( 'How much of the page behind is hidden while the search is open.', 'styrk-blocks' ) );
}

function cb_search_row_heading_colour(): void {
	$s = cb_get_search_settings();
	cb_search_colour_button( cb_search_name( 'results_heading_color' ), (string) $s['results_heading_color'], __( 'Heading', 'styrk-blocks' ) );
	sb_ui_help( __( 'The heading and the small text above it on the results page.', 'styrk-blocks' ) );
}

function cb_search_row_labels(): void {
	$s = cb_get_search_settings();
	sb_ui_line(
		static function () use ( $s ): void {
			cb_search_colour_button( cb_search_name( 'pill_text' ), (string) $s['pill_text'], __( 'Text', 'styrk-blocks' ) );
			cb_search_colour_button( cb_search_name( 'pill_bg' ), (string) $s['pill_bg'], __( 'Background', 'styrk-blocks' ) );
		}
	);
	sb_ui_help( __( 'The small label on each hit that says what it is. The background shows as a light tint.', 'styrk-blocks' ) );
}

function cb_search_row_px(): void {
	$s = cb_get_search_settings();
	sb_ui_line(
		static function () use ( $s ): void {
			foreach ( [
				[ 'radius', __( 'Search box', 'styrk-blocks' ), 40 ],
				[ 'card_radius', __( 'Hits', 'styrk-blocks' ), 40 ],
				[ 'pill_radius', __( 'Labels', 'styrk-blocks' ), 999 ],
			] as [ $key, $label, $max ] ) {
				echo '<span class="sb-inline"><span>' . esc_html( $label ) . '</span>';
				sb_ui_stepper(
					cb_search_name( $key ),
					(string) (int) $s[ $key ],
					0,
					$max,
					(int) $s[ $key ],
					[
						'less'  => __( 'Less', 'styrk-blocks' ),
						'more'  => __( 'More', 'styrk-blocks' ),
						'label' => $label,
					]
				);
				echo '</span>';
			}
		}
	);
	sb_ui_help( __( 'Overrides the corner choice under Appearance. 0 is square. For the labels, 999 is fully round.', 'styrk-blocks' ) );
}

/* ── Part summaries (shown while a part is closed) ──────────────────────────── */

/**
 * Name of a palette colour, for the closed summary.
 *
 * @param string $slug Palette slug.
 */
function cb_search_colour_name( string $slug ): string {
	foreach ( cb_get_theme_palette() as $entry ) {
		if ( (string) ( $entry['slug'] ?? '' ) === $slug ) {
			return (string) ( $entry['name'] ?? $slug );
		}
	}
	return '';
}

/**
 * One-line summary of a part.
 *
 * @param string $id Section id.
 */
function cb_search_part_summary( string $id ): string {
	$s = cb_get_search_settings();
	if ( 'cb_search_texts' === $id ) {
		/* translators: %d: number of hits per page */
		return '«' . (string) $s['eyebrow_text'] . '» · ' . sprintf( __( '%d hits per page', 'styrk-blocks' ), (int) $s['posts_per_page'] );
	}
	if ( 'cb_search_look' === $id ) {
		$corners = [
			'sharp' => __( 'square corners', 'styrk-blocks' ),
			'soft'  => __( 'soft corners', 'styrk-blocks' ),
			'round' => __( 'round corners', 'styrk-blocks' ),
		][ cb_search_current_corners( $s ) ] ?? __( 'own corners', 'styrk-blocks' );
		return implode(
			' · ',
			array_filter(
				[
					cb_search_colour_name( (string) $s['overlay_panel_bg'] ),
					cb_search_colour_name( (string) $s['overlay_panel_text'] ),
					cb_search_colour_name( (string) $s['results_link_hover'] ),
					$corners,
				]
			)
		);
	}
	$names = [
		35 => _x( 'light', 'backdrop strength', 'styrk-blocks' ),
		55 => _x( 'middle', 'backdrop strength', 'styrk-blocks' ),
		75 => _x( 'dark', 'backdrop strength', 'styrk-blocks' ),
	];
	$op = (int) $s['overlay_backdrop_opacity'];
	/* translators: %s: light, medium or dark */
	return sprintf( __( 'Behind the search box: %s', 'styrk-blocks' ), $names[ $op ] ?? ( $op . ' %' ) );
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

function cb_search_sanitize( $input ): array {
	$defaults  = cb_search_defaults();
	$sanitized = [];

	$text_keys = [
		'eyebrow_text', 'heading_with_query', 'heading_no_query',
		'empty_line', 'empty_back_label', 'form_placeholder', 'form_button',
	];
	foreach ( $text_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) $input[ $k ] : '';
		$clean = sanitize_text_field( wp_unslash( $raw ) );
		$sanitized[ $k ] = $clean !== '' ? $clean : $defaults[ $k ];
	}

	$textarea_keys = [ 'hint_no_query', 'empty_hint' ];
	foreach ( $textarea_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) $input[ $k ] : '';
		$clean = sanitize_textarea_field( wp_unslash( $raw ) );
		$sanitized[ $k ] = $clean !== '' ? $clean : $defaults[ $k ];
	}

	$ppp = isset( $input['posts_per_page'] ) ? (int) $input['posts_per_page'] : $defaults['posts_per_page'];
	$sanitized['posts_per_page'] = max( 1, min( 100, $ppp ) );

	$rad = isset( $input['radius'] ) ? (int) $input['radius'] : $defaults['radius'];
	$sanitized['radius'] = max( 0, min( 40, $rad ) );

	$card_rad = isset( $input['card_radius'] ) ? (int) $input['card_radius'] : $defaults['card_radius'];
	$sanitized['card_radius'] = max( 0, min( 40, $card_rad ) );

	$pill_rad = isset( $input['pill_radius'] ) ? (int) $input['pill_radius'] : $defaults['pill_radius'];
	$sanitized['pill_radius'] = max( 0, min( 999, $pill_rad ) );

	/* Color keys — slug-only. Each value must match a slug declared in the
	   active theme's theme.json palette. Anything else (legacy hex, junk,
	   slug for a color that's been removed from theme.json) falls back to
	   the default slug. This is the design-system lockdown. */
	$color_keys = [
		'overlay_panel_bg', 'overlay_panel_text', 'overlay_panel_muted',
		'overlay_panel_placeholder', 'overlay_icon_color',
		'overlay_close_hover_bg', 'overlay_result_hover_bg',
		'overlay_all_results_color', 'overlay_all_results_hover_color',
		'overlay_all_results_hover_bg',
		'overlay_backdrop_color',
		'results_eyebrow_color', 'results_heading_color',
		'results_text', 'results_muted',
		'results_input_bg', 'results_input_text', 'results_input_border',
		'results_submit_bg', 'results_submit_text', 'results_submit_hover_bg',
		'results_link_hover',
		'pill_text', 'pill_bg',
	];
	$palette     = cb_get_theme_palette();
	$valid_slugs = array_column( $palette, 'slug' );
	$existing    = get_option( CB_SEARCH_OPTION, [] );
	if ( ! is_array( $existing ) ) $existing = [];
	foreach ( $color_keys as $k ) {
		// Field not submitted (hidden derived field in v0.10+ admin UI):
		// preserve whatever was previously saved so legacy per-state
		// overrides survive a save action on the simplified form.
		if ( ! array_key_exists( $k, $input ) ) {
			if ( array_key_exists( $k, $existing ) ) {
				$sanitized[ $k ] = (string) $existing[ $k ];
			}
			continue;
		}
		$raw = trim( (string) wp_unslash( $input[ $k ] ) );
		if ( in_array( $raw, $valid_slugs, true ) ) {
			$sanitized[ $k ] = $raw;
		} else {
			$sanitized[ $k ] = $defaults[ $k ];
		}
	}

	$op_raw = isset( $input['overlay_backdrop_opacity'] ) ? (int) $input['overlay_backdrop_opacity'] : $defaults['overlay_backdrop_opacity'];
	$sanitized['overlay_backdrop_opacity'] = max( 0, min( 100, $op_raw ) );

	return cb_search_apply_shared_choices( $sanitized, (array) $input, $valid_slugs );
}


/**
 * The page's shared choices (one set of colours, one corner choice) written
 * onto the stored keys. Each is applied only when it differs from what the
 * page showed (the saved value), so saving without touching it changes
 * nothing. A field changed one by one under "Advanced" wins over the shared
 * choice.
 *
 * @param array    $sanitized   Values sanitised so far.
 * @param array    $input       Raw posted values.
 * @param string[] $valid_slugs Palette slugs.
 */
function cb_search_apply_shared_choices( array $sanitized, array $input, array $valid_slugs ): array {
	$prev    = cb_get_search_settings();
	$touched = [];
	foreach ( $sanitized as $k => $v ) {
		if ( array_key_exists( $k, $prev ) && (string) $v !== (string) $prev[ $k ] ) {
			$touched[ $k ] = true;
		}
	}
	foreach ( cb_search_shared_colours() as $shared => $keys ) {
		$raw = isset( $input[ $shared ] ) ? trim( (string) wp_unslash( $input[ $shared ] ) ) : '';
		if ( ! in_array( $raw, $valid_slugs, true ) || (string) $prev[ $keys[0] ] === $raw ) {
			continue;
		}
		foreach ( array_diff( $keys, array_keys( $touched ) ) as $k ) {
			$sanitized[ $k ] = $raw;
		}
	}
	$corners = isset( $input['ui_corners'] ) ? trim( (string) wp_unslash( $input['ui_corners'] ) ) : '';
	$presets = cb_search_corner_presets();
	if ( isset( $presets[ $corners ] ) && cb_search_current_corners( $prev ) !== $corners ) {
		foreach ( array_diff_key( $presets[ $corners ], $touched ) as $k => $v ) {
			$sanitized[ $k ] = $v;
		}
	}
	return $sanitized;
}

/* ── Frontend CSS injector ──────────────────────────────────────────────────── */

/**
 * Emit a <style> block in <head> that publishes the configured colors as
 * CSS custom properties on :root. The theme's stylesheet reads these vars
 * (--cb-search-panel-bg, --cb-search-panel-text, etc.) so the admin's
 * picks become the live values without touching the stylesheet.
 */
function cb_search_emit_css_vars(): void {
	$s       = cb_get_search_settings();
	$palette = cb_get_theme_palette();

	// Compose the translucent backdrop from the slug's hex + 0–100 opacity.
	// Slug → hex lookup happens server-side so the rgba() string is fully
	// resolved (CSS can't natively turn `var(...)` into an rgba channel).
	$backdrop_hex = cb_search_resolve_color_to_hex( (string) $s['overlay_backdrop_color'], $palette );
	$bd           = ltrim( $backdrop_hex, '#' );
	if ( strlen( $bd ) === 3 ) {
		$bd = $bd[0] . $bd[0] . $bd[1] . $bd[1] . $bd[2] . $bd[2];
	}
	$r = strlen( $bd ) === 6 ? hexdec( substr( $bd, 0, 2 ) ) : 0;
	$g = strlen( $bd ) === 6 ? hexdec( substr( $bd, 2, 2 ) ) : 0;
	$b = strlen( $bd ) === 6 ? hexdec( substr( $bd, 4, 2 ) ) : 0;
	$a = number_format( ( (int) $s['overlay_backdrop_opacity'] ) / 100, 2, '.', '' );
	$backdrop_rgba = "rgba({$r},{$g},{$b},{$a})";

	// Map each setting key to its CSS-var name. Each value becomes
	// `var(--wp--preset--color--SLUG, HEX)` so the active theme.json palette
	// drives the live color, with a hex fallback for cache-misses.
	// Keys in $tint_pct emit at low alpha via color-mix() — hover tints need
	// to be translucent or they're indistinguishable from the panel they
	// sit on (e.g. surface hover on a surface panel = invisible).
	$mapping = [
		'overlay_panel_bg'              => '--cb-search-panel-bg',
		'overlay_panel_text'            => '--cb-search-panel-text',
		'overlay_panel_muted'           => '--cb-search-panel-muted',
		'overlay_panel_placeholder'     => '--cb-search-panel-placeholder',
		'overlay_icon_color'            => '--cb-search-icon-color',
		'overlay_close_hover_bg'        => '--cb-search-close-hover-bg',
		'overlay_result_hover_bg'       => '--cb-search-result-hover-bg',
		'overlay_all_results_color'        => '--cb-search-all-results-color',
		'overlay_all_results_hover_color'  => '--cb-search-all-results-hover-color',
		'overlay_all_results_hover_bg'     => '--cb-search-all-results-hover-bg',
		'results_eyebrow_color'         => '--cb-search-results-eyebrow',
		'results_heading_color'         => '--cb-search-results-heading',
		'results_text'                  => '--cb-search-results-text',
		'results_muted'                 => '--cb-search-results-muted',
		'results_input_bg'              => '--cb-search-results-input-bg',
		'results_input_text'            => '--cb-search-results-input-text',
		'results_input_border'          => '--cb-search-results-input-border',
		'results_submit_bg'             => '--cb-search-results-submit-bg',
		'results_submit_text'           => '--cb-search-results-submit-text',
		'results_submit_hover_bg'       => '--cb-search-results-submit-hover-bg',
		'results_link_hover'            => '--cb-search-results-link-hover',
		'pill_text'                     => '--cb-search-pill-text',
		'pill_bg'                       => '--cb-search-pill-bg',
	];
	$tint_pct = [
		'overlay_close_hover_bg'       => 8,
		'overlay_result_hover_bg'      => 8,
		'overlay_all_results_hover_bg' => 8,
		// Pill bg shows as a light 10% tone of the chosen colour, matching
		// the current hardcoded rgba(accent, 0.10) look.
		'pill_bg'                      => 10,
	];

	// A text colour that cannot be read on its surface (under 4.5:1) is
	// replaced by black or white, whichever reads. Settings → Search tells
	// the admin which pairs these are (cb_search_contrast_conflicts()).
	$readable = [];
	if ( function_exists( 'cb_search_contrast_conflicts' ) ) {
		$to_hex = static fn( string $v ): string => cb_search_resolve_color_to_hex( $v, $palette );
		foreach ( cb_search_contrast_conflicts( $s, $to_hex ) as $conflict ) {
			$readable[ $conflict['key'] ] = $conflict['safe'];
		}
	}

	$decls = [];
	foreach ( $mapping as $key => $var ) {
		$resolved = $readable[ $key ] ?? cb_search_resolve_color_to_css( (string) $s[ $key ], $palette );
		// currentColor is tinted too: a colour slug the theme doesn't have
		// resolves to currentColor, and a SOLID currentColor background is the
		// text colour itself — the label vanishes ("dead pill", seen on a
		// palette without an accent slug).
		if ( isset( $tint_pct[ $key ] ) && $resolved !== 'transparent' ) {
			$pct      = (int) $tint_pct[ $key ];
			$resolved = "color-mix(in srgb, {$resolved} {$pct}%, transparent)";
		}
		$decls[] = $var . ':' . $resolved;
	}
	$decls[] = '--cb-search-backdrop-bg:' . $backdrop_rgba;
	$decls[] = '--cb-search-radius:' . (int) $s['radius'] . 'px';
	$decls[] = '--cb-search-card-radius:' . (int) $s['card_radius'] . 'px';
	$decls[] = '--cb-search-pill-radius:' . (int) $s['pill_radius'] . 'px';

	// Baseline rules that read the vars emitted above. Shipped here in the
	// plugin (not the theme) so the search UI respects admin choices on
	// EVERY site, even when the active theme has stale CSS or a broad
	// `.cb-site-header a:hover { color: #fff !important; ... }` rule that
	// would otherwise repaint overlay anchors white on hover.
	//
	// !important + plain class specificity wins over equal-specificity
	// theme `!important` rules by declaration order — this <style> tag is
	// emitted at wp_head priority 100, after theme stylesheets.
	$rules = (
		// Standalone results page
		'.cb-search-page__eyebrow{color:var(--cb-search-results-eyebrow, var(--cb-search-results-muted, currentColor)) !important;}'
		. '.cb-search-page__heading{color:var(--cb-search-results-heading, var(--cb-search-results-text, currentColor)) !important;}'

		// Header dropdown — admin controls drive every interactive state.
		// Selectors are prefixed with `.rh-search-overlay` so specificity
		// matches the common theme pattern
		//   `.rh-search-overlay .rh-search-all { color: ... !important; }`
		// — without the prefix, the theme's two-class selector beats our
		// one-class !important even with the priority-100 cascade trick.
		// `text-decoration: none` everywhere defeats the broad
		// `header a:hover { text-decoration: underline !important; }`
		// patterns common in themes.
		. '.rh-search-overlay .rh-search-all{'
		.   'color:var(--cb-search-all-results-color, currentColor) !important;'
		.   'text-decoration:none !important;'
		. '}'
		. '.rh-search-overlay .rh-search-all:hover,.rh-search-overlay .rh-search-all:focus-visible{'
		.   'color:var(--cb-search-all-results-hover-color, var(--cb-search-all-results-color, currentColor)) !important;'
		.   'background:var(--cb-search-all-results-hover-bg, transparent) !important;'
		.   'text-decoration:none !important;'
		. '}'
		. '.rh-search-overlay .rh-search-result,.rh-search-overlay .rh-search-result:hover,.rh-search-overlay .rh-search-result:focus-visible{'
		.   'text-decoration:none !important;'
		. '}'
		. '.rh-search-overlay .rh-search-result.is-active,.rh-search-overlay .rh-search-result:hover{'
		.   'background:var(--cb-search-result-hover-bg, transparent) !important;'
		. '}'
	);

	// ── Results-page hit-title hover ────────────────────────────────────────
	// Theme groups hit-title under --cb-search-results-link-hover on hover,
	// which doubles as the "Page accent" core (submit-button colour). When
	// admins pick a light accent (e.g. White) for the button, hit-titles
	// went invisible on hover. Force hit-title hover to stay body-text
	// colour — underline alone carries the hover feedback. Submit button
	// keeps the bright accent independently.
	$rules .= '.cb-search-page__hit-link:hover .cb-search-page__hit-title,'
		. '.cb-search-page__hit-link:focus-visible .cb-search-page__hit-title{'
		. 'color:var(--cb-search-results-text, currentColor) !important;'
		. '}';

	// ── Single-project page visibility floor ────────────────────────────────
	// The "Beskrivelse" eyebrow and the meta-strip values are rendered by
	// theme-side `the_content` filters that ship no colour API. On themes
	// where a broad cream/`color:inherit` rule turns these invisible on a
	// light body bg, force the brand palette via !important. NOT
	// admin-customizable yet — the block-conversion refactor planned for
	// the next release exposes per-element controls. Until then, these
	// rules guarantee these elements have legible contrast out of the box.
	$rules .= '.cb-project-body__eyebrow{'
		. 'color:var(--wp--preset--color--accent, currentColor) !important;'
		. '}'
		. '.cb-project-meta-strip dt{'
		. 'color:var(--wp--preset--color--accent, currentColor) !important;'
		. '}'
		. '.cb-project-meta-strip dd{'
		. 'color:var(--wp--preset--color--primary, currentColor) !important;'
		. '}';

	// ── Orphaned-var wiring ─────────────────────────────────────────────────
	// The built stylesheet hardcodes the dropdown panel bg, the backdrop, and
	// the ENTIRE results-page palette (input box, submit button, body text) —
	// so those admin settings published vars that nothing read ("colours don't
	// work"). Wire them here (priority-100 !important so they win the cascade),
	// each with the built CSS's previous hardcoded value as the fallback.
	$rules .=
		// Header dropdown
		'.rh-search-panel{background:var(--cb-search-panel-bg, var(--wp--preset--color--surface, #f1ece1)) !important;}'
		. '.rh-search-overlay{background:var(--cb-search-backdrop-bg, rgba(10,15,30,0.55)) !important;}'
		// Results page — input box
		. '.cb-search-page__form{background:var(--cb-search-results-input-bg, rgba(255,255,255,0.08)) !important;border-color:var(--cb-search-results-input-border, rgba(255,255,255,0.15)) !important;}'
		. '.cb-search-page__form input[type="search"]{color:var(--cb-search-results-input-text, #fff) !important;}'
		// The placeholder follows the input text (the stylesheet's own is
		// white at 55%, invisible in a light field).
		. '.cb-search-page__form input[type="search"]::placeholder{color:color-mix(in srgb, var(--cb-search-results-input-text, #fff) 64%, transparent) !important;opacity:1;}'
		// Results page — submit button
		. '.cb-search-page__form button{background:var(--cb-search-results-submit-bg, currentColor) !important;color:var(--cb-search-results-submit-text, #fff) !important;}'
		. '.cb-search-page__form button:hover,.cb-search-page__form button:focus-visible{background:var(--cb-search-results-submit-hover-bg, var(--cb-search-results-submit-bg, currentColor)) !important;}'
		// Results page — body text + muted helpers
		. '.cb-search-page__body,.cb-search-page__empty-line,.cb-search-page__hit-title{color:var(--cb-search-results-text, currentColor) !important;}'
		// NOTE: `.cb-search-page__hit-type` is intentionally NOT in this muted
		// group — the type pill now has its own admin-controlled text colour
		// (see the pill rules below) so it must not be forced to the muted
		// body colour here.
		. '.cb-search-page__count,.cb-search-page__hint,.cb-search-page__hit-excerpt,.cb-search-page__empty-hint{color:var(--cb-search-results-muted, var(--cb-search-results-text, currentColor)) !important;}';

	// ── Corner radius (admin-controlled). Modal panel scoped to ≥641px so the
	// mobile full-screen search panel stays square; results-page input box +
	// its submit button round to match.
	$rules .= '@media(min-width:641px){.rh-search-panel{border-radius:var(--cb-search-radius,16px) !important;}}'
		. '.cb-search-page__form{border-radius:var(--cb-search-radius,16px) !important;}'
		. '.cb-search-page__form button{border-radius:max(0px,calc(var(--cb-search-radius,16px) - 4px)) !important;}';

	// ── Result cards + type pills (admin-controlled). Shared across the header
	// dropdown (`.rh-search-result*`) and the /?s= results page
	// (`.cb-search-page__hit*`). Fallbacks reproduce the previously hardcoded
	// look: pill text = accent, pill bg = accent @10%, pill radius = 999px
	// (full pill), card radius = 8px (dropdown) / 12px (results page). The
	// admin's single card-radius now applies to both surfaces.
	$rules .= '.rh-search-result__type,.cb-search-page__hit-type{'
		.   'color:var(--cb-search-pill-text, var(--wp--preset--color--accent, currentColor)) !important;'
		.   'background:var(--cb-search-pill-bg, color-mix(in srgb, var(--wp--preset--color--accent, #f0a83c) 10%, transparent)) !important;'
		.   'border-radius:var(--cb-search-pill-radius, 999px) !important;'
		. '}'
		. '.rh-search-result,.cb-search-page__hit-link{'
		.   'border-radius:var(--cb-search-card-radius, 12px) !important;'
		. '}';

	$css = ':root{' . implode( ';', $decls ) . ';}' . $rules;
	// wp_strip_all_tags() so a value can never close the <style> element and
	// start an executable one. Values are already sanitized in cb_search_sanitize().
	printf( '<style id="cb-search-vars">%s</style>', wp_strip_all_tags( $css ) );
}
// Priority 100 — runs AFTER theme stylesheets so equal-specificity
// `!important` rules in this <style> tag win the cascade.
add_action( 'wp_head', 'cb_search_emit_css_vars', 100 );

/* ── Admin page template ────────────────────────────────────────────────────── */

function cb_search_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) return;
	?>
	<div class="wrap sb-ui" data-sb-page="search">
		<h1><?php esc_html_e( 'Search Settings', 'styrk-blocks' ); ?></h1>
		<p class="sb-ui__intro"><?php esc_html_e( 'Open a part to change it. The closed parts show what is chosen now.', 'styrk-blocks' ); ?></p>
		<?php
		// Text / surface pairs that cannot be read. The site already shows a
		// readable colour instead; this tells the admin which choices clash.
		if ( function_exists( 'cb_search_contrast_conflicts' ) ) {
			$cb_palette   = cb_get_theme_palette();
			$cb_conflicts = cb_search_contrast_conflicts(
				cb_get_search_settings(),
				static fn( string $v ): string => cb_search_resolve_color_to_hex( $v, $cb_palette )
			);
			if ( $cb_conflicts ) :
				?>
				<div class="notice notice-warning inline" style="max-width:720px;">
					<p><strong><?php esc_html_e( 'Colour conflict: these choices cannot be read against their background.', 'styrk-blocks' ); ?></strong>
					<?php esc_html_e( 'The site shows a readable colour instead until you change the choice (the requirement is 4.5:1).', 'styrk-blocks' ); ?></p>
					<ul style="margin:0 0 12px 18px;list-style:disc;">
						<?php foreach ( $cb_conflicts as $cb_c ) : ?>
							<li>
								<?php echo esc_html( $cb_c['label'] ); ?>:
								<span style="display:inline-block;padding:1px 8px;border:1px solid #c3c4c7;border-radius:3px;background:<?php echo esc_attr( $cb_c['bg'] ); ?>;color:<?php echo esc_attr( $cb_c['fg'] ); ?>;">Aa</span>
								<?php
								/* translators: 1: contrast ratio, e.g. 1.9 */
								echo esc_html( sprintf( __( 'contrast %s:1', 'styrk-blocks' ), number_format_i18n( $cb_c['ratio'], 1 ) ) );
								?>
								→
								<span style="display:inline-block;padding:1px 8px;border:1px solid #c3c4c7;border-radius:3px;background:<?php echo esc_attr( $cb_c['bg'] ); ?>;color:<?php echo esc_attr( $cb_c['safe'] ); ?>;">Aa</span>
								<?php esc_html_e( 'shown now', 'styrk-blocks' ); ?>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
				<?php
			endif;
		}
		?>
		<noscript><style>.sb-part__body[hidden]{display:block}</style></noscript>
		<form method="post" action="options.php">
			<?php settings_fields( 'cb_search_group' ); ?>
			<div class="sb-panel">
				<h2 class="sb-panel__title"><?php esc_html_e( 'Search', 'styrk-blocks' ); ?></h2>
				<?php sb_ui_render_parts( 'cb-search-settings', 'cb_search_part_summary' ); ?>
			</div>
			<button type="submit" name="submit" class="sb-submit"><?php esc_html_e( 'Save changes', 'styrk-blocks' ); ?></button>
		</form>
	</div>
	<?php
}

/* ── Seed defaults on first load ────────────────────────────────────────────── */

function cb_search_seed_defaults(): void {
	if ( get_option( CB_SEARCH_OPTION ) ) return;
	update_option( CB_SEARCH_OPTION, cb_search_defaults() );
}
add_action( 'admin_init', 'cb_search_seed_defaults' );

/* ── One-shot migration: existing hex saves → palette slugs ─────────────────── */

/**
 * In v0.8.x the option store held hex strings (`#0F1B2D`). In v0.9.0 it
 * holds theme.json slugs (`primary`). This one-shot maps each saved hex to
 * the closest swatch in the active palette so admins don't lose their
 * configuration on upgrade. Runs once per site (flagged by
 * `cb_search_color_migration_v1`), and only when the palette is loadable
 * — if theme.json isn't ready yet (very early hook), it skips and retries
 * on the next admin_init.
 */
function cb_search_migrate_hex_to_slugs(): void {
	if ( get_option( 'cb_search_color_migration_v1' ) ) return;

	$saved = get_option( CB_SEARCH_OPTION );
	if ( ! is_array( $saved ) || empty( $saved ) ) {
		// Nothing to migrate — fresh install gets the slug defaults directly.
		update_option( 'cb_search_color_migration_v1', 1, false );
		return;
	}

	$palette = cb_get_theme_palette();
	if ( empty( $palette ) ) {
		// Theme.json not yet readable. Don't flag migrated — retry next request.
		return;
	}

	$defaults    = cb_search_defaults();
	$color_keys  = [
		'overlay_panel_bg', 'overlay_panel_text', 'overlay_panel_muted',
		'overlay_panel_placeholder', 'overlay_icon_color',
		'overlay_close_hover_bg', 'overlay_result_hover_bg',
		'overlay_all_results_color', 'overlay_all_results_hover_color',
		'overlay_all_results_hover_bg',
		'overlay_backdrop_color',
		'results_eyebrow_color', 'results_heading_color',
		'results_text', 'results_muted',
		'results_input_bg', 'results_input_text', 'results_input_border',
		'results_submit_bg', 'results_submit_text', 'results_submit_hover_bg',
		'results_link_hover',
		'pill_text', 'pill_bg',
	];
	$valid_slugs = array_column( $palette, 'slug' );

	foreach ( $color_keys as $k ) {
		if ( ! isset( $saved[ $k ] ) ) continue;
		$val = (string) $saved[ $k ];
		if ( in_array( $val, $valid_slugs, true ) ) continue; // already a slug
		if ( $val === '' || $val[0] !== '#' ) {
			// Junk value — reset to default slug.
			$saved[ $k ] = $defaults[ $k ];
			continue;
		}
		$nearest = cb_search_nearest_palette_slug( $val, $palette );
		$saved[ $k ] = $nearest ?: $defaults[ $k ];
	}

	update_option( CB_SEARCH_OPTION, $saved );
	update_option( 'cb_search_color_migration_v1', 1, false );
}
add_action( 'admin_init', 'cb_search_migrate_hex_to_slugs', 9 );

/**
 * Return the palette slug whose color is closest to the given hex via
 * Euclidean distance in RGB. Used by the v0.9.0 migration to map legacy
 * hex settings onto the active theme palette.
 */
function cb_search_nearest_palette_slug( string $hex, array $palette ): ?string {
	$target = cb_search_hex_to_rgb( $hex );
	if ( $target === null ) return null;

	$best_slug = null;
	$best_dist = PHP_FLOAT_MAX;
	foreach ( $palette as $entry ) {
		$rgb = cb_search_hex_to_rgb( (string) ( $entry['color'] ?? '' ) );
		if ( $rgb === null ) continue;
		$dr = $target[0] - $rgb[0];
		$dg = $target[1] - $rgb[1];
		$db = $target[2] - $rgb[2];
		$dist = $dr * $dr + $dg * $dg + $db * $db;
		if ( $dist < $best_dist ) {
			$best_dist = $dist;
			$best_slug = (string) ( $entry['slug'] ?? '' );
		}
	}
	return $best_slug ?: null;
}

function cb_search_hex_to_rgb( string $hex ): ?array {
	$h = ltrim( trim( $hex ), '#' );
	if ( strlen( $h ) === 3 ) {
		$h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
	}
	if ( strlen( $h ) !== 6 || ! ctype_xdigit( $h ) ) return null;
	return [
		hexdec( substr( $h, 0, 2 ) ),
		hexdec( substr( $h, 2, 2 ) ),
		hexdec( substr( $h, 4, 2 ) ),
	];
}
