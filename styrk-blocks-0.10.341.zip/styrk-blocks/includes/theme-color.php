<?php
/**
 * Theme palette lookup.
 *
 * Inline styles that need a real hex — anything later fed to
 * cb_best_contrast_text(), which has to do luminance arithmetic on it —
 * cannot use `var(--wp--preset--color--primary, …)`. Several block templates
 * therefore fell back to a bare '#0a2020' when the editor had picked no
 * colour. That hex is only the example skin baked into tailwind.config.js,
 * so every client whose palette differs rendered the wrong brand colour
 * whenever a button was left unstyled.
 *
 * Reading the slug out of the active theme.json fixes it at the source: the
 * literal stays only as the last resort for when no palette is registered.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_theme_color' ) ) {
	/**
	 * Resolve a theme.json palette slug to its hex value.
	 *
	 * @param string $slug     Palette slug, e.g. 'primary'.
	 * @param string $fallback Returned when the slug is not in the palette.
	 * @return string Hex colour.
	 */
	function cb_theme_color( $slug, $fallback = '#0a2020' ) {
		static $cache = null;

		if ( null === $cache ) {
			$cache = [];
			if ( function_exists( 'wp_get_global_settings' ) ) {
				$palette = wp_get_global_settings( [ 'color', 'palette' ] );
				// theme.json splits the palette into default/theme/custom
				// origins; a flat list arrives when only one origin exists.
				$groups = isset( $palette[0] ) ? [ $palette ] : array_values( (array) $palette );
				foreach ( $groups as $group ) {
					foreach ( (array) $group as $entry ) {
						if ( isset( $entry['slug'], $entry['color'] ) ) {
							$cache[ $entry['slug'] ] = $entry['color'];
						}
					}
				}
			}
		}

		$value = $cache[ $slug ] ?? '';
		// Only a literal hex is usable by the contrast helpers; a palette
		// entry defined as a var() or gradient is no better than the fallback.
		return ( is_string( $value ) && preg_match( '/^#[0-9a-f]{3,8}$/i', $value ) )
			? $value
			: $fallback;
	}
}

if ( ! function_exists( 'cb_accent_text_color' ) ) {
	/**
	 * The accent, when it can be read as text on this site's light surfaces;
	 * otherwise the primary (#276).
	 *
	 * Process numbers, the FAQ "+" and breadcrumb dots were painted in the
	 * accent. On a light accent (Styrk amber) that is 1.7:1 on the surface —
	 * unreadable — while on a strong one (Skotnes blue, 5.4:1) it is fine. So
	 * the choice is made per site, from its own palette: 3:1 against both the
	 * surface and white (these are large numerals, icons and dots, not body
	 * copy), else fall back to the primary, which is dark by design.
	 *
	 * @return string Hex colour.
	 */
	function cb_accent_text_color() {
		$accent  = cb_theme_color( 'accent', '#f0a83c' );
		$primary = cb_theme_color( 'primary', '#0a2020' );
		if ( ! function_exists( 'cb_contrast_ratio' ) ) {
			return $primary;
		}
		$floor = min(
			cb_contrast_ratio( $accent, cb_theme_color( 'surface', '#f1ece1' ) ),
			cb_contrast_ratio( $accent, '#ffffff' )
		);
		return $floor >= 3 ? $accent : $primary;
	}
}

if ( ! function_exists( 'cb_role_colors' ) ) {
	/**
	 * Colours for a surface painted in one palette ROLE (a coloured panel).
	 *
	 * The editor picks a role — accent, primary, secondary, surface, white —
	 * not a hex, so the panel follows the client's theme.json. The background
	 * is emitted as the preset with the canon fallback; the text and button
	 * colours are worked out from the site's own value for that role, so they
	 * pass WCAG AA (4.5:1) whatever the client's palette is.
	 *
	 * - Text: white on a dark role, else the theme primary — and if that
	 *   fails, whichever of black and white passes.
	 * - Button: filled in the text colour, its label in the best contrast
	 *   against that fill. Button and panel are each other's inverse.
	 *
	 * Mirrored for the editor preview by src/components/roleColors.ts.
	 *
	 * @param mixed $role Palette slug. Unknown values fall back to accent.
	 * @return array{role:string,bg:string,fg:string,btn_bg:string,btn_fg:string}
	 */
	function cb_role_colors( $role ) {
		$canon = [
			'accent'    => '#f0a83c',
			'primary'   => '#0a2020',
			'secondary' => '#173838',
			'surface'   => '#f1ece1',
			'white'     => '#ffffff',
		];
		$role = is_string( $role ) && isset( $canon[ $role ] ) ? $role : 'accent';
		$bg   = cb_theme_color( $role, $canon[ $role ] );
		$ink  = cb_theme_color( 'primary', $canon['primary'] );
		$fg   = cb_best_contrast_text( $bg, cb_is_dark_color( $bg ) ? '#ffffff' : $ink );
		return [
			'role'   => $role,
			'bg'     => 'var(--wp--preset--color--' . $role . ', ' . $canon[ $role ] . ')',
			'fg'     => $fg,
			'btn_bg' => $fg,
			'btn_fg' => cb_best_contrast_text( $fg, cb_is_dark_color( $fg ) ? '#ffffff' : $ink ),
		];
	}
}

add_action(
	'enqueue_block_assets',
	static function () {
		if ( wp_style_is( 'styrk-blocks-shared', 'enqueued' ) ) {
			wp_add_inline_style(
				'styrk-blocks-shared',
				':root{--cb-accent-text:' . esc_attr( cb_accent_text_color() ) . ';}'
			);
		}
	},
	20
);

if ( ! function_exists( 'cb_sanitize_color_value' ) ) {
	/**
	 * Sanitize a colour attribute that may be a theme palette variable.
	 *
	 * Ready-made looks (the News block's «Stil» choice) save colours as
	 * `var(--wp--preset--color--<slug>, #hex)` so each client's theme decides
	 * the actual colour. sanitize_hex_color() would strip those, so this
	 * accepts a plain hex OR exactly that variable form, and nothing else.
	 *
	 * @param mixed $value Raw attribute value.
	 * @return string Safe CSS colour value, or '' when invalid.
	 */
	function cb_sanitize_color_value( $value ) {
		$value = trim( (string) $value );
		if ( '' === $value ) {
			return '';
		}
		$hex = sanitize_hex_color( $value );
		if ( $hex ) {
			return $hex;
		}
		return preg_match( '/^var\(--wp--preset--color--[a-z0-9-]+,\s*#[0-9a-f]{3,8}\)$/i', $value )
			? $value
			: '';
	}
}
