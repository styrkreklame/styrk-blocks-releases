/*
 * Settings → Footer: the two behaviours only this screen has.
 *
 *  1. Opening hours. The seven days with the real fields (hours_mon_open …
 *     hours_sun_to) are always in the form. The compact table (Weekdays,
 *     Saturday, Sunday) is made of unnamed stand-ins; typing in one copies the
 *     value into the real fields, so what is saved is the same 21 keys as ever.
 *     Nothing is written on load, only when someone types or switches a toggle.
 *  2. A legal link's address box is only shown while "Own address" is picked
 *     in its page dropdown.
 *
 * Vanilla JS, loaded after the admin UI kit (styrk-admin-ui.js).
 */
( function () {
	'use strict';

	var root = document.querySelector( '.sb-ui[data-sb-page="footer"]' );
	if ( ! root ) {
		return;
	}

	function fire( el ) {
		el.dispatchEvent( new Event( 'input', { bubbles: true } ) );
		el.dispatchEvent( new Event( 'change', { bubbles: true } ) );
	}

	/* ── Opening hours ──────────────────────────────────────────────────── */
	var hours = root.querySelector( '[data-sb-hours]' );
	if ( hours ) {
		var compact = hours.querySelector( '[data-sb-hours-compact]' );
		var days = hours.querySelector( '[data-sb-hours-days]' );
		var sw = hours.querySelector( '[data-sb-hours-switch]' );
		var WEEKDAYS = [ 'mon', 'tue', 'wed', 'thu', 'fri' ];

		var real = function ( key ) {
			var row = days.querySelector( '[data-sb-real="' + key + '"]' );
			return {
				open: row.querySelector( 'input[type="checkbox"]' ),
				from: row.querySelector( 'input[name$="_from]"]' ),
				to: row.querySelector( 'input[name$="_to]"]' ),
			};
		};

		// Do Monday to Friday hold the same hours right now?
		var uniform = function () {
			var m = real( 'mon' );
			return WEEKDAYS.every( function ( k ) {
				var r = real( k );
				return (
					r.open.checked === m.open.checked &&
					r.from.value.trim() === m.from.value.trim() &&
					r.to.value.trim() === m.to.value.trim()
				);
			} );
		};

		var wdFrom = compact.querySelector( '[data-sb-wd="from"]' );
		var wdTo = compact.querySelector( '[data-sb-wd="to"]' );

		// Weekdays → Monday to Friday.
		var copyWeekdays = function () {
			var from = wdFrom.value.trim();
			var to = wdTo.value.trim();
			WEEKDAYS.forEach( function ( k ) {
				var r = real( k );
				r.from.value = from;
				r.to.value = to;
				r.open.checked = '' !== from && '' !== to;
			} );
		};
		wdFrom.addEventListener( 'input', copyWeekdays );
		wdTo.addEventListener( 'input', copyWeekdays );

		// Saturday and Sunday → their own real fields.
		compact.querySelectorAll( '[data-sb-day]' ).forEach( function ( row ) {
			var r = real( row.getAttribute( 'data-sb-day' ) );
			var closed = row.querySelector( '[data-sb-closed]' );
			var from = row.querySelector( '[data-sb-day-from]' );
			var to = row.querySelector( '[data-sb-day-to]' );
			var times = row.querySelector( '.sb-hours__times' );
			closed.addEventListener( 'change', function () {
				r.open.checked = ! closed.checked;
				times.hidden = closed.checked;
				if ( ! closed.checked ) {
					from.focus();
				}
			} );
			from.addEventListener( 'input', function () {
				r.from.value = from.value.trim();
			} );
			to.addEventListener( 'input', function () {
				r.to.value = to.value.trim();
			} );
		} );

		// The seven days → the compact rows (read when switching back).
		var refreshCompact = function () {
			var m = real( 'mon' );
			wdFrom.value = m.open.checked ? m.from.value : '';
			wdTo.value = m.open.checked ? m.to.value : '';
			compact.querySelectorAll( '[data-sb-day]' ).forEach( function ( row ) {
				var r = real( row.getAttribute( 'data-sb-day' ) );
				var closed = row.querySelector( '[data-sb-closed]' );
				closed.checked = ! r.open.checked;
				row.querySelector( '.sb-hours__times' ).hidden = closed.checked;
				row.querySelector( '[data-sb-day-from]' ).value = r.from.value;
				row.querySelector( '[data-sb-day-to]' ).value = r.to.value;
			} );
		};

		// The link only goes back to the compact table while that can show
		// the week without hiding a difference.
		var refreshSwitch = function () {
			if ( days.hidden ) {
				sw.hidden = false;
				return;
			}
			sw.hidden = ! uniform();
		};

		sw.addEventListener( 'click', function () {
			var showDays = days.hidden;
			if ( ! showDays ) {
				refreshCompact();
			}
			days.hidden = ! showDays;
			compact.hidden = showDays;
			sw.textContent = hours.getAttribute( showDays ? 'data-less' : 'data-more' );
			refreshSwitch();
			var first = ( showDays ? days : compact ).querySelector( 'input[type="text"]' );
			if ( first ) {
				first.focus();
			}
		} );
		days.addEventListener( 'input', refreshSwitch );
		days.addEventListener( 'change', refreshSwitch );
		refreshSwitch();
	}

	/* ── Legal links: address box only for "Own address" ────────────────── */
	root.querySelectorAll( '[data-sb-legal-page]' ).forEach( function ( select ) {
		var row = select.closest( '.sb-legal__row' );
		var url = row ? row.querySelector( '.sb-legal__url' ) : null;
		if ( ! url ) {
			return;
		}
		select.addEventListener( 'change', function () {
			url.hidden = '0' !== select.value;
		} );
	} );
} )();
