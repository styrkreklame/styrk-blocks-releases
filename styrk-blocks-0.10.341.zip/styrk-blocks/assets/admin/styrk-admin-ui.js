/*
 * Styrk admin UI kit — behaviour for the shared settings-page controls.
 * Vanilla JS, no build step. Pairs with styrk-admin-ui.css and the PHP
 * helpers in includes/admin-ui.php. Every control works as a plain form
 * without this file; this only adds the open/close parts, the colour palette
 * popover, the logo picker, the stepper and "only when ..." dimming.
 */
( function () {
	'use strict';

	var root = document.querySelector( '.sb-ui' );
	if ( ! root ) {
		return;
	}
	var form = root.querySelector( 'form' ) || root;

	/* ── Storage (never trusted: private windows throw) ─────────────────── */
	function store( key, value ) {
		try {
			if ( undefined === value ) {
				return window.localStorage.getItem( key );
			}
			window.localStorage.setItem( key, value );
		} catch ( e ) {
			return null;
		}
		return null;
	}

	/* ── Collapsible parts ──────────────────────────────────────────────── */
	var pageKey = 'sbui:' + ( root.getAttribute( 'data-sb-page' ) || 'page' ) + ':';

	function setPart( part, open ) {
		var btn = part.querySelector( '.sb-part__toggle' );
		var body = part.querySelector( '.sb-part__body' );
		if ( ! btn || ! body ) {
			return;
		}
		btn.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		body.hidden = ! open;
	}

	root.querySelectorAll( '.sb-part' ).forEach( function ( part ) {
		var id = part.getAttribute( 'data-sb-part' );
		var saved = store( pageKey + id );
		if ( 'open' === saved ) {
			setPart( part, true );
		} else if ( 'closed' === saved ) {
			setPart( part, false );
		}
		var btn = part.querySelector( '.sb-part__toggle' );
		if ( btn ) {
			btn.addEventListener( 'click', function () {
				var open = 'true' !== btn.getAttribute( 'aria-expanded' );
				setPart( part, open );
				store( pageKey + id, open ? 'open' : 'closed' );
			} );
		}
	} );

	/* ── Colour palette popover ─────────────────────────────────────────── */
	function closePops( except ) {
		root.querySelectorAll( '.sb-color' ).forEach( function ( c ) {
			if ( c === except ) {
				return;
			}
			var pop = c.querySelector( '.sb-color__pop' );
			var btn = c.querySelector( '.sb-color__btn' );
			if ( pop && ! pop.hidden ) {
				pop.hidden = true;
				btn.setAttribute( 'aria-expanded', 'false' );
			}
		} );
	}

	root.querySelectorAll( '.sb-color' ).forEach( function ( c ) {
		var btn = c.querySelector( '.sb-color__btn' );
		var pop = c.querySelector( '.sb-color__pop' );
		var dot = c.querySelector( '.sb-dot' );
		if ( ! btn || ! pop ) {
			return;
		}
		btn.addEventListener( 'click', function () {
			var open = pop.hidden;
			closePops( c );
			pop.hidden = ! open;
			btn.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			if ( open ) {
				var on = pop.querySelector( 'input:checked' ) || pop.querySelector( 'input' );
				if ( on ) {
					on.focus();
				}
			}
		} );
		pop.addEventListener( 'change', function ( e ) {
			var input = e.target;
			if ( ! input || 'radio' !== input.type ) {
				return;
			}
			var fallback = c.querySelector( 'input[data-sb-fallback]' );
			if ( fallback ) {
				fallback.value = input.value;
			}
			var color = input.getAttribute( 'data-color' );
			if ( color ) {
				dot.style.setProperty( '--sb-dot', color );
				dot.classList.remove( 'sb-dot--default' );
			} else {
				dot.style.removeProperty( '--sb-dot' );
				dot.classList.add( 'sb-dot--default' );
			}
			pop.hidden = true;
			btn.setAttribute( 'aria-expanded', 'false' );
			btn.focus();
		} );
		c.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && ! pop.hidden ) {
				e.preventDefault();
				e.stopPropagation();
				pop.hidden = true;
				btn.setAttribute( 'aria-expanded', 'false' );
				btn.focus();
			}
		} );
	} );

	document.addEventListener( 'click', function ( e ) {
		if ( ! e.target.closest || ! e.target.closest( '.sb-color' ) ) {
			closePops( null );
		}
	} );

	/* ── "Only when ..." dimming ────────────────────────────────────────── */
	// data-sb-when="field[name]:a|b" dims (and makes unreachable) the element
	// unless the named field currently has one of the listed values. The
	// element stays in the form, so its saved value is never lost.
	function currentValue( name ) {
		var checked = form.querySelector( 'input[name="' + name + '"]:checked' );
		if ( checked ) {
			return checked.value;
		}
		var select = form.querySelector( 'select[name="' + name + '"]' );
		if ( select ) {
			return select.value;
		}
		var fallback = form.querySelector( 'input[type="hidden"][name="' + name + '"]' );
		return fallback ? fallback.value : '';
	}

	function applyWhen() {
		root.querySelectorAll( '[data-sb-when]' ).forEach( function ( el ) {
			var spec = el.getAttribute( 'data-sb-when' );
			var cut = spec.lastIndexOf( ':' );
			var name = spec.slice( 0, cut );
			var values = spec.slice( cut + 1 ).split( '|' );
			var on = -1 !== values.indexOf( currentValue( name ) );
			el.classList.toggle( 'sb-is-dim', ! on );
			if ( on ) {
				el.removeAttribute( 'inert' );
			} else {
				el.setAttribute( 'inert', '' );
			}
		} );
	}
	form.addEventListener( 'change', applyWhen );
	applyWhen();

	/* ── Reset link ("Ikke valgt", "Tilbakestill") ─────────────────────── */
	// data-sb-reset holds one field name, or several separated by commas. It
	// puts each back on its empty choice, and hides itself while all are empty.
	function resetNames( link ) {
		return link.getAttribute( 'data-sb-reset' ).split( ',' );
	}
	root.querySelectorAll( '[data-sb-reset]' ).forEach( function ( link ) {
		link.addEventListener( 'click', function () {
			var last = null;
			resetNames( link ).forEach( function ( name ) {
				var empty = form.querySelector( 'input[type="radio"][name="' + name + '"][value=""]' );
				if ( empty ) {
					var tile = empty.closest( '.sb-tile' );
					if ( tile ) {
						tile.hidden = false;
					}
					empty.checked = true;
					empty.dispatchEvent( new Event( 'change', { bubbles: true } ) );
					last = empty;
				}
			} );
			if ( last ) {
				last.focus();
			}
			link.hidden = true;
		} );
	} );
	form.addEventListener( 'change', function ( e ) {
		var t = e.target;
		if ( ! t || 'radio' !== t.type ) {
			return;
		}
		root.querySelectorAll( '[data-sb-reset]' ).forEach( function ( link ) {
			var names = resetNames( link );
			if ( -1 === names.indexOf( t.name ) ) {
				return;
			}
			link.hidden = names.every( function ( name ) {
				var on = form.querySelector( 'input[type="radio"][name="' + name + '"]:checked' );
				return ! on || '' === on.value;
			} );
		} );
	} );

	/* ── Stepper ────────────────────────────────────────────────────────── */
	root.querySelectorAll( '.sb-stepper' ).forEach( function ( box ) {
		var input = box.querySelector( 'input' );
		box.querySelectorAll( '[data-sb-step]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var step = parseInt( b.getAttribute( 'data-sb-step' ), 10 ) || 0;
				var min = input.min === '' ? -Infinity : parseInt( input.min, 10 );
				var max = input.max === '' ? Infinity : parseInt( input.max, 10 );
				var start = parseInt( input.getAttribute( 'data-start' ) || '0', 10 );
				var cur = input.value === '' ? start : parseInt( input.value, 10 );
				if ( isNaN( cur ) ) {
					cur = start;
				}
				var next = input.value === '' ? cur : cur + step;
				input.value = String( Math.max( min, Math.min( max, next ) ) );
				input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
			} );
		} );
	} );

	/* ── "Add one more" list: reveals the next hidden field ─────────────── */
	// A [data-sb-extra][hidden] block is a spare slot. The add button shows the
	// next one and hides itself when none is left; [data-sb-remove] (below)
	// empties a slot and puts it back, so the button returns.
	root.querySelectorAll( '[data-sb-add]' ).forEach( function ( btn ) {
		var list = btn.closest( '.sb-row__ctl' ) || btn.parentNode;
		function refresh() {
			btn.hidden = ! list.querySelector( '[data-sb-extra][hidden]' );
		}
		btn.addEventListener( 'click', function () {
			var next = list.querySelector( '[data-sb-extra][hidden]' );
			if ( next ) {
				next.hidden = false;
				if ( next.hasAttribute( 'data-sb-card' ) ) {
					setCard( next, true );
				}
				var first = next.querySelector( 'input:not([type="hidden"]), select, textarea, [data-sb-media-pick]' );
				if ( first ) {
					first.focus();
				}
			}
			refresh();
		} );
		btn.addEventListener( 'sb:refresh', refresh );
		refresh();
	} );

	/* ── Remove a slot: empty it and hide it again ──────────────────────── */
	root.querySelectorAll( '[data-sb-remove]' ).forEach( function ( link ) {
		link.addEventListener( 'click', function () {
			var slot = link.closest( '[data-sb-extra]' );
			if ( ! slot ) {
				return;
			}
			var list = slot.closest( '.sb-row__ctl' ) || slot.parentNode;
			var clear = slot.querySelector( '[data-sb-media-clear]' );
			if ( clear && ! clear.hidden ) {
				clear.click();
			}
			slot.querySelectorAll( 'input, textarea, select' ).forEach( function ( f ) {
				if ( 'select' === f.tagName.toLowerCase() ) {
					f.selectedIndex = 0;
				} else if ( 'hidden' === f.type ) {
					f.value = '0';
				} else if ( 'checkbox' !== f.type && 'radio' !== f.type ) {
					f.value = '';
				}
				f.dispatchEvent( new Event( 'input', { bubbles: true } ) );
				f.dispatchEvent( new Event( 'change', { bubbles: true } ) );
			} );
			slot.hidden = true;
			var add = list.querySelector( '[data-sb-add]' );
			if ( add ) {
				add.dispatchEvent( new Event( 'sb:refresh' ) );
				add.focus();
			}
		} );
	} );

	/* ── Cards (a thumb, a name, "Endre" opens the rest) ────────────────── */
	function setCard( card, open ) {
		var btn = card.querySelector( '[data-sb-card-toggle]' );
		var body = card.querySelector( '.sb-card__body' );
		if ( btn && body ) {
			btn.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			body.hidden = ! open;
		}
	}
	root.querySelectorAll( '[data-sb-card]' ).forEach( function ( card ) {
		var btn = card.querySelector( '[data-sb-card-toggle]' );
		var name = card.querySelector( '[data-sb-name]' );
		var from = card.querySelector( '[data-sb-name-from]' );
		var thumb = card.querySelector( '.sb-card__thumb img' );
		if ( btn ) {
			btn.addEventListener( 'click', function () {
				setCard( card, 'true' !== btn.getAttribute( 'aria-expanded' ) );
			} );
		}
		if ( name && from ) {
			from.addEventListener( 'input', function () {
				name.textContent = from.value.trim() || name.getAttribute( 'data-fallback' ) || '';
			} );
		}
		// The picker tells us which picture it now holds.
		card.addEventListener( 'sb:media', function ( e ) {
			if ( ! thumb ) {
				return;
			}
			if ( e.detail && e.detail.url ) {
				thumb.setAttribute( 'src', e.detail.url );
				thumb.hidden = false;
			} else {
				thumb.removeAttribute( 'src' );
				thumb.hidden = true;
			}
		} );
	} );

	/* ── A folded field: a link that shows and hides it ─────────────────── */
	root.querySelectorAll( '[data-sb-fold]' ).forEach( function ( link ) {
		var target = document.getElementById( link.getAttribute( 'data-sb-fold' ) );
		if ( ! target ) {
			return;
		}
		link.addEventListener( 'click', function () {
			var open = 'true' !== link.getAttribute( 'aria-expanded' );
			link.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			target.hidden = ! open;
			if ( open ) {
				var field = target.querySelector( 'textarea, input' );
				if ( field ) {
					field.focus();
				}
			}
		} );
	} );

	/* ── Logo picker (WordPress media library) ──────────────────────────── */
	root.querySelectorAll( '[data-sb-media]' ).forEach( function ( box ) {
		var input = box.querySelector( 'input[type="hidden"]' );
		var pick = box.querySelector( '[data-sb-media-pick]' );
		var clear = box.querySelector( '[data-sb-media-clear]' );
		var preview = box.querySelector( '.sb-media__preview' );
		var img = preview ? preview.querySelector( 'img' ) : null;
		var frame = null;

		function show( url ) {
			box.dispatchEvent( new CustomEvent( 'sb:media', { bubbles: true, detail: { url: url } } ) );
			if ( url ) {
				img.setAttribute( 'src', url );
				preview.hidden = false;
				pick.textContent = box.getAttribute( 'data-label-change' );
				clear.hidden = false;
			} else {
				img.removeAttribute( 'src' );
				preview.hidden = true;
				pick.textContent = box.getAttribute( 'data-label-upload' );
				clear.hidden = true;
			}
		}

		pick.addEventListener( 'click', function () {
			if ( ! window.wp || ! window.wp.media ) {
				return;
			}
			if ( ! frame ) {
				frame = window.wp.media( {
					title: box.getAttribute( 'data-title' ),
					button: { text: box.getAttribute( 'data-button' ) },
					multiple: false,
					library: { type: [ 'image', 'image/svg+xml' ] },
				} );
				frame.on( 'select', function () {
					var a = frame.state().get( 'selection' ).first().toJSON();
					input.value = String( a.id );
					show( a.sizes && a.sizes.medium ? a.sizes.medium.url : a.url );
				} );
			}
			frame.open();
		} );

		clear.addEventListener( 'click', function () {
			input.value = '0';
			show( '' );
			pick.focus();
		} );
	} );
} )();
