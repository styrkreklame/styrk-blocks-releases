<?php
/**
 * Search results page — server-rendered shortcode.
 *
 * `[styrk_search_results]` outputs the entire body of the
 * `?s=query` results page: a navy hero band with eyebrow +
 * Norwegian h1 ("Søkeresultater for «query»"), a list of result
 * cards (title + post-type chip + excerpt), and a clearly-styled
 * "no results" empty state.
 *
 * This replaces the WP `core/query-title` + `core/query` block
 * combination in `templates/search.html`. Reasons we don't lean on
 * core blocks here:
 *
 * 1. `core/query-title` outputs the literal English string "Search
 *    results for:" with no locale fallback short of switching the
 *    site to nb_NO. The shortcode hardcodes the Norwegian wording.
 * 2. `core/query` with `inherit:true` runs the main query, which on
 *    a search request silently filters by the default-searchable
 *    post types only — the empty-state message inside
 *    `query-no-results` was rendering with zero spacing on staging,
 *    making the whole page look broken when no results matched.
 *    The shortcode renders an explicit, styled empty state.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_SEARCH_RENDER_LOADED' ) ) return;
define( 'CB_SEARCH_RENDER_LOADED', true );

/**
 * Map a post type slug to its Norwegian display label. Used on each
 * result card's post-type chip ("Side", "Innlegg", "Ansatt").
 */
function cb_search_post_type_label( string $slug ): string {
	$map = [
		'page'     => 'Side',
		'post'     => 'Innlegg',
		'employee' => 'Ansatt',
	];
	return $map[ $slug ] ?? ucfirst( $slug );
}

function cb_search_results_shortcode(): string {
	$query   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
	$trimmed = trim( $query );

	ob_start();
	?>
	<section class="cb-search-page__hero">
		<div class="cb-search-page__hero-inner">
			<p class="cb-eyebrow cb-search-page__eyebrow">SØKERESULTATER</p>
			<h1 class="cb-search-page__heading">
				<?php if ( $trimmed === '' ) : ?>
					Søk på siden
				<?php else : ?>
					Søkeresultater for «<?php echo esc_html( $trimmed ); ?>»
				<?php endif; ?>
			</h1>

			<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="cb-search-page__form">
				<label class="screen-reader-text" for="cb-search-page-input">Søk</label>
				<input type="search" id="cb-search-page-input" name="s" value="<?php echo esc_attr( $trimmed ); ?>" placeholder="Søk på siden…" autocomplete="off">
				<button type="submit">Søk</button>
			</form>
		</div>
	</section>
	<?php

	if ( $trimmed === '' ) {
		?>
		<section class="cb-search-page__body">
			<p class="cb-search-page__hint">Skriv et søkeord over for å finne sider, ansatte eller innlegg.</p>
		</section>
		<?php
		return ob_get_clean();
	}

	// Run the search query manually so we control which post types
	// are searched + the explicit empty handling.
	$args = [
		's'              => $trimmed,
		'post_status'    => 'publish',
		'posts_per_page' => 20,
		'no_found_rows'  => false,
	];
	$wp_query = new WP_Query( $args );

	?>
	<section class="cb-search-page__body">
		<?php if ( ! $wp_query->have_posts() ) : ?>
			<div class="cb-search-page__empty">
				<p class="cb-search-page__empty-line">Ingen treff for «<?php echo esc_html( $trimmed ); ?>».</p>
				<p class="cb-search-page__empty-hint">Sjekk stavemåten eller prøv et annet søkeord. Du kan også <a href="<?php echo esc_url( home_url( '/' ) ); ?>">gå tilbake til forsiden</a>.</p>
			</div>
		<?php else : ?>
			<p class="cb-search-page__count">
				<?php
				$count = (int) $wp_query->found_posts;
				if ( $count === 1 ) {
					echo '1 treff';
				} else {
					echo esc_html( $count ) . ' treff';
				}
				?>
			</p>
			<ol class="cb-search-page__list">
				<?php while ( $wp_query->have_posts() ) : $wp_query->the_post();
					$post_type = get_post_type();
					$type_lbl  = cb_search_post_type_label( (string) $post_type );
					$excerpt   = wp_strip_all_tags( get_the_excerpt() );
					if ( $excerpt === '' ) {
						$excerpt = wp_trim_words( wp_strip_all_tags( (string) get_the_content() ), 30, '…' );
					}
				?>
					<li class="cb-search-page__hit">
						<a href="<?php the_permalink(); ?>" class="cb-search-page__hit-link">
							<div class="cb-search-page__hit-head">
								<span class="cb-search-page__hit-title"><?php echo esc_html( get_the_title() ); ?></span>
								<span class="cb-search-page__hit-type"><?php echo esc_html( $type_lbl ); ?></span>
							</div>
							<?php if ( $excerpt !== '' ) : ?>
								<p class="cb-search-page__hit-excerpt"><?php echo esc_html( wp_html_excerpt( $excerpt, 200, '…' ) ); ?></p>
							<?php endif; ?>
						</a>
					</li>
				<?php endwhile; wp_reset_postdata(); ?>
			</ol>
		<?php endif; ?>
	</section>
	<?php

	return ob_get_clean();
}
add_shortcode( 'styrk_search_results', 'cb_search_results_shortcode' );
