<?php
/**
 * WCAG-aware color helpers.
 *
 * Used by block templates to guarantee that text placed on a user-picked
 * background colour still meets WCAG AA contrast (4.5:1 for normal text,
 * 3:1 for large text). Keeps the user's background, adjusts the text.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_hex_to_rgb' ) ) {
	function cb_hex_to_rgb( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( strlen( $hex ) === 3 ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( strlen( $hex ) !== 6 || ! ctype_xdigit( $hex ) ) {
			return null;
		}
		return [
			hexdec( substr( $hex, 0, 2 ) ),
			hexdec( substr( $hex, 2, 2 ) ),
			hexdec( substr( $hex, 4, 2 ) ),
		];
	}
}

if ( ! function_exists( 'cb_relative_luminance' ) ) {
	function cb_relative_luminance( $hex ) {
		$rgb = cb_hex_to_rgb( $hex );
		if ( ! $rgb ) return null;
		$lin = array_map( function ( $c ) {
			$s = $c / 255;
			return $s <= 0.03928 ? $s / 12.92 : pow( ( $s + 0.055 ) / 1.055, 2.4 );
		}, $rgb );
		return 0.2126 * $lin[0] + 0.7152 * $lin[1] + 0.0722 * $lin[2];
	}
}

if ( ! function_exists( 'cb_contrast_ratio' ) ) {
	function cb_contrast_ratio( $a, $b ) {
		$la = cb_relative_luminance( $a );
		$lb = cb_relative_luminance( $b );
		if ( $la === null || $lb === null ) return 0.0;
		$lighter = max( $la, $lb );
		$darker  = min( $la, $lb );
		return ( $lighter + 0.05 ) / ( $darker + 0.05 );
	}
}

if ( ! function_exists( 'cb_best_contrast_text' ) ) {
	/**
	 * Pick a WCAG-passing text color for a given background.
	 *
	 * - If $preferred is passed AND meets $min_ratio against $bg → keep it.
	 * - Otherwise pick whichever of #ffffff / #111111 gives the higher ratio.
	 *
	 * @param string $bg         Background colour (hex).
	 * @param string $preferred  User-picked text colour (hex). May be empty.
	 * @param float  $min_ratio  Minimum required contrast. 4.5 = AA normal text,
	 *                           3.0 = AA large text / UI components.
	 * @return string            Hex color with leading #.
	 */
	function cb_best_contrast_text( $bg, $preferred = '', $min_ratio = 4.5 ) {
		if ( $preferred && cb_contrast_ratio( $bg, $preferred ) >= $min_ratio ) {
			return $preferred;
		}
		// Use pure black (not #111111) for the dark fallback so mid-tone
		// brand backgrounds — e.g. Støttefarge 1 #0084AF — still pass AA.
		// On #0084AF: white = 4.22, #111111 = 4.42 (both fail 4.5);
		// #000000 = 4.98 (passes).
		$white_ratio = cb_contrast_ratio( $bg, '#ffffff' );
		$black_ratio = cb_contrast_ratio( $bg, '#000000' );
		return $white_ratio >= $black_ratio ? '#ffffff' : '#000000';
	}
}

if ( ! function_exists( 'cb_is_dark_color' ) ) {
	/**
	 * Is this background dark enough that light-section text defaults become
	 * unreadable on it?
	 *
	 * The library signals "this section is dark" with the `.styrk-dark` class,
	 * which flips a set of CSS custom properties (eyebrow default colour,
	 * placeholder ink, align-picker chrome). Until now only hero ever set that
	 * class, while every other block paints its dark background as an inline
	 * `background-color` style — so on those sections the dark defaults never
	 * applied and the eyebrow/heading rendered dark-on-dark.
	 *
	 * 0.18 relative luminance is the cut: it sits above the brand's darkest
	 * surfaces (Styrk primary #0a2020 = 0.017, Viken primary #00486a = 0.056)
	 * and below the light ones (#f1ece1 = 0.83), with mid-tones such as
	 * #0084AF (0.21) treated as light — those already carry enough contrast
	 * against the dark ink defaults.
	 *
	 * @param string $hex Background colour.
	 * @return bool True when the colour needs the dark-section treatment.
	 */
	function cb_is_dark_color( $hex ) {
		$lum = cb_relative_luminance( $hex );
		return $lum !== null && $lum < 0.18;
	}
}
