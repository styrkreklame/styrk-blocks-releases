<?php
/**
 * Theme palette lookup.
 *
 * Inline styles that need a real hex — anything later fed to
 * cb_best_contrast_text(), which has to do luminance arithmetic on it —
 * cannot use `var(--wp--preset--color--primary, …)`. Several block templates
 * therefore fell back to a bare '#00486A' when the editor had picked no
 * colour. That hex is the Viken reference skin baked into tailwind.config.js,
 * so every other client rendered Viken's navy whenever a button was left
 * unstyled.
 *
 * Reading the slug out of the active theme.json fixes it at the source: the
 * literal stays only as the last resort for when no palette is registered.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_theme_color' ) ) {
	/**
	 * Resolve a theme.json palette slug to its hex value.
	 *
	 * @param string $slug     Palette slug, e.g. 'primary'.
	 * @param string $fallback Returned when the slug is not in the palette.
	 * @return string Hex colour.
	 */
	function cb_theme_color( $slug, $fallback = '#00486A' ) {
		static $cache = null;

		if ( null === $cache ) {
			$cache = [];
			if ( function_exists( 'wp_get_global_settings' ) ) {
				$palette = wp_get_global_settings( [ 'color', 'palette' ] );
				// theme.json splits the palette into default/theme/custom
				// origins; a flat list arrives when only one origin exists.
				$groups = isset( $palette[0] ) ? [ $palette ] : array_values( (array) $palette );
				foreach ( $groups as $group ) {
					foreach ( (array) $group as $entry ) {
						if ( isset( $entry['slug'], $entry['color'] ) ) {
							$cache[ $entry['slug'] ] = $entry['color'];
						}
					}
				}
			}
		}

		$value = $cache[ $slug ] ?? '';
		// Only a literal hex is usable by the contrast helpers; a palette
		// entry defined as a var() or gradient is no better than the fallback.
		return ( is_string( $value ) && preg_match( '/^#[0-9a-f]{3,8}$/i', $value ) )
			? $value
			: $fallback;
	}
}
