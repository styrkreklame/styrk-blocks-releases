<?php
/**
 * Dark-section marker.
 *
 * The stylesheet keys every dark-surface adjustment off `.styrk-dark` (or
 * theme.json's `.has-primary-background-color`): the eyebrow's default
 * colour, placeholder ink, the align-picker chrome. Hero was the only block
 * that ever set the class. Every other section paints its dark background as
 * an inline `background-color` from the `sectionBgColor` attribute, so the
 * rule could not match and the eyebrow + heading kept their light-section
 * dark ink — saved, rendered, and invisible on the dark band.
 *
 * Deriving the marker from the colour the editor actually picked fixes all of
 * them at once, and keeps working for blocks added later. The editor canvas
 * gets the same treatment from src/plugins/dark-section.tsx.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_mark_dark_sections' ) ) {
	/**
	 * Add `styrk-dark` to a styrk-blocks block whose section background is dark.
	 *
	 * @param string $content Rendered block HTML.
	 * @param array  $block   Parsed block.
	 * @return string
	 */
	function cb_mark_dark_sections( $content, $block ) {
		$name = $block['blockName'] ?? '';
		if ( 0 !== strpos( (string) $name, 'styrk-blocks/' ) ) {
			return $content;
		}

		$bg = $block['attrs']['sectionBgColor'] ?? '';
		if ( ! is_string( $bg ) || '' === $bg || ! cb_is_dark_color( $bg ) ) {
			return $content;
		}

		// Only the block's own root element — the first tag in the rendered
		// markup. A regex bounded to offset 0 cannot reach nested children.
		if ( preg_match( '/^(\s*<[a-z][a-z0-9-]*)\b([^>]*)>/i', $content, $m ) ) {
			$open = $m[0];
			$attr = $m[2];
			if ( preg_match( '/\sclass=("|\')(.*?)\1/i', $attr, $c ) ) {
				if ( preg_match( '/(^|\s)styrk-dark(\s|$)/', $c[2] ) ) {
					return $content;
				}
				$replaced = str_replace(
					$c[0],
					' class=' . $c[1] . $c[2] . ' styrk-dark' . $c[1],
					$open
				);
			} else {
				$replaced = $m[1] . ' class="styrk-dark"' . $attr . '>';
			}
			$content = $replaced . substr( $content, strlen( $open ) );
		}

		return $content;
	}
}

add_filter( 'render_block', 'cb_mark_dark_sections', 10, 2 );
