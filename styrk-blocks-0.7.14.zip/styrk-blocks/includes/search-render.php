<?php
/**
 * Search results page — server-rendered shortcode.
 *
 * `[styrk_search_results]` outputs the entire body of the
 * `?s=query` results page: a navy hero band with eyebrow +
 * Norwegian h1 ("Søkeresultater for «query»"), a list of result
 * cards (title + post-type chip + excerpt), and a clearly-styled
 * "no results" empty state.
 *
 * This replaces the WP `core/query-title` + `core/query` block
 * combination in `templates/search.html`. Reasons we don't lean on
 * core blocks here:
 *
 * 1. `core/query-title` outputs the literal English string "Search
 *    results for:" with no locale fallback short of switching the
 *    site to nb_NO. The shortcode hardcodes the Norwegian wording.
 * 2. `core/query` with `inherit:true` runs the main query, which on
 *    a search request silently filters by the default-searchable
 *    post types only — the empty-state message inside
 *    `query-no-results` was rendering with zero spacing on staging,
 *    making the whole page look broken when no results matched.
 *    The shortcode renders an explicit, styled empty state.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_SEARCH_RENDER_LOADED' ) ) return;
define( 'CB_SEARCH_RENDER_LOADED', true );

/**
 * Map a post type slug to its Norwegian display label. Used on each
 * result card's post-type chip ("Side", "Innlegg", "Ansatt").
 */
function cb_search_post_type_label( string $slug ): string {
	$map = [
		'page'     => 'Side',
		'post'     => 'Innlegg',
		'employee' => 'Ansatt',
	];
	return $map[ $slug ] ?? ucfirst( $slug );
}

function cb_search_results_shortcode(): string {
	$query   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
	$trimmed = trim( $query );

	// Pull editable copy from Settings → Search (with built-in
	// Norwegian fallbacks). Fall back to defaults defensively if
	// search-settings.php failed to load — never render blank copy.
	$settings = function_exists( 'cb_get_search_settings' )
		? cb_get_search_settings()
		: [];
	$defaults = function_exists( 'cb_search_defaults' )
		? cb_search_defaults()
		: [];
	$copy = static function ( string $key ) use ( $settings, $defaults ): string {
		$v = (string) ( $settings[ $key ] ?? $defaults[ $key ] ?? '' );
		return $v;
	};

	$heading = $trimmed === ''
		? $copy( 'heading_no_query' )
		: str_replace( '{query}', $trimmed, $copy( 'heading_with_query' ) );

	ob_start();
	?>
	<section class="cb-search-page__hero">
		<div class="cb-search-page__hero-inner">
			<p class="cb-eyebrow cb-search-page__eyebrow"><?php echo esc_html( $copy( 'eyebrow_text' ) ); ?></p>
			<h1 class="cb-search-page__heading"><?php echo esc_html( $heading ); ?></h1>

			<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="cb-search-page__form">
				<label class="screen-reader-text" for="cb-search-page-input"><?php echo esc_html( $copy( 'form_button' ) ); ?></label>
				<input type="search" id="cb-search-page-input" name="s" value="<?php echo esc_attr( $trimmed ); ?>" placeholder="<?php echo esc_attr( $copy( 'form_placeholder' ) ); ?>" autocomplete="off">
				<button type="submit"><?php echo esc_html( $copy( 'form_button' ) ); ?></button>
			</form>
		</div>
	</section>
	<?php

	if ( $trimmed === '' ) {
		?>
		<section class="cb-search-page__body">
			<p class="cb-search-page__hint"><?php echo esc_html( $copy( 'hint_no_query' ) ); ?></p>
		</section>
		<?php
		return ob_get_clean();
	}

	// Run the search query manually so we control which post types
	// are searched + the explicit empty handling.
	$ppp  = (int) ( $settings['posts_per_page'] ?? $defaults['posts_per_page'] ?? 20 );
	$args = [
		's'              => $trimmed,
		'post_status'    => 'publish',
		'posts_per_page' => max( 1, min( 100, $ppp ) ),
		'no_found_rows'  => false,
	];
	$wp_query = new WP_Query( $args );

	$empty_line = str_replace( '{query}', $trimmed, $copy( 'empty_line' ) );
	?>
	<section class="cb-search-page__body">
		<?php if ( ! $wp_query->have_posts() ) : ?>
			<div class="cb-search-page__empty">
				<p class="cb-search-page__empty-line"><?php echo esc_html( $empty_line ); ?></p>
				<p class="cb-search-page__empty-hint">
					<?php echo esc_html( $copy( 'empty_hint' ) ); ?>
					<?php
					/* translators: bridge connecting the suggestion sentence to the inline home link. Kept fixed because it is grammatical filler, not editorial copy. */
					esc_html_e( 'Du kan også', 'styrk-blocks' );
					?>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( $copy( 'empty_back_label' ) ); ?></a>.
				</p>
			</div>
		<?php else : ?>
			<p class="cb-search-page__count">
				<?php
				$count = (int) $wp_query->found_posts;
				if ( $count === 1 ) {
					echo '1 treff';
				} else {
					echo esc_html( $count ) . ' treff';
				}
				?>
			</p>
			<ol class="cb-search-page__list">
				<?php while ( $wp_query->have_posts() ) : $wp_query->the_post();
					$post_type = get_post_type();
					$type_lbl  = cb_search_post_type_label( (string) $post_type );
					$excerpt   = wp_strip_all_tags( get_the_excerpt() );
					if ( $excerpt === '' ) {
						$excerpt = wp_trim_words( wp_strip_all_tags( (string) get_the_content() ), 30, '…' );
					}
				?>
					<li class="cb-search-page__hit">
						<a href="<?php the_permalink(); ?>" class="cb-search-page__hit-link">
							<div class="cb-search-page__hit-head">
								<span class="cb-search-page__hit-title"><?php echo esc_html( get_the_title() ); ?></span>
								<span class="cb-search-page__hit-type"><?php echo esc_html( $type_lbl ); ?></span>
							</div>
							<?php if ( $excerpt !== '' ) : ?>
								<p class="cb-search-page__hit-excerpt"><?php echo esc_html( wp_html_excerpt( $excerpt, 200, '…' ) ); ?></p>
							<?php endif; ?>
						</a>
					</li>
				<?php endwhile; wp_reset_postdata(); ?>
			</ol>
		<?php endif; ?>
	</section>
	<?php

	return ob_get_clean();
}
add_shortcode( 'styrk_search_results', 'cb_search_results_shortcode' );
