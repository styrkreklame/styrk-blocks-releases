<?php
/**
 * Companion theme installer.
 *
 * Styrk Blocks ships a bundled copy of the Styrk Theme zip at
 * `assets/styrk-theme.zip`. This file:
 *
 *   1. Detects whether the Styrk Theme is installed AND active on the
 *      current site.
 *   2. Shows a single admin notice when it isn't, with a one-click
 *      "Install & activate" button (form POST to admin-post.php).
 *   3. Handles the POST: unpacks the bundled zip via WP's native
 *      Theme_Upgrader, then activates the theme, then redirects.
 *
 * This eliminates the "I forgot to install the theme" failure mode for
 * fresh WP installs that bypass the Rocket.net template workflow.
 *
 * Bundling-vs-fetching: we ship the theme zip INSIDE the plugin (instead
 * of fetching from GitHub) so the install is offline, instant, and
 * version-locked to the plugin release. Trade-off: the plugin zip is
 * ~140 KB larger than it would otherwise be.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard — see header-settings.php for the rationale.
if ( defined( 'CB_COMPANION_THEME_LOADED' ) ) return;
define( 'CB_COMPANION_THEME_LOADED', true );

const CB_COMPANION_THEME_SLUG    = 'styrk-theme';
const CB_COMPANION_THEME_ACTION  = 'cb_install_companion_theme';
const CB_COMPANION_THEME_NOTICE  = 'cb_companion_theme_notice_dismissed';

if ( ! function_exists( 'cb_companion_theme_zip_path' ) ) {
	function cb_companion_theme_zip_path(): string {
		return dirname( __DIR__ ) . '/assets/' . CB_COMPANION_THEME_SLUG . '.zip';
	}
}

if ( ! function_exists( 'cb_companion_theme_status' ) ) {
	/**
	 * @return string 'active' | 'active-stale' | 'active-drift' | 'installed' | 'installed-stale' | 'installed-drift' | 'missing'
	 *
	 * 'stale' = disk version is OLDER than bundled (forward drift, normal
	 *           "you have an update available" path).
	 * 'drift' = disk version is NEWER than bundled. Happens after an
	 *           intentional version reset (e.g. PR #45 dropped the theme
	 *           1.4.3 → 0.4.0; sites already on 1.4.x are stuck because
	 *           the standard "update" check uses `<` and won't fire on a
	 *           downgrade). The bundled zip is the source of truth, so
	 *           we surface a separate notice offering to reinstall and
	 *           overwrite the on-disk files.
	 *
	 * Detection is purely header-version comparison (Version: X.Y.Z in
	 * style.css).
	 */
	function cb_companion_theme_status(): string {
		$all       = wp_get_themes();
		$installed = $all[ CB_COMPANION_THEME_SLUG ] ?? null;
		$current   = wp_get_theme();
		$is_active = $current->get_stylesheet() === CB_COMPANION_THEME_SLUG;

		if ( ! $installed ) return 'missing';

		$bundled_version = cb_companion_theme_bundled_version();
		$disk_version    = (string) $installed->get( 'Version' );

		// Can't compare — fall back to the simple active/installed split.
		if ( $bundled_version === '' || $disk_version === '' ) {
			return $is_active ? 'active' : 'installed';
		}

		$cmp = version_compare( $disk_version, $bundled_version );
		if ( $cmp < 0 ) return $is_active ? 'active-stale' : 'installed-stale';
		if ( $cmp > 0 ) return $is_active ? 'active-drift' : 'installed-drift';
		return $is_active ? 'active' : 'installed';
	}
}

if ( ! function_exists( 'cb_companion_theme_bundled_version' ) ) {
	/**
	 * Parse Version: X.Y.Z out of the bundled theme zip's style.css
	 * without unpacking the zip to disk. Cheap enough to run on every
	 * admin pageload.
	 */
	function cb_companion_theme_bundled_version(): string {
		static $cached = null;
		if ( $cached !== null ) return $cached;

		$zip = cb_companion_theme_zip_path();
		if ( ! file_exists( $zip ) || ! class_exists( 'ZipArchive' ) ) return $cached = '';

		$archive = new \ZipArchive();
		if ( $archive->open( $zip ) !== true ) return $cached = '';

		$contents = $archive->getFromName( CB_COMPANION_THEME_SLUG . '/style.css' );
		$archive->close();
		if ( ! $contents ) return $cached = '';

		if ( preg_match( '/^\s*Version:\s*([\d.]+)/m', $contents, $m ) ) {
			return $cached = trim( $m[1] );
		}
		return $cached = '';
	}
}

/* ── Admin notice ──────────────────────────────────────────────────────── */
add_action( 'admin_notices', function () {
	if ( ! current_user_can( 'install_themes' ) ) return;

	$status = cb_companion_theme_status();
	// Don't dismiss-suppress stale or drift — both mean disk files
	// don't match the bundled source-of-truth, which causes real
	// rendering bugs (e.g. missing templates after a version reset).
	$is_mismatched = in_array( $status, [ 'active-stale', 'installed-stale', 'active-drift', 'installed-drift' ], true );
	if ( ! $is_mismatched && get_user_meta( get_current_user_id(), CB_COMPANION_THEME_NOTICE, true ) ) return;
	if ( $status === 'active' ) return;

	$bundled_exists = file_exists( cb_companion_theme_zip_path() );
	$action_url     = wp_nonce_url(
		admin_url( 'admin-post.php?action=' . CB_COMPANION_THEME_ACTION ),
		CB_COMPANION_THEME_ACTION
	);
	$dismiss_url    = wp_nonce_url(
		admin_url( 'admin-post.php?action=' . CB_COMPANION_THEME_ACTION . '_dismiss' ),
		CB_COMPANION_THEME_ACTION . '_dismiss'
	);

	$bundled_ver = cb_companion_theme_bundled_version();
	$disk_ver    = $status !== 'missing' ? (string) ( wp_get_themes()[ CB_COMPANION_THEME_SLUG ]->get( 'Version' ) ?? '' ) : '';

	switch ( $status ) {
		case 'missing':
			$button_label = __( 'Install &amp; activate Styrk Theme', 'styrk-blocks' );
			$body         = __( 'Styrk Blocks works best with its companion <strong>Styrk Theme</strong> — it provides the header, footer, and brand palette. Install it with one click.', 'styrk-blocks' );
			break;
		case 'installed':
			$button_label = __( 'Activate Styrk Theme', 'styrk-blocks' );
			$body         = __( 'Styrk Theme is installed but not active. Activate it for the proper header, footer, and brand styling.', 'styrk-blocks' );
			break;
		case 'installed-stale':
		case 'active-stale':
			$button_label = __( 'Update Styrk Theme', 'styrk-blocks' );
			$body         = sprintf(
				/* translators: 1: installed theme version, 2: bundled theme version. */
				__( 'Styrk Theme update available: <strong>%1$s → %2$s</strong>. A newer version is bundled inside the plugin. Click to upgrade.', 'styrk-blocks' ),
				esc_html( $disk_ver ),
				esc_html( $bundled_ver )
			);
			break;
		case 'installed-drift':
		case 'active-drift':
			$button_label = __( 'Reinstall Styrk Theme', 'styrk-blocks' );
			$body         = sprintf(
				/* translators: 1: installed theme version, 2: bundled theme version. */
				__( 'Styrk Theme version mismatch: <strong>%1$s on disk</strong>, <strong>%2$s bundled inside plugin</strong>. The bundled version is the source of truth — click to reinstall and sync. (Common after an intentional version reset.)', 'styrk-blocks' ),
				esc_html( $disk_ver ),
				esc_html( $bundled_ver )
			);
			break;
		default:
			return;
	}
	?>
	<div class="notice notice-warning" style="display:flex;align-items:center;gap:16px;padding:14px 16px;">
		<div style="flex:1;">
			<p style="margin:0;font-size:14px;line-height:1.5;">
				<strong>Styrk Blocks:</strong>
				<?php echo wp_kses_post( $body ); ?>
			</p>
		</div>
		<div style="display:flex;gap:8px;flex-shrink:0;">
			<?php if ( $bundled_exists || $status === 'installed' ) : ?>
				<a href="<?php echo esc_url( $action_url ); ?>" class="button button-primary">
					<?php echo esc_html( $button_label ); ?>
				</a>
			<?php else : ?>
				<span style="color:#cc1818;font-size:13px;">
					<?php esc_html_e( 'Bundled theme zip missing — reinstall the plugin.', 'styrk-blocks' ); ?>
				</span>
			<?php endif; ?>
			<a href="<?php echo esc_url( $dismiss_url ); ?>" class="button button-secondary">
				<?php esc_html_e( 'Dismiss', 'styrk-blocks' ); ?>
			</a>
		</div>
	</div>
	<?php
} );

/* ── Install + activate handler ────────────────────────────────────────── */
add_action( 'admin_post_' . CB_COMPANION_THEME_ACTION, function () {
	if ( ! current_user_can( 'install_themes' ) ) wp_die( 'Forbidden', 403 );
	check_admin_referer( CB_COMPANION_THEME_ACTION );

	$status = cb_companion_theme_status();

	// Fresh install not needed — just activate.
	if ( $status === 'installed' ) {
		switch_theme( CB_COMPANION_THEME_SLUG );
		wp_safe_redirect( admin_url( 'themes.php?activated=true' ) );
		exit;
	}

	$zip = cb_companion_theme_zip_path();
	if ( ! file_exists( $zip ) ) {
		wp_die( esc_html__( 'Bundled Styrk Theme zip not found in the plugin. Reinstall the plugin and try again.', 'styrk-blocks' ) );
	}

	// Load WP's theme installer machinery (not loaded outside the
	// theme-install screen by default).
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

	$skin     = new \Automatic_Upgrader_Skin();
	$upgrader = new \Theme_Upgrader( $skin );

	// Stale or drift: overwrite the existing theme with the bundled
	// version. WP's default install() refuses to overwrite; we pass the
	// `overwrite_package` flag via the installer's hook to allow it.
	$needs_overwrite = in_array(
		$status,
		[ 'active-stale', 'installed-stale', 'active-drift', 'installed-drift' ],
		true
	);
	if ( $needs_overwrite ) {
		$result = $upgrader->install( $zip, [ 'overwrite_package' => true ] );
	} else {
		$result = $upgrader->install( $zip );
	}

	if ( is_wp_error( $result ) ) {
		wp_die( esc_html( $result->get_error_message() ) );
	}
	if ( ! $result ) {
		$messages = method_exists( $skin, 'get_upgrade_messages' ) ? implode( ' / ', $skin->get_upgrade_messages() ) : '';
		wp_die( esc_html__( 'Theme install failed.', 'styrk-blocks' ) . ' ' . esc_html( $messages ) );
	}

	// For fresh installs, also activate. For overwrites of the
	// already-active theme (stale/drift), WP keeps it active
	// automatically — nothing else to do.
	$already_active = in_array( $status, [ 'active-stale', 'active-drift' ], true );
	if ( ! $already_active ) {
		switch_theme( CB_COMPANION_THEME_SLUG );
	}
	wp_safe_redirect( admin_url( 'themes.php?activated=true' ) );
	exit;
} );

/* ── Dismiss handler ───────────────────────────────────────────────────── */
add_action( 'admin_post_' . CB_COMPANION_THEME_ACTION . '_dismiss', function () {
	check_admin_referer( CB_COMPANION_THEME_ACTION . '_dismiss' );
	update_user_meta( get_current_user_id(), CB_COMPANION_THEME_NOTICE, 1 );
	wp_safe_redirect( wp_get_referer() ?: admin_url() );
	exit;
} );

/* ── Reset dismiss flag whenever the plugin is activated ───────────────── */
register_activation_hook( dirname( __DIR__ ) . '/styrk-blocks.php', function () {
	delete_metadata( 'user', 0, CB_COMPANION_THEME_NOTICE, '', true );
} );
