<?php
/**
 * Header Settings — admin page for logo + header appearance.
 *
 * Settings → Header lets admins manage:
 *  - Logo uploads (main header logo + white footer variant)
 *  - Header background mode (transparent overlay or solid color)
 *  - Header background color (when solid)
 *  - Header text / nav link color
 *
 * On save, the main logo also updates the `custom_logo` theme mod
 * so wp:site-logo blocks work out of the box.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// File-level idempotency guard: if this file somehow gets included twice
// (symlink setups, mu-plugins double-load, etc.) the `function` declarations
// below would fatal with "Cannot redeclare". Bail early on the second include.
if ( defined( 'CB_HEADER_SETTINGS_LOADED' ) ) return;
define( 'CB_HEADER_SETTINGS_LOADED', true );

/* ── Option key ─────────────────────────────────────────────────────────────── */
define( 'CB_HEADER_OPTION', 'cb_header_settings' );

/**
 * Default values for header settings.
 */
function cb_header_defaults(): array {
	return [
		'logo_id'        => 0,              // attachment ID — main/color logo
		// NOTE: logo_white_id USED to live here. As of v1.6.5 the white
		// (footer) logo is managed under Settings → Footer → Logo so the
		// setting sits with the rest of the footer fields (address, email,
		// credits, legal links). The key is intentionally kept in the
		// defaults array, set to 0, so any callsite that still reads it
		// gets a falsy default — the footer-logo shortcode falls through
		// to the new footer-settings key first, then header for back-compat,
		// then the theme asset.
		'logo_white_id'  => 0,
		'bg_mode'        => 'transparent',  // 'transparent' | 'solid'
		'bg_color'       => '#00486A',      // solid background color
		'text_color'     => '#ffffff',      // header text / nav link color
		'position'       => 'relative',     // 'relative' | 'sticky'
		'hide_on_scroll' => '0',            // '0' | '1' — only effective with sticky
		// How the header row distributes logo / nav / controls. Default '' =
		// INHERIT: emit nothing, so the per-block `navLayout` attribute set in
		// the template part wins. A value chosen here overrides the block
		// globally — 'spread' pushes the search + CTA cluster to the far-right
		// edge (via the flex spacer in view.tsx), 'compact' groups everything
		// on the left.
		'nav_layout'     => '',             // '' (inherit) | 'compact' | 'spread'
		// Horizontal alignment of the desktop nav LINKS within the header row,
		// independent of nav_layout: 'start' = grouped next to the logo
		// (historical default), 'center' = centered in the header, 'end' =
		// pushed to the right next to the search / CTA cluster (matches designs
		// that group the menu with the header utilities).
		'nav_align'      => 'start',        // 'start' | 'center' | 'end'
		// Header content rail width + side gutters. These let an admin line
		// the logo/nav/CTA row up with the page's content band (which varies
		// per theme). Default '' = INHERIT: emit no CSS var, so the per-block
		// `contentWidth` attribute set in the template part (e.g. hywer's
		// 1440) and the historical 1280px/52px fallback in view.tsx still win.
		// Only a value explicitly chosen here overrides the block.
		'content_width'  => '',             // '' (inherit) | '1180' | '1280' | '1440' | 'full'
		'side_pad'       => '',             // '' (inherit) | px gutter 0–120
		// Optional header CTA — when set, the theme's header script
		// renders this label/URL as a button next to the search icon.
		// Default `cta_show='1'` so existing live sites keep their
		// button even before an admin visits this page; unchecking the
		// box hides it. Label/URL empty = script falls back to its own
		// historical defaults ("Ta kontakt" → "/kontakt/").
		'cta_label'      => '',
		'cta_url'        => '',
		'cta_show'       => '1',
	];
}

/**
 * Return merged (saved + defaults) header settings.
 */
function cb_get_header_settings(): array {
	$saved = get_option( CB_HEADER_OPTION, [] );
	return wp_parse_args( $saved, cb_header_defaults() );
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_header_settings_menu(): void {
	add_options_page(
		__( 'Header Settings', 'styrk-blocks' ),
		__( 'Header', 'styrk-blocks' ),
		'manage_options',
		'cb-header-settings',
		'cb_header_settings_page'
	);
}
add_action( 'admin_menu', 'cb_header_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

function cb_header_settings_init(): void {
	register_setting( 'cb_header_group', CB_HEADER_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_header_sanitize',
		'default'           => cb_header_defaults(),
	] );

	/* ── Section: Logo ────────────────────────────────────────────────────────
	 * Only the header logo lives on this page now. The white footer logo is
	 * managed under Settings → Footer so it groups with the rest of the
	 * footer fields (address, email, copyright, legal links). */
	add_settings_section(
		'cb_header_logos',
		__( 'Logo', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Upload your site logo. SVG or PNG recommended.', 'styrk-blocks' )
		),
		'cb-header-settings'
	);

	add_settings_field(
		'cb_header_logo',
		__( 'Main Logo (header)', 'styrk-blocks' ),
		'cb_header_render_media_field',
		'cb-header-settings',
		'cb_header_logos',
		[ 'key' => 'logo_id', 'description' => __( 'Displayed in the site header. Use a white/light version if your header background is dark.', 'styrk-blocks' ) ]
	);

	/* ── Section: Appearance ─────────────────────────────────────────────────── */
	add_settings_section(
		'cb_header_appearance',
		__( 'Header Appearance', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Control how the header looks across the site. These settings apply globally.', 'styrk-blocks' )
		),
		'cb-header-settings'
	);

	add_settings_field(
		'cb_header_bg_mode',
		__( 'Background Mode', 'styrk-blocks' ),
		'cb_header_render_bg_mode_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_bg_color',
		__( 'Background Color', 'styrk-blocks' ),
		'cb_header_render_color_field',
		'cb-header-settings',
		'cb_header_appearance',
		[
			'key'         => 'bg_color',
			'description' => __( 'Used when Background Mode is set to "Solid color".', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_text_color',
		__( 'Text / Nav Color', 'styrk-blocks' ),
		'cb_header_render_color_field',
		'cb-header-settings',
		'cb_header_appearance',
		[
			'key'         => 'text_color',
			'description' => __( 'Color for the site name, navigation links, and hamburger icon.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_position',
		__( 'Position', 'styrk-blocks' ),
		'cb_header_render_position_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_hide_on_scroll',
		__( 'Hide on scroll down', 'styrk-blocks' ),
		'cb_header_render_hide_on_scroll_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_nav_layout',
		__( 'Element alignment', 'styrk-blocks' ),
		'cb_header_render_nav_layout_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_nav_align',
		__( 'Menu alignment', 'styrk-blocks' ),
		'cb_header_render_nav_align_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_content_width',
		__( 'Content width', 'styrk-blocks' ),
		'cb_header_render_content_width_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_side_pad',
		__( 'Side padding', 'styrk-blocks' ),
		'cb_header_render_side_pad_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	/* ── Section: Header CTA ─────────────────────────────────────────────────
	 * Optional button next to the search icon — label + URL configurable from
	 * the admin so the editor doesn't have to touch theme JS. */
	add_settings_section(
		'cb_header_cta',
		__( 'Header CTA', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Optional button shown next to the search icon on every page. Leave blank to hide.', 'styrk-blocks' )
		),
		'cb-header-settings'
	);

	add_settings_field(
		'cb_header_cta_show',
		__( 'Show CTA button', 'styrk-blocks' ),
		'cb_header_render_cta_show_field',
		'cb-header-settings',
		'cb_header_cta'
	);

	add_settings_field(
		'cb_header_cta_label',
		__( 'Label', 'styrk-blocks' ),
		'cb_header_render_text_field',
		'cb-header-settings',
		'cb_header_cta',
		[
			'key'         => 'cta_label',
			'placeholder' => 'Ta kontakt',
			'description' => __( 'Button text. Default: "Ta kontakt".', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_cta_url',
		__( 'URL', 'styrk-blocks' ),
		'cb_header_render_text_field',
		'cb-header-settings',
		'cb_header_cta',
		[
			'key'         => 'cta_url',
			'placeholder' => '/kontakt/',
			'description' => __( 'Where the button links. Use a relative path or full URL.', 'styrk-blocks' ),
		]
	);
}
add_action( 'admin_init', 'cb_header_settings_init' );

/* ── Field renderers ────────────────────────────────────────────────────────── */

/**
 * Media uploader field (for logos).
 */
function cb_header_render_media_field( array $args ): void {
	$settings      = cb_get_header_settings();
	$key           = $args['key'];
	$attachment_id = (int) ( $settings[ $key ] ?? 0 );
	$name          = CB_HEADER_OPTION . "[{$key}]";
	$field_id      = "cb_header_{$key}";
	$preview_url   = $attachment_id ? wp_get_attachment_image_url( $attachment_id, 'medium' ) : '';
	$description   = $args['description'] ?? '';
	$bg            = $key === 'logo_white_id' ? '#00486A' : '#f0f0f1';

	?>
	<div class="cb-media-field" id="<?php echo esc_attr( $field_id ); ?>_wrapper">
		<div class="cb-media-preview" style="margin-bottom:10px;padding:16px;background:<?php echo esc_attr( $bg ); ?>;border-radius:8px;display:<?php echo $preview_url ? 'block' : 'none'; ?>;max-width:320px;">
			<img id="<?php echo esc_attr( $field_id ); ?>_preview" src="<?php echo esc_url( $preview_url ); ?>" alt="" style="max-width:100%;max-height:120px;width:auto;height:auto;display:block;" />
		</div>
		<input type="hidden" id="<?php echo esc_attr( $field_id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $attachment_id ); ?>" />
		<button type="button" class="button cb-upload-btn" data-target="<?php echo esc_attr( $field_id ); ?>" data-preview-bg="<?php echo esc_attr( $bg ); ?>">
			<?php echo $preview_url ? esc_html__( 'Change Logo', 'styrk-blocks' ) : esc_html__( 'Upload Logo', 'styrk-blocks' ); ?>
		</button>
		<?php if ( $preview_url ) : ?>
			<button type="button" class="button cb-remove-btn" data-target="<?php echo esc_attr( $field_id ); ?>" style="margin-left:8px;color:#b32d2e;">
				<?php esc_html_e( 'Remove', 'styrk-blocks' ); ?>
			</button>
		<?php endif; ?>
		<?php if ( $description ) : ?>
			<p class="description" style="margin-top:8px;"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Background mode radio buttons.
 */
function cb_header_render_bg_mode_field(): void {
	$settings = cb_get_header_settings();
	$current  = $settings['bg_mode'] ?? 'transparent';
	$name     = CB_HEADER_OPTION . '[bg_mode]';

	$options = [
		'transparent' => __( 'Transparent (overlays hero/content)', 'styrk-blocks' ),
		'solid'       => __( 'Solid color', 'styrk-blocks' ),
	];

	echo '<fieldset>';
	foreach ( $options as $value => $label ) {
		printf(
			'<label style="display:block;margin-bottom:8px;"><input type="radio" name="%s" value="%s" %s /> %s</label>',
			esc_attr( $name ),
			esc_attr( $value ),
			checked( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</fieldset>';
	echo '<p class="description">' . esc_html__( 'Transparent works best when the first block is a hero with a dark background image.', 'styrk-blocks' ) . '</p>';
}

/**
 * Position radio buttons — relative (scrolls with the page) vs sticky
 * (pins to the top of the viewport on scroll).
 */
function cb_header_render_position_field(): void {
	$settings = cb_get_header_settings();
	$current  = $settings['position'] ?? 'relative';
	$name     = CB_HEADER_OPTION . '[position]';

	$options = [
		'relative' => __( 'Relative — scrolls away with the page', 'styrk-blocks' ),
		'sticky'   => __( 'Sticky — pins to the top of the viewport on scroll', 'styrk-blocks' ),
	];

	echo '<fieldset>';
	foreach ( $options as $value => $label ) {
		printf(
			'<label style="display:block;margin-bottom:8px;"><input type="radio" name="%s" value="%s" %s /> %s</label>',
			esc_attr( $name ),
			esc_attr( $value ),
			checked( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</fieldset>';
	echo '<p class="description">' . esc_html__( 'Sticky keeps the same starting position as relative — it only changes behaviour once the page scrolls past the header.', 'styrk-blocks' ) . '</p>';
}

/**
 * Hide-on-scroll-down toggle. Only effective when Position is "sticky" —
 * the header slides out of view as the visitor scrolls down and slides
 * back in as they scroll up. Common pattern (Medium, GitHub) that gives
 * mobile/tablet visitors more reading space.
 */
function cb_header_render_hide_on_scroll_field(): void {
	$settings = cb_get_header_settings();
	$current  = ! empty( $settings['hide_on_scroll'] ) ? '1' : '0';
	$name     = CB_HEADER_OPTION . '[hide_on_scroll]';

	printf(
		'<label><input type="checkbox" name="%s" value="1" %s /> %s</label>',
		esc_attr( $name ),
		checked( $current, '1', false ),
		esc_html__( 'Slide the header out when scrolling down, slide it back in when scrolling up', 'styrk-blocks' )
	);
	echo '<p class="description">' . esc_html__( 'Only takes effect when Position is set to "Sticky".', 'styrk-blocks' ) . '</p>';
}

/**
 * Element-alignment select — controls how the header row distributes the
 * logo, navigation and the search/CTA controls.
 *
 *  - Inherit : emit nothing; the per-block `navLayout` attribute set in the
 *              template part wins (back-compat).
 *  - Compact : logo, nav and controls grouped together on the left.
 *  - Spread  : a flex spacer (added in view.tsx) pushes the search icon and
 *              CTA button hard to the right edge of the header.
 *
 * This is the global override for the same compact/spread switch that also
 * exists as a block attribute — set it here once and every page's header
 * follows, no template editing required.
 */
function cb_header_render_nav_layout_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['nav_layout'] ?? '' );
	$name     = CB_HEADER_OPTION . '[nav_layout]';

	$options = [
		''        => __( 'Inherit — use the header block setting', 'styrk-blocks' ),
		'compact' => __( 'Compact — logo, menu and buttons grouped on the left', 'styrk-blocks' ),
		'spread'  => __( 'Spread — push search / CTA buttons to the far-right edge', 'styrk-blocks' ),
	];

	echo '<select name="' . esc_attr( $name ) . '">';
	foreach ( $options as $value => $label ) {
		printf(
			'<option value="%s" %s>%s</option>',
			esc_attr( $value ),
			selected( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'How the header row lines up its elements. "Spread" pushes the search icon and CTA button to the far right; "Compact" keeps the logo, menu and buttons together on the left.', 'styrk-blocks' ) . '</p>';
}

/**
 * Menu-alignment select — where the desktop nav links sit horizontally in the
 * header row. Independent of the compact/spread element-alignment above:
 *
 *  - Start  : links grouped right after the logo (historical default).
 *  - Center : links centered in the header row.
 *  - End    : links pushed to the right, next to the search / CTA cluster.
 */
function cb_header_render_nav_align_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['nav_align'] ?? 'start' );
	$name     = CB_HEADER_OPTION . '[nav_align]';

	$options = [
		'start'  => __( 'Start — menu next to the logo (left)', 'styrk-blocks' ),
		'center' => __( 'Center — menu centered in the header', 'styrk-blocks' ),
		'end'    => __( 'End — menu on the right, next to search / CTA', 'styrk-blocks' ),
	];

	echo '<select name="' . esc_attr( $name ) . '">';
	foreach ( $options as $value => $label ) {
		printf(
			'<option value="%s" %s>%s</option>',
			esc_attr( $value ),
			selected( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'Horizontal position of the navigation links. "End" groups the menu with the search and CTA on the right (matches the Hywer design).', 'styrk-blocks' ) . '</p>';
}

/**
 * Content-width select — the max width of the logo/nav/CTA rail. Line this
 * up with the page's content band so the logo sits flush with the content
 * below it. "Full width" stretches edge to edge (gutters only).
 */
function cb_header_render_content_width_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['content_width'] ?? '' );
	$name     = CB_HEADER_OPTION . '[content_width]';

	$options = [
		''     => __( 'Inherit — use the block/theme setting', 'styrk-blocks' ),
		'1180' => __( 'Narrow — 1180px', 'styrk-blocks' ),
		'1280' => __( 'Standard — 1280px', 'styrk-blocks' ),
		'1440' => __( 'Wide — 1440px', 'styrk-blocks' ),
		'full' => __( 'Full width — edge to edge', 'styrk-blocks' ),
	];

	echo '<select name="' . esc_attr( $name ) . '">';
	foreach ( $options as $value => $label ) {
		printf(
			'<option value="%s" %s>%s</option>',
			esc_attr( $value ),
			selected( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'Max width of the header content. Leave on "Inherit" to use the width set on the header block in the template; pick a value here to override it globally. Match it to your page content width so the logo lines up with the content below.', 'styrk-blocks' ) . '</p>';
}

/**
 * Side-padding number field — the gutter on each side of the header rail.
 * Match it to the page section gutter for pixel-perfect logo alignment.
 */
function cb_header_render_side_pad_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['side_pad'] ?? '' );
	$name     = CB_HEADER_OPTION . '[side_pad]';

	printf(
		'<input type="number" name="%s" value="%s" min="0" max="120" step="1" placeholder="%s" style="width:90px;" /> <span>px</span>',
		esc_attr( $name ),
		esc_attr( $current ),
		esc_attr__( 'inherit', 'styrk-blocks' )
	);
	echo '<p class="description">' . esc_html__( 'Horizontal gutter on each side of the header. Leave blank to inherit the block/theme default (52px); set a value to override. Match it to your content section gutter so the logo aligns with the content edge.', 'styrk-blocks' ) . '</p>';
}

/**
 * Theme colour palette (from theme.json / global settings) as a flat list of
 * { color, name } for the admin swatch picker — same palette the in-canvas
 * block colour pickers use.
 */
function cb_header_theme_palette(): array {
	$out = array();
	if ( function_exists( 'wp_get_global_settings' ) ) {
		$palette = wp_get_global_settings( array( 'color', 'palette' ) );
		$list    = array();
		if ( ! empty( $palette['theme'] ) ) {
			$list = $palette['theme'];
		} elseif ( ! empty( $palette['default'] ) ) {
			$list = $palette['default'];
		} elseif ( is_array( $palette ) && isset( $palette[0] ) ) {
			$list = $palette;
		}
		foreach ( (array) $list as $c ) {
			if ( ! empty( $c['color'] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $c['color'] ) ) {
				$out[] = array(
					'color' => $c['color'],
					'name'  => $c['name'] ?? ( $c['slug'] ?? $c['color'] ),
				);
			}
		}
	}
	return $out;
}

/**
 * Color picker field.
 */
function cb_header_render_color_field( array $args ): void {
	$settings    = cb_get_header_settings();
	$key         = $args['key'];
	$value       = $settings[ $key ] ?? '';
	$name        = CB_HEADER_OPTION . "[{$key}]";
	$field_id    = "cb_header_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<input type="color" id="%s" name="%s" value="%s" style="width:60px;height:40px;padding:2px;border:1px solid #c3c4c7;border-radius:4px;cursor:pointer;" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_attr( $value )
	);
	printf(
		'<input type="text" id="%s_hex" value="%s" style="margin-left:8px;width:90px;font-family:monospace;vertical-align:middle;" readonly />',
		esc_attr( $field_id ),
		esc_attr( $value )
	);

	// Theme-palette swatches — click to set the colour from the same theme
	// palette the in-canvas block colour pickers expose (consistent UX).
	$palette = cb_header_theme_palette();
	if ( $palette ) {
		echo '<div class="cb-theme-swatches" style="display:flex;flex-wrap:wrap;gap:6px;margin-top:10px;align-items:center;">';
		echo '<span style="font-size:12px;color:#646970;margin-right:2px;">' . esc_html__( 'Temafarger:', 'styrk-blocks' ) . '</span>';
		foreach ( $palette as $swatch ) {
			printf(
				'<button type="button" class="cb-theme-swatch" data-target="%s" data-color="%s" title="%s" aria-label="%s" style="width:26px;height:26px;border-radius:4px;border:1px solid rgba(0,0,0,0.2);background:%s;cursor:pointer;padding:0;"></button>',
				esc_attr( $field_id ),
				esc_attr( $swatch['color'] ),
				esc_attr( $swatch['name'] ),
				esc_attr( $swatch['name'] ),
				esc_attr( $swatch['color'] )
			);
		}
		echo '</div>';
	}

	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/**
 * Generic text input — driven by `key`, `placeholder`, `description` args.
 */
function cb_header_render_text_field( array $args ): void {
	$settings    = cb_get_header_settings();
	$key         = $args['key'];
	$value       = $settings[ $key ] ?? '';
	$placeholder = $args['placeholder'] ?? '';
	$description = $args['description'] ?? '';
	$name        = CB_HEADER_OPTION . "[{$key}]";
	$field_id    = "cb_header_{$key}";

	printf(
		'<input type="text" id="%s" name="%s" value="%s" placeholder="%s" class="regular-text" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_attr( $value ),
		esc_attr( $placeholder )
	);
	if ( $description ) {
		printf( '<p class="description">%s</p>', esc_html( $description ) );
	}
}

/**
 * CTA show-toggle — same checkbox pattern as hide_on_scroll above.
 */
function cb_header_render_cta_show_field(): void {
	$settings = cb_get_header_settings();
	$current  = ! empty( $settings['cta_show'] ) ? '1' : '0';
	$name     = CB_HEADER_OPTION . '[cta_show]';

	printf(
		'<label><input type="checkbox" name="%s" value="1" %s /> %s</label>',
		esc_attr( $name ),
		checked( $current, '1', false ),
		esc_html__( 'Render the CTA button in the header', 'styrk-blocks' )
	);
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

function cb_header_sanitize( $input ): array {
	$defaults  = cb_header_defaults();
	$sanitized = [];

	/* Logos — integer IDs */
	$sanitized['logo_id']       = isset( $input['logo_id'] )       ? absint( $input['logo_id'] )       : $defaults['logo_id'];
	$sanitized['logo_white_id'] = isset( $input['logo_white_id'] ) ? absint( $input['logo_white_id'] ) : $defaults['logo_white_id'];

	/* Background mode — whitelist */
	$sanitized['bg_mode'] = isset( $input['bg_mode'] ) && in_array( $input['bg_mode'], [ 'transparent', 'solid' ], true )
		? $input['bg_mode']
		: $defaults['bg_mode'];

	/* Position — whitelist */
	$sanitized['position'] = isset( $input['position'] ) && in_array( $input['position'], [ 'relative', 'sticky' ], true )
		? $input['position']
		: $defaults['position'];

	/* Hide-on-scroll — checkbox is "1" when present, absent when off */
	$sanitized['hide_on_scroll'] = ! empty( $input['hide_on_scroll'] ) ? '1' : '0';

	/* Element alignment — '' (inherit) or a whitelisted layout. Inherit means
	   "don't override the block", so the template part's navLayout wins. */
	$sanitized['nav_layout'] = isset( $input['nav_layout'] ) && in_array( $input['nav_layout'], [ 'compact', 'spread' ], true )
		? $input['nav_layout']
		: '';

	/* Menu alignment — whitelist start/center/end, fall back to historical 'start'. */
	$sanitized['nav_align'] = isset( $input['nav_align'] ) && in_array( $input['nav_align'], [ 'start', 'center', 'end' ], true )
		? $input['nav_align']
		: $defaults['nav_align'];

	/* Content width — whitelist of presets, fall back to historical 1280 */
	/* Content width — '' (inherit) or a whitelisted preset. Inherit means
	   "don't emit a CSS var", so the block/template value wins. */
	$sanitized['content_width'] = isset( $input['content_width'] ) && in_array( $input['content_width'], [ '1180', '1280', '1440', 'full' ], true )
		? $input['content_width']
		: '';

	/* Side padding — '' (inherit) or integer px clamped to 0–120. A blank
	   field stays blank (inherit) rather than snapping to 0. */
	$sanitized['side_pad'] = ( isset( $input['side_pad'] ) && '' !== trim( (string) $input['side_pad'] ) )
		? (string) max( 0, min( 120, absint( $input['side_pad'] ) ) )
		: '';

	/* Header CTA — label/url plain text, show toggle as "1"/"0". */
	$sanitized['cta_label'] = isset( $input['cta_label'] ) ? sanitize_text_field( (string) $input['cta_label'] ) : $defaults['cta_label'];
	$sanitized['cta_url']   = isset( $input['cta_url'] )   ? esc_url_raw( (string) $input['cta_url'] )           : $defaults['cta_url'];
	$sanitized['cta_show']  = ! empty( $input['cta_show'] ) ? '1' : '0';

	/* Colors — must be valid hex */
	foreach ( [ 'bg_color', 'text_color' ] as $color_key ) {
		if ( isset( $input[ $color_key ] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $input[ $color_key ] ) ) {
			$sanitized[ $color_key ] = $input[ $color_key ];
		} else {
			$sanitized[ $color_key ] = $defaults[ $color_key ];
		}
	}

	/* Sync main logo to the custom_logo theme mod so wp:site-logo works */
	if ( ! empty( $sanitized['logo_id'] ) ) {
		set_theme_mod( 'custom_logo', $sanitized['logo_id'] );
	}

	return $sanitized;
}

/* ── Admin page template ────────────────────────────────────────────────────── */

function cb_header_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	wp_enqueue_media();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Header Settings', 'styrk-blocks' ); ?></h1>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'cb_header_group' );
			do_settings_sections( 'cb-header-settings' );
			submit_button();
			?>
		</form>
	</div>

	<script>
	(function($){
		'use strict';

		/* ── Media upload ───────────────────────────────────────────────────── */
		$(document).on('click', '.cb-upload-btn', function(e) {
			e.preventDefault();
			var btn      = $(this);
			var targetId = btn.data('target');
			var bgColor  = btn.data('preview-bg') || '#f0f0f1';
			var frame    = wp.media({
				title:    '<?php echo esc_js( __( 'Select Logo', 'styrk-blocks' ) ); ?>',
				button:   { text: '<?php echo esc_js( __( 'Use as Logo', 'styrk-blocks' ) ); ?>' },
				multiple: false,
				library:  { type: ['image', 'image/svg+xml'] }
			});

			frame.on('select', function() {
				var attachment = frame.state().get('selection').first().toJSON();
				var previewUrl = attachment.sizes && attachment.sizes.medium
					? attachment.sizes.medium.url
					: attachment.url;

				$('#' + targetId).val(attachment.id);
				$('#' + targetId + '_preview').attr('src', previewUrl);
				$('#' + targetId + '_wrapper .cb-media-preview')
					.css({ display: 'block', background: bgColor }).show();
				btn.text('<?php echo esc_js( __( 'Change Logo', 'styrk-blocks' ) ); ?>');

				if ( ! btn.siblings('.cb-remove-btn').length ) {
					$('<button type="button" class="button cb-remove-btn" data-target="' + targetId + '" style="margin-left:8px;color:#b32d2e;"><?php echo esc_js( __( 'Remove', 'styrk-blocks' ) ); ?></button>')
						.insertAfter(btn);
				}
			});
			frame.open();
		});

		$(document).on('click', '.cb-remove-btn', function(e) {
			e.preventDefault();
			var targetId = $(this).data('target');
			$('#' + targetId).val('0');
			$('#' + targetId + '_preview').attr('src', '');
			$('#' + targetId + '_wrapper .cb-media-preview').hide();
			$(this).siblings('.cb-upload-btn').text('<?php echo esc_js( __( 'Upload Logo', 'styrk-blocks' ) ); ?>');
			$(this).remove();
		});

		/* ── Sync color picker → hex text ───────────────────────────────────── */
		$('input[type="color"]').on('input change', function() {
			$('#' + this.id + '_hex').val(this.value);
		});

		/* ── Theme-palette swatch → set colour + hex ────────────────────────── */
		$(document).on('click', '.cb-theme-swatch', function(e) {
			e.preventDefault();
			var targetId = $(this).data('target');
			var color    = String($(this).data('color'));
			$('#' + targetId).val(color);
			$('#' + targetId + '_hex').val(color);
		});
	})(jQuery);
	</script>
	<?php
}

/* ── Seed defaults on first load ────────────────────────────────────────────── */

function cb_header_seed_defaults(): void {
	if ( get_option( CB_HEADER_OPTION ) ) {
		return;
	}
	update_option( CB_HEADER_OPTION, cb_header_defaults() );
}
add_action( 'admin_init', 'cb_header_seed_defaults' );

/* ── Output header CSS vars to <head> ───────────────────────────────────────── */

function cb_header_output_css_vars(): void {
	$s = cb_get_header_settings();

	$bg_mode    = $s['bg_mode'] ?? 'transparent';
	$bg_color   = $s['bg_color'] ?? '#00486A';
	$text_color = $s['text_color'] ?? '#ffffff';

	$bg_value = $bg_mode === 'solid' ? $bg_color : 'transparent';

	$vars  = '--cb-header-bg:' . esc_attr( $bg_value ) . ';';
	$vars .= '--cb-header-text:' . esc_attr( $text_color ) . ';';
	$vars .= '--cb-header-bg-mode:' . esc_attr( $bg_mode ) . ';';

	// Content rail width + side gutter → CSS vars consumed by the React
	// header (view.tsx). These are emitted ONLY when an admin explicitly
	// chose a value here. When left on "Inherit" (empty), no var is emitted,
	// so the per-block `contentWidth` attribute set in the template part
	// (e.g. hywer's 1440) and view.tsx's historical 1280px/52px fallback
	// keep working — the global setting never silently clobbers a block.
	$content_width = (string) ( $s['content_width'] ?? '' );
	if ( in_array( $content_width, [ '1180', '1280', '1440', 'full' ], true ) ) {
		$max_width = $content_width === 'full' ? 'none' : $content_width . 'px';
		$vars .= '--cb-header-max-width:' . esc_attr( $max_width ) . ';';
	}

	$side_pad = (string) ( $s['side_pad'] ?? '' );
	if ( '' !== $side_pad && is_numeric( $side_pad ) ) {
		$vars .= '--cb-header-side-pad:' . esc_attr( $side_pad . 'px' ) . ';';
	}

	printf( '<style id="cb-header-vars">:root{%s}</style>' . "\n", $vars );
}
add_action( 'wp_head', 'cb_header_output_css_vars', 1 );
