# Produktpresentasjonen

En 16:9 PDF som forklarer Styrk Blocks — til intern onboarding og til å vise
fram produktet.

```bash
npm run mockup     # bygg PDF + én PNG per slide → mockup/build/
```

Ingen WordPress, ingen nettverk, ingen skjermbilder å holde ved like. Alt
genereres fra repoet og fra CSS. `mockup/build/` er gitignorert; CI bygger
presentasjonen på hver kjøring og laster den opp som artefakten
**styrk-blocks-presentasjon**.

## Hva som leses fra repoet

| Innhold | Kilde |
|---|---|
| Versjonsnummer | `styrk-blocks.php` |
| Blokkliste, navn og beskrivelser | `src/blocks/*/block.json` |
| Kvalitetsportene | `package.json` + `composer.json` |
| Ratchet-tallene | `scripts/*-gate.js` |

Legger noen til en blokk, står den i katalogen neste gang decket bygges.
Beskrivelsene er de samme tekstene kunden ser i innsetteren — ett sted å
vedlikeholde, ikke to.

## Alt er tegnet

Hver illustrasjon er en wireframe bygget av CSS: bilderamme med kryss over,
tekstlinjer, knapper, ikoner, avatarer. Byggeklossene ligger øverst i
`scripts/mockup.js`, og wireframene for hver blokk i `WIRES`.

**Hvorfor ikke ekte skjermbilder?** To grunner, begge lært den harde veien:

1. Ekte skjermbilder blandet med skjematiske diagrammer leser som to
   dokumenter limt sammen. Ett visuelt språk er bedre enn to gode halvdeler.
2. Et skjermbilde binder presentasjonen til ett bestemt nettsted. Styrk Blocks
   er nøytral og ser ut som kundens merkevare — poenget er strukturen, ikke
   hvordan den ser ut hos én kunde. Bruker vi en kundes nettsted som
   utstillingsvindu, sier vi det motsatte av slide 3.

Det gjelder også kontrollbåndet i editoren: det tegnes med de samme
pille-knappene som anatomidiagrammene, ikke fotograferes.

Én konsekvens er verdt å kjenne til: **wireframene er hardkodet.** Endrer en
blokk struktur, må wireframen oppdateres for hånd. De viser grovformen — kort,
kolonner, rutenett — så det skjer sjelden, men de følger ikke koden slik
blokklista gjør.

## Filene

| Sti | Hva |
|---|---|
| `deck.css` | All styling. Slidene er 1920×1080, wireframe-språket ligger nederst. |
| `fonts/` | Barlow Condensed, Poppins, Oswald — selvhostet, så CI rendrer likt uten nett. |
| `logo-white.png`, `logo-black.png` | Fra `design-system/assets/`. |

## Merkevare

Decket bruker **Styrk Reklames egen** profil — mørk grønn `#0a2020`, amber
`#f0a83c`, cream `#f1ece1`, og Barlow Condensed / Poppins / Oswald. Det er
riktig her, fordi det er vårt eget produkt som presenteres.

Det er ikke det samme som pluginens farger. Styrk Blocks er nøytral og henter
alt fra kundens `theme.json` — som er hele poenget med slide 3.
