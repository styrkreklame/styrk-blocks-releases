<?php
/**
 * Opening hours as DATA, not as a sentence.
 *
 * The hours used to be one free-text box: "Mandag – Fredag: 08.00 – 16.00" on
 * one line, "Lørdag – Søndag: Stengt" on the next. That renders fine and is
 * unreadable to everything else — Google, an assistant answering "når har de
 * åpent?", or a future opening-hours widget all get a string that would have
 * to be parsed back into days and times, in Norwegian, with whatever dash and
 * time format the admin happened to use.
 *
 * So each weekday is stored as three values: open/closed, from, to. The footer
 * renders them into the same lines as before by collapsing consecutive days
 * that share their hours ("Mandag–fredag: 08.00–16.00"), and
 * openingHoursSpecification is emitted straight from the same numbers.
 *
 * The old free-text value is kept and still rendered on any site that has not
 * filled the per-day fields, so nothing goes blank on update.
 *
 * @package styrk-blocks
 */

namespace Styrk\Blocks\Footer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Weekdays in week order: option-key suffix => [ translated label, schema.org day ].
 *
 * @return array<string, array{0:string,1:string}>
 */
function hour_days(): array {
	return [
		'mon' => [ __( 'Monday', 'styrk-blocks' ), 'Monday' ],
		'tue' => [ __( 'Tuesday', 'styrk-blocks' ), 'Tuesday' ],
		'wed' => [ __( 'Wednesday', 'styrk-blocks' ), 'Wednesday' ],
		'thu' => [ __( 'Thursday', 'styrk-blocks' ), 'Thursday' ],
		'fri' => [ __( 'Friday', 'styrk-blocks' ), 'Friday' ],
		'sat' => [ __( 'Saturday', 'styrk-blocks' ), 'Saturday' ],
		'sun' => [ __( 'Sunday', 'styrk-blocks' ), 'Sunday' ],
	];
}

/**
 * Normalise a typed time to 24h "HH:MM", or '' when it is not a time.
 *
 * Accepts what admins actually type: "8", "8.00", "08:00", "0800".
 *
 * @param string $raw Raw field value.
 * @return string
 */
function normalise_time( string $raw ): string {
	$raw = trim( $raw );
	if ( '' === $raw ) {
		return '';
	}
	if ( preg_match( '/^(\d{1,2})[.:]?(\d{2})?$/', $raw, $m ) ) {
		$h = (int) $m[1];
		$i = isset( $m[2] ) ? (int) $m[2] : 0;
		if ( $h > 23 || $i > 59 ) {
			return '';
		}
		return sprintf( '%02d:%02d', $h, $i );
	}
	return '';
}

/**
 * The week as stored: one entry per day, in week order.
 *
 * @param array $settings Footer settings.
 * @return array<int, array{key:string,label:string,schema:string,open:bool,from:string,to:string}>
 */
function hour_week( array $settings ): array {
	$week = [];
	foreach ( hour_days() as $key => list( $label, $schema_day ) ) {
		$week[] = [
			'key'    => $key,
			'label'  => $label,
			'schema' => $schema_day,
			'open'   => ! empty( $settings[ "hours_{$key}_open" ] ),
			'from'   => normalise_time( (string) ( $settings[ "hours_{$key}_from" ] ?? '' ) ),
			'to'     => normalise_time( (string) ( $settings[ "hours_{$key}_to" ] ?? '' ) ),
		];
	}
	return $week;
}

/**
 * Has anyone actually filled the per-day fields?
 *
 * Decides whether to use them or fall back to the legacy free-text box.
 *
 * @param array $settings Footer settings.
 * @return bool
 */
function hours_are_set( array $settings ): bool {
	foreach ( hour_week( $settings ) as $day ) {
		if ( $day['open'] && '' !== $day['from'] && '' !== $day['to'] ) {
			return true;
		}
	}
	return false;
}

/**
 * The week as display lines, consecutive days with equal hours collapsed.
 *
 * "Mandag–fredag: 08.00–16.00" / "Lørdag–søndag: Stengt" — the same shape the
 * free-text box was used to write by hand.
 *
 * @param array $settings Footer settings.
 * @return string[]
 */
function hour_lines( array $settings ): array {
	$week   = hour_week( $settings );
	$lines  = [];
	$run    = [];

	$flush = static function () use ( &$run, &$lines ) {
		if ( ! $run ) {
			return;
		}
		$first = $run[0];
		$last  = $run[ count( $run ) - 1 ];
		$days  = count( $run ) === 1
			? $first['label']
			// En dash between day names, as Norwegian typography wants.
			: $first['label'] . '–' . mb_strtolower( $last['label'] );
		$when  = $first['open']
			? str_replace( ':', '.', $first['from'] ) . '–' . str_replace( ':', '.', $first['to'] )
			: __( 'Closed', 'styrk-blocks' );
		$lines[] = $days . ': ' . $when;
		$run     = [];
	};

	foreach ( $week as $day ) {
		$same = $run
			&& $run[0]['open'] === $day['open']
			&& $run[0]['from'] === $day['from']
			&& $run[0]['to'] === $day['to'];
		if ( ! $same ) {
			$flush();
		}
		$run[] = $day;
	}
	$flush();

	return $lines;
}

/**
 * schema.org openingHoursSpecification for the week.
 *
 * Closed days are emitted too (opens = closes = "00:00"), because "closed on
 * Sunday" is an answer, and leaving the day out only says "unknown".
 *
 * @param array $settings Footer settings.
 * @return array<int, array<string, mixed>>
 */
function hours_schema( array $settings ): array {
	if ( ! hours_are_set( $settings ) ) {
		return [];
	}

	$spec = [];
	foreach ( hour_week( $settings ) as $day ) {
		if ( $day['open'] && '' !== $day['from'] && '' !== $day['to'] ) {
			$spec[] = [
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => 'https://schema.org/' . $day['schema'],
				'opens'     => $day['from'],
				'closes'    => $day['to'],
			];
			continue;
		}
		// Closed all day: opens = closes = "00:00" is Google's documented way to
		// say so (developers.google.com/search/docs/appearance/structured-data/local-business,
		// "Specify a business that is closed all day"). Do not change it.
		$spec[] = [
			'@type'     => 'OpeningHoursSpecification',
			'dayOfWeek' => 'https://schema.org/' . $day['schema'],
			'opens'     => '00:00',
			'closes'    => '00:00',
		];
	}
	return $spec;
}

/**
 * LocalBusiness JSON-LD built from the footer's own contact details.
 *
 * The site already carries an Organization node (SmartCrawl's, or a theme's),
 * but nothing machine-readable said where the company is, when it is open or
 * how to phone it — the footer had all three as plain text. This adds one
 * node, linked to the site by @id, so a search engine or an assistant asked
 * "når har de åpent?" has an actual answer.
 *
 * Emitted only when there is something to say: no hours and no address means
 * no node, rather than an empty shell claiming to describe a business.
 */
/**
 * A PostalAddress from the footer's address text: one line per row or comma,
 * the last "1234 City" line becomes postcode + locality (without a postcode the last line is the locality), the rest the street.
 *
 * @param string $address Address text.
 * @return array<string,string>
 */
function postal_address( string $address ): array {
	$lines  = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n|,/', $address ) ), 'strlen' ) );
	$postal = [ '@type' => 'PostalAddress', 'addressCountry' => 'NO' ];
	$last   = end( $lines );
	if ( $last && preg_match( '/^(\d{4})\s+(.+)$/u', $last, $m ) ) {
		$postal['postalCode']      = $m[1];
		$postal['addressLocality'] = $m[2];
		array_pop( $lines );
	} elseif ( $last && count( $lines ) > 1 ) {
		// No postcode line: the last line is still the place.
		$postal['addressLocality'] = $last;
		array_pop( $lines );
	}
	if ( $lines ) {
		$postal['streetAddress'] = implode( ', ', $lines );
	}
	return $postal;
}

/**
 * schema.org areaServed from the footer's "Area served" text. Comma-separated
 * values become a list; a recognised country name is a Country, anything else
 * (a county, a region, a city) an AdministrativeArea. One value stays a single
 * object, several become an array.
 *
 * @param string $text Raw setting.
 * @return array<int|string,mixed>|null Null when nothing is set.
 */
function area_served( string $text ): ?array {
	$countries = [ 'norge', 'norway', 'sverige', 'sweden', 'danmark', 'denmark', 'finland', 'island', 'iceland' ];
	$areas     = [];
	foreach ( array_unique( array_filter( array_map( 'trim', explode( ',', $text ) ), static fn( string $v ): bool => '' !== $v ) ) as $name ) {
		$lower   = function_exists( 'mb_strtolower' ) ? mb_strtolower( $name, 'UTF-8' ) : strtolower( $name );
		$areas[] = [
			'@type' => in_array( $lower, $countries, true ) ? 'Country' : 'AdministrativeArea',
			'name'  => $name,
		];
	}
	if ( ! $areas ) {
		return null;
	}
	return 1 === count( $areas ) ? $areas[0] : $areas;
}

/**
 * Profile URLs of the published social_link posts, for schema.org sameAs.
 *
 * @return string[]
 */
function social_profile_urls(): array {
	if ( ! function_exists( 'get_posts' ) ) {
		return [];
	}
	$urls = [];
	foreach ( (array) get_posts( [ 'post_type' => 'social_link', 'post_status' => 'publish', 'posts_per_page' => 20, 'orderby' => 'menu_order', 'order' => 'ASC' ] ) as $post ) {
		$url = esc_url_raw( trim( (string) get_post_meta( $post->ID, '_cb_social_url', true ) ) );
		if ( '' !== $url ) {
			$urls[] = $url;
		}
	}
	return array_values( array_unique( $urls ) );
}

/**
 * The site's logo (custom logo, else site icon) as a schema.org ImageObject.
 *
 * @return array<string,string>|null
 */
function logo_object(): ?array {
	$url  = '';
	$logo = (int) get_theme_mod( 'custom_logo' );
	if ( $logo > 0 ) {
		$url = (string) wp_get_attachment_image_url( $logo, 'full' );
	}
	if ( '' === $url && function_exists( 'get_site_icon_url' ) ) {
		$url = (string) get_site_icon_url( 512 );
	}
	$url = esc_url_raw( $url );
	return '' === $url ? null : [ '@type' => 'ImageObject', 'url' => $url ];
}

/** True when SmartCrawl prints its own Organization node (@id #schema-publishing-organization). */
function smartcrawl_active(): bool {
	return defined( 'SMARTCRAWL_PLUGIN_DIR' ) || class_exists( 'Smartcrawl_Loader', false );
}

add_action( 'wp_head', __NAMESPACE__ . '\\print_local_business_schema', 20 );
function print_local_business_schema(): void {
	if ( ! function_exists( 'cb_get_footer_settings' ) || is_admin() ) {
		return;
	}

	$s       = cb_get_footer_settings();
	$address = trim( (string) ( $s['address'] ?? '' ) );
	$hours   = hours_schema( $s );

	$address_2 = trim( (string) ( $s['address_2'] ?? '' ) );
	if ( ! $hours && '' === $address && '' === $address_2 ) {
		return;
	}

	$node = [
		'@context' => 'https://schema.org',
		'@type'    => 'LocalBusiness',
		'@id'      => home_url( '/#local-business' ),
		'name'     => get_bloginfo( 'name' ),
		'url'      => home_url( '/' ),
	];

	if ( '' !== $address ) {
		// One line per row in the footer field; schema wants a street line and
		// (where the last line looks like "7500 Stjørdal") a postcode + city.
		// Split on newlines AND commas: "Krogstads veg 11, 7500 Stjørdal" is
		// one line to the admin but a street and a postcode to schema.org.
		$node['address'] = postal_address( $address );
	}

	$phone = trim( (string) ( $s['phone_1'] ?? '' ) );
	if ( '' !== $phone ) {
		$node['telephone'] = $phone;
	}

	$email = trim( (string) ( $s['email'] ?? '' ) );
	if ( '' !== $email ) {
		$node['email'] = $email;
	}

	$org = preg_replace( '/\D+/', '', (string) ( $s['org_number'] ?? '' ) );
	if ( 9 === strlen( (string) $org ) ) {
		// Norwegian organisasjonsnummer — vatID is what consumers look for.
		$node['vatID'] = 'NO' . $org;
	}

	if ( $hours ) {
		$node['openingHoursSpecification'] = $hours;
	}

	$area = area_served( (string) ( $s['area_served'] ?? '' ) );
	if ( $area ) {
		$node['areaServed'] = $area;
	}

	$same_as = social_profile_urls();
	if ( $same_as ) {
		$node['sameAs'] = $same_as;
	}

	$logo = logo_object();
	if ( $logo ) {
		$node['logo'] = $logo;
	}

	if ( smartcrawl_active() ) {
		// Link to SmartCrawl's Organization node instead of printing a second,
		// unrelated organisation.
		$node['parentOrganization'] = [ '@id' => home_url( '/#schema-publishing-organization' ) ];
	}

	if ( '' !== $address_2 ) {
		// A second location is a department; the main address stays address 1.
		$dept = [
			'@type'   => 'LocalBusiness',
			'@id'     => home_url( '/#local-business-2' ),
			'name'    => trim( get_bloginfo( 'name' ) . ' ' . trim( (string) ( $s['address_2_heading'] ?? '' ) ) ),
			'address' => postal_address( $address_2 ),
		];
		foreach ( [ 'telephone' => $node['telephone'] ?? '', 'email' => $node['email'] ?? '' ] as $k => $v ) {
			if ( '' !== $v ) {
				$dept[ $k ] = $v;
			}
		}
		$dept['parentOrganization'] = [ '@id' => $node['@id'] ];
		if ( $area ) {
			$dept['areaServed'] = $area;
		}
		$node['department'] = [ $dept ];
	}

	printf(
		"<script type=\"application/ld+json\">%s</script>\n",
		wp_json_encode( $node, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
	);
}
