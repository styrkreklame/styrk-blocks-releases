<?php
/**
 * Search results page — server-rendered shortcode.
 *
 * `[styrk_search_results]` outputs the entire body of the
 * `?s=query` results page: a navy hero band with eyebrow +
 * Norwegian h1 ("Søkeresultater for «query»"), a list of result
 * cards (title + post-type chip + excerpt), and a clearly-styled
 * "no results" empty state.
 *
 * This replaces the WP `core/query-title` + `core/query` block
 * combination in `templates/search.html`. Reasons we don't lean on
 * core blocks here:
 *
 * 1. `core/query-title` outputs the literal English string "Search
 *    results for:" with no locale fallback short of switching the
 *    site to nb_NO. The shortcode hardcodes the Norwegian wording.
 * 2. `core/query` with `inherit:true` runs the main query, which on
 *    a search request silently filters by the default-searchable
 *    post types only — the empty-state message inside
 *    `query-no-results` was rendering with zero spacing on staging,
 *    making the whole page look broken when no results matched.
 *    The shortcode renders an explicit, styled empty state.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_SEARCH_RENDER_LOADED' ) ) return;
define( 'CB_SEARCH_RENDER_LOADED', true );

/**
 * Map a post type slug to its Norwegian display label. Used on each
 * result card's post-type chip ("Side", "Innlegg", "Ansatt").
 */
function cb_search_post_type_label( string $slug ): string {
	$map = [
		'page'     => 'Side',
		'post'     => 'Innlegg',
		'employee' => 'Ansatt',
		'project'  => 'Prosjekt',
		// WooCommerce's own label is only Norwegian when its nb_NO language
		// pack is installed; never show "Product" on a Norwegian site.
		'product'  => 'Produkt',
	];
	if ( isset( $map[ $slug ] ) ) {
		return $map[ $slug ];
	}
	// Other post types (e.g. WooCommerce products) use their registered,
	// already translated label ("Produkt"), never the raw slug.
	$obj = get_post_type_object( $slug );
	return $obj ? (string) $obj->labels->singular_name : ucfirst( $slug );
}

/**
 * WP_Query arguments for a site search. Shared by the search page and the
 * header's live search (REST), so the two can never disagree about what
 * matches — the header overlay used to filter titles/excerpts client-side
 * and said "Ingen treff" for words the search page found.
 *
 * @param string $query Search terms (already sanitised).
 * @param int    $limit Max hits.
 * @return array<string, mixed>
 */
function cb_search_query_args( string $query, int $limit ): array {
	return [
		's'              => $query,
		'post_status'    => 'publish',
		'posts_per_page' => max( 1, min( 100, $limit ) ),
		'no_found_rows'  => false,
	];
}

if ( ! function_exists( 'cb_search_thumb' ) ) {
	/**
	 * The small image of a hit: the featured image in a registered small size
	 * (WooCommerce's catalogue size for products when the shop defines it,
	 * else the core thumbnail), with the alt text of the attachment.
	 *
	 * @param int    $attachment_id Featured image, 0 for none.
	 * @param string $post_type     Post type of the hit.
	 * @return array{url: string, alt: string}|null Null when there is no image.
	 */
	function cb_search_thumb( int $attachment_id, string $post_type ): ?array {
		if ( $attachment_id <= 0 ) {
			return null;
		}
		$size = 'product' === $post_type && function_exists( 'has_image_size' ) && has_image_size( 'woocommerce_thumbnail' )
			? 'woocommerce_thumbnail'
			: 'thumbnail';
		$src  = wp_get_attachment_image_src( $attachment_id, $size );
		if ( ! is_array( $src ) || empty( $src[0] ) ) {
			return null;
		}
		return [
			'url' => (string) $src[0],
			'alt' => trim( wp_strip_all_tags( (string) get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ) ) ),
		];
	}
}

/**
 * One search hit: title, URL, post-type label and a plain-text excerpt, plus
 * `thumb` (small image URL + alt) when the post has a featured image. Hits
 * without one carry no `thumb` key at all.
 *
 * The excerpt is built from the RENDERED blocks (dynamic blocks keep their
 * text in render callbacks; some imported content is HTML-encoded; block
 * delimiters are HTML comments wp_strip_all_tags would keep), and cached
 * per post revision because rendering is not cheap for live search.
 *
 * @param WP_Post $post Post.
 * @return array{id: int, title: string, url: string, type: string, typeLabel: string, excerpt: string, thumb?: array{url: string, alt: string}}
 */
function cb_search_hit( WP_Post $post ): array {
	$cache_key = 'cb_search_excerpt_' . $post->ID . '_' . md5( (string) $post->post_modified_gmt );
	$excerpt   = get_transient( $cache_key );
	if ( ! is_string( $excerpt ) ) {
		$source  = html_entity_decode( (string) $post->post_content, ENT_QUOTES | ENT_HTML5 );
		$excerpt = wp_trim_words( wp_strip_all_tags( do_blocks( $source ) ), 30, '…' );
		set_transient( $cache_key, $excerpt, WEEK_IN_SECONDS );
	}
	$hit   = [
		'id'        => (int) $post->ID,
		'title'     => wp_strip_all_tags( get_the_title( $post ) ),
		'url'       => (string) get_permalink( $post ),
		'type'      => (string) $post->post_type,
		'typeLabel' => cb_search_post_type_label( (string) $post->post_type ),
		'excerpt'   => $excerpt,
	];
	$thumb = cb_search_thumb( (int) get_post_thumbnail_id( $post ), (string) $post->post_type );
	if ( $thumb ) {
		$hit['thumb'] = $thumb;
	}
	return $hit;
}

if ( ! function_exists( 'cb_search_hit_link_html' ) ) {
	/**
	 * The link of one hit on the search page. With an image the link gets a
	 * square image well to the left of title and excerpt; without one the
	 * markup is what it always was.
	 *
	 * @param array<string, mixed> $hit From cb_search_hit().
	 * @return string HTML.
	 */
	function cb_search_hit_link_html( array $hit ): string {
		$thumb   = isset( $hit['thumb'] ) && is_array( $hit['thumb'] ) ? $hit['thumb'] : null;
		$excerpt = '' !== (string) $hit['excerpt']
			? '<span class="cb-search-page__hit-excerpt">' . esc_html( wp_html_excerpt( (string) $hit['excerpt'], 200, '…' ) ) . '</span>'
			: '';
		$text    = '<span class="cb-search-page__hit-head"><span class="cb-search-page__hit-title">' . esc_html( (string) $hit['title'] ) . '</span><span class="cb-search-page__hit-type">' . esc_html( (string) $hit['typeLabel'] ) . '</span></span>' . $excerpt;
		if ( ! $thumb ) {
			return '<a href="' . esc_url( (string) $hit['url'] ) . '" class="cb-search-page__hit-link">' . $text . '</a>';
		}
		return '<a href="' . esc_url( (string) $hit['url'] ) . '" class="cb-search-page__hit-link cb-search-page__hit-link--thumb">'
			. '<span class="cb-search-page__hit-thumb"><img src="' . esc_url( (string) $thumb['url'] ) . '" alt="' . esc_attr( (string) $thumb['alt'] ) . '" width="80" height="80" loading="lazy" decoding="async"></span>'
			. '<span class="cb-search-page__hit-body">' . $text . '</span></a>';
	}
}

/**
 * Normalise live-search request params: trimmed, sanitised, capped.
 *
 * @param mixed $q     Raw query.
 * @param mixed $limit Raw limit.
 * @return array{q: string, limit: int}
 */
function cb_search_api_params( $q, $limit ): array {
	$q = trim( sanitize_text_field( is_string( $q ) ? $q : '' ) );
	return [
		'q'     => function_exists( 'mb_substr' ) ? mb_substr( $q, 0, 100 ) : substr( $q, 0, 100 ),
		'limit' => max( 1, min( 10, (int) $limit ?: 7 ) ),
	];
}

/**
 * GET /wp-json/styrk/v1/search?q=…&limit=… — the header's live search.
 * Public and read-only: exactly what the public search page shows.
 */
add_action(
	'rest_api_init',
	static function () {
		register_rest_route(
			'styrk/v1',
			'/search',
			[
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'args'                => [
					'q'     => [ 'type' => 'string', 'required' => true ],
					'limit' => [ 'type' => 'integer', 'default' => 7 ],
				],
				'callback'            => static function ( WP_REST_Request $request ) {
					$p = cb_search_api_params( $request->get_param( 'q' ), $request->get_param( 'limit' ) );
					if ( strlen( $p['q'] ) < 2 ) {
						return rest_ensure_response( [ 'query' => $p['q'], 'total' => 0, 'hits' => [] ] );
					}
					$query = new WP_Query( cb_search_query_args( $p['q'], $p['limit'] ) );
					return rest_ensure_response(
						[
							'query' => $p['q'],
							'total' => (int) $query->found_posts,
							'hits'  => array_map( 'cb_search_hit', $query->posts ),
						]
					);
				},
			]
		);
	}
);

function cb_search_results_shortcode(): string {
	$query   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
	$trimmed = trim( $query );

	// Pull editable copy from Settings → Search (with built-in
	// Norwegian fallbacks). Fall back to defaults defensively if
	// search-settings.php failed to load — never render blank copy.
	$settings = function_exists( 'cb_get_search_settings' )
		? cb_get_search_settings()
		: [];
	$defaults = function_exists( 'cb_search_defaults' )
		? cb_search_defaults()
		: [];
	$copy = static function ( string $key ) use ( $settings, $defaults ): string {
		$v = (string) ( $settings[ $key ] ?? $defaults[ $key ] ?? '' );
		return $v;
	};

	$heading = $trimmed === ''
		? $copy( 'heading_no_query' )
		: str_replace( '{query}', $trimmed, $copy( 'heading_with_query' ) );

	ob_start();
	?>
	<section class="cb-search-page__hero">
		<div class="cb-search-page__hero-inner">
			<p class="cb-eyebrow cb-search-page__eyebrow"><?php echo esc_html( $copy( 'eyebrow_text' ) ); ?></p>
			<h1 class="cb-search-page__heading"><?php echo esc_html( $heading ); ?></h1>

			<form role="search" method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="cb-search-page__form">
				<label class="screen-reader-text" for="cb-search-page-input"><?php echo esc_html( $copy( 'form_button' ) ); ?></label>
				<input type="search" id="cb-search-page-input" name="s" value="<?php echo esc_attr( $trimmed ); ?>" placeholder="<?php echo esc_attr( $copy( 'form_placeholder' ) ); ?>" autocomplete="off">
				<button type="submit"><?php echo esc_html( $copy( 'form_button' ) ); ?></button>
			</form>
		</div>
	</section>
	<?php

	if ( $trimmed === '' ) {
		?>
		<section class="cb-search-page__body">
			<p class="cb-search-page__hint"><?php echo esc_html( $copy( 'hint_no_query' ) ); ?></p>
		</section>
		<?php
		return ob_get_clean();
	}

	// Run the search query manually so we control which post types
	// are searched + the explicit empty handling.
	$ppp      = (int) ( $settings['posts_per_page'] ?? $defaults['posts_per_page'] ?? 20 );
	$wp_query = new WP_Query( cb_search_query_args( $trimmed, $ppp ) );

	$empty_line = str_replace( '{query}', $trimmed, $copy( 'empty_line' ) );
	?>
	<section class="cb-search-page__body">
		<?php if ( ! $wp_query->have_posts() ) : ?>
			<div class="cb-search-page__empty">
				<p class="cb-search-page__empty-line"><?php echo esc_html( $empty_line ); ?></p>
				<p class="cb-search-page__empty-hint">
					<?php echo esc_html( $copy( 'empty_hint' ) ); ?>
					<?php
					/* translators: bridge connecting the suggestion sentence to the inline home link. Kept fixed because it is grammatical filler, not editorial copy. */
					esc_html_e( 'You can also', 'styrk-blocks' );
					?>
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php echo esc_html( $copy( 'empty_back_label' ) ); ?></a>.
				</p>
			</div>
		<?php else : ?>
			<p class="cb-search-page__count">
				<?php
				$count = (int) $wp_query->found_posts;
				if ( $count === 1 ) {
					echo '1 treff';
				} else {
					echo esc_html( $count ) . ' treff';
				}
				?>
			</p>
			<ol class="cb-search-page__list">
				<?php while ( $wp_query->have_posts() ) : $wp_query->the_post();
					$hit = cb_search_hit( get_post() );
				?>
					<li class="cb-search-page__hit"><?php echo cb_search_hit_link_html( $hit ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in cb_search_hit_link_html(). ?></li>
				<?php endwhile; wp_reset_postdata(); ?>
			</ol>
		<?php endif; ?>
	</section>
	<?php

	$out = ob_get_clean();

	// Collapse whitespace between HTML tags. WordPress runs `wpautop` over
	// shortcode output as part of the_content filter, which sees the
	// indentation/newlines in our buffered output and inserts <p>/</p>
	// pairs that break the anchor structure (auto-closing <a> when a
	// "block" element appears inside). Stripping inter-tag whitespace
	// gives wpautop nothing to grab. Safe because the output is purely
	// structural — no significant text whitespace between tags.
	// trim(): a leading newline became a stray <br> above the band.
	return trim( (string) preg_replace( '/>\s+</', '><', $out ) );
}
add_shortcode( 'styrk_search_results', 'cb_search_results_shortcode' );
