<?php
/**
 * Hero block: the «Innganger» (entry cards) element.
 *
 * Kept out of template.php so it can be tested without rendering a page.
 * Opt-in: with no `entries` the helpers return nothing, so a hero saved
 * before the element existed renders exactly as before.
 *
 * @package styrk-blocks
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_hero_clean_entries' ) ) {
	/**
	 * The entries worth rendering: arrays with a title or a link text.
	 *
	 * @param mixed $raw The saved `entries` attribute.
	 * @return array<int, array{icon:string,title:string,linkText:string,url:string,highlight:bool}>
	 */
	function cb_hero_clean_entries( $raw ): array {
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$entries = array();
		foreach ( $raw as $entry ) {
			if ( ! is_array( $entry ) ) {
				continue;
			}
			$title     = (string) ( $entry['title'] ?? '' );
			$link_text = (string) ( $entry['linkText'] ?? '' );
			if ( '' === trim( wp_strip_all_tags( $title ) ) && '' === trim( wp_strip_all_tags( $link_text ) ) ) {
				continue;
			}
			$entries[] = array(
				'icon'      => preg_replace( '/[^a-z0-9\-]/', '', strtolower( (string) ( $entry['icon'] ?? '' ) ) ),
				'title'     => $title,
				'linkText'  => $link_text,
				'url'       => (string) ( $entry['url'] ?? '' ),
				'highlight' => ! empty( $entry['highlight'] ),
			);
		}
		// One card is highlighted at most: the first one flagged wins.
		$seen = false;
		foreach ( $entries as $i => $entry ) {
			if ( $entry['highlight'] && $seen ) {
				$entries[ $i ]['highlight'] = false;
			}
			$seen = $seen || $entry['highlight'];
		}
		return $entries;
	}
}

if ( ! function_exists( 'cb_hero_render_entries' ) ) {
	/**
	 * Markup for the entry cards, or '' when there are none.
	 *
	 * Every card is ONE link (a stretched link over the whole card) with the
	 * title and the link text as its name. A card without a URL is plain text.
	 *
	 * @param array $attributes Hero block attributes.
	 * @return string Escaped HTML.
	 */
	function cb_hero_render_entries( array $attributes ): string {
		$entries = cb_hero_clean_entries( $attributes['entries'] ?? array() );
		if ( ! $entries ) {
			return '';
		}
		$inline = array(
			'br'     => array(),
			'em'     => array(),
			'strong' => array(),
		);
		$html   = '<ul class="cb-hero__entries" role="list">';
		foreach ( $entries as $entry ) {
			$icon = '' !== $entry['icon'] ? cb_render_icon_sized( $entry['icon'], 24 ) : '';
			$url  = '' !== $entry['url'] ? esc_url( $entry['url'] ) : '';
			$tag  = '' !== $url ? 'a' : 'span';

			$html .= '<li class="cb-hero__entry' . ( $entry['highlight'] ? ' is-highlight' : '' ) . '">';
			if ( '' !== $icon ) {
				$html .= '<span class="cb-hero__entry-icon" aria-hidden="true">' . $icon . '</span>';
			}
			$html .= '<span class="cb-hero__entry-text">';
			$html .= '<' . $tag . ' class="cb-hero__entry-link"' . ( '' !== $url ? ' href="' . esc_url( $url ) . '"' : '' ) . '>';
			if ( '' !== trim( wp_strip_all_tags( $entry['title'] ) ) ) {
				$html .= '<span class="cb-hero__entry-title">' . wp_kses( $entry['title'], $inline ) . '</span>';
			}
			if ( '' !== trim( wp_strip_all_tags( $entry['linkText'] ) ) ) {
				$html .= '<span class="cb-hero__entry-cta">' . wp_kses( $entry['linkText'], $inline );
				if ( '' !== $url ) {
					$html .= '<span class="cb-hero__entry-arrow" aria-hidden="true">' . cb_render_icon_sized( 'arrow-right', 16 ) . '</span>';
				}
				$html .= '</span>';
			}
			$html .= '</' . $tag . '>';
			$html .= '</span></li>';
		}
		return $html . '</ul>';
	}
}
