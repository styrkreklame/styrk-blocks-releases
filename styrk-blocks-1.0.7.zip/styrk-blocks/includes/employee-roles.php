<?php
/**
 * Employee job titles: ONE source of truth, the `employee_role` taxonomy.
 *
 * Before this, a title lived in two places: the `employee_role` terms
 * (admin column «Roller», grid pills, inline editing) and the legacy
 * `_cb_occupation` text meta («Stilling»). They overlapped, were not linked,
 * and editing one changed nothing in the other. Now:
 *
 *  - every reader goes through cb_employee_roles() (terms first, the legacy
 *    meta only as a read-only fallback for posts not migrated yet);
 *  - every writer writes the terms;
 *  - cb_employee_migrate_occupation_to_roles() copies old titles into terms
 *    once (idempotent), leaving `_cb_occupation` in place as the fallback.
 *
 * @package styrk-blocks
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_employee_occupation_parts' ) ) {
	/**
	 * Split a legacy occupation string into role labels, keeping the
	 * separator the editor typed after each one ("," / " og" / " |").
	 * Pill styles ignore it; themes that show roles as plain text print it,
	 * so "Japanske biler, veteranbiler" never loses its comma.
	 *
	 * @param string $occupation Raw `_cb_occupation` value.
	 * @return array<int,array{label:string,sep:string}>
	 */
	function cb_employee_occupation_parts( string $occupation ): array {
		$chunks = preg_split( '/(\s+og\s+|,|\|)/u', $occupation, -1, PREG_SPLIT_DELIM_CAPTURE ) ?: [];
		$parts  = [];
		$count  = count( $chunks );
		for ( $i = 0; $i < $count; $i += 2 ) {
			$label = trim( $chunks[ $i ] );
			if ( '' === $label ) {
				continue;
			}
			$delim   = isset( $chunks[ $i + 1 ] ) ? trim( $chunks[ $i + 1 ] ) : '';
			$parts[] = [
				'label' => $label,
				'sep'   => ( '' === $delim || ',' === $delim ) ? $delim : ' ' . $delim,
			];
		}
		if ( $parts ) {
			// Nothing follows the last role.
			$parts[ count( $parts ) - 1 ]['sep'] = '';
		}
		return $parts;
	}
}

if ( ! function_exists( 'cb_employee_role_parts' ) ) {
	/**
	 * Roles of one employee as label + separator, in render order.
	 *
	 * Terms first. Only when none are tagged is the legacy `_cb_occupation`
	 * string split (with its typed separators), so un-migrated posts still show
	 * their title.
	 *
	 * @param int $post_id Employee post ID.
	 * @return array<int,array{label:string,sep:string}>
	 */
	function cb_employee_role_parts( int $post_id ): array {
		$terms = get_the_terms( $post_id, 'employee_role' );
		if ( $terms && ! is_wp_error( $terms ) ) {
			$parts = [];
			foreach ( $terms as $term ) {
				$parts[] = [ 'label' => (string) $term->name, 'sep' => '' ];
			}
			return $parts;
		}
		return cb_employee_occupation_parts( (string) get_post_meta( $post_id, '_cb_occupation', true ) );
	}
}

if ( ! function_exists( 'cb_employee_roles' ) ) {
	/**
	 * Role labels of one employee, in render order.
	 *
	 * @param int $post_id Employee post ID.
	 * @return string[]
	 */
	function cb_employee_roles( int $post_id ): array {
		return array_column( cb_employee_role_parts( $post_id ), 'label' );
	}
}

if ( ! function_exists( 'cb_employee_roles_text' ) ) {
	/**
	 * Roles as one plain line ("Daglig leder, Selger"), for places that show or
	 * emit a single title string (schema.org jobTitle, contact lists, search).
	 *
	 * @param int $post_id Employee post ID.
	 * @return string
	 */
	function cb_employee_roles_text( int $post_id ): string {
		return implode( ', ', cb_employee_roles( $post_id ) );
	}
}

if ( ! function_exists( 'cb_employee_set_roles' ) ) {
	/**
	 * Replace an employee's roles with the names in a comma-separated string.
	 * The one writer for the classic admin box.
	 *
	 * @param int    $post_id    Employee post ID.
	 * @param string $comma_list e.g. "Daglig leder, Selger".
	 */
	function cb_employee_set_roles( int $post_id, string $comma_list ): void {
		$names = array_values( array_filter( array_map( 'trim', explode( ',', $comma_list ) ) ) );
		wp_set_object_terms( $post_id, $names, 'employee_role', false );
		// An explicit «no title» must not let the legacy text come back as the
		// fallback, so it is cleared together with the terms.
		if ( ! $names ) {
			update_post_meta( $post_id, '_cb_occupation', '' );
		}
	}
}

if ( ! function_exists( 'cb_employee_migrate_occupation_to_roles' ) ) {
	/**
	 * Copy legacy `_cb_occupation` titles into `employee_role` terms.
	 *
	 * Only employees with NO role terms and a non-empty occupation are touched,
	 * so terms an editor already set are never overwritten and a second run
	 * changes nothing. `_cb_occupation` is kept as the read-only fallback.
	 * Safe to call from WP-CLI: `wp eval 'cb_employee_migrate_occupation_to_roles();'`.
	 *
	 * @return int Number of employees migrated.
	 */
	function cb_employee_migrate_occupation_to_roles(): int {
		$posts = get_posts( [
			'post_type'      => 'employee',
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'no_found_rows'  => true,
		] );

		$migrated = 0;
		foreach ( (array) $posts as $post ) {
			$post_id = (int) $post;
			$terms   = get_the_terms( $post_id, 'employee_role' );
			if ( $terms && ! is_wp_error( $terms ) ) {
				continue;
			}
			$labels = array_column( cb_employee_occupation_parts( (string) get_post_meta( $post_id, '_cb_occupation', true ) ), 'label' );
			if ( ! $labels ) {
				continue;
			}
			$result = wp_set_object_terms( $post_id, $labels, 'employee_role', false );
			if ( ! is_wp_error( $result ) ) {
				++$migrated;
			}
		}
		return $migrated;
	}
}

if ( ! function_exists( 'cb_employee_maybe_migrate_roles' ) ) {
	/**
	 * Run the migration once per site (versioned flag), in wp-admin.
	 */
	function cb_employee_maybe_migrate_roles(): void {
		if ( '1' === (string) get_option( 'cb_employee_roles_migrated', '' ) ) {
			return;
		}
		cb_employee_migrate_occupation_to_roles();
		update_option( 'cb_employee_roles_migrated', '1', false );
	}
	add_action( 'admin_init', 'cb_employee_maybe_migrate_roles' );
}
