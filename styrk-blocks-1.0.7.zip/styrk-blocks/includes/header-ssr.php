<?php
/**
 * Server-rendered header — bar markup (SSR slice 2).
 *
 * PHP port of the closed-state markup ReactHeader (react-header/view.tsx)
 * renders: menu, search and dropdowns shut, page not scrolled. It must stay
 * DOM-identical to the client output for the same props; HeaderSsrBarTest
 * checks that against tests/fixtures/header-bar/*.html, which
 * ssr-parity.test.tsx renders from the real component.
 *
 * Dormant: nothing calls this on the front end yet. It is switched on (behind
 * cb_header_settings['ssr']) once the megamenu, dropdowns and search
 * behaviour are ported too — see
 * HiveMind (styrkreklame/hivemind, plugins/hivemind/projects/styrk-blocks/docs/specs/2026-09-30-server-rendered-header.md).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_header_ssr_style' ) ) {
	/**
	 * Inline style from ordered camelCase declarations, serialised the way
	 * React does (kebab-case, Webkit prefix, null values dropped).
	 *
	 * @param array<string, string|int|float|null> $decl Declarations.
	 * @return string Escaped attribute value.
	 */
	function cb_header_ssr_style( array $decl ): string {
		$out = [];
		foreach ( $decl as $prop => $value ) {
			if ( null === $value ) {
				continue;
			}
			$name  = strtolower( (string) preg_replace( '/([A-Z])/', '-$1', $prop ) );
			$out[] = $name . ':' . $value;
		}
		return esc_attr( implode( ';', $out ) );
	}
}

if ( ! function_exists( 'cb_header_ssr_icon' ) ) {
	/**
	 * Header icons, byte-for-byte what the client renders.
	 *
	 * @param string $name hamburger|close|search|user|basket|chevron|chevron-open.
	 * @param int    $size Icon size (search, user, basket).
	 * @return string
	 */
	function cb_header_ssr_icon( string $name, int $size = 22 ): string {
		switch ( $name ) {
			case 'hamburger':
				return '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><line x1="4" y1="9" x2="28" y2="9"></line><line x1="4" y1="16" x2="28" y2="16"></line><line x1="4" y1="23" x2="28" y2="23"></line></svg>';
			case 'close':
				return '<svg width="32" height="32" viewBox="0 0 32 32" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><line x1="6" y1="6" x2="26" y2="26"></line><line x1="26" y1="6" x2="6" y2="26"></line></svg>';
			case 'search':
				return sprintf( '<svg width="%1$d" height="%1$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="11" cy="11" r="7"></circle><line x1="21" y1="21" x2="16.5" y2="16.5"></line></svg>', $size );
			case 'user':
				return sprintf( '<svg width="%1$d" height="%1$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="8" r="4"></circle><path d="M4 21c0-4.4 3.6-8 8-8s8 3.6 8 8"></path></svg>', $size );
			case 'basket':
				return sprintf( '<svg width="%1$d" height="%1$d" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9h18l-1.6 10.2a1 1 0 0 1-1 .8H5.6a1 1 0 0 1-1-.8L3 9z"></path><path d="M8 9l3-5M16 9l-3-5"></path></svg>', $size );
			case 'chevron-open':
				return '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="transition:transform 0.2s;transform:rotate(180deg);flex-shrink:0" aria-hidden="true"><polyline points="1,4 6,8 11,4"></polyline></svg>';
			case 'chevron':
				return '<svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="transition:transform 0.2s;transform:rotate(0deg);flex-shrink:0" aria-hidden="true"><polyline points="1,4 6,8 11,4"></polyline></svg>';
		}
		return '';
	}
}

if ( ! function_exists( 'cb_header_ssr_cart_label' ) ) {
	/**
	 * Accessible name of the basket link, e.g. «Kurv, 3 varer».
	 * Mirrors cartAriaLabel() in src/blocks/react-header/shop.ts.
	 *
	 * @param string $label Visible label.
	 * @param int    $count Items in the basket.
	 * @return string
	 */
	function cb_header_ssr_cart_label( string $label, int $count ): string {
		if ( $count <= 0 ) {
			return $label;
		}
		return $label . ', ' . $count . ( 1 === $count ? ' vare' : ' varer' );
	}
}

if ( ! function_exists( 'cb_header_ssr_cart_badge' ) ) {
	/**
	 * Text of the basket count badge. Mirrors cartBadgeText() in shop.ts.
	 *
	 * @param int $count Items in the basket.
	 * @return string
	 */
	function cb_header_ssr_cart_badge( int $count ): string {
		return $count > 99 ? '99+' : (string) $count;
	}
}

if ( ! function_exists( 'cb_header_ssr_search_field' ) ) {
	/**
	 * The inline search field (Settings → Header → Search: «Search field»).
	 * Desktop only: below the nav breakpoint CSS shows the icon trigger.
	 *
	 * @param array<string, mixed> $p      Header props.
	 * @param string               $color  Nav colour.
	 * @param int|string           $margin marginLeft of the search cluster.
	 * @return string HTML.
	 */
	function cb_header_ssr_search_field( array $p, string $color, $margin ): string {
		$placeholder = (string) ( $p['searchPlaceholder'] ?? '' );
		$h  = '<form class="rh-search-field' . ( 'center' === (string) ( $p['searchAlign'] ?? '' ) ? ' rh-search-field--center' : '' ) . '" role="search" action="/" method="get" aria-label="Søk på siden" data-rh="searchfield" style="' . cb_header_ssr_style(
			[
				'marginLeft' => $margin,
				'flexShrink' => 0,
				'color'      => $color,
			]
		) . '">';
		$h .= '<label class="rh-visually-hidden" for="rh-search-field-input">Søk</label>';
		$h .= '<input id="rh-search-field-input" class="rh-search-field__input" type="search" name="s" placeholder="' . esc_attr( $placeholder ) . '" autocomplete="off" spellcheck="false" value="" style="' . cb_header_ssr_style(
			[ 'borderRadius' => (int) ( $p['ctaRadius'] ?? 0 ) . 'px' ]
		) . '"/>';
		$h .= '<button type="submit" class="rh-search-field__submit" aria-label="Søk">' . cb_header_ssr_icon( 'search', 20 ) . '</button>';
		return $h . '</form>';
	}
}

if ( ! function_exists( 'cb_header_ssr_extra_links' ) ) {
	/**
	 * Own links in the bar (Settings → Header → Extra links), drawn like the
	 * log in link: same box, type, hover and focus. Desktop only; the open
	 * menu carries them below the breakpoint.
	 *
	 * @param array<string, mixed> $p     Header props.
	 * @param string               $color Nav colour.
	 * @return string HTML, '' when there are none.
	 */
	function cb_header_ssr_extra_links( array $p, string $color ): string {
		$links = is_array( $p['extraLinks'] ?? null ) ? $p['extraLinks'] : [];
		if ( ! $links ) {
			return '';
		}
		$style = cb_header_ssr_style( [ 'color' => $color ] );
		$h     = '<div class="rh-extra-links">';
		foreach ( $links as $link ) {
			$tab = ! empty( $link['newTab'] );
			$h  .= '<a class="rh-shop-link rh-extra-link" href="' . esc_url( (string) ( $link['url'] ?? '' ) ) . '"' . ( $tab ? ' target="_blank" rel="noopener"' : '' ) . ' style="' . $style . '">'
				. '<span class="rh-shop-link__label">' . esc_html( (string) ( $link['label'] ?? '' ) ) . '</span>'
				. ( $tab ? '<span class="rh-visually-hidden"> (åpnes i ny fane)</span>' : '' )
				. '</a>';
		}
		return $h . '</div>';
	}
}

if ( ! function_exists( 'cb_header_ssr_shop_links' ) ) {
	/**
	 * Account and basket links (Settings → Header → Shop). The account link
	 * is desktop only (the mobile menu carries it); the basket stays in the
	 * bar next to the menu button, icon only, below the nav breakpoint.
	 *
	 * @param array<string, mixed> $p     Header props.
	 * @param string               $color Nav colour.
	 * @return string HTML.
	 */
	function cb_header_ssr_shop_links( array $p, string $color ): string {
		$count      = max( 0, (int) ( $p['cartCount'] ?? 0 ) );
		$cart_label = (string) ( $p['cartLabel'] ?? '' );
		$style      = cb_header_ssr_style( [ 'color' => $color ] );
		$h          = '<div class="rh-shop-links">';
		$h         .= '<a class="rh-shop-link rh-shop-link--account" href="' . esc_attr( (string) ( $p['accountUrl'] ?? '' ) ) . '" data-rh="account" style="' . $style . '">'
			. cb_header_ssr_icon( 'user', 22 )
			. '<span class="rh-shop-link__label">' . esc_html( (string) ( $p['accountLabel'] ?? '' ) ) . '</span></a>';
		$h         .= '<a class="rh-shop-link rh-shop-link--cart" href="' . esc_attr( (string) ( $p['cartUrl'] ?? '' ) ) . '" aria-label="' . esc_attr( cb_header_ssr_cart_label( $cart_label, $count ) ) . '" data-rh="cart" data-rh-cart data-rh-cart-label="' . esc_attr( $cart_label ) . '" style="' . $style . '">'
			. '<span class="rh-shop-link__icon">' . cb_header_ssr_icon( 'basket', 22 )
			. '<span class="rh-cart-count" aria-hidden="true" data-rh-cart-count' . ( $count > 0 ? '' : ' hidden' ) . '>' . esc_html( cb_header_ssr_cart_badge( $count ) ) . '</span></span>'
			. '<span class="rh-shop-link__label">' . esc_html( $cart_label ) . '</span></a>';
		return $h . '</div>';
	}
}

if ( ! function_exists( 'cb_header_ssr_bar' ) ) {
	/**
	 * The header bar, closed state.
	 *
	 * @param array<string, mixed> $p     The props view.tsx receives (same keys).
	 * @param array<string, mixed> $state menuOpen / scrolled / dropdown (default: closed, top).
	 * @param bool                 $live  Page output: every dropdown panel rendered, hidden.
	 * @return string HTML.
	 */
	function cb_header_ssr_bar( array $p, array $state = [], bool $live = false ): string {
		$menu_open = ! empty( $state['menuOpen'] );
		$scrolled  = ! empty( $state['scrolled'] );
		$str  = static fn ( string $k ): string => (string) ( $p[ $k ] ?? '' );
		$bool = static fn ( string $k ): bool => ! empty( $p[ $k ] );

		$two_rows   = 'two_rows' === $str( 'barLayout' );
		$is_overlay = $bool( 'isOverlay' );
		$solidify   = $bool( 'solidifyOnScroll' );
		$nav_align  = $str( 'navAlign' );
		$nav_layout = $str( 'navLayout' );
		$colors     = cb_header_colors(
			[
				'bgMode'           => $str( 'bgMode' ),
				'bgColor'          => $str( 'bgColor' ),
				'textColor'        => $str( 'textColor' ),
				'solidifyOnScroll' => $solidify,
				'scrolled'         => $scrolled,
				'menuOpen'         => $menu_open,
				'mobileMenuBg'     => $str( 'mobileMenuBg' ),
				'mobileMenuText'   => $str( 'mobileMenuText' ),
			]
		);
		$nav_color      = $colors['navColor'];
		// Mirrors view.tsx: the nav carries its own auto-margins.
		$nav_margin     = ( 'center' === $nav_align || 'end' === $nav_align ) ? 'auto' : null;
		$nav_margin_r   = ( 'start' === $nav_align || 'center' === $nav_align ) ? 'auto' : null;
		$content_width  = $str( 'contentWidth' );
		$logo_url       = $str( 'logoUrl' );
		$mega_logo_url  = $str( 'megaMenuLogoUrl' );
		$mega_logo_col  = $str( 'megaMenuLogoColor' );

		$h  = '<div class="site-header-react' . ( $two_rows ? ' rh-bar--two-rows' : '' ) . '" data-rh="bar" style="' . cb_header_ssr_style(
			[
				'position'   => $is_overlay ? 'absolute' : ( $solidify ? 'fixed' : 'relative' ),
				'top'        => 0,
				'left'       => 0,
				'right'      => 0,
				'height'     => $two_rows ? 'auto' : '100px',
				'display'    => 'flex',
				'alignItems' => 'stretch',
				'background' => $colors['headerBg'],
				'zIndex'     => 10000,
				'boxSizing'  => 'border-box',
				'transition' => 'background 0.2s ease, transform 0.32s cubic-bezier(0.32, 0.72, 0, 1)',
				'color'      => $nav_color,
			]
		) . '">';
		$h .= '<div style="' . cb_header_ssr_style(
			[
				'maxWidth'   => 'var(--cb-header-max-width, ' . ( 'full' === $content_width ? 'none' : $content_width . 'px' ) . ')',
				'width'      => '100%',
				'margin'     => '0 auto',
				'padding'    => '0 var(--cb-header-side-pad, var(--cb-rail, 52px))',
				'display'    => 'flex',
				'flexDirection' => $two_rows ? 'column' : null,
				'alignItems' => $two_rows ? 'stretch' : 'center',
				'gap'        => $two_rows ? '0' : '48px',
				'boxSizing'  => 'border-box',
			]
		) . '">';
		// Two rows: logo, search, shop and button on the first; the menu on the second.
		if ( $two_rows ) {
			$h .= '<div class="rh-bar-row1" style="' . cb_header_ssr_style(
				[
					'display'    => 'flex',
					'alignItems' => 'center',
					'gap'        => '48px',
					'minHeight'  => '80px',
					'minWidth'   => 0,
				]
			) . '">';
		}

		// Logo.
		$h .= '<a href="/" aria-label="Hjem" style="display:flex;align-items:center;text-decoration:none;flex-shrink:0">';
		if ( '' !== $logo_url ) {
			$h .= '<span class="rh-logo-stack" style="position:relative;display:inline-flex;align-items:center">';
			$logo_hidden = $menu_open && ( '' !== $mega_logo_url || 'colored' !== $mega_logo_col );
			$h          .= '<img src="' . esc_attr( $logo_url ) . '" alt="' . esc_attr( $str( 'logoAlt' ) ) . '" class="rh-logo" data-rh="logo" style="' . cb_header_ssr_style(
				[
					'opacity'    => $logo_hidden ? 0 : 1,
					'transition' => 'opacity 0.2s ease',
				]
			) . '"/>';
			if ( '' !== $mega_logo_url ) {
				$h .= '<img aria-hidden="true" src="' . esc_attr( $mega_logo_url ) . '" alt="" class="rh-logo rh-logo-mega" data-rh="logo-mega" style="' . cb_header_ssr_style(
					[
						'position'       => 'absolute',
						'inset'          => 0,
						'width'          => '100%',
						'height'         => '100%',
						'objectFit'      => 'contain',
						'objectPosition' => 'left center',
						'opacity'        => $menu_open ? 1 : 0,
						'transition'     => 'opacity 0.2s ease',
						'pointerEvents'  => 'none',
					]
				) . '"/>';
			} else {
				$mask = 'url(' . $logo_url . ')';
				$h   .= '<span aria-hidden="true" class="rh-logo-mask" data-rh="logo-mask" style="' . cb_header_ssr_style(
					[
						'position'           => 'absolute',
						'inset'              => 0,
						'background'         => 'black' === $mega_logo_col ? '#000' : '#fff',
						'WebkitMaskImage'    => $mask,
						'maskImage'          => $mask,
						'WebkitMaskSize'     => 'contain',
						'maskSize'           => 'contain',
						'WebkitMaskRepeat'   => 'no-repeat',
						'maskRepeat'         => 'no-repeat',
						'WebkitMaskPosition' => 'left center',
						'maskPosition'       => 'left center',
						'opacity'            => $menu_open && 'colored' !== $mega_logo_col ? 1 : 0,
						'transition'         => 'opacity 0.2s ease',
						'pointerEvents'      => 'none',
					]
				) . '"></span>';
			}
			$h .= '</span>';
		} else {
			$h .= '<span data-rh="sitename" style="' . cb_header_ssr_style(
				[
					'color'         => $nav_color,
					'fontSize'      => '32px',
					'fontWeight'    => 700,
					'letterSpacing' => '-0.02em',
				]
			) . '">Bedriftsnavn</span>';
		}
		$h .= '</a>';

		// Desktop nav. (Two rows: built here, placed on the second row below.)
		$h_bar = $h;
		$h     = '';
		$nav_style = cb_header_ssr_style(
			[
				'display'    => 'flex',
				'alignItems' => 'center',
				'gap'        => '36px',
				'marginLeft' => $nav_margin,
				'marginRight' => $nav_margin_r,
			]
		);
		$top = is_array( $p['topNavLinks'] ?? null ) ? $p['topNavLinks'] : [];
		$nav = is_array( $p['navLinks'] ?? null ) ? $p['navLinks'] : [];
		if ( $top ) {
			$h .= '<nav class="rh-desktop-nav rh-desktop-nav--flat" style="' . $nav_style . '">';
			foreach ( $top as $link ) {
				$h .= '<a href="' . esc_attr( (string) ( $link['href'] ?? '' ) ) . '" class="rh-desktop-link" data-rh="navflat" style="' . cb_header_ssr_style(
					[
						'color'          => $nav_color,
						'textDecoration' => 'none',
						'fontWeight'     => 600,
						'fontSize'       => '15px',
						'whiteSpace'     => 'nowrap',
						'display'        => $two_rows ? 'inline-flex' : null,
						'alignItems'     => $two_rows ? 'center' : null,
						'minHeight'      => $two_rows ? '48px' : null,
					]
				) . '">' . esc_html( (string) ( $link['label'] ?? '' ) ) . '</a>';
			}
			$h .= '</nav>';
		} elseif ( $nav ) {
			$link_style = cb_header_ssr_style(
				[
					'color'          => $nav_color . 'e0',
					'textDecoration' => 'none',
					'fontSize'       => '18px',
					'fontWeight'     => 500,
					'letterSpacing'  => '0.01em',
					'display'        => 'flex',
					'alignItems'     => 'center',
					'gap'            => '6px',
					'padding'        => '6px 0',
					'background'     => 'none',
					'border'         => 'none',
					'cursor'         => 'pointer',
					'fontFamily'     => 'inherit',
					'position'       => 'relative',
					'transition'     => 'color 0.15s',
					'minHeight'      => $two_rows ? '48px' : null,
				]
			);
			$panel = cb_header_panel_style( $str( 'bgColor' ), $is_overlay );
			// Two rows: the panel takes the header's own (solid) colours.
			$start_tone = $two_rows ? [
				'bg'     => $str( 'bgColor' ),
				'color'  => cb_header_colors( [ 'bgMode' => 'solid', 'bgColor' => $str( 'bgColor' ), 'textColor' => $str( 'textColor' ) ] )['navColor'],
				'radius' => (int) ( $p['ctaRadius'] ?? 0 ),
			] : null;
			$h    .= '<nav class="rh-desktop-nav" style="' . $nav_style . '">';
			foreach ( array_values( $nav ) as $i => $link ) {
				$href  = esc_attr( (string) ( $link['href'] ?? '' ) );
				$label = esc_html( (string) ( $link['label'] ?? '' ) );
				if ( ! empty( $link['children'] ) ) {
					$dd      = isset( $state['dropdown']['nav'] ) && (int) $state['dropdown']['nav'] === $i ? $state['dropdown'] : null;
					$is_open = null !== $dd;
					$h      .= '<div style="position:relative" data-rh-dd><a href="' . $href . '" class="rh-desktop-link" data-rh="navdd" style="' . $link_style . '" aria-expanded="' . ( $is_open ? 'true' : 'false' ) . '" aria-haspopup="true">' . $label . cb_header_ssr_icon( $is_open ? 'chevron-open' : 'chevron' ) . '</a>';
					if ( $is_open || $live ) {
						$h .= cb_header_ssr_dropdown_panel( (array) $link['children'], $panel, $dd['item'] ?? null, (string) ( $dd['side'] ?? 'right' ), ! $is_open, false, $start_tone );
					}
					$h .= '</div>';
				} else {
					$h .= '<a href="' . $href . '" class="rh-desktop-link" data-rh="navdd" style="' . $link_style . '">' . $label . '</a>';
				}
			}
			$h .= '</nav>';
		}

		$nav_html = $h;
		$h        = $h_bar . ( $two_rows ? '' : $nav_html );

		if ( ! $two_rows && 'spread' === $nav_layout && 'start' === $nav_align ) {
			$h .= '<div style="flex:1" aria-hidden="true"></div>';
		}

		// Search trigger.
		if ( 'end' === $nav_align || 'center' === $nav_align ) {
			$search_margin = 0;
		} else {
			$search_margin = 'spread' === $nav_layout ? 0 : 'auto';
		}
		$search_field = 'field' === $str( 'searchStyle' );
		if ( $search_field ) {
			$h .= cb_header_ssr_search_field( $p, $nav_color, $search_margin );
		}
		$h .= '<button class="rh-search-trigger' . ( $search_field ? ' rh-search-trigger--with-field' : '' ) . '" data-rh="search" aria-label="Søk" aria-expanded="' . ( empty( $state['searchOpen'] ) ? 'false' : 'true' ) . '" style="' . cb_header_ssr_style(
			[
				'background' => 'none',
				'border'     => 'none',
				'color'      => $nav_color,
				'cursor'     => 'pointer',
				'padding'    => '8px',
				'lineHeight' => 0,
				'flexShrink' => 0,
				'marginLeft' => $search_margin,
			]
		) . '">' . cb_header_ssr_icon( 'search', 22 ) . '</button>';

		// Own links.
		$h .= cb_header_ssr_extra_links( $p, $nav_color );

		// Account + basket.
		if ( $bool( 'shopLinks' ) ) {
			$h .= cb_header_ssr_shop_links( $p, $nav_color );
		}

		// CTA.
		if ( $bool( 'ctaEnabled' ) && '' !== $str( 'ctaLabel' ) ) {
			$h .= '<a class="rh-cta" href="' . esc_attr( '' !== $str( 'ctaUrl' ) ? $str( 'ctaUrl' ) : '#' ) . '" style="' . cb_header_ssr_style(
				[
					'flexShrink'     => 0,
					'whiteSpace'     => 'nowrap',
					'display'        => 'inline-flex',
					'alignItems'     => 'center',
					'gap'            => '8px',
					'padding'        => '12px 22px',
					'borderRadius'   => (int) ( $p['ctaRadius'] ?? 0 ) . 'px',
					'background'     => '' !== $str( 'ctaBg' ) ? $str( 'ctaBg' ) : 'var(--wp--preset--color--accent, #f0a83c)',
					'color'          => '' !== $str( 'ctaColor' ) ? $str( 'ctaColor' ) : 'var(--wp--preset--color--white, #ffffff)',
					'fontWeight'     => 700,
					'fontSize'       => '15px',
					'lineHeight'     => 1,
				]
			) . '">' . esc_html( $str( 'ctaLabel' ) ) . '</a>';
		}

		// Hamburger.
		$h .= '<button class="rh-mobile-toggle" aria-expanded="' . ( $menu_open ? 'true' : 'false' ) . '" aria-label="' . ( $menu_open ? 'Lukk meny' : 'Åpne meny' ) . '" style="' . cb_header_ssr_style(
			[
				'background'   => '' !== $str( 'hamburgerBg' ) ? $str( 'hamburgerBg' ) : 'var(--wp--preset--color--primary, #0a2020)',
				'border'       => 'none',
				'borderRadius' => 0,
				'color'        => '' !== $str( 'hamburgerIcon' ) ? $str( 'hamburgerIcon' ) : 'var(--wp--preset--color--surface, #f1ece1)',
				'cursor'       => 'pointer',
				'padding'      => '6px',
				'lineHeight'   => 0,
				'flexShrink'   => 0,
			]
		) . '">' . cb_header_ssr_icon( $menu_open ? 'close' : 'hamburger' ) . '</button>';

		if ( $two_rows ) {
			$h .= '</div><div class="rh-bar-row2" data-rh="row2" style="' . cb_header_ssr_style(
				[
					'display'    => 'flex',
					'alignItems' => 'center',
					'minHeight'  => '48px',
					'borderTop'  => '1px solid color-mix(in srgb, ' . $nav_color . ' 22%, transparent)',
				]
			) . '">' . $nav_html . '</div></div></div>';
		} else {
			$h .= '</div></div>';
		}
		if ( $menu_open ) {
			$h .= cb_header_ssr_megamenu( $p );
		}
		if ( ! empty( $state['searchOpen'] ) ) {
			$h .= cb_header_ssr_search_overlay();
		}
		return $h;
	}
}

if ( ! function_exists( 'cb_header_ssr_start_panel_style' ) ) {
	/**
	 * Two rows: position and box of a first-level panel. It hangs flush from
	 * the bottom of the header (no gap above it, so it reads as part of the
	 * bar) and starts at its trigger. Left 46px = the 24px hover bridge + the
	 * box padding (6) + the item padding (16): item text lines up with the
	 * trigger text.
	 *
	 * @param array<string, mixed> $start bg, color, radius.
	 * @return array{0: array<string, mixed>, 1: array<string, mixed>} [ position, box ].
	 */
	function cb_header_ssr_start_panel_style( array $start ): array {
		$radius = (int) $start['radius'];
		return [
			[
				'position'      => 'absolute',
				'top'           => '100%',
				'left'          => '-46px',
				'paddingLeft'   => '24px',
				'paddingRight'  => '24px',
				'paddingBottom' => '4px',
				'zIndex'        => 10001,
			],
			[
				'background'   => $start['bg'],
				'borderTop'    => '1px solid color-mix(in srgb, ' . $start['color'] . ' 22%, transparent)',
				'borderRadius' => '0 0 ' . $radius . 'px ' . $radius . 'px',
				'padding'      => '6px',
				'minWidth'     => '220px',
				'boxShadow'    => '0 16px 32px color-mix(in srgb, black 25%, transparent)',
			],
		];
	}
}

if ( ! function_exists( 'cb_header_ssr_dropdown_item_style' ) ) {
	/**
	 * Inline style of one dropdown item. In a two-row panel ($tone) the
	 * colours come from the header and the corners from the button radius.
	 *
	 * @param bool                      $is_active Item active (hovered / flyout open).
	 * @param array<string, mixed>|null $tone      bg, color, radius of a two-row panel.
	 * @return string Escaped attribute value.
	 */
	function cb_header_ssr_dropdown_item_style( bool $is_active, ?array $tone ): string {
		if ( $tone ) {
			$color  = $is_active ? $tone['color'] : 'color-mix(in srgb, ' . $tone['color'] . ' 75%, transparent)';
			$bg     = $is_active ? 'color-mix(in srgb, ' . $tone['color'] . ' 10%, transparent)' : 'transparent';
			$radius = (int) $tone['radius'] . 'px';
		} else {
			$color  = $is_active ? '#fff' : 'rgba(255,255,255,0.7)';
			$bg     = $is_active ? 'rgba(255,255,255,0.06)' : 'transparent';
			$radius = '8px';
		}
		return cb_header_ssr_style(
			[
				'display'        => 'flex',
				'alignItems'     => 'center',
				'justifyContent' => 'space-between',
				'gap'            => '12px',
				'padding'        => $tone ? '11px 16px' : '10px 16px',
				'color'          => $color,
				'textDecoration' => 'none',
				'fontSize'       => '16px',
				'fontWeight'     => 400,
				'letterSpacing'  => '0.01em',
				'borderRadius'   => $radius,
				'whiteSpace'     => 'nowrap',
				'transition'     => 'background 0.12s, color 0.12s',
				'background'     => $bg,
				'minHeight'      => $tone ? '44px' : null,
				'lineHeight'     => $tone ? '22px' : null,
				'boxSizing'      => $tone ? 'border-box' : null,
				'margin'         => $tone ? 0 : null,
			]
		);
	}
}

if ( ! function_exists( 'cb_header_ssr_dropdown_panel' ) ) {
	/**
	 * A desktop dropdown panel (DesktopNavItem's open panel) or, nested, a
	 * flyout (DesktopDropdownItem's). Items render inactive unless $active.
	 *
	 * @param array<int, array<string, mixed>> $links  Items.
	 * @param array<string, string>            $panel  cb_header_panel_style().
	 * @param int|null                         $active Active item (flyout open).
	 * @param string                           $side   right|left flyout side.
	 * @param bool                             $hidden Emit closed (`hidden`).
	 * @param bool                             $flyout Nested flyout, not the top panel.
	 * @param array<string, mixed>|null        $start  Two rows: the panel sits flush under the header — [ bg, color, radius ].
	 * @return string HTML.
	 */
	function cb_header_ssr_dropdown_panel( array $links, array $panel, ?int $active, string $side, bool $hidden, bool $flyout = false, ?array $start = null ): string {
		if ( $flyout ) {
			$pos = 'left' === $side
				? [ 'position' => 'absolute', 'top' => 0, 'right' => '100%', 'paddingRight' => '8px', 'zIndex' => 10002 ]
				: [ 'position' => 'absolute', 'top' => 0, 'left' => '100%', 'paddingLeft' => '8px', 'zIndex' => 10002 ];
		} elseif ( $start ) {
			[ $pos, $box ] = cb_header_ssr_start_panel_style( $start );
		} else {
			$pos = [
				'position'      => 'absolute',
				'top'           => '100%',
				'left'          => '50%',
				'transform'     => 'translateX(-50%)',
				'paddingTop'    => '12px',
				'paddingLeft'   => '24px',
				'paddingRight'  => '24px',
				'paddingBottom' => '4px',
				'zIndex'        => 10001,
			];
		}
		$box ??= $panel;
		$h    = '<div role="menu" style="' . cb_header_ssr_style( $pos ) . '"' . ( $hidden ? ' hidden' : '' ) . ( $flyout ? ' data-rh-flyout' : ' data-rh-panel' ) . ( $start && ! $flyout ? ' data-rh-start data-rh-idle="' . esc_attr( 'color-mix(in srgb, ' . $start['color'] . ' 75%, transparent)' ) . '" data-rh-active="' . esc_attr( (string) $start['color'] ) . '" data-rh-hover="' . esc_attr( 'color-mix(in srgb, ' . $start['color'] . ' 10%, transparent)' ) . '"' : '' ) . '><div style="' . cb_header_ssr_style( $box ) . '">';
		foreach ( array_values( $links ) as $j => $item ) {
			$is_active = $active === $j;
			$style     = cb_header_ssr_dropdown_item_style( $is_active, $flyout ? null : $start );
			$href  = esc_attr( (string) ( $item['href'] ?? '' ) );
			$label = esc_html( (string) ( $item['label'] ?? '' ) );
			if ( empty( $item['children'] ) ) {
				$h .= '<a href="' . $href . '" role="menuitem" style="' . $style . '">' . $label . '</a>';
				continue;
			}
			$h .= '<div style="position:relative"><a href="' . $href . '" role="menuitem" aria-haspopup="true" aria-expanded="' . ( $is_active ? 'true' : 'false' ) . '" style="' . $style . '">' . $label;
			$h .= '<svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;opacity:0.7;transform:' . ( 'left' === $side ? 'scaleX(-1)' : 'none' ) . '" aria-hidden="true"><polyline points="3,1 7,5 3,9"></polyline></svg></a>';
			if ( $is_active ) {
				$h .= cb_header_ssr_dropdown_panel( (array) $item['children'], $panel, null, $side, false, true );
			} elseif ( $hidden ) {
				// Page output: every flyout present but closed; ssr.ts opens it.
				$h .= cb_header_ssr_dropdown_panel( (array) $item['children'], $panel, null, 'right', true, true );
			}
			$h .= '</div>';
		}
		return $h . '</div></div>';
	}
}

if ( ! function_exists( 'cb_header_ssr_search_overlay' ) ) {
	/**
	 * The search overlay shell (empty query). Results are rendered by ssr.ts
	 * from /wp-json/styrk/v1/search; they only appear after the user types.
	 *
	 * @param bool $hidden Emit closed (`hidden`) for the live page.
	 * @return string HTML.
	 */
	function cb_header_ssr_search_overlay( bool $hidden = false ): string {
		return '<div class="rh-search-overlay" role="dialog" aria-modal="true" aria-label="Søk på siden"' . ( $hidden ? ' hidden' : '' ) . '>'
			. '<div class="rh-search-panel"><form action="/" method="get" class="rh-search-form">'
			. cb_header_ssr_icon( 'search', 22 )
			. '<input type="search" name="s" placeholder="Søk på siden…" autocomplete="off" spellcheck="false" aria-label="Søk" value=""/>'
			. '<button type="button" class="rh-search-close" aria-label="Lukk søk">' . cb_header_ssr_icon( 'close' ) . '</button>'
			. '</form><p class="rh-search-status">Skriv minst 2 tegn for å søke.</p></div></div>';
	}
}

if ( ! function_exists( 'cb_header_ssr_megamenu' ) ) {
	/**
	 * The full-screen menu (every navLinks group with its children).
	 *
	 * @param array<string, mixed> $p      Header props.
	 * @param bool                 $hidden Emit it closed (`hidden`) for the live page.
	 * @return string HTML.
	 */
	function cb_header_ssr_megamenu( array $p, bool $hidden = false ): string {
		$style = [];
		if ( '' !== (string) ( $p['mobileMenuBg'] ?? '' ) ) {
			$style['background'] = (string) $p['mobileMenuBg'];
		}
		if ( '' !== (string) ( $p['mobileMenuText'] ?? '' ) ) {
			$style['color'] = (string) $p['mobileMenuText'];
		}
		$h  = '<div class="rh-megamenu" role="dialog" aria-modal="true" aria-label="Navigasjonsmeny"' . ( $style ? ' style="' . cb_header_ssr_style( $style ) . '"' : '' ) . ( $hidden ? ' hidden' : '' ) . '>';
		$h .= '<div class="rh-megamenu__brand" aria-hidden="true"><div class="rh-megamenu__turbine" aria-hidden="true"></div></div>';
		$h .= '<div class="rh-megamenu__panel"><nav class="rh-megamenu__groups" aria-label="Hovedmeny">';
		foreach ( (array) ( $p['navLinks'] ?? [] ) as $group ) {
			$h .= '<div class="rh-megamenu__group"><h2 class="rh-megamenu__group-title"><a href="' . esc_attr( (string) ( $group['href'] ?? '' ) ) . '">' . esc_html( (string) ( $group['label'] ?? '' ) ) . '</a></h2>';
			if ( ! empty( $group['children'] ) ) {
				$h .= '<ul class="rh-megamenu__links">';
				foreach ( $group['children'] as $child ) {
					$h .= cb_header_ssr_megamenu_item( (array) $child );
				}
				$h .= '</ul>';
			}
			$h .= '</div>';
		}
		$h .= '</nav>';
		if ( ! empty( $p['shopLinks'] ) ) {
			$h .= '<div class="rh-megamenu__shop"><a class="rh-megamenu__account" href="' . esc_attr( (string) ( $p['accountUrl'] ?? '' ) ) . '">' . cb_header_ssr_icon( 'user', 20 ) . '<span>' . esc_html( (string) ( $p['accountLabel'] ?? '' ) ) . '</span></a></div>';
		}
		if ( ! empty( $p['extraLinks'] ) && is_array( $p['extraLinks'] ) ) {
			$h .= '<ul class="rh-megamenu__extras">';
			foreach ( $p['extraLinks'] as $link ) {
				$tab = ! empty( $link['newTab'] );
				$h  .= '<li><a class="rh-megamenu__extra-link" href="' . esc_url( (string) ( $link['url'] ?? '' ) ) . '"' . ( $tab ? ' target="_blank" rel="noopener"' : '' ) . '>'
					. esc_html( (string) ( $link['label'] ?? '' ) )
					. ( $tab ? '<span class="rh-visually-hidden"> (åpnes i ny fane)</span>' : '' )
					. '</a></li>';
			}
			$h .= '</ul>';
		}
		$h .= '</div></div>';
		return $h;
	}
}

if ( ! function_exists( 'cb_header_ssr_megamenu_item' ) ) {
	/**
	 * One sub-page in the megamenu. A sub-page with its own children (a third
	 * menu level, e.g. Tjenester → Bli synlig → Annonsering) lists them under
	 * it, so the concrete pages are visible without a click. Menus with two
	 * levels render exactly as before.
	 *
	 * @param array<string, mixed> $child Menu item: label, href, children.
	 * @return string HTML.
	 */
	function cb_header_ssr_megamenu_item( array $child ): string {
		$link = '<a href="' . esc_attr( (string) ( $child['href'] ?? '' ) ) . '">' . esc_html( (string) ( $child['label'] ?? '' ) ) . '</a>';
		if ( empty( $child['children'] ) ) {
			return '<li>' . $link . '</li>';
		}
		$h = '<li class="rh-megamenu__sub">' . $link . '<ul class="rh-megamenu__sublinks">';
		foreach ( (array) $child['children'] as $grand ) {
			$h .= '<li><a href="' . esc_attr( (string) ( $grand['href'] ?? '' ) ) . '">' . esc_html( (string) ( $grand['label'] ?? '' ) ) . '</a></li>';
		}
		return $h . '</ul></li>';
	}
}

if ( ! function_exists( 'cb_header_ssr_state_styles' ) ) {
	/**
	 * data-rh key => inline style, for one header state.
	 *
	 * Read back from the parity-tested bar markup rather than recomputed, so
	 * the snapshots ssr.ts switches between can never drift from it.
	 *
	 * @param array<string, mixed> $p     Header props.
	 * @param array<string, bool>  $state Interactive state.
	 * @return array<string, string>
	 */
	function cb_header_ssr_state_styles( array $p, array $state ): array {
		$html = cb_header_ssr_bar( $p, $state );
		preg_match_all( '/<[a-z]+\b[^>]*\sdata-rh="([a-z-]+)"[^>]*\sstyle="([^"]*)"/', $html, $m, PREG_SET_ORDER );
		$out = [];
		foreach ( $m as $hit ) {
			$out[ $hit[1] ] = html_entity_decode( $hit[2], ENT_QUOTES, 'UTF-8' );
		}
		// Full-strength nav colour for a hovered dropdown trigger (the client
		// wrote it inline on mouseenter).
		$out['hover'] = cb_header_colors(
			[
				'bgMode'           => (string) ( $p['bgMode'] ?? '' ),
				'bgColor'          => (string) ( $p['bgColor'] ?? '' ),
				'textColor'        => (string) ( $p['textColor'] ?? '' ),
				'solidifyOnScroll' => ! empty( $p['solidifyOnScroll'] ),
				'scrolled'         => ! empty( $state['scrolled'] ),
				'menuOpen'         => ! empty( $state['menuOpen'] ),
				'mobileMenuBg'     => (string) ( $p['mobileMenuBg'] ?? '' ),
				'mobileMenuText'   => (string) ( $p['mobileMenuText'] ?? '' ),
			]
		)['navColor'];
		return $out;
	}
}

if ( ! function_exists( 'cb_header_ssr_render' ) ) {
	/**
	 * The whole server-rendered header for the page: the same wrapper the
	 * client mount code builds (so sticky / hide-on-scroll CSS applies as-is),
	 * the closed bar, the menu (hidden) and the per-state style snapshots.
	 *
	 * @param array<string, mixed> $p        Header props.
	 * @param array<string, mixed> $settings position, hideOnScroll, navMode.
	 * @return string HTML.
	 */
	function cb_header_ssr_render( array $p, array $settings ): string {
		$position = 'sticky' === ( $settings['position'] ?? '' ) ? 'sticky' : 'relative';
		$overlay  = ! empty( $p['isOverlay'] );
		$solidify = ! empty( $p['solidifyOnScroll'] );
		$classes  = 'react-header-live-wrapper';
		if ( 'sticky' === $position && ! $overlay && ! $solidify ) {
			$classes .= ' react-header-live-wrapper--sticky';
		}
		$styles = [
			'closed'   => cb_header_ssr_state_styles( $p, [] ),
			'scrolled' => cb_header_ssr_state_styles( $p, [ 'scrolled' => true ] ),
			'open'     => cb_header_ssr_state_styles( $p, [ 'menuOpen' => true ] ),
		];
		return sprintf(
			'<div class="%1$s" data-rh-root data-position="%2$s" data-hide-on-scroll="%3$s" data-nav-mode="%4$s" data-solidify="%5$s" data-rh-styles="%6$s">%7$s%8$s</div>',
			esc_attr( $classes ),
			esc_attr( $position ),
			! empty( $settings['hideOnScroll'] ) ? 'true' : 'false',
			esc_attr( (string) ( $settings['navMode'] ?? 'nav_toggle' ) ),
			$solidify ? 'true' : 'false',
			esc_attr( (string) wp_json_encode( $styles ) ),
			cb_header_ssr_bar( $p, [], true ),
			cb_header_ssr_megamenu( $p, true ) . cb_header_ssr_search_overlay( true )
		);
	}
}

if ( ! function_exists( 'cb_header_ssr_extras_props' ) ) {
	/**
	 * Props of the optional header extras, from render.php's `extras` blob.
	 * Only what is switched on is returned, so a site that uses none gets
	 * the props it always had.
	 *
	 * @param mixed $extras Decoded JSON.
	 * @return array<string, mixed>
	 */
	function cb_header_ssr_extras_props( $extras ): array {
		$extras = is_array( $extras ) ? $extras : [];
		$out    = [];
		if ( 'two_rows' === ( $extras['barLayout'] ?? '' ) ) {
			$out['barLayout'] = 'two_rows';
		}
		if ( 'field' === ( $extras['searchStyle'] ?? '' ) ) {
			$out['searchStyle']       = 'field';
			if ( 'center' === ( $extras['searchAlign'] ?? '' ) ) {
				$out['searchAlign'] = 'center';
			}
			$out['searchPlaceholder'] = (string) ( $extras['searchPlaceholder'] ?? '' );
		}
		if ( ! empty( $extras['extraLinks'] ) && is_array( $extras['extraLinks'] ) ) {
			$links = [];
			foreach ( array_slice( array_values( $extras['extraLinks'] ), 0, 3 ) as $link ) {
				if ( is_array( $link ) && '' !== (string) ( $link['label'] ?? '' ) && '' !== (string) ( $link['url'] ?? '' ) ) {
					$links[] = [
						'label'  => (string) $link['label'],
						'url'    => (string) $link['url'],
						'newTab' => ! empty( $link['newTab'] ),
					];
				}
			}
			if ( $links ) {
				$out['extraLinks'] = $links;
			}
		}
		if ( ! empty( $extras['shopLinks'] ) ) {
			$out['shopLinks']    = true;
			$out['accountUrl']   = (string) ( $extras['accountUrl'] ?? '' );
			$out['accountLabel'] = (string) ( $extras['accountLabel'] ?? '' );
			$out['cartUrl']      = (string) ( $extras['cartUrl'] ?? '' );
			$out['cartLabel']    = (string) ( $extras['cartLabel'] ?? '' );
			$out['cartCount']    = max( 0, (int) ( $extras['cartCount'] ?? 0 ) );
		}
		return $out;
	}
}

if ( ! function_exists( 'cb_header_ssr_props' ) ) {
	/**
	 * The props ReactHeader would receive, from the same data-* values
	 * render.php prints for it — the client's parsing (view.tsx mount code),
	 * defaults included, ported 1:1.
	 *
	 * @param array<string, string> $data data-* attribute values, keys without "data-".
	 * @return array{0: array<string, mixed>, 1: array<string, mixed>} [ props, wrapper settings ].
	 */
	function cb_header_ssr_props( array $data ): array {
		$get  = static fn ( string $k, string $default = '' ): string => array_key_exists( $k, $data ) ? (string) $data[ $k ] : $default;
		$menu = static function ( string $json ): array {
			$v = json_decode( $json, true );
			return is_array( $v ) ? $v : [];
		};
		$radius_raw = $get( 'cta-radius' );
		$nav_align  = $get( 'nav-align' );
		$nav_mode   = $get( 'nav-mode' );
		$mega_color = $get( 'megamenu-logo-color' );

		$props = [
			'logoUrl'           => $get( 'logo-url' ),
			'logoWhiteUrl'      => $get( 'logo-white-url' ),
			'logoAlt'           => $get( 'logo-alt' ),
			'navLinks'          => $menu( $get( 'menu-json', '[]' ) ),
			'topNavLinks'       => $menu( $get( 'top-menu-json', '[]' ) ),
			'bgMode'            => $get( 'bg-mode', 'transparent' ),
			'bgColor'           => $get( 'bg-color', '#0a2020' ),
			'textColor'         => $get( 'text-color', '#ffffff' ),
			'isOverlay'         => 'true' === $get( 'overlay' ),
			'solidifyOnScroll'  => 'true' === $get( 'solidify-on-scroll' ),
			'navLayout'         => 'spread' === $get( 'nav-layout' ) ? 'spread' : 'compact',
			'navAlign'          => in_array( $nav_align, [ 'center', 'end' ], true ) ? $nav_align : 'start',
			'megaMenuLogoColor' => in_array( $mega_color, [ 'colored', 'black' ], true ) ? $mega_color : 'white',
			'megaMenuLogoUrl'   => $get( 'megamenu-logo-url' ),
			'contentWidth'      => $get( 'content-width', '1280' ),
			'ctaEnabled'        => 'true' === $get( 'cta-enabled' ),
			'ctaLabel'          => $get( 'cta-label' ),
			'ctaUrl'            => $get( 'cta-url' ),
			'ctaBg'             => $get( 'cta-bg' ),
			'ctaColor'          => $get( 'cta-color' ),
			'ctaRadius'         => max( 0, min( 50, '' === $radius_raw ? 6 : (int) $radius_raw ) ),
			'hamburgerBg'       => $get( 'hamburger-bg' ),
			'hamburgerIcon'     => $get( 'hamburger-icon' ),
			'mobileMenuBg'      => $get( 'mobile-menu-bg' ),
			'mobileMenuText'    => $get( 'mobile-menu-text' ),
		];
		// Optional header extras (Settings → Header → Search / Shop / Rows), one
		// JSON blob from render.php; absent unless switched on.
		$props += cb_header_ssr_extras_props( json_decode( $get( 'extras', '{}' ), true ) );
		$settings = [
			'position'     => 'sticky' === $get( 'position' ) ? 'sticky' : 'relative',
			'hideOnScroll' => 'true' === $get( 'hide-on-scroll' ),
			'navMode'      => in_array( $nav_mode, [ 'nav_toggle', 'toggle' ], true ) ? $nav_mode : 'nav',
		];
		return [ $props, $settings ];
	}
}

if ( ! function_exists( 'cb_header_sort_sub_links' ) ) {
	/**
	 * Menu items sorted by label in Norwegian alphabetical order (Æ Ø Å after
	 * Z), children too. A call-to-action link to /kontakt/ that closes a list
	 * («Book en prat») stays last: it is not a page in the list.
	 *
	 * @param array<int, array<string, mixed>> $items Menu items.
	 * @return array<int, array<string, mixed>>
	 */
	function cb_header_sort_sub_links( array $items ): array {
		$tail = [];
		$last = end( $items );
		if ( is_array( $last ) && empty( $last['children'] ) && preg_match( '#/kontakt/?$#', (string) ( $last['href'] ?? '' ) ) ) {
			$tail = [ array_pop( $items ) ];
		}
		$collator = class_exists( 'Collator' ) ? new Collator( 'nb_NO' ) : null;
		$key      = static function ( string $s ): string {
			// Fallback without intl: æ ø å sort after z.
			return strtr( mb_strtolower( $s ), [ 'æ' => 'z~1', 'ø' => 'z~2', 'å' => 'z~3' ] );
		};
		usort(
			$items,
			static function ( $a, $b ) use ( $collator, $key ): int {
				$x = (string) ( $a['label'] ?? '' );
				$y = (string) ( $b['label'] ?? '' );
				return $collator ? (int) $collator->compare( $x, $y ) : strcmp( $key( $x ), $key( $y ) );
			}
		);
		foreach ( $items as $i => $item ) {
			if ( ! empty( $item['children'] ) ) {
				$items[ $i ]['children'] = cb_header_sort_sub_links( (array) $item['children'] );
			}
		}
		return array_merge( $items, $tail );
	}
}
