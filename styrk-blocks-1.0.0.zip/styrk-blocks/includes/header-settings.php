<?php
/**
 * Header Settings — admin page for logo + header appearance.
 *
 * Settings → Header lets admins manage:
 *  - Logo uploads (main header logo + white footer variant)
 *  - Header background mode (transparent overlay or solid color)
 *  - Header background color (when solid)
 *  - Header text / nav link color
 *
 * On save, the main logo also updates the `custom_logo` theme mod
 * so wp:site-logo blocks work out of the box.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

require_once __DIR__ . '/admin-ui.php';

// File-level idempotency guard: if this file somehow gets included twice
// (symlink setups, mu-plugins double-load, etc.) the `function` declarations
// below would fatal with "Cannot redeclare". Bail early on the second include.
if ( defined( 'CB_HEADER_SETTINGS_LOADED' ) ) return;
define( 'CB_HEADER_SETTINGS_LOADED', true );

/* ── Option key ─────────────────────────────────────────────────────────────── */
define( 'CB_HEADER_OPTION', 'cb_header_settings' );

/**
 * Default values for header settings.
 */
function cb_header_defaults(): array {
	return [
		'logo_id'        => 0,              // attachment ID — main/color logo
		// NOTE: logo_white_id USED to live here. As of v1.6.5 the white
		// (footer) logo is managed under Settings → Footer → Logo so the
		// setting sits with the rest of the footer fields (address, email,
		// credits, legal links). The key is intentionally kept in the
		// defaults array, set to 0, so any callsite that still reads it
		// gets a falsy default — the footer-logo shortcode falls through
		// to the new footer-settings key first, then header for back-compat,
		// then the theme asset.
		'logo_white_id'  => 0,
		'bg_mode'        => 'transparent',  // 'transparent' | 'solid'
		'bg_color'       => '#0a2020',      // solid background color
		'text_color'     => '#ffffff',      // header text / nav link color
		'position'       => 'relative',     // 'relative' | 'sticky'
		'hide_on_scroll' => '0',            // '0' | '1' — only effective with sticky
		'ssr'            => '1',            // '0' | '1' — server-rendered header (default since 0.10.288)
		'sort_sub'       => '0',            // '0' | '1' — sub-pages in the menu sorted A–Å instead of menu order
		// How the header row distributes logo / nav / controls. Default '' =
		// INHERIT: emit nothing, so the per-block `navLayout` attribute set in
		// the template part wins. A value chosen here overrides the block
		// globally — 'spread' pushes the search + CTA cluster to the far-right
		// edge (via the flex spacer in view.tsx), 'compact' groups everything
		// on the left.
		// Header alignment — the ONE control that frames the header. 'content' =
		// the header rail matches the page content column (logo lines up with the
		// content's left edge, search/CTA with its right edge); 'full' = edge to
		// edge; 'custom' = fall back to the advanced Content width + Side padding
		// controls below. Default 'custom' so existing sites keep whatever
		// content_width/side_pad they saved (back-compat).
		'header_align'   => 'custom',       // 'content' | 'full' | 'custom'
		// Header AND footer width — one switch that frames both bands. '' = not
		// set: the header follows "Header alignment" below and the footer keeps
		// its own theme width, so existing sites render exactly as before.
		//   'full'    = both stretch to the device width (small edge gutter)
		//   'content' = both follow the page content column
		//   'wide'    = both use a wider 1600px rail
		'frame_width'    => '',             // '' (not set) | 'full' | 'content' | 'wide'
		'nav_layout'     => '',             // '' (inherit) | 'compact' | 'spread' — legacy, only under 'custom'
		// Horizontal alignment of the desktop nav LINKS within the header row,
		// independent of nav_layout: 'start' = grouped next to the logo
		// (historical default), 'center' = centered in the header, 'end' =
		// pushed to the right next to the search / CTA cluster (matches designs
		// that group the menu with the header utilities).
		'nav_align'      => 'start',        // 'start' | 'center' | 'end'
		// What the DESKTOP header shows for navigation. Historical behaviour =
		// 'nav' (inline links on desktop, hamburger/megamenu only on mobile).
		// 'nav_toggle' also surfaces the hamburger/megamenu icon on desktop
		// ALONGSIDE the inline nav; 'toggle' hides the inline nav entirely and
		// shows ONLY the hamburger/megamenu icon at every width. Default 'nav'
		// keeps existing sites unchanged.
		'nav_mode'       => 'nav',          // 'nav' | 'nav_toggle' | 'toggle'
		// How the site logo renders while the megamenu is OPEN (the header sits
		// on the dark navy overlay then). 'white' = the historical CSS-mask
		// white logo; 'black' = the same mask filled black; 'colored' = the
		// real colour logo (no recolour). Default 'white' = unchanged.
		// Optional dedicated megamenu logo image (e.g. a ready-made white
		// version). When set, render.php emits its URL and view.tsx renders it
		// as a real <img> in the open megamenu (no CSS mask). Default 0 = none,
		// so the megamenu_logo_color CSS-mask fallback below is used and
		// existing sites render exactly as before.
		'megamenu_logo_id'    => 0,         // attachment ID — uploaded megamenu logo
		'megamenu_logo_color' => 'white',   // 'colored' | 'white' | 'black'
		// Mobile hamburger button + mobile menu colours, stored as theme
		// palette SLUGS (resolved to `var(--wp--preset--color--{slug})` in
		// render.php). Default '' = INHERIT: emit nothing, so view.tsx keeps
		// its historical hardcoded look (teal button, icon = nav colour, menu
		// bg = primary, menu text = white). Existing sites stay unchanged
		// until an admin picks a colour here.
		'hamburger_bg'     => '',           // '' (inherit) | palette slug → button background
		'hamburger_icon'   => '',           // '' (inherit) | palette slug → hamburger icon colour
		'mobile_menu_bg'   => '',           // '' (inherit) | palette slug → mobile menu panel bg
		'mobile_menu_text' => '',           // '' (inherit) | palette slug → mobile menu link/text colour
		// Header content rail width + side gutters. These let an admin line
		// the logo/nav/CTA row up with the page's content band (which varies
		// per theme). Default '' = INHERIT: emit no CSS var, so the per-block
		// `contentWidth` attribute set in the template part (e.g. hywer's
		// 1440) and the historical 1280px/52px fallback in view.tsx still win.
		// Only a value explicitly chosen here overrides the block.
		'content_width'  => '',             // '' (inherit) | '1180' | '1280' | '1440' | 'full'
		'side_pad'       => '',             // '' (inherit) | px gutter 0–120
		// Optional header CTA — when set, the theme's header script
		// renders this label/URL as a button next to the search icon.
		// Default `cta_show='1'` so existing live sites keep their
		// button even before an admin visits this page; unchecking the
		// box hides it. Label/URL empty = script falls back to its own
		// historical defaults ("Ta kontakt" → "/kontakt/").
		'cta_label'      => '',
		'cta_url'        => '',
		'cta_show'       => '1',
		// CTA button colours — palette slugs (resolved to CSS vars in render.php).
		// '' = inherit: keep the historical accent bg + white text.
		'cta_bg'         => '',
		'cta_text'       => '',
		// Corner radius in px. 6 is the value the button was hardcoded to before
		// this became a setting, so an untouched site renders unchanged.
		'cta_radius'     => 6,
	];
}

/**
 * Return merged (saved + defaults) header settings.
 */
function cb_get_header_settings(): array {
	$saved = get_option( CB_HEADER_OPTION, [] );
	return wp_parse_args( $saved, cb_header_defaults() );
}

/**
 * One-time switch to the server-rendered header on every site.
 *
 * The React header is built in the browser after load, so the logo and menu
 * popped in and shifted (seen on skotnes-bygg.no and hywer.no). The server
 * version is the same header, pixel-identical, already in the HTML. It was an
 * opt-in beta, so a stored '0' only ever meant "never switched on". Turn it on
 * once; an admin who then switches it off is respected.
 */
function cb_header_ssr_default_migration(): void {
	if ( get_option( 'cb_header_ssr_default_v1' ) ) {
		return;
	}
	$saved = get_option( CB_HEADER_OPTION, [] );
	if ( is_array( $saved ) && isset( $saved['ssr'] ) && '1' !== $saved['ssr'] ) {
		$saved['ssr'] = '1';
		update_option( CB_HEADER_OPTION, $saved );
	}
	update_option( 'cb_header_ssr_default_v1', '1', false );
}
add_action( 'init', 'cb_header_ssr_default_migration', 5 );

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_header_settings_menu(): void {
	add_options_page(
		__( 'Header Settings', 'styrk-blocks' ),
		__( 'Header', 'styrk-blocks' ),
		'manage_options',
		'cb-header-settings',
		'cb_header_settings_page'
	);
}
add_action( 'admin_menu', 'cb_header_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

/**
 * Name attribute of one option inside the single stored array.
 *
 * @param string $key Option key.
 */
function cb_header_field_name( string $key ): string {
	return CB_HEADER_OPTION . '[' . $key . ']';
}

/**
 * The page is built from the Settings API: every SECTION is one named part of
 * the panel, every FIELD one row of it. The sections and fields are laid out by
 * sb_ui_render_parts() (includes/admin-ui.php), not by core's table renderer.
 * Every saved option key, type and sanitizer is unchanged.
 */
function cb_header_settings_init(): void {
	register_setting( 'cb_header_group', CB_HEADER_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_header_sanitize',
		'default'           => cb_header_defaults(),
	] );

	$page = 'cb-header-settings';

	/* Part 1 — open by default. */
	add_settings_section( 'cb_header_logos', __( 'Content', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_header_logo', __( 'Logo', 'styrk-blocks' ), 'cb_header_render_logo_row', $page, 'cb_header_logos' );
	add_settings_field( 'cb_header_button', __( 'Button', 'styrk-blocks' ), 'cb_header_render_button_row', $page, 'cb_header_logos' );

	/* Part 2 */
	add_settings_section( 'cb_header_appearance', __( 'Appearance', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_header_bg', __( 'Background', 'styrk-blocks' ), 'cb_header_render_background_row', $page, 'cb_header_appearance' );
	add_settings_field( 'cb_header_cta_colors', __( 'The button', 'styrk-blocks' ), 'cb_header_render_button_colors_row', $page, 'cb_header_appearance' );
	add_settings_field( 'cb_header_corners', __( 'Corners', 'styrk-blocks' ), 'cb_header_render_corners_row', $page, 'cb_header_appearance' );
	add_settings_field( 'cb_header_frame_width', __( 'Width', 'styrk-blocks' ), 'cb_header_render_width_row', $page, 'cb_header_appearance' );
	add_settings_field( 'cb_header_nav_align', __( 'The menu', 'styrk-blocks' ), 'cb_header_render_nav_align_row', $page, 'cb_header_appearance' );

	/* Part 3 */
	add_settings_section( 'cb_header_behavior', __( 'Behaviour', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_header_scroll', __( 'When you scroll', 'styrk-blocks' ), 'cb_header_render_scroll_row', $page, 'cb_header_behavior' );
	add_settings_field( 'cb_header_subpages', __( 'Sub-pages', 'styrk-blocks' ), 'cb_header_render_subpages_row', $page, 'cb_header_behavior' );
	add_settings_field( 'cb_header_nav_mode', __( 'On desktop', 'styrk-blocks' ), 'cb_header_render_nav_mode_row', $page, 'cb_header_behavior' );

	/* Part 4 */
	add_settings_section( 'cb_header_mobile', __( 'Mobile menu and megamenu', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_header_hamburger', __( 'Menu button', 'styrk-blocks' ), 'cb_header_render_hamburger_row', $page, 'cb_header_mobile' );
	add_settings_field( 'cb_header_mobile_menu', __( 'The menu', 'styrk-blocks' ), 'cb_header_render_mobile_menu_row', $page, 'cb_header_mobile' );
	add_settings_field( 'cb_header_megamenu_logo_color', __( 'Logo in the menu', 'styrk-blocks' ), 'cb_header_render_megamenu_logo_color_row', $page, 'cb_header_mobile' );
	add_settings_field( 'cb_header_megamenu_logo_id', __( 'Own menu logo', 'styrk-blocks' ), 'cb_header_render_megamenu_logo_row', $page, 'cb_header_mobile' );

	/* Part 5 */
	add_settings_section( 'cb_header_advanced', __( 'Advanced', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_header_ssr', __( 'Loading', 'styrk-blocks' ), 'cb_header_render_loading_row', $page, 'cb_header_advanced' );
	add_settings_field( 'cb_header_own_width', __( 'Own width', 'styrk-blocks' ), 'cb_header_render_own_width_row', $page, 'cb_header_advanced' );
}
add_action( 'admin_init', 'cb_header_settings_init' );

/* ── Rows ───────────────────────────────────────────────────────────────────── */

/**
 * Strings of the logo picker (shared by both logo rows).
 *
 * @return array<string,string>
 */
function cb_header_media_text(): array {
	return [
		'title'  => __( 'Select Logo', 'styrk-blocks' ),
		'button' => __( 'Use as Logo', 'styrk-blocks' ),
		'change' => __( 'Change Logo', 'styrk-blocks' ),
		'upload' => __( 'Upload Logo', 'styrk-blocks' ),
		'remove' => __( 'Remove', 'styrk-blocks' ),
	];
}

function cb_header_render_logo_row(): void {
	$s = cb_get_header_settings();
	sb_ui_media( cb_header_field_name( 'logo_id' ), (int) $s['logo_id'], cb_header_media_text(), false );
	sb_ui_help( __( 'SVG or PNG. Shown at the top of every page.', 'styrk-blocks' ) );
}

function cb_header_render_button_row(): void {
	$s = cb_get_header_settings();
	sb_ui_toggle( cb_header_field_name( 'cta_show' ), ! empty( $s['cta_show'] ), __( 'Show the button', 'styrk-blocks' ) );
	sb_ui_line(
		static function () use ( $s ): void {
			sb_ui_text( cb_header_field_name( 'cta_label' ), (string) $s['cta_label'], __( 'Text', 'styrk-blocks' ), 'Ta kontakt', 'cb_header_cta_label' );
			sb_ui_text( cb_header_field_name( 'cta_url' ), (string) $s['cta_url'], __( 'Link', 'styrk-blocks' ), '/kontakt/', 'cb_header_cta_url' );
		},
		cb_header_field_name( 'cta_show' ) . ':1'
	);
	sb_ui_help( __( 'The link can be a page here, like /kontakt/, or a full address.', 'styrk-blocks' ) );
}

/**
 * One colour button, with this page's palette and wording.
 *
 * @param string $key    Option key.
 * @param string $label  Button text.
 * @param string $mode   'slug' | 'hex'.
 * @param string $when   Optional dimming condition.
 */
function cb_header_color_button( string $key, string $label, string $mode = 'slug', string $when = '' ): void {
	$s = cb_get_header_settings();
	sb_ui_color(
		cb_header_field_name( $key ),
		(string) ( $s[ $key ] ?? '' ),
		$label,
		cb_header_theme_palette(),
		$mode,
		'slug' === $mode,
		__( 'Default', 'styrk-blocks' ),
		$when
	);
}

function cb_header_render_background_row(): void {
	$s = cb_get_header_settings();
	sb_ui_segmented(
		cb_header_field_name( 'bg_mode' ),
		(string) $s['bg_mode'],
		[
			'transparent' => __( 'Transparent', 'styrk-blocks' ),
			'solid'       => __( 'Colour', 'styrk-blocks' ),
		],
		__( 'Background', 'styrk-blocks' )
	);
	sb_ui_line(
		static function (): void {
			cb_header_color_button( 'bg_color', __( 'Background', 'styrk-blocks' ), 'hex', cb_header_field_name( 'bg_mode' ) . ':solid' );
			cb_header_color_button( 'text_color', __( 'Text', 'styrk-blocks' ), 'hex' );
		}
	);
	sb_ui_help( __( 'Transparent puts the menu on top of the image at the top of the page.', 'styrk-blocks' ) );
}

function cb_header_render_button_colors_row(): void {
	sb_ui_line(
		static function (): void {
			cb_header_color_button( 'cta_bg', __( 'Background', 'styrk-blocks' ) );
			cb_header_color_button( 'cta_text', __( 'Text', 'styrk-blocks' ) );
		}
	);
	sb_ui_help( __( 'The button in the top menu. Default keeps the colours of the theme.', 'styrk-blocks' ) );
}

/**
 * The three corner choices and the stored pixel radius behind each. The front
 * end takes the number as it is (0–50 px, capped by the sanitizer): 0 = square,
 * 6 = the radius the button always had, 50 = fully round on a button this tall.
 *
 * @return array<string,int>
 */
function cb_header_corner_values(): array {
	return [
		'sharp' => 0,
		'soft'  => 6,
		'round' => 50,
	];
}

function cb_header_render_corners_row(): void {
	$s       = cb_get_header_settings();
	$current = (int) ( $s['cta_radius'] ?? 6 );
	$values  = cb_header_corner_values();
	$labels  = [
		'sharp' => __( 'Square', 'styrk-blocks' ),
		'soft'  => __( 'Slightly round', 'styrk-blocks' ),
		'round' => __( 'Fully round', 'styrk-blocks' ),
	];
	$options = [];
	foreach ( $values as $kind => $px ) {
		$options[ (string) $px ] = [
			'label' => $labels[ $kind ],
			'svg'   => sb_ui_corner_svg( $kind ),
		];
	}
	$listed = in_array( $current, $values, true );
	sb_ui_tiles( cb_header_field_name( 'cta_radius' ), (string) $current, $options, __( 'Corners', 'styrk-blocks' ), 'corners', $listed );
	if ( $listed ) {
		sb_ui_help( __( 'Applies to the button in the top menu.', 'styrk-blocks' ) );
	} else {
		/* translators: %d: the corner radius that is saved now, in pixels. */
		sb_ui_help( sprintf( __( 'The button has its own corners now (%d). Pick one to replace them.', 'styrk-blocks' ), $current ) );
	}
}

function cb_header_render_scroll_row(): void {
	$s = cb_get_header_settings();
	sb_ui_segmented(
		cb_header_field_name( 'position' ),
		(string) $s['position'],
		[
			'relative' => __( 'Scrolls with the page', 'styrk-blocks' ),
			'sticky'   => __( 'Fixed at the top', 'styrk-blocks' ),
		],
		__( 'When you scroll', 'styrk-blocks' )
	);
	sb_ui_toggle(
		cb_header_field_name( 'hide_on_scroll' ),
		! empty( $s['hide_on_scroll'] ),
		__( 'Hide when you scroll down', 'styrk-blocks' ),
		cb_header_field_name( 'position' ) . ':sticky'
	);
	sb_ui_help( __( 'The menu comes back when you scroll up. Only when the menu is fixed at the top.', 'styrk-blocks' ) );
}

function cb_header_render_subpages_row(): void {
	$s = cb_get_header_settings();
	sb_ui_toggle( cb_header_field_name( 'sort_sub' ), ! empty( $s['sort_sub'] ), __( 'Sort from A to Z', 'styrk-blocks' ) );
	sb_ui_help( __( 'Applies to the sub-pages in the menu.', 'styrk-blocks' ) );
}

/**
 * Header-and-footer width. The three pictures map one to one onto the stored
 * values. "Not set" ('' — the default every site starts with) is shown as a
 * fourth, quiet picture only while it is the saved value; once a width is
 * chosen, "back to not set" is a link instead, so it is never picked by
 * accident but never lost either.
 */
function cb_header_render_width_row(): void {
	$s       = cb_get_header_settings();
	$current = (string) ( $s['frame_width'] ?? '' );
	$name    = cb_header_field_name( 'frame_width' );
	sb_ui_tiles(
		$name,
		$current,
		[
			'full'    => [
				'label' => __( 'Full width', 'styrk-blocks' ),
				'svg'   => sb_ui_width_svg( 'full' ),
			],
			'wide'    => [
				'label' => __( 'Wide', 'styrk-blocks' ),
				'svg'   => sb_ui_width_svg( 'wide' ),
			],
			'content' => [
				'label' => __( 'Like the content', 'styrk-blocks' ),
				'svg'   => sb_ui_width_svg( 'content' ),
			],
			''        => [
				'label' => __( 'Not set', 'styrk-blocks' ),
				'svg'   => sb_ui_width_svg( 'none' ),
				'quiet' => true,
			],
		],
		__( 'Width', 'styrk-blocks' ),
		'wide'
	);
	sb_ui_reset_link( $name, __( 'Back to not set', 'styrk-blocks' ), '' !== $current );
	sb_ui_help( __( 'Applies to both the top menu and the footer.', 'styrk-blocks' ) );
}

function cb_header_render_nav_align_row(): void {
	$s = cb_get_header_settings();
	sb_ui_segmented(
		cb_header_field_name( 'nav_align' ),
		(string) $s['nav_align'],
		[
			'start'  => __( 'To the left', 'styrk-blocks' ),
			'center' => __( 'In the middle', 'styrk-blocks' ),
			'end'    => __( 'To the right', 'styrk-blocks' ),
		],
		__( 'The menu', 'styrk-blocks' )
	);
}

function cb_header_render_nav_mode_row(): void {
	$s = cb_get_header_settings();
	sb_ui_segmented(
		cb_header_field_name( 'nav_mode' ),
		(string) $s['nav_mode'],
		[
			'nav'        => __( 'Menu', 'styrk-blocks' ),
			'nav_toggle' => __( 'Menu and icon', 'styrk-blocks' ),
			'toggle'     => __( 'Icon only', 'styrk-blocks' ),
		],
		__( 'On desktop', 'styrk-blocks' )
	);
	sb_ui_help( __( 'The icon opens the big menu with all the services.', 'styrk-blocks' ) );
}

function cb_header_render_hamburger_row(): void {
	sb_ui_line(
		static function (): void {
			cb_header_color_button( 'hamburger_bg', __( 'Background', 'styrk-blocks' ) );
			cb_header_color_button( 'hamburger_icon', __( 'Icon', 'styrk-blocks' ) );
		}
	);
	sb_ui_help( __( 'The button that opens the menu on mobile.', 'styrk-blocks' ) );
}

function cb_header_render_mobile_menu_row(): void {
	sb_ui_line(
		static function (): void {
			cb_header_color_button( 'mobile_menu_bg', __( 'Background', 'styrk-blocks' ) );
			cb_header_color_button( 'mobile_menu_text', __( 'Text', 'styrk-blocks' ) );
		}
	);
	sb_ui_help( __( 'Applies to the menu on mobile and the big menu on desktop.', 'styrk-blocks' ) );
}

function cb_header_render_megamenu_logo_color_row(): void {
	$s = cb_get_header_settings();
	sb_ui_segmented(
		cb_header_field_name( 'megamenu_logo_color' ),
		(string) $s['megamenu_logo_color'],
		[
			'colored' => __( 'Usual', 'styrk-blocks' ),
			'white'   => __( 'White', 'styrk-blocks' ),
			'black'   => __( 'Black', 'styrk-blocks' ),
		],
		__( 'Logo in the menu', 'styrk-blocks' )
	);
	sb_ui_help( __( 'Pick white or black if the logo does not show against the colour.', 'styrk-blocks' ) );
}

function cb_header_render_megamenu_logo_row(): void {
	$s = cb_get_header_settings();
	sb_ui_media( cb_header_field_name( 'megamenu_logo_id' ), (int) $s['megamenu_logo_id'], cb_header_media_text(), false );
	sb_ui_help( __( 'A ready-made logo for the open menu. Leave it empty to use the choice above.', 'styrk-blocks' ) );
}

function cb_header_render_loading_row(): void {
	$s = cb_get_header_settings();
	sb_ui_toggle( cb_header_field_name( 'ssr' ), ! empty( $s['ssr'] ), __( 'Show the menu straight away', 'styrk-blocks' ) );
	sb_ui_help( __( 'The menu is made before the page shows, so it does not jump into place. Turn it off if something looks wrong.', 'styrk-blocks' ) );
}

/**
 * The manual width controls (alignment, content width, side padding). They only
 * matter when no picture is chosen under Width, so the whole row dims then.
 * Content width and side padding matter only for "Own" alignment.
 */
function cb_header_render_own_width_row(): void {
	$s = cb_get_header_settings();
	sb_ui_stack(
		static function () use ( $s ): void {
			sb_ui_segmented(
				cb_header_field_name( 'header_align' ),
				(string) $s['header_align'],
				[
					'content' => __( 'Like the content', 'styrk-blocks' ),
					'full'    => __( 'Full width', 'styrk-blocks' ),
					'custom'  => __( 'Own', 'styrk-blocks' ),
				],
				__( 'Own width', 'styrk-blocks' )
			);
			sb_ui_line(
				static function () use ( $s ): void {
					echo '<span class="sb-inline"><span>' . esc_html__( 'Content', 'styrk-blocks' ) . '</span>';
					sb_ui_select(
						cb_header_field_name( 'content_width' ),
						(string) $s['content_width'],
						[
							''     => __( 'Follows the site', 'styrk-blocks' ),
							'1180' => __( 'Narrow', 'styrk-blocks' ),
							'1280' => __( 'Normal', 'styrk-blocks' ),
							'1440' => __( 'Wide', 'styrk-blocks' ),
							'full' => __( 'Full width', 'styrk-blocks' ),
						],
						__( 'Content', 'styrk-blocks' )
					);
					echo '</span><span class="sb-inline"><span>' . esc_html__( 'Side margin', 'styrk-blocks' ) . '</span>';
					sb_ui_stepper(
						cb_header_field_name( 'side_pad' ),
						(string) $s['side_pad'],
						0,
						120,
						52,
						[
							'less'        => __( 'Less', 'styrk-blocks' ),
							'more'        => __( 'More', 'styrk-blocks' ),
							'label'       => __( 'Side margin', 'styrk-blocks' ),
							'placeholder' => '—',
						]
					);
					echo '</span>';
				},
				cb_header_field_name( 'header_align' ) . ':custom'
			);
		},
		cb_header_field_name( 'frame_width' ) . ':'
	);
	sb_ui_help( __( 'Only when none of the pictures under Width fit. An empty side margin means the standard.', 'styrk-blocks' ) );
}

/* ── Summaries (the one line a closed part shows) ───────────────────────────── */

/**
 * How light or dark a colour is, in the words the summary uses.
 *
 * @param string $hex Colour (#rrggbb); anything else counts as unknown.
 * @return string 'white' | 'light' | 'dark' | ''
 */
function cb_header_tone( string $hex ): string {
	if ( ! function_exists( 'cb_header_parse_hex' ) || null === cb_header_parse_hex( $hex ) ) {
		return '';
	}
	$lum = cb_header_relative_luminance( $hex );
	if ( $lum > 0.85 ) {
		return 'white';
	}
	return $lum > 0.25 ? 'light' : 'dark';
}

/**
 * Hex of a palette slug ('' when the slug is empty or not in the palette).
 *
 * @param string $slug Palette slug.
 */
function cb_header_slug_color( string $slug ): string {
	if ( '' === $slug ) {
		return '';
	}
	foreach ( cb_header_theme_palette() as $sw ) {
		if ( (string) ( $sw['slug'] ?? '' ) === $slug ) {
			return (string) $sw['color'];
		}
	}
	return '';
}

/**
 * Summary pieces of one part.
 *
 * @param array<string,mixed> $s Saved settings.
 * @return string[]
 */
function cb_header_summary_logos( array $s ): array {
	$parts = [];
	$parts[] = ! empty( $s['logo_id'] ) ? __( 'Logo', 'styrk-blocks' ) : __( 'No logo', 'styrk-blocks' );
	if ( ! empty( $s['cta_show'] ) ) {
		$label   = '' !== trim( (string) $s['cta_label'] ) ? (string) $s['cta_label'] : 'Ta kontakt';
		$parts[] = '«' . $label . '»';
	} else {
		$parts[] = __( 'no button', 'styrk-blocks' );
	}

	return $parts;
}

/**
 * Summary pieces of one part.
 *
 * @param array<string,mixed> $s Saved settings.
 * @return string[]
 */
function cb_header_summary_appearance( array $s ): array {
	$parts = [];
	if ( 'solid' === $s['bg_mode'] ) {
		$bg = [
			'white' => __( 'White background', 'styrk-blocks' ),
			'light' => __( 'Light background', 'styrk-blocks' ),
			'dark'  => __( 'Dark background', 'styrk-blocks' ),
		][ cb_header_tone( (string) $s['bg_color'] ) ] ?? __( 'Coloured background', 'styrk-blocks' );
		$parts[] = $bg;
	} else {
		$parts[] = __( 'Transparent background', 'styrk-blocks' );
	}
	$text = cb_header_tone( (string) $s['text_color'] );
	if ( '' !== $text ) {
		$parts[] = 'dark' === $text ? __( 'dark text', 'styrk-blocks' ) : __( 'light text', 'styrk-blocks' );
	}
	$radius  = (int) $s['cta_radius'];
	$corners = array_search( $radius, cb_header_corner_values(), true );
	$parts[] = [
		'sharp' => __( 'square corners', 'styrk-blocks' ),
		'soft'  => __( 'slightly round corners', 'styrk-blocks' ),
		'round' => __( 'round corners', 'styrk-blocks' ),
	][ (string) $corners ] ?? __( 'own corners', 'styrk-blocks' );

	return $parts;
}

/**
 * Summary pieces of one part.
 *
 * @param array<string,mixed> $s Saved settings.
 * @return string[]
 */
function cb_header_summary_behavior( array $s ): array {
	$parts = [];
	$sticky  = 'sticky' === $s['position'];
	$parts[] = $sticky ? __( 'Fixed at the top', 'styrk-blocks' ) : __( 'Scrolls with the page', 'styrk-blocks' );
	if ( $sticky && ! empty( $s['hide_on_scroll'] ) ) {
		$parts[] = __( 'hides when you scroll', 'styrk-blocks' );
	}
	if ( ! empty( $s['sort_sub'] ) ) {
		$parts[] = __( 'sub-pages A–Z', 'styrk-blocks' );
	}

	return $parts;
}

/**
 * Summary pieces of one part.
 *
 * @param array<string,mixed> $s Saved settings.
 * @return string[]
 */
function cb_header_summary_placement( array $s ): array {
	$parts = [];
	$parts[] = [
		'full'    => __( 'Full width', 'styrk-blocks' ),
		'wide'    => __( 'Wide', 'styrk-blocks' ),
		'content' => __( 'Like the content', 'styrk-blocks' ),
	][ (string) $s['frame_width'] ] ?? __( 'Width not set', 'styrk-blocks' );
	$parts[] = [
		'start'  => __( 'menu to the left', 'styrk-blocks' ),
		'center' => __( 'menu in the middle', 'styrk-blocks' ),
		'end'    => __( 'menu to the right', 'styrk-blocks' ),
	][ (string) $s['nav_align'] ] ?? '';
	if ( 'nav_toggle' === $s['nav_mode'] ) {
		$parts[] = __( 'menu and icon', 'styrk-blocks' );
	} elseif ( 'toggle' === $s['nav_mode'] ) {
		$parts[] = __( 'icon only', 'styrk-blocks' );
	}

	return $parts;
}

/**
 * Summary pieces of one part.
 *
 * @param array<string,mixed> $s Saved settings.
 * @return string[]
 */
function cb_header_summary_mobile( array $s ): array {
	$parts = [];
	$bg = (string) $s['mobile_menu_bg'];
	if ( '' === $bg ) {
		$parts[] = __( 'Standard colours', 'styrk-blocks' );
	} else {
		$tone    = cb_header_tone( cb_header_slug_color( $bg ) );
		$parts[] = 'dark' === $tone ? __( 'Dark menu', 'styrk-blocks' ) : ( '' === $tone ? __( 'Own colours', 'styrk-blocks' ) : __( 'Light menu', 'styrk-blocks' ) );
	}
	$parts[] = [
		'colored' => __( 'normal logo', 'styrk-blocks' ),
		'white'   => __( 'white logo', 'styrk-blocks' ),
		'black'   => __( 'black logo', 'styrk-blocks' ),
	][ (string) $s['megamenu_logo_color'] ] ?? '';

	return $parts;
}

/**
 * Summary pieces of one part.
 *
 * @param array<string,mixed> $s Saved settings.
 * @return string[]
 */
function cb_header_summary_advanced( array $s ): array {
	$parts = [];
	if ( empty( $s['ssr'] ) ) {
		$parts[] = __( 'menu not shown straight away', 'styrk-blocks' );
	}
	if ( '' === (string) $s['frame_width'] && 'custom' !== $s['header_align'] ) {
		$parts[] = 'content' === $s['header_align'] ? __( 'width like the content', 'styrk-blocks' ) : __( 'full width', 'styrk-blocks' );
	} elseif ( '' === (string) $s['frame_width'] && ( '' !== (string) $s['content_width'] || '' !== (string) $s['side_pad'] ) ) {
		$parts[] = __( 'own width', 'styrk-blocks' );
	}
	if ( ! $parts ) {
		$parts[] = __( 'Standard', 'styrk-blocks' );
	}

	return $parts;
}

/**
 * One-line summary of a part, computed from the SAVED options.
 *
 * @param string $id Section id.
 */
function cb_header_part_summary( string $id ): string {
	$map = [
		'cb_header_logos'      => 'cb_header_summary_logos',
		'cb_header_appearance' => 'cb_header_summary_appearance',
		'cb_header_behavior'   => 'cb_header_summary_behavior',
		'cb_header_mobile'     => 'cb_header_summary_mobile',
		'cb_header_advanced'   => 'cb_header_summary_advanced',
	];
	if ( ! isset( $map[ $id ] ) ) {
		return '';
	}
	$set   = cb_get_header_settings();
	$parts = $map[ $id ]( $set );
	// Width and menu side now live in Appearance, the desktop menu choice in Behaviour.
	if ( 'cb_header_appearance' === $id ) {
		$parts = array_merge( $parts, array_slice( cb_header_summary_placement( $set ), 0, 2 ) );
	} elseif ( 'cb_header_behavior' === $id ) {
		$parts = array_merge( $parts, array_slice( cb_header_summary_placement( $set ), 2 ) );
	}
	$parts = array_filter( $parts, static fn( $p ) => '' !== (string) $p );
	return implode( ' · ', $parts );
}

/**
 * Theme-palette dropdown. Stores a palette SLUG (or '' for "keep the current
 * look"). render.php turns the slug into `var(--wp--preset--color--{slug})`,
 * so the colour tracks the theme palette instead of a frozen hex. Options are
 * built from the active theme palette, so each site shows its own colours.
 */
/**
 * Shared visual swatch picker — renders the theme palette as clickable colour
 * squares (radio inputs, no JS, no hex typing). Used by every colour field on
 * this page so they all look + behave the same.
 *
 * $value_mode:
 *   'slug' → each swatch submits the palette slug (resolved to a CSS var later)
 *   'hex'  → each swatch submits the literal hex
 * $has_default adds a leading "Default / current look" swatch (value '').
 *
 * A hidden input mirrors the current value first; the checked radio (later in
 * the DOM) overrides it on submit. So picking nothing keeps the current value
 * — even a legacy off-palette hex — instead of silently resetting it.
 */
function cb_header_render_swatches( string $name, string $current, string $value_mode, bool $has_default ): void {
	static $css_printed = false;
	if ( ! $css_printed ) {
		$css_printed = true;
		echo '<style>'
			. '.cb-swatches{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:2px 0}'
			. '.cb-swatch{position:relative;display:inline-flex;cursor:pointer;line-height:0}'
			. '.cb-swatch input{position:absolute;inset:0;width:100%;height:100%;margin:0;opacity:0;cursor:pointer}'
			. '.cb-swatch__box{display:block;width:30px;height:30px;border-radius:6px;border:1px solid rgba(0,0,0,.18);box-sizing:border-box}'
			. '.cb-swatch input:checked+.cb-swatch__box{box-shadow:0 0 0 2px #fff,0 0 0 4px #2271b1}'
			. '.cb-swatch input:focus-visible+.cb-swatch__box{box-shadow:0 0 0 2px #fff,0 0 0 4px #2271b1}'
			. '.cb-swatch--default .cb-swatch__box{background:repeating-linear-gradient(135deg,#fff 0 6px,#d63638 6px 8px)}'
			. '</style>';
	}

	// Hidden fallback so an off-palette current value survives a save.
	printf( '<input type="hidden" name="%s" value="%s" />', esc_attr( $name ), esc_attr( $current ) );

	echo '<div class="cb-swatches">';

	if ( $has_default ) {
		printf(
			'<label class="cb-swatch cb-swatch--default" title="%1$s"><input type="radio" name="%2$s" value="" %3$s aria-label="%1$s" /><span class="cb-swatch__box"></span></label>',
			esc_attr__( 'Default (current look)', 'styrk-blocks' ),
			esc_attr( $name ),
			checked( $current, '', false )
		);
	}

	foreach ( cb_header_theme_palette() as $sw ) {
		$slug  = (string) ( $sw['slug'] ?? '' );
		$color = (string) ( $sw['color'] ?? '' );
		$value = 'slug' === $value_mode ? $slug : $color;
		if ( '' === $value || '' === $color ) {
			continue;
		}
		$label = (string) ( $sw['name'] ?? $slug ) . ' — ' . $color;
		printf(
			'<label class="cb-swatch" title="%1$s"><input type="radio" name="%2$s" value="%3$s" %4$s aria-label="%1$s" /><span class="cb-swatch__box" style="background:%5$s"></span></label>',
			esc_attr( $label ),
			esc_attr( $name ),
			esc_attr( $value ),
			checked( strcasecmp( $current, $value ) === 0, true, false ),
			esc_attr( $color )
		);
	}

	echo '</div>';
}

/**
 * Theme colour palette (from theme.json / global settings) as a flat list of
 * { color, name } for the admin swatch picker — same palette the in-canvas
 * block colour pickers use.
 */
function cb_header_theme_palette(): array {
	$out = array();
	if ( function_exists( 'wp_get_global_settings' ) ) {
		$palette = wp_get_global_settings( array( 'color', 'palette' ) );
		$list    = array();
		if ( ! empty( $palette['theme'] ) ) {
			$list = $palette['theme'];
		} elseif ( ! empty( $palette['default'] ) ) {
			$list = $palette['default'];
		} elseif ( is_array( $palette ) && isset( $palette[0] ) ) {
			$list = $palette;
		}
		foreach ( (array) $list as $c ) {
			if ( ! empty( $c['color'] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $c['color'] ) ) {
				$out[] = array(
					'color' => $c['color'],
					'name'  => $c['name'] ?? ( $c['slug'] ?? $c['color'] ),
					'slug'  => $c['slug'] ?? '',
				);
			}
		}
	}
	return $out;
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

function cb_header_sanitize( $input ): array {
	$defaults  = cb_header_defaults();
	$sanitized = [];

	/* Logos — integer IDs */
	$sanitized['logo_id']       = isset( $input['logo_id'] )       ? absint( $input['logo_id'] )       : $defaults['logo_id'];
	$sanitized['logo_white_id'] = isset( $input['logo_white_id'] ) ? absint( $input['logo_white_id'] ) : $defaults['logo_white_id'];
	$sanitized['megamenu_logo_id'] = isset( $input['megamenu_logo_id'] ) ? absint( $input['megamenu_logo_id'] ) : $defaults['megamenu_logo_id'];

	/* Background mode — whitelist */
	$sanitized['bg_mode'] = isset( $input['bg_mode'] ) && in_array( $input['bg_mode'], [ 'transparent', 'solid' ], true )
		? $input['bg_mode']
		: $defaults['bg_mode'];

	/* Position — whitelist */
	$sanitized['position'] = isset( $input['position'] ) && in_array( $input['position'], [ 'relative', 'sticky' ], true )
		? $input['position']
		: $defaults['position'];

	/* Hide-on-scroll — checkbox is "1" when present, absent when off */
	$sanitized['hide_on_scroll'] = ! empty( $input['hide_on_scroll'] ) ? '1' : '0';
	$sanitized['ssr']            = ! empty( $input['ssr'] ) ? '1' : '0';
	$sanitized['sort_sub']       = ! empty( $input['sort_sub'] ) ? '1' : '0';

	/* Header and footer width — whitelist, fall back to '' (not set). */
	$sanitized['frame_width'] = isset( $input['frame_width'] ) && in_array( $input['frame_width'], [ 'full', 'content', 'wide' ], true )
		? $input['frame_width']
		: '';

	/* Header alignment — whitelist, fall back to 'custom' (back-compat). */
	$sanitized['header_align'] = isset( $input['header_align'] ) && in_array( $input['header_align'], [ 'content', 'full', 'custom' ], true )
		? $input['header_align']
		: $defaults['header_align'];

	/* Element alignment (legacy, Custom only) — no longer has its own field, so
	   PRESERVE whatever value was saved when it isn't in the submitted form
	   (otherwise saving the page would silently wipe an existing 'spread'). */
	$existing_layout = (string) ( get_option( CB_HEADER_OPTION, [] )['nav_layout'] ?? '' );
	$sanitized['nav_layout'] = isset( $input['nav_layout'] ) && in_array( $input['nav_layout'], [ 'compact', 'spread' ], true )
		? $input['nav_layout']
		: $existing_layout;

	/* Menu alignment — whitelist start/center/end, fall back to historical 'start'. */
	$sanitized['nav_align'] = isset( $input['nav_align'] ) && in_array( $input['nav_align'], [ 'start', 'center', 'end' ], true )
		? $input['nav_align']
		: $defaults['nav_align'];

	/* Desktop nav mode — whitelist, fall back to historical 'nav'. */
	$sanitized['nav_mode'] = isset( $input['nav_mode'] ) && in_array( $input['nav_mode'], [ 'nav', 'nav_toggle', 'toggle' ], true )
		? $input['nav_mode']
		: $defaults['nav_mode'];

	/* Megamenu logo color — whitelist, fall back to historical 'white'. */
	$sanitized['megamenu_logo_color'] = isset( $input['megamenu_logo_color'] ) && in_array( $input['megamenu_logo_color'], [ 'colored', 'white', 'black' ], true )
		? $input['megamenu_logo_color']
		: $defaults['megamenu_logo_color'];

	/* Content width — whitelist of presets, fall back to historical 1280 */
	/* Content width — '' (inherit) or a whitelisted preset. Inherit means
	   "don't emit a CSS var", so the block/template value wins. */
	$sanitized['content_width'] = isset( $input['content_width'] ) && in_array( $input['content_width'], [ '1180', '1280', '1440', 'full' ], true )
		? $input['content_width']
		: '';

	/* Side padding — '' (inherit) or integer px clamped to 0–120. A blank
	   field stays blank (inherit) rather than snapping to 0. */
	$sanitized['side_pad'] = ( isset( $input['side_pad'] ) && '' !== trim( (string) $input['side_pad'] ) )
		? (string) max( 0, min( 120, absint( $input['side_pad'] ) ) )
		: '';

	/* Header CTA — label/url plain text, show toggle as "1"/"0". */
	$sanitized['cta_label'] = isset( $input['cta_label'] ) ? sanitize_text_field( (string) $input['cta_label'] ) : $defaults['cta_label'];
	$sanitized['cta_url']   = isset( $input['cta_url'] )   ? esc_url_raw( (string) $input['cta_url'] )           : $defaults['cta_url'];
	$sanitized['cta_show']  = ! empty( $input['cta_show'] ) ? '1' : '0';

	/* Colors — must be valid hex */
	foreach ( [ 'bg_color', 'text_color' ] as $color_key ) {
		if ( isset( $input[ $color_key ] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $input[ $color_key ] ) ) {
			$sanitized[ $color_key ] = $input[ $color_key ];
		} else {
			$sanitized[ $color_key ] = $defaults[ $color_key ];
		}
	}

	/* Mobile hamburger + menu colours — '' (inherit) or a slug that exists in
	   the current theme palette. Anything else falls back to '' so a stale or
	   spoofed slug can never reach render.php. */
	$palette_slugs = array_filter( array_map(
		static fn( $sw ) => (string) ( $sw['slug'] ?? '' ),
		cb_header_theme_palette()
	) );
	foreach ( [ 'hamburger_bg', 'hamburger_icon', 'mobile_menu_bg', 'mobile_menu_text', 'cta_bg', 'cta_text' ] as $palette_key ) {
		$val = isset( $input[ $palette_key ] ) ? sanitize_key( (string) $input[ $palette_key ] ) : '';
		$sanitized[ $palette_key ] = ( '' !== $val && in_array( $val, $palette_slugs, true ) ) ? $val : '';
	}

	/* CTA corner radius. `max` on a number input is advisory — a crafted POST
	   submits anything — so clamp on the way in. */
	$sanitized['cta_radius'] = isset( $input['cta_radius'] )
		? max( 0, min( 50, (int) $input['cta_radius'] ) )
		: $defaults['cta_radius'];

	/* Sync main logo to the custom_logo theme mod so wp:site-logo works */
	if ( ! empty( $sanitized['logo_id'] ) ) {
		set_theme_mod( 'custom_logo', $sanitized['logo_id'] );
	}

	return $sanitized;
}

/* ── Admin page template ────────────────────────────────────────────────────── */

function cb_header_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	wp_enqueue_media();
	?>
	<div class="wrap sb-ui" data-sb-page="header">
		<h1><?php esc_html_e( 'Header Settings', 'styrk-blocks' ); ?></h1>
		<p class="sb-ui__intro"><?php esc_html_e( 'Open a part to change it. The closed parts show what is chosen now.', 'styrk-blocks' ); ?></p>
		<noscript><style>.sb-part__body[hidden]{display:block}</style></noscript>
		<form method="post" action="options.php">
			<?php settings_fields( 'cb_header_group' ); ?>
			<div class="sb-panel">
				<h2 class="sb-panel__title"><?php esc_html_e( 'Top menu', 'styrk-blocks' ); ?></h2>
				<?php sb_ui_render_parts( 'cb-header-settings', 'cb_header_part_summary' ); ?>
			</div>
			<button type="submit" name="submit" class="sb-submit"><?php esc_html_e( 'Save changes', 'styrk-blocks' ); ?></button>
		</form>
	</div>
	<?php
}

/* ── Seed defaults on first load ────────────────────────────────────────────── */

function cb_header_seed_defaults(): void {
	if ( get_option( CB_HEADER_OPTION ) ) {
		return;
	}
	update_option( CB_HEADER_OPTION, cb_header_defaults() );
}
add_action( 'admin_init', 'cb_header_seed_defaults' );

/* ── Output header CSS vars to <head> ───────────────────────────────────────── */

function cb_header_output_css_vars(): void {
	$s = cb_get_header_settings();

	$bg_mode    = $s['bg_mode'] ?? 'transparent';
	$bg_color   = $s['bg_color'] ?? '#0a2020';
	$text_color = $s['text_color'] ?? '#ffffff';

	$bg_value = $bg_mode === 'solid' ? $bg_color : 'transparent';

	$vars  = '--cb-header-bg:' . esc_attr( $bg_value ) . ';';
	$vars .= '--cb-header-text:' . esc_attr( $text_color ) . ';';
	$vars .= '--cb-header-bg-mode:' . esc_attr( $bg_mode ) . ';';

	// Header rail width + side gutter → CSS vars consumed by the React header
	// (view.tsx). Driven by the single "Header alignment" control:
	$header_align = (string) ( $s['header_align'] ?? 'custom' );
	$side_css     = '';

	// "Header and footer width" outranks "Header alignment": it sets the same
	// two header vars AND frames the footer with them, so both bands share
	// their edges. Printed here (not in style.css) so it applies only when an
	// admin chose a value; !important because companion themes pin their own
	// footer width.
	$frame_width = (string) ( $s['frame_width'] ?? '' );
	$frames      = [
		// Capped at 2560px like the hero and full-bleed sections (see .cb-hero).
		'full'    => [ '2560px', 'clamp(16px,2vw,40px)' ],
		'content' => [ 'var(--cb-content-max,1280px)', 'var(--cb-rail,3.25rem)' ],
		'wide'    => [ '1600px', 'var(--cb-rail,3.25rem)' ],
	];

	if ( isset( $frames[ $frame_width ] ) ) {
		$vars     .= '--cb-header-max-width:' . $frames[ $frame_width ][0] . ';';
		$vars     .= '--cb-header-side-pad:' . $frames[ $frame_width ][1] . ';';
		$side_css  = '.site-footer__inner,.site-footer__bar{box-sizing:border-box!important;width:100%!important;max-width:var(--cb-header-max-width)!important;margin-left:auto!important;margin-right:auto!important;padding-left:var(--cb-header-side-pad)!important;padding-right:var(--cb-header-side-pad)!important}';
		$side_css .= '.site-footer__bar>.wp-block-group{max-width:none!important;padding-left:0!important;padding-right:0!important}';
		// Themes give the footer band its own side padding on small screens,
		// which would push the footer further in than the header.
		$side_css .= '.site-footer{padding-left:0!important;padding-right:0!important}';
	} elseif ( 'content' === $header_align ) {
		// Match the page content column: reuse the SAME max-width + rail gutter
		// every section uses, so the logo lines up with the content's left edge
		// and the search / CTA cluster with its right edge — no manual numbers.
		$vars .= '--cb-header-max-width:var(--cb-content-max,1280px);';
		$vars .= '--cb-header-side-pad:var(--cb-rail,3.25rem);';
	} elseif ( 'full' === $header_align ) {
		// Border to border WITH the hero. The hero and full-bleed sections cap at
		// max-width:2560px centred (see .cb-hero in style.css); a raw 100vw header
		// overhangs them on ultra-wide screens. Match that exact 2560px box with
		// no side gutter, so the logo and search/CTA sit on the hero image's
		// left/right edges at every width, with a small 16px breathing gutter so
		// the logo/CTA aren't jammed against the edge. (Keep the 2560 in sync
		// with .cb-hero max-width.)
		$vars .= '--cb-header-max-width:2560px;';
		$vars .= '--cb-header-side-pad:16px;';
	} else {
		// Custom / legacy: honour the explicit Content width + Side padding
		// controls exactly as before. Emitted ONLY when a value is set, so a
		// per-block contentWidth attribute and view.tsx's 1280/52 fallback still
		// win when left on "Inherit".
		$content_width = (string) ( $s['content_width'] ?? '' );
		if ( in_array( $content_width, [ '1180', '1280', '1440', 'full' ], true ) ) {
			$max_width = $content_width === 'full' ? 'none' : $content_width . 'px';
			$vars .= '--cb-header-max-width:' . esc_attr( $max_width ) . ';';
		}
		// Admin side gutter is the DESKTOP value; cap it to the shared section
		// rail on smaller screens (32px tablet, 16px mobile) via media queries
		// emitted AFTER the base rule so they win by source order.
		$side_pad = (string) ( $s['side_pad'] ?? '' );
		if ( '' !== $side_pad && is_numeric( $side_pad ) ) {
			$pad       = (int) $side_pad;
			$vars     .= '--cb-header-side-pad:' . esc_attr( $pad . 'px' ) . ';';
			$side_css  = sprintf( '@media (max-width:1023px){:root{--cb-header-side-pad:min(%dpx,2rem)}}', $pad );
			$side_css .= sprintf( '@media (max-width:639px){:root{--cb-header-side-pad:min(%dpx,1rem)}}', $pad );
		}
	}

	// wp_strip_all_tags() so a value can never close the <style> element.
	printf( '<style id="cb-header-vars">:root{%s}%s</style>' . "\n", wp_strip_all_tags( $vars ), wp_strip_all_tags( $side_css ) );
}
add_action( 'wp_head', 'cb_header_output_css_vars', 1 );
