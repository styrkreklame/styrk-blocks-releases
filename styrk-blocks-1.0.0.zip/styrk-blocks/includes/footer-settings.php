<?php
/**
 * Footer Settings — admin page and helpers.
 *
 * Registers an options page under Settings → Footer where site admins
 * can manage company description, address, phone, email, copyright,
 * and the "follow us" column heading. Social links themselves are
 * managed via the social_link CPT (see styrk-blocks.php).
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard — see header-settings.php for the rationale.
if ( defined( 'CB_FOOTER_SETTINGS_LOADED' ) ) return;
define( 'CB_FOOTER_SETTINGS_LOADED', true );

/* ── Option key (all stored under one serialized option) ────────────────────── */
define( 'CB_FOOTER_OPTION', 'cb_footer_settings' );

/**
 * Default values for every footer field.
 */
function cb_footer_defaults(): array {
	$site_name = get_bloginfo( 'name' ) ?: 'Bedriftsnavn';
	return [
		// Attachment ID of the white/light logo variant used in the dark
		// footer. Zero = no custom logo uploaded; the shortcode falls back
		// to the main header logo (CSS-inverted) or the theme asset.
		// (This used to live under cb_header_settings as logo_white_id —
		// moved to footer settings in v1.6.5 to group with other footer
		// fields. A one-shot migration copies the old value across.)
		'logo_white_id'  => 0,
		// Footer bar colours — theme palette SLUGS (resolved to CSS vars in
		// cb_footer_output_css_vars). '' = inherit: keep the historical navy bar
		// with white text.
		'bg_color'       => '',
		'text_color'     => '',
		// Heading of the first footer column (the company name). Empty =
		// no heading rendered — it is NOT auto-filled from the global site
		// name, so the footer only shows what an admin explicitly sets here.
		'site_name_heading' => '',
		// Contact + description default to EMPTY, never to sample text.
		// A default that looks like real content ships to the front end of
		// every site that has not yet saved this screen — visitors saw
		// "Gateadresse 1 / 0000 Sted, Norge / post@bedriftsnavn.no". The
		// example wording now lives in the field's placeholder attribute,
		// where it guides the admin without ever rendering. Matches how
		// `org_number` below has always behaved.
		'description'    => '',
		// Heading of the Kontakt column. Defaults to "Kontakt" so existing
		// sites keep the label they already show; it is suppressed anyway
		// when every contact field is empty.
		'contact_heading' => 'Kontakt',
		// Optional SEPARATE heading for the address, for footers whose design
		// splits "Adresse" and "Kontakt" into two labelled stacks inside one
		// column. Empty by default, so the historical single-heading layout
		// ([footer_contact_heading] over address + email + phone) is unchanged
		// on every site that does not set it.
		'address_heading' => '',
		'address'        => '',
		'email'          => '',
		'phone_1'        => '',
		'phone_2'        => '',
		// Opening hours, free text, one line per row (e.g.
		// "Mandag-fredag 07:00-15:30"). Empty by default so no existing
		// site suddenly grows an hours line in its footer. Rendered by
		// [footer_contact] (part `hours`) and read by any site-level
		// LocalBusiness schema, so the client edits the hours in one place.
		// Legacy free-text hours. Still rendered when the per-day fields below
		// are untouched, so no site loses its hours on update.
		'opening_hours'  => '',
		// Per-day hours: the machine-readable source of truth (see
		// includes/footer-hours.php). Closed by default — an empty week says
		// nothing, which is honest, where a guessed 08–16 would not be.
		'hours_mon_open' => 0, 'hours_mon_from' => '', 'hours_mon_to' => '',
		'hours_tue_open' => 0, 'hours_tue_from' => '', 'hours_tue_to' => '',
		'hours_wed_open' => 0, 'hours_wed_from' => '', 'hours_wed_to' => '',
		'hours_thu_open' => 0, 'hours_thu_from' => '', 'hours_thu_to' => '',
		'hours_fri_open' => 0, 'hours_fri_from' => '', 'hours_fri_to' => '',
		'hours_sat_open' => 0, 'hours_sat_from' => '', 'hours_sat_to' => '',
		'hours_sun_open' => 0, 'hours_sun_from' => '', 'hours_sun_to' => '',
		// Norwegian organisasjonsnummer (9 digits). Empty by default — the
		// shortcode output is silently skipped when unset, so sites outside
		// NO or without a registered entity don't get a broken "Org.nr."
		// label. Formatted for display as "NNN NNN NNN" regardless of how
		// the admin enters it.
		'org_number'     => '',
		'copyright'      => '© ' . gmdate( 'Y' ) . ' ' . $site_name . '. Alle rettigheter forbeholdt.',
		'social_heading' => 'Følg oss',
		'credits'        => 'Utvikling og design av Styrk Reklame AS',
		'credits_url'    => 'https://styrkreklame.no/',
		// Optional small mark/icon shown to the LEFT of the credits text
		// (e.g. an agency logo). Attachment ID; 0 = use the bundled
		// styrk-reklame-logo.webp when the credits text mentions Styrk
		// Reklame, otherwise no mark.
		'credits_icon_id' => 0,
		// Where the credits logo sits relative to the credits text.
		//   inline — replace the spot next to "Styrk Reklame" (default,
		//            back-compat with sites built before this setting existed)
		//   start  — before the credits sentence (e.g. "[logo] Utvikling og…")
		//   end    — after the credits sentence (e.g. "Utvikling og… [logo]")
		'credits_logo_position' => 'inline',
		// LEGACY. The old "one link per line, Label|URL" textarea.
		//
		// It made admins learn a private mini-language — a pipe, or a bare
		// path, and a slash meant something else again. Typing
		// "Personvern/personvern" (slash instead of pipe) silently produced
		// <a href="http://Personvern/personvern"> — an off-site link to a
		// host called "Personvern" — with no warning anywhere.
		//
		// Replaced by the legal_{1..4}_* slots below: a label, and a link you
		// either pick from a page or type. Still READ, so no existing site
		// loses its links, and still migrated into the new fields on the
		// settings screen — but no longer editable as a DSL.
		'legal_links'    => '',

		// Legal links — up to four, each a plain label plus a destination.
		//   *_label  the visible text  ("Personvern")
		//   *_page   an internal page, chosen from a dropdown (0 = none)
		//   *_url    a URL, used when no page is picked. Internal ("/sti")
		//            or external ("https://…") — both work, no syntax to learn.
		// The page wins when both are set.
		'legal_1_label'  => '',
		'legal_1_page'   => 0,
		'legal_1_url'    => '',
		'legal_2_label'  => '',
		'legal_2_page'   => 0,
		'legal_2_url'    => '',
		'legal_3_label'  => '',
		'legal_3_page'   => 0,
		'legal_3_url'    => '',
		'legal_4_label'  => '',
		'legal_4_page'   => 0,
		'legal_4_url'    => '',
		// Certification badges shown in the footer top row (paired with
		// the logo). Up to three. Each is an attachment ID — empty/0
		// means no badge, and the [footer_certs] shortcode renders only
		// the slots that are set, so a site with one cert doesn't get
		// two empty placeholders. Optional one-line text under each
		// badge for screen readers + a tooltip.
		'cert_1_id'      => 0,
		'cert_1_label'   => '',
		'cert_1_url'     => '',
		'cert_2_id'      => 0,
		'cert_2_label'   => '',
		'cert_2_url'     => '',
		'cert_3_id'      => 0,
		'cert_3_label'   => '',
		'cert_3_url'     => '',
		'cert_4_id'      => 0,
		'cert_4_label'   => '',
		'cert_4_url'     => '',
		'cert_5_id'      => 0,
		'cert_5_label'   => '',
		'cert_5_url'     => '',
		'cert_6_id'      => 0,
		'cert_6_label'   => '',
		'cert_6_url'     => '',
		// Horizontal alignment of the certification-badge row on desktop:
		// 'left' | 'center' | 'right'. Mobile is ALWAYS centred (handled in
		// CSS). Default 'center' — a badge/cert strip reads best centred.
		'cert_align'     => 'center',
		// Footer layout controls. Defaults reproduce the historical footer:
		// logo on the left with the description as the first column beside
		// it, and every column left-aligned.
		//   brand_layout 'stacked' = description UNDER the logo, split by the
		//   footer's thin rule; the remaining columns sit centre and right,
		//   echoing the bottom bar (copyright | legal | credits).
		//   social_align 'right' = the last column lines up with the right
		//   edge, above the credits.
		'brand_layout'   => 'side',   // 'side' | 'stacked'
		// Page-links column ([footer_pages]). Off until a menu is chosen: the
		// links come from a Navigation menu (edited in the Site Editor), the
		// heading and the choice of menu from here.
		'pages_heading'  => '',
		'pages_menu'     => 0,        // wp_navigation post ID, 0 = no column
		'pages_all_page' => 0,        // page ID of the «Alle sider» sitemap, 0 = no link
		'social_align'   => 'left',   // 'left' | 'right'
		'cert_height'    => 96,
		// Newsletter signup column. Optional + OFF by default — the
		// [footer_newsletter] shortcode renders nothing until an admin
		// ticks "Show newsletter signup". When on, the heading + consent
		// body + a trailing privacy link + the email form are shown.
		'newsletter_enabled'       => 0,
		'newsletter_heading'       => 'Motta vårt nyhetsbrev',
		// Consent sentence. The privacy link (label + URL below) is
		// appended after this text by the shortcode, so the body ends just
		// before the link — keep it ending with "… i vår".
		'newsletter_body'          => 'Ved å registrere deg samtykker du til at vi kan samle inn og behandle opplysninger om deg. Les mer i vår',
		'newsletter_privacy_url'   => '/personvern',
		'newsletter_privacy_label' => 'personvernerklæringen',
	];
}

/**
 * Return merged (saved + defaults) footer settings.
 */
function cb_get_footer_settings(): array {
	$saved = get_option( CB_FOOTER_OPTION, [] );
	return wp_parse_args( $saved, cb_footer_defaults() );
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_footer_settings_menu(): void {
	add_options_page(
		__( 'Footer Settings', 'styrk-blocks' ),
		__( 'Footer', 'styrk-blocks' ),
		'manage_options',
		'cb-footer-settings',
		'cb_footer_settings_page'
	);
}
add_action( 'admin_menu', 'cb_footer_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

/**
 * Settings → Footer is one panel of named parts (the admin UI kit, see
 * includes/admin-ui.php). Every option key, sanitiser and saved value is the
 * same as before; only the screen changed. Legacy fields (`legal_links`,
 * `opening_hours` while empty, `newsletter_privacy_*`) are no longer shown but
 * keep their saved value — see cb_footer_sanitize().
 */
function cb_footer_settings_init(): void {
	register_setting( 'cb_footer_group', CB_FOOTER_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_footer_sanitize',
		'default'           => cb_footer_defaults(),
	] );

	$page = 'cb-footer-settings';

	add_settings_section( 'cb_footer_contact', __( 'Contact', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_footer_row_company', __( 'Company', 'styrk-blocks' ), 'cb_footer_row_company', $page, 'cb_footer_contact' );
	add_settings_field( 'cb_footer_row_address', __( 'Address', 'styrk-blocks' ), 'cb_footer_row_address', $page, 'cb_footer_contact' );
	add_settings_field( 'cb_footer_row_phone', __( 'Email and phone', 'styrk-blocks' ), 'cb_footer_row_phone', $page, 'cb_footer_contact' );
	add_settings_field( 'cb_footer_row_org', __( 'Org. no.', 'styrk-blocks' ), 'cb_footer_row_org', $page, 'cb_footer_contact' );
	add_settings_field( 'cb_footer_row_hours', __( 'Opening hours', 'styrk-blocks' ), 'cb_footer_row_hours', $page, 'cb_footer_contact' );

	add_settings_section( 'cb_footer_logo', __( 'Logo and badges', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_footer_row_logo', __( 'Logo', 'styrk-blocks' ), 'cb_footer_row_logo', $page, 'cb_footer_logo' );
	add_settings_field( 'cb_footer_row_badges', __( 'Badges', 'styrk-blocks' ), 'cb_footer_row_badges', $page, 'cb_footer_logo' );

	add_settings_section( 'cb_footer_cols', __( 'Columns', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_footer_row_pages', __( 'Pages', 'styrk-blocks' ), 'cb_footer_row_pages', $page, 'cb_footer_cols' );
	add_settings_field( 'cb_footer_row_social', __( 'Follow us', 'styrk-blocks' ), 'cb_footer_row_social', $page, 'cb_footer_cols' );
	add_settings_field( 'cb_footer_row_contact_col', __( 'Contact column', 'styrk-blocks' ), 'cb_footer_row_contact_col', $page, 'cb_footer_cols' );
	add_settings_field( 'cb_footer_row_newsletter', __( 'Newsletter', 'styrk-blocks' ), 'cb_footer_row_newsletter', $page, 'cb_footer_cols' );

	add_settings_section( 'cb_footer_bottom', __( 'Bottom bar', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_footer_row_copyright', __( 'Copyright', 'styrk-blocks' ), 'cb_footer_row_copyright', $page, 'cb_footer_bottom' );
	add_settings_field( 'cb_footer_row_credits', __( 'Made by', 'styrk-blocks' ), 'cb_footer_row_credits', $page, 'cb_footer_bottom' );
	add_settings_field( 'cb_footer_row_legal', __( 'Links', 'styrk-blocks' ), 'cb_footer_row_legal', $page, 'cb_footer_bottom' );

	add_settings_section( 'cb_footer_look', __( 'Appearance', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_footer_row_colours', __( 'Colours', 'styrk-blocks' ), 'cb_footer_row_colours', $page, 'cb_footer_look' );
}
add_action( 'admin_init', 'cb_footer_settings_init' );

/** The kit's styles and script, and this screen's own script, on this screen. */
add_filter(
	'sb_ui_pages',
	static function ( $pages ) {
		$pages   = (array) $pages;
		$pages[] = 'settings_page_cb-footer-settings';
		return $pages;
	}
);

/**
 * The few behaviours only this screen needs (the opening-hours table and the
 * legal-link rows). Loaded with the kit, after it.
 *
 * @param string $hook Admin page hook suffix.
 */
function cb_footer_enqueue_admin( $hook ): void {
	if ( 'settings_page_cb-footer-settings' !== (string) $hook ) {
		return;
	}
	$file = dirname( __DIR__ ) . '/assets/admin/styrk-footer-admin.js';
	$ver  = (string) @filemtime( $file ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- a missing file only means no cache-bust.
	wp_enqueue_script( 'sb-footer-admin', plugins_url( 'assets/admin/styrk-footer-admin.js', dirname( __DIR__ ) . '/styrk-blocks.php' ), [ 'sb-admin-ui' ], $ver ?: null, true );
}
add_action( 'admin_enqueue_scripts', 'cb_footer_enqueue_admin' );

/* ── Small field helpers ────────────────────────────────────────────────────── */

/**
 * Name of a footer option's form field.
 *
 * @param string $key Option key.
 */
function cb_footer_field_name( string $key ): string {
	return CB_FOOTER_OPTION . '[' . $key . ']';
}

/**
 * A single-line (or two-line) text field for one option key.
 *
 * @param string $key         Option key.
 * @param string $label       Accessible name.
 * @param string $placeholder Placeholder.
 * @param string $type        'text' | 'email' | 'tel' | 'textarea'.
 */
function cb_footer_field( string $key, string $label, string $placeholder = '', string $type = 'text' ): void {
	$value = (string) ( cb_get_footer_settings()[ $key ] ?? '' );
	if ( 'textarea' === $type ) {
		printf(
			'<textarea class="sb-input sb-input--wide" name="%1$s" rows="2" aria-label="%2$s" placeholder="%3$s">%4$s</textarea>',
			esc_attr( cb_footer_field_name( $key ) ),
			esc_attr( $label ),
			esc_attr( $placeholder ),
			esc_textarea( $value )
		);
		return;
	}
	printf(
		'<input type="%1$s" class="sb-input sb-input--wide" name="%2$s" value="%3$s" aria-label="%4$s" placeholder="%5$s" />',
		esc_attr( $type ),
		esc_attr( cb_footer_field_name( $key ) ),
		esc_attr( $value ),
		esc_attr( $label ),
		esc_attr( $placeholder )
	);
}

/**
 * A text field with its label on its left ("Heading [ ... ]").
 *
 * @param string $key         Option key.
 * @param string $label       Visible label.
 * @param string $placeholder Placeholder.
 * @param string $when        Optional "field[name]:a|b" condition.
 */
function cb_footer_labelled( string $key, string $label, string $placeholder = '', string $when = '' ): void {
	printf(
		'<label class="sb-inline"%5$s><span>%1$s</span><input type="text" class="sb-input" name="%2$s" value="%3$s" placeholder="%4$s" /></label>',
		esc_html( $label ),
		esc_attr( cb_footer_field_name( $key ) ),
		esc_attr( (string) ( cb_get_footer_settings()[ $key ] ?? '' ) ),
		esc_attr( $placeholder ),
		sb_ui_when_attr( $when ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in sb_ui_when_attr().
	);
}

/**
 * The logo / image picker text, in one place.
 *
 * @param string $what 'logo' | 'image'.
 * @return array<string,string>
 */
function cb_footer_media_text( string $what ): array {
	if ( 'logo' === $what ) {
		return [
			'title'  => __( 'Select Logo', 'styrk-blocks' ),
			'button' => __( 'Use as Logo', 'styrk-blocks' ),
			'change' => __( 'Change logo', 'styrk-blocks' ),
			'upload' => __( 'Choose logo', 'styrk-blocks' ),
			'remove' => __( 'Remove', 'styrk-blocks' ),
		];
	}
	return [
		'title'  => __( 'Select image', 'styrk-blocks' ),
		'button' => __( 'Use image', 'styrk-blocks' ),
		'change' => __( 'Change image', 'styrk-blocks' ),
		'upload' => __( 'Choose image', 'styrk-blocks' ),
		'remove' => __( 'Remove', 'styrk-blocks' ),
	];
}

/* ── Rows: Contact ──────────────────────────────────────────────────────────── */

function cb_footer_row_company(): void {
	sb_ui_stack(
		static function (): void {
			cb_footer_field( 'site_name_heading', __( 'Company name', 'styrk-blocks' ), 'Bedriftsnavn AS' );
			cb_footer_field( 'description', __( 'Short text about the company', 'styrk-blocks' ), __( 'A short text about the company, shown under the logo.', 'styrk-blocks' ), 'textarea' );
		}
	);
	sb_ui_help( __( 'The name becomes the heading of the first column. Leave the field empty to hide it.', 'styrk-blocks' ) );
}

function cb_footer_row_address(): void {
	cb_footer_field( 'address', __( 'Address', 'styrk-blocks' ), "Gateadresse 1\n0000 Sted", 'textarea' );
	sb_ui_help( __( 'Leave the field empty to hide the address.', 'styrk-blocks' ) );
}

function cb_footer_row_phone(): void {
	$s = cb_get_footer_settings();
	sb_ui_stack(
		static function () use ( $s ): void {
			cb_footer_field( 'email', __( 'Email', 'styrk-blocks' ), 'post@bedriftsnavn.no', 'email' );
			sb_ui_line(
				static function () use ( $s ): void {
					printf(
						'<input type="tel" class="sb-input" name="%1$s" value="%2$s" aria-label="%3$s" placeholder="%4$s" />',
						esc_attr( cb_footer_field_name( 'phone_1' ) ),
						esc_attr( (string) $s['phone_1'] ),
						esc_attr__( 'Phone', 'styrk-blocks' ),
						esc_attr( '+47 00 00 00 00' )
					);
					printf(
						'<div data-sb-extra%1$s><input type="tel" class="sb-input" name="%2$s" value="%3$s" aria-label="%4$s" placeholder="%5$s" /></div>',
						'' === trim( (string) $s['phone_2'] ) ? ' hidden' : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal.
						esc_attr( cb_footer_field_name( 'phone_2' ) ),
						esc_attr( (string) $s['phone_2'] ),
						esc_attr__( 'Second phone number', 'styrk-blocks' ),
						esc_attr( '+47 00 00 00 00' )
					);
					printf( '<button type="button" class="sb-btn sb-btn--add" data-sb-add>%s</button>', esc_html__( 'Add number', 'styrk-blocks' ) );
				}
			);
		}
	);
	echo '<noscript><style>[data-sb-extra][hidden]{display:block}</style></noscript>';
}

function cb_footer_row_org(): void {
	cb_footer_field( 'org_number', __( 'Organisation number', 'styrk-blocks' ) );
	sb_ui_help( __( '9 digits. Shown as "Org.nr. 123 456 789".', 'styrk-blocks' ) );
}

/**
 * Opening hours: Weekdays + Saturday + Sunday as a compact table, or all seven
 * days. Storage is unchanged — 21 option keys, one open/from/to per weekday.
 *
 * The seven rows with the real fields are always in the form. The compact rows
 * are unnamed stand-ins that the screen's script copies into them as you type
 * (see assets/admin/styrk-footer-admin.js). Which view opens first is decided
 * here: compact when Monday to Friday share the same hours, otherwise the
 * seven days, because compact would hide the difference.
 */
function cb_footer_row_hours(): void {
	$s    = cb_get_footer_settings();
	$week = \Styrk\Blocks\Footer\hour_week( $s );
	$by   = [];
	foreach ( $week as $day ) {
		$by[ $day['key'] ] = $day;
	}

	$uniform = true;
	foreach ( [ 'tue', 'wed', 'thu', 'fri' ] as $k ) {
		foreach ( [ 'open', 'from', 'to' ] as $f ) {
			if ( $by[ $k ][ $f ] !== $by['mon'][ $f ] ) {
				$uniform = false;
			}
		}
	}
	$wd_from = $uniform && $by['mon']['open'] ? $by['mon']['from'] : '';
	$wd_to   = $uniform && $by['mon']['open'] ? $by['mon']['to'] : '';

	printf(
		'<div class="sb-hours" data-sb-hours data-more="%1$s" data-less="%2$s">',
		esc_attr__( 'Different times each day', 'styrk-blocks' ),
		esc_attr__( 'Same times on weekdays', 'styrk-blocks' )
	);

	// Compact view.
	printf( '<div class="sb-hours__compact" data-sb-hours-compact%s>', $uniform ? '' : ' hidden' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal.
	printf(
		'<div class="sb-hours__row"><span class="sb-hours__day">%1$s</span>'
		. '<input type="text" class="sb-input sb-time" data-sb-wd="from" value="%2$s" placeholder="08:00" aria-label="%3$s" />'
		. '<span aria-hidden="true">–</span>'
		. '<input type="text" class="sb-input sb-time" data-sb-wd="to" value="%4$s" placeholder="16:00" aria-label="%5$s" /></div>',
		esc_html__( 'Weekdays', 'styrk-blocks' ),
		esc_attr( $wd_from ),
		esc_attr__( 'Weekdays from', 'styrk-blocks' ),
		esc_attr( $wd_to ),
		esc_attr__( 'Weekdays to', 'styrk-blocks' )
	);
	foreach ( [ 'sat', 'sun' ] as $k ) {
		$d      = $by[ $k ];
		$closed = ! $d['open'];
		printf(
			'<div class="sb-hours__row" data-sb-day="%1$s"><span class="sb-hours__day">%2$s</span>'
			. '<label class="sb-toggle"><input type="checkbox" class="sb-toggle__input" role="switch" data-sb-closed %3$s /><span class="sb-toggle__track" aria-hidden="true"><span class="sb-toggle__knob"></span></span><span class="sb-toggle__text">%4$s</span></label>'
			. '<span class="sb-hours__times"%5$s><input type="text" class="sb-input sb-time" data-sb-day-from value="%6$s" placeholder="10:00" aria-label="%7$s" />'
			. '<span aria-hidden="true">–</span>'
			. '<input type="text" class="sb-input sb-time" data-sb-day-to value="%8$s" placeholder="14:00" aria-label="%9$s" /></span></div>',
			esc_attr( $k ),
			esc_html( $d['label'] ),
			checked( $closed, true, false ),
			esc_html__( 'Closed', 'styrk-blocks' ),
			$closed ? ' hidden' : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal.
			esc_attr( $d['from'] ),
			/* translators: %s: weekday */
			esc_attr( sprintf( __( '%s from', 'styrk-blocks' ), $d['label'] ) ),
			esc_attr( $d['to'] ),
			/* translators: %s: weekday */
			esc_attr( sprintf( __( '%s to', 'styrk-blocks' ), $d['label'] ) )
		);
	}
	echo '</div>';

	// The seven days, with the real fields.
	printf( '<div class="sb-hours__days" data-sb-hours-days%s>', $uniform ? ' hidden' : '' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal.
	foreach ( $week as $day ) {
		$name = CB_FOOTER_OPTION . '[hours_' . $day['key'];
		printf(
			'<div class="sb-hours__row" data-sb-real="%1$s"><span class="sb-hours__day">%2$s</span>'
			. '<input type="hidden" name="%3$s_open]" value="0" />'
			. '<label class="sb-toggle"><input type="checkbox" class="sb-toggle__input" role="switch" name="%3$s_open]" value="1" %4$s /><span class="sb-toggle__track" aria-hidden="true"><span class="sb-toggle__knob"></span></span><span class="sb-toggle__text">%5$s</span></label>'
			. '<span class="sb-hours__times"><input type="text" class="sb-input sb-time" name="%3$s_from]" value="%6$s" placeholder="08:00" aria-label="%7$s" />'
			. '<span aria-hidden="true">–</span>'
			. '<input type="text" class="sb-input sb-time" name="%3$s_to]" value="%8$s" placeholder="16:00" aria-label="%9$s" /></span></div>',
			esc_attr( $day['key'] ),
			esc_html( $day['label'] ),
			esc_attr( $name ),
			checked( $day['open'], true, false ),
			esc_html_x( 'Open', 'opening hours', 'styrk-blocks' ),
			esc_attr( $day['from'] ),
			/* translators: %s: weekday */
			esc_attr( sprintf( __( '%s from', 'styrk-blocks' ), $day['label'] ) ),
			esc_attr( $day['to'] ),
			/* translators: %s: weekday */
			esc_attr( sprintf( __( '%s to', 'styrk-blocks' ), $day['label'] ) )
		);
	}
	echo '</div>';

	printf(
		'<button type="button" class="sb-link" data-sb-hours-switch>%s</button>',
		esc_html( $uniform ? __( 'Different times each day', 'styrk-blocks' ) : __( 'Same times on weekdays', 'styrk-blocks' ) )
	);
	echo '</div>';
	echo '<noscript><style>.sb-hours__days[hidden]{display:block}.sb-hours__compact,.sb-hours__compact[hidden],[data-sb-hours-switch]{display:none}</style></noscript>';

	sb_ui_help( __( 'Shown as "Monday–Friday: 08.00–16.00" — days with the same hours are merged. The same hours feed the structured data for search and AI answers.', 'styrk-blocks' ) );

	// The old free-text box: only while it still holds something.
	$legacy = (string) $s['opening_hours'];
	if ( '' !== trim( $legacy ) ) {
		echo '<div class="sb-stack sb-hours__legacy">';
		cb_footer_field( 'opening_hours', __( 'Old opening hours text', 'styrk-blocks' ), 'Stengt i juli', 'textarea' );
		sb_ui_help( __( 'Only used when the weekdays above are empty, or for additions such as "Closed in July".', 'styrk-blocks' ) );
		echo '</div>';
	}
}

/* ── Rows: Logo and badges ──────────────────────────────────────────────────── */

function cb_footer_row_logo(): void {
	$s = cb_get_footer_settings();
	sb_ui_stack(
		static function () use ( $s ): void {
			sb_ui_media( cb_footer_field_name( 'logo_white_id' ), (int) $s['logo_white_id'], cb_footer_media_text( 'logo' ) );
			sb_ui_segmented(
				cb_footer_field_name( 'brand_layout' ),
				(string) $s['brand_layout'],
				[
					'side'    => __( 'Beside the text', 'styrk-blocks' ),
					'stacked' => __( 'Above the text', 'styrk-blocks' ),
				],
				__( 'Logo placement', 'styrk-blocks' )
			);
		}
	);
	sb_ui_help( __( 'Use a white or light logo. It sits on a dark background. "Above the text" puts the description under the logo, with a thin line between.', 'styrk-blocks' ) );
}

function cb_footer_row_badges(): void {
	$s       = cb_get_footer_settings();
	$visible = [];
	for ( $i = 1; $i <= CB_FOOTER_CERT_SLOTS; $i++ ) {
		$visible[ $i ] = (int) $s[ "cert_{$i}_id" ] > 0
			|| '' !== trim( (string) $s[ "cert_{$i}_label" ] )
			|| '' !== trim( (string) $s[ "cert_{$i}_url" ] );
	}

	echo '<div class="sb-cards">';
	for ( $i = 1; $i <= CB_FOOTER_CERT_SLOTS; $i++ ) {
		$id    = (int) $s[ "cert_{$i}_id" ];
		$label = trim( (string) $s[ "cert_{$i}_label" ] );
		$thumb = $id ? (string) wp_get_attachment_image_url( $id, 'thumbnail' ) : '';
		/* translators: %d: badge number */
		$fallback = sprintf( __( 'Badge %d', 'styrk-blocks' ), $i );
		printf(
			'<div class="sb-card" data-sb-card data-sb-extra%1$s>'
			. '<div class="sb-card__head"><span class="sb-card__thumb" aria-hidden="true"><img src="%2$s" alt=""%3$s /></span>'
			. '<span class="sb-card__name" data-sb-name data-fallback="%4$s">%5$s</span>'
			. '<button type="button" class="sb-link" data-sb-card-toggle aria-expanded="false" aria-controls="sb-card-body-%6$d">%7$s</button>'
			. '<button type="button" class="sb-link" data-sb-remove aria-label="%9$s">%8$s</button></div>'
			. '<div class="sb-card__body" id="sb-card-body-%6$d" hidden>',
			$visible[ $i ] ? '' : ' hidden', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal.
			esc_url( $thumb ),
			'' === $thumb ? ' hidden' : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal.
			esc_attr( $fallback ),
			esc_html( '' !== $label ? $label : $fallback ),
			(int) $i,
			esc_html__( 'Edit', 'styrk-blocks' ),
			esc_html__( 'Remove', 'styrk-blocks' ),
			esc_attr__( 'Remove badge', 'styrk-blocks' )
		);
		sb_ui_media( cb_footer_field_name( "cert_{$i}_id" ), $id, cb_footer_media_text( 'image' ) );
		printf(
			'<label class="sb-inline"><span>%1$s</span><input type="text" class="sb-input" name="%2$s" value="%3$s" placeholder="%4$s" data-sb-name-from /></label>',
			esc_html__( 'Name', 'styrk-blocks' ),
			esc_attr( cb_footer_field_name( "cert_{$i}_label" ) ),
			esc_attr( $label ),
			esc_attr( 'Mesterbedrift' )
		);
		printf(
			'<label class="sb-inline"><span>%1$s</span><input type="text" class="sb-input" name="%2$s" value="%3$s" placeholder="%4$s" /></label>',
			esc_html__( 'Link', 'styrk-blocks' ),
			esc_attr( cb_footer_field_name( "cert_{$i}_url" ) ),
			esc_attr( (string) $s[ "cert_{$i}_url" ] ),
			esc_attr( 'https://' )
		);
		sb_ui_help( __( 'The name is read out to people who cannot see the picture. The link is optional.', 'styrk-blocks' ) );
		echo '</div></div>';
	}
	echo '</div>';
	echo '<noscript><style>.sb-card[hidden],.sb-card__body[hidden]{display:block}</style></noscript>';

	printf( '<button type="button" class="sb-btn sb-btn--add" data-sb-add>%s</button>', esc_html__( 'Add badge', 'styrk-blocks' ) );

	// Size: the three steps write the same pixel heights as before.
	$height = (string) (int) $s['cert_height'];
	sb_ui_line(
		static function () use ( $height ): void {
			echo '<span class="sb-line__label">' . esc_html__( 'Size', 'styrk-blocks' ) . '</span>';
			sb_ui_segmented(
				cb_footer_field_name( 'cert_height' ),
				$height,
				[
					'64'  => _x( 'Small', 'badge size', 'styrk-blocks' ),
					'96'  => _x( 'Medium', 'badge size', 'styrk-blocks' ),
					'128' => _x( 'Large', 'badge size', 'styrk-blocks' ),
				],
				__( 'Badge size', 'styrk-blocks' )
			);
		}
	);
	$align   = (string) $s['cert_align'];
	$options = [
		'left'   => __( 'Left', 'styrk-blocks' ),
		'center' => __( 'Center', 'styrk-blocks' ),
		'right'  => __( 'Right', 'styrk-blocks' ),
	];
	// An older choice (space between, around, evenly) stays on, and is shown.
	$extra = [
		'between' => __( 'Space between', 'styrk-blocks' ),
		'around'  => __( 'Space around', 'styrk-blocks' ),
		'evenly'  => __( 'Space evenly', 'styrk-blocks' ),
	];
	if ( isset( $extra[ $align ] ) ) {
		$options[ $align ] = $extra[ $align ];
	}
	sb_ui_line(
		static function () use ( $align, $options ): void {
			echo '<span class="sb-line__label">' . esc_html__( 'Placement', 'styrk-blocks' ) . '</span>';
			sb_ui_segmented( cb_footer_field_name( 'cert_align' ), $align, $options, __( 'Badge placement', 'styrk-blocks' ) );
		}
	);
	sb_ui_help(
		sprintf(
			/* translators: %d: maximum number of badges */
			__( 'Certificates and memberships. Up to %d badges. On a phone they are always centred.', 'styrk-blocks' ),
			CB_FOOTER_CERT_SLOTS
		)
	);
}

/* ── Rows: Columns ──────────────────────────────────────────────────────────── */

/**
 * Navigation menus offered for the page-links column: id => title.
 *
 * @return array<int,string>
 */
function cb_footer_menu_choices(): array {
	$menus = [ 0 => __( 'None — hide the column', 'styrk-blocks' ) ];
	foreach ( get_posts(
		[
			'post_type'      => 'wp_navigation',
			'post_status'    => 'publish',
			'posts_per_page' => 50,
			'orderby'        => 'title',
			'order'          => 'ASC',
		]
	) as $menu ) {
		$menus[ (int) $menu->ID ] = '' !== $menu->post_title ? $menu->post_title : '#' . $menu->ID;
	}
	return $menus;
}

function cb_footer_row_pages(): void {
	$s     = cb_get_footer_settings();
	$all   = [ 0 => __( 'None — hide the link', 'styrk-blocks' ) ];
	foreach ( get_pages( [ 'sort_column' => 'post_title', 'number' => 200 ] ) as $page ) {
		$all[ (int) $page->ID ] = get_the_title( $page );
	}
	$menus = cb_footer_menu_choices();
	sb_ui_stack(
		static function () use ( $s, $all, $menus ): void {
			sb_ui_line(
				static function () use ( $s, $menus ): void {
					echo '<span class="sb-line__label">' . esc_html__( 'Shows', 'styrk-blocks' ) . '</span>';
					sb_ui_select( cb_footer_field_name( 'pages_menu' ), (string) (int) $s['pages_menu'], array_map( 'strval', $menus ), __( 'Menu', 'styrk-blocks' ) );
				}
			);
			cb_footer_labelled( 'pages_heading', __( 'Heading', 'styrk-blocks' ), '', 'cb_footer_settings[pages_menu]:' . implode( '|', array_map( 'strval', array_diff( array_keys( $menus ), [ 0 ] ) ) ) );
			sb_ui_line(
				static function () use ( $s, $all ): void {
					echo '<span class="sb-line__label">' . esc_html__( 'Page with all pages', 'styrk-blocks' ) . '</span>';
					sb_ui_select( cb_footer_field_name( 'pages_all_page' ), (string) (int) $s['pages_all_page'], array_map( 'strval', $all ), __( 'Page with all pages', 'styrk-blocks' ) );
				},
				'cb_footer_settings[pages_menu]:' . implode( '|', array_map( 'strval', array_diff( array_keys( $menus ), [ 0 ] ) ) )
			);
		}
	);
	sb_ui_help( __( 'The links come from a menu you edit in the Site Editor under Navigation. Sub-pages sit behind a button that opens them. The last row can link to the page that holds the "All pages" block.', 'styrk-blocks' ) );
}

function cb_footer_row_social(): void {
	$s = cb_get_footer_settings();
	sb_ui_stack(
		static function () use ( $s ): void {
			cb_footer_labelled( 'social_heading', __( 'Heading', 'styrk-blocks' ) );
			printf(
				'<a class="sb-link" href="%1$s">%2$s</a>',
				esc_url( admin_url( 'edit.php?post_type=social_link' ) ),
				esc_html__( 'Edit social media links', 'styrk-blocks' )
			);
			sb_ui_line(
				static function () use ( $s ): void {
					echo '<span class="sb-line__label">' . esc_html__( 'Placement', 'styrk-blocks' ) . '</span>';
					sb_ui_segmented(
						cb_footer_field_name( 'social_align' ),
						(string) $s['social_align'],
						[
							'left'  => __( 'Left', 'styrk-blocks' ),
							'right' => __( 'Right', 'styrk-blocks' ),
						],
						__( 'Placement of the last column', 'styrk-blocks' )
					);
				}
			);
		}
	);
	sb_ui_help( __( 'Placement is for large screens. On a phone the columns stand under each other. "Right" lines the last column up with the credits.', 'styrk-blocks' ) );
}

function cb_footer_row_contact_col(): void {
	sb_ui_stack(
		static function (): void {
			cb_footer_labelled( 'contact_heading', __( 'Heading', 'styrk-blocks' ), 'Kontakt' );
			cb_footer_labelled( 'address_heading', __( 'Heading for the address', 'styrk-blocks' ), 'Adresse' );
		}
	);
	sb_ui_help( __( 'Leave a heading empty to hide it. The address only gets its own heading if you fill it in.', 'styrk-blocks' ) );
}

function cb_footer_row_newsletter(): void {
	$s    = cb_get_footer_settings();
	$when = 'cb_footer_settings[newsletter_enabled]:1';
	sb_ui_stack(
		static function () use ( $s, $when ): void {
			sb_ui_toggle( cb_footer_field_name( 'newsletter_enabled' ), ! empty( $s['newsletter_enabled'] ), __( 'Show newsletter signup', 'styrk-blocks' ) );
			cb_footer_labelled( 'newsletter_heading', __( 'Heading', 'styrk-blocks' ), '', $when );
			printf(
				'<button type="button" class="sb-link" data-sb-fold="sb-fold-consent" aria-expanded="false" aria-controls="sb-fold-consent"%1$s>%2$s</button>',
				sb_ui_when_attr( $when ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in sb_ui_when_attr().
				esc_html__( 'Edit consent text', 'styrk-blocks' )
			);
			printf(
				'<div id="sb-fold-consent" hidden><textarea class="sb-input sb-input--wide" name="%1$s" rows="3" aria-label="%2$s">%3$s</textarea></div>',
				esc_attr( cb_footer_field_name( 'newsletter_body' ) ),
				esc_attr__( 'Consent text', 'styrk-blocks' ),
				esc_textarea( (string) $s['newsletter_body'] )
			);
		}
	);
	sb_ui_help( __( 'The consent text shows above the email field. A link to the privacy page is added at the end.', 'styrk-blocks' ) );
}

/* ── Rows: Bottom bar ───────────────────────────────────────────────────────── */

function cb_footer_row_copyright(): void {
	cb_footer_field( 'copyright', __( 'Copyright text', 'styrk-blocks' ) );
	sb_ui_help( __( 'The small text shown at the very bottom of the footer.', 'styrk-blocks' ) );
}

function cb_footer_row_credits(): void {
	$s = cb_get_footer_settings();
	sb_ui_stack(
		static function () use ( $s ): void {
			cb_footer_labelled( 'credits', __( 'Text', 'styrk-blocks' ) );
			cb_footer_labelled( 'credits_url', __( 'Link', 'styrk-blocks' ), 'https://' );
			sb_ui_line(
				static function () use ( $s ): void {
					echo '<span class="sb-line__label">' . esc_html__( 'Mark', 'styrk-blocks' ) . '</span>';
					sb_ui_media( cb_footer_field_name( 'credits_icon_id' ), (int) $s['credits_icon_id'], cb_footer_media_text( 'image' ) );
				}
			);
			sb_ui_line(
				static function () use ( $s ): void {
					echo '<span class="sb-line__label">' . esc_html__( 'Mark placement', 'styrk-blocks' ) . '</span>';
					sb_ui_segmented(
						cb_footer_field_name( 'credits_logo_position' ),
						(string) $s['credits_logo_position'],
						[
							'start'  => __( 'In front', 'styrk-blocks' ),
							'inline' => __( 'In the text', 'styrk-blocks' ),
							'end'    => __( 'Behind', 'styrk-blocks' ),
						],
						__( 'Mark placement', 'styrk-blocks' )
					);
				}
			);
		}
	);
	sb_ui_help( __( 'The link opens in a new tab. The mark is a small picture beside the text and takes the footer text colour.', 'styrk-blocks' ) );
}

function cb_footer_row_legal(): void {
	$s     = cb_get_footer_settings();
	$rows  = cb_footer_legal_rows( $s );
	$pages = [];
	foreach ( get_pages( [ 'sort_column' => 'post_title', 'number' => 200 ] ) as $page ) {
		$pages[ (int) $page->ID ] = get_the_title( $page );
	}

	echo '<div class="sb-legal">';
	for ( $i = 1; $i <= CB_FOOTER_LEGAL_SLOTS; $i++ ) {
		$row    = $rows[ $i - 1 ] ?? null;
		$page   = $row ? (int) $row['page'] : 0;
		$url    = $row ? (string) $row['url'] : '';
		$sel    = cb_footer_field_name( "legal_{$i}_page" );
		printf(
			'<div class="sb-legal__row" data-sb-extra%1$s>',
			$row ? '' : ' hidden' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal.
		);
		printf(
			'<input type="text" class="sb-input" name="%1$s" value="%2$s" placeholder="%3$s" aria-label="%4$s" />',
			esc_attr( cb_footer_field_name( "legal_{$i}_label" ) ),
			esc_attr( $row ? (string) $row['label'] : '' ),
			esc_attr__( 'Privacy', 'styrk-blocks' ),
			/* translators: %d: row number */
			esc_attr( sprintf( __( 'Legal link %d text', 'styrk-blocks' ), $i ) )
		);
		printf( '<select class="sb-select" name="%1$s" aria-label="%2$s" data-sb-legal-page>', esc_attr( $sel ), esc_attr( sprintf( /* translators: %d: row number */ __( 'Legal link %d page', 'styrk-blocks' ), $i ) ) );
		printf( '<option value="0">%s</option>', esc_html__( 'Own address', 'styrk-blocks' ) );
		foreach ( $pages as $pid => $title ) {
			printf( '<option value="%d"%s>%s</option>', (int) $pid, selected( $page, (int) $pid, false ), esc_html( $title ) );
		}
		echo '</select>';
		printf( '<button type="button" class="sb-link" data-sb-remove>%s</button>', esc_html__( 'Remove', 'styrk-blocks' ) );
		printf(
			'<input type="text" class="sb-input sb-legal__url" name="%1$s" value="%2$s" placeholder="%3$s" aria-label="%4$s"%5$s />',
			esc_attr( cb_footer_field_name( "legal_{$i}_url" ) ),
			esc_attr( $url ),
			esc_attr__( 'https://… or /page', 'styrk-blocks' ),
			/* translators: %d: row number */
			esc_attr( sprintf( __( 'Legal link %d URL', 'styrk-blocks' ), $i ) ),
			$page > 0 ? ' hidden' : '' // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal.
		);
		echo '</div>';
	}
	echo '</div>';
	echo '<noscript><style>.sb-legal__row[hidden],.sb-legal__url[hidden]{display:grid}</style></noscript>';
	printf( '<button type="button" class="sb-btn sb-btn--add" data-sb-add>%s</button>', esc_html__( 'Add link', 'styrk-blocks' ) );
	sb_ui_help( __( 'Legal links are picked from your pages, not written as text. Choose "Own address" to type a link to somewhere else.', 'styrk-blocks' ) );
}

/* ── Rows: Appearance ───────────────────────────────────────────────────────── */

function cb_footer_row_colours(): void {
	$s       = cb_get_footer_settings();
	$palette = cb_get_theme_palette();
	sb_ui_line(
		static function () use ( $s, $palette ): void {
			sb_ui_color( cb_footer_field_name( 'bg_color' ), (string) $s['bg_color'], __( 'Background', 'styrk-blocks' ), $palette, 'slug', true, __( 'Default (the dark bar)', 'styrk-blocks' ) );
			sb_ui_color( cb_footer_field_name( 'text_color' ), (string) $s['text_color'], __( 'Text colour', 'styrk-blocks' ), $palette, 'slug', true, __( 'Default (white)', 'styrk-blocks' ) );
			printf(
				'<button type="button" class="sb-link" data-sb-reset="%1$s,%2$s"%3$s>%4$s</button>',
				esc_attr( cb_footer_field_name( 'bg_color' ) ),
				esc_attr( cb_footer_field_name( 'text_color' ) ),
				'' === (string) $s['bg_color'] . (string) $s['text_color'] ? ' hidden' : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal.
				esc_html__( 'Reset', 'styrk-blocks' )
			);
		}
	);
	sb_ui_help( __( 'Only the colours from the site can be picked. Reset gives the dark bar with white text.', 'styrk-blocks' ) );
}

/* ── Summary line of each closed part ───────────────────────────────────────── */

/**
 * The one-line summary shown on a closed part.
 *
 * @param string $id Section id.
 */
function cb_footer_part_summary( string $id ): string {
	$s = cb_get_footer_settings();
	if ( 'cb_footer_contact' === $id ) {
		$have = [];
		if ( '' !== trim( (string) $s['address'] ) ) {
			$have[] = __( 'Address', 'styrk-blocks' );
		}
		if ( '' !== trim( (string) $s['email'] ) ) {
			$have[] = __( 'email', 'styrk-blocks' );
		}
		if ( '' !== trim( (string) $s['phone_1'] ) ) {
			$have[] = __( 'phone', 'styrk-blocks' );
		}
		if ( \Styrk\Blocks\Footer\hours_are_set( $s ) || '' !== trim( (string) $s['opening_hours'] ) ) {
			$have[] = __( 'opening hours', 'styrk-blocks' );
		}
		return $have ? implode( ' · ', $have ) : __( 'Nothing filled in yet', 'styrk-blocks' );
	}
	if ( 'cb_footer_logo' === $id ) {
		$badges = 0;
		for ( $i = 1; $i <= CB_FOOTER_CERT_SLOTS; $i++ ) {
			if ( (int) $s[ "cert_{$i}_id" ] > 0 ) {
				++$badges;
			}
		}
		$parts = [ (int) $s['logo_white_id'] > 0 ? __( 'White logo', 'styrk-blocks' ) : __( 'No logo', 'styrk-blocks' ) ];
		if ( $badges ) {
			/* translators: %d: number of badges */
			$parts[] = sprintf( _n( '%d badge', '%d badges', $badges, 'styrk-blocks' ), $badges );
		}
		return implode( ' · ', $parts );
	}
	if ( 'cb_footer_cols' === $id ) {
		$parts = [];
		if ( (int) $s['pages_menu'] > 0 ) {
			$parts[] = __( 'Pages', 'styrk-blocks' );
		}
		$parts[] = __( 'Follow us', 'styrk-blocks' );
		if ( ! empty( $s['newsletter_enabled'] ) ) {
			$parts[] = __( 'Newsletter', 'styrk-blocks' );
		}
		return implode( ' · ', $parts );
	}
	if ( 'cb_footer_bottom' === $id ) {
		$copy  = trim( wp_strip_all_tags( (string) $s['copyright'] ) );
		$copy  = function_exists( 'mb_strimwidth' ) ? mb_strimwidth( $copy, 0, 28, '…' ) : $copy;
		$links = count( cb_footer_legal_rows( $s ) );
		$parts = array_filter( [ $copy ] );
		if ( $links ) {
			/* translators: %d: number of links */
			$parts[] = sprintf( _n( '%d link', '%d links', $links, 'styrk-blocks' ), $links );
		}
		return implode( ' · ', $parts );
	}
	return '' === (string) $s['bg_color'] . (string) $s['text_color']
		? __( 'Default colours', 'styrk-blocks' )
		: __( 'Own colours', 'styrk-blocks' );
}

/**
 * The number of legal-link slots offered in the UI and read by the shortcode.
 * Both sides derive from this, so they can never disagree.
 */
const CB_FOOTER_LEGAL_SLOTS = 4;

/**
 * Certification badge slots.
 *
 * Was a hard-coded three, printed as nine always-visible fields — a wall of
 * empty inputs for the many sites that show one badge, and a hard ceiling for
 * the ones that have four. Six slots, of which the screen shows only the ones
 * in use plus the next empty one.
 */
const CB_FOOTER_CERT_SLOTS = 6;

/**
 * The single source of truth for "what legal links does this site have?".
 *
 * Used by BOTH the settings screen and the [footer_legal] shortcode, so the
 * admin UI can never show something different from what the footer renders —
 * the editor/renderer parity that scripts/parity-gate.js exists to protect.
 *
 * Returns a list of [ 'label' => string, 'page' => int, 'url' => string ].
 *
 * @param array<string,mixed> $settings
 * @return array<int,array{label:string,page:int,url:string}>
 */
function cb_footer_legal_rows( array $settings ): array {
	$rows = [];

	for ( $i = 1; $i <= CB_FOOTER_LEGAL_SLOTS; $i++ ) {
		$label = trim( (string) ( $settings[ "legal_{$i}_label" ] ?? '' ) );
		$page  = (int) ( $settings[ "legal_{$i}_page" ] ?? 0 );
		$url   = trim( (string) ( $settings[ "legal_{$i}_url" ] ?? '' ) );
		if ( $page > 0 || '' !== $url ) {
			$rows[] = [ 'label' => $label, 'page' => $page, 'url' => $url ];
		}
	}

	if ( $rows ) {
		return $rows;
	}

	// Nothing in the new slots — fall back to the legacy "Label|URL" lines so
	// a site that has not been re-saved keeps the links it already had.
	$legacy = (string) ( $settings['legal_links'] ?? '' );
	if ( '' === trim( $legacy ) ) {
		return [];
	}

	foreach ( preg_split( '/\r\n|\r|\n/', $legacy ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts = explode( '|', $line, 2 );
		if ( 2 === count( $parts ) ) {
			$rows[] = [
				'label' => trim( $parts[0] ),
				'page'  => 0,
				'url'   => trim( $parts[1] ),
			];
		} else {
			$url = trim( $parts[0] );
			$rows[] = [
				'label' => cb_footer_label_from_url( $url ),
				'page'  => 0,
				'url'   => $url,
			];
		}
		if ( count( $rows ) >= CB_FOOTER_LEGAL_SLOTS ) {
			break;
		}
	}

	return $rows;
}

/**
 * Resolve one row to a final [ label, href ] pair, or null if it cannot make
 * a usable link.
 *
 * @param array{label:string,page:int,url:string} $row
 * @return array{0:string,1:string}|null
 */
function cb_footer_legal_resolve( array $row ): ?array {
	$label = trim( (string) $row['label'] );
	$page  = (int) $row['page'];
	$url   = trim( (string) $row['url'] );

	// A picked page always wins — it is the unambiguous choice.
	if ( $page > 0 ) {
		$permalink = get_permalink( $page );
		if ( ! $permalink ) {
			return null;
		}
		$href = wp_make_link_relative( $permalink );
		if ( '' === $label ) {
			$label = (string) get_the_title( $page );
		}
	} else {
		if ( '' === $url ) {
			return null;
		}
		$href = cb_footer_normalise_url( $url );
		if ( '' === $href ) {
			return null;
		}
		if ( '' === $label ) {
			$label = cb_footer_label_from_url( $href );
		}
	}

	if ( '' === $label || '' === $href ) {
		return null;
	}

	return [ $label, $href ];
}

/**
 * Make a typed URL safe and unsurprising.
 *
 * THE BUG THIS KILLS: esc_url() sees "Personvern/personvern" — no scheme, no
 * leading slash — decides "Personvern" must be a HOSTNAME, and silently returns
 * "http://Personvern/personvern". The admin typed a typo and got a working-
 * looking link to a domain that does not exist. Nothing warned them.
 *
 * A bare token with no scheme and no leading slash is, on a footer legal link,
 * always meant to be a path on THIS site. Treat it as one.
 */
function cb_footer_normalise_url( string $url ): string {
	$url = trim( $url );
	if ( '' === $url ) {
		return '';
	}

	// Explicit scheme, or protocol-relative, or an anchor/mailto/tel — leave it.
	//
	// Delimiter is ~, not #. The second pattern has to match a literal '#'
	// (an on-page anchor), and with # as the delimiter that character ENDED
	// the pattern: PHP read '#^(mailto:|tel:|#' and choked on the ')' after
	// it — "Unknown modifier ')'", printed above the settings screen on every
	// save. preg_match then returned false, so anchors and mailto: links fell
	// through to the path branch below and were rewritten as '/#kontakt' and
	// '/mailto:post@…'.
	if ( preg_match( '~^(https?:)?//~i', $url ) || preg_match( '~^(mailto:|tel:|#)~i', $url ) ) {
		return (string) esc_url_raw( $url );
	}

	// Anything else is a path on this site. Guarantee the leading slash so
	// esc_url_raw() can never mistake the first segment for a hostname.
	if ( '/' !== $url[0] ) {
		$url = '/' . ltrim( $url, '/' );
	}

	return (string) esc_url_raw( $url );
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

/**
 * Allowed inline HTML for the copyright + credits fields — just enough to let
 * an admin add a link or basic emphasis, nothing that could break the footer
 * bar layout or open an XSS hole. Shared by the sanitiser (on save) and the
 * render shortcodes (on output). Relative hrefs ("/personvern") are preserved
 * by wp_kses; javascript:/data: schemes are rejected.
 */
function cb_footer_allowed_inline_html(): array {
	return [
		'a'      => [ 'href' => true, 'title' => true, 'target' => true, 'rel' => true ],
		'br'     => [],
		'strong' => [],
		'em'     => [],
		'span'   => [ 'class' => true ],
	];
}

/**
 * Derive a human label from a bare URL when a Legal Links line omits the
 * "Label|" prefix — e.g. "/personvernerklaering" → "Personvernerklaering".
 * Lets admins paste a plain path and still get a labelled link.
 */
function cb_footer_label_from_url( string $url ): string {
	$path = (string) wp_parse_url( $url, PHP_URL_PATH );
	if ( '' === $path ) {
		$path = $url;
	}
	$slug = trim( $path, '/' );
	if ( '' === $slug ) {
		return '';
	}

	// Prefer the real page title when the path resolves to an internal page —
	// e.g. "/personvernerklaering" → "Personvernerklæring" (correct æ), no
	// guessing. Only for same-site relative/absolute paths.
	$is_internal = ! preg_match( '#^https?://#i', $url )
		|| 0 === stripos( $url, home_url() );
	if ( $is_internal && function_exists( 'get_page_by_path' ) ) {
		$last = (string) preg_replace( '#^.*/#', '', $slug );
		$page = get_page_by_path( $last ) ?: get_page_by_path( $slug );
		if ( $page instanceof \WP_Post ) {
			$title = get_the_title( $page );
			if ( '' !== $title ) {
				return $title;
			}
		}
	}

	// Fallback: humanise the last path segment.
	$last = (string) preg_replace( '#^.*/#', '', $slug );
	$last = str_replace( [ '-', '_' ], ' ', urldecode( $last ) );
	return function_exists( 'mb_convert_case' )
		? mb_convert_case( $last, MB_CASE_TITLE, 'UTF-8' )
		: ucwords( $last );
}

function cb_footer_sanitize( $input ): array {
	$defaults  = cb_footer_defaults();
	$current   = cb_get_footer_settings();
	$sanitized = [];

	foreach ( $defaults as $key => $default ) {
		if ( ! isset( $input[ $key ] ) ) {
			// Fields the screen no longer shows are never submitted, and falling
			// back to the default here would DELETE what a site has saved:
			//  - `legal_links`: the retired "Label|URL" text. Kept until the new
			//    slots carry something (see the retire step at the end).
			//  - `opening_hours`: the free-text hours, shown only while filled in.
			//  - `newsletter_privacy_*`: the old override of the privacy link.
			$sanitized[ $key ] = in_array( $key, [ 'legal_links', 'opening_hours', 'newsletter_privacy_url', 'newsletter_privacy_label' ], true )
				? (string) ( $current[ $key ] ?? $default )
				: $default;
			continue;
		}
		// Per-day opening hours: a checkbox and two times per weekday. Times
		// are normalised to 24h "HH:MM" here so everything downstream — footer
		// lines and openingHoursSpecification alike — reads one format.
		if ( preg_match( '/^hours_(mon|tue|wed|thu|fri|sat|sun)_(open|from|to)$/', $key, $hm ) ) {
			$sanitized[ $key ] = 'open' === $hm[2]
				? ( empty( $input[ $key ] ) ? 0 : 1 )
				: \Styrk\Blocks\Footer\normalise_time( (string) ( $input[ $key ] ?? '' ) );
			continue;
		}

		$sanitized[ $key ] = match ( $key ) {
			'logo_white_id',
			'cert_1_id',
			'cert_2_id',
			'cert_3_id',
			'cert_4_id',
			'cert_5_id',
			'cert_6_id',
			'legal_1_page',
			'legal_2_page',
			'legal_3_page',
			'legal_4_page',
			'credits_icon_id',
			'pages_menu',
			'pages_all_page'  => absint( $input[ $key ] ),
			// Not esc_url_raw() directly: that is what turned the typo
			// "Personvern/personvern" into "http://Personvern/personvern".
			// cb_footer_normalise_url() forces a leading slash on anything
			// schemeless, so a path can never be read as a hostname.
			'legal_1_url',
			'legal_2_url',
			'legal_3_url',
			'legal_4_url',
			// Cert links get the same treatment: a schemeless value is a path,
			// never a hostname, so "startbank.no" cannot become a broken
			// relative link and "/side" stays site-relative.
			'cert_1_url',
			'cert_2_url',
			'cert_3_url',
			'cert_4_url',
			'cert_5_url',
			'cert_6_url',
			'credits_url' => cb_footer_normalise_url( (string) $input[ $key ] ),
			'newsletter_enabled' => empty( $input[ $key ] ) ? 0 : 1,
			'newsletter_body'    => sanitize_textarea_field( $input[ $key ] ),
			// esc_url_raw keeps relative paths ("/personvern") and validates
			// absolute URLs, stripping javascript:/data: schemes.
			'newsletter_privacy_url' => esc_url_raw( $input[ $key ] ),
			'credits_logo_position' => in_array( (string) $input[ $key ], [ 'inline', 'start', 'end' ], true ) ? (string) $input[ $key ] : 'inline',
			// Clamped, not just absint: a badge at 4px is invisible and one at
			// 900px breaks the footer layout.
			'cert_height'   => max( 40, min( 160, absint( $input[ $key ] ) ) ),
			'brand_layout'  => 'stacked' === (string) $input[ $key ] ? 'stacked' : 'side',
			'social_align'  => 'right' === (string) $input[ $key ] ? 'right' : 'left',
			'cert_align'    => in_array( (string) $input[ $key ], [ 'left', 'center', 'right', 'between', 'around', 'evenly' ], true ) ? (string) $input[ $key ] : 'center',
			'email'         => sanitize_email( $input[ $key ] ),
			// Strip anything that isn't a digit. Storing bare digits keeps
			// the display formatter in one place (see cb_format_org_number)
			// and lets admins paste "987 654 321", "987-654-321", or
			// "Org.nr. 987654321" interchangeably.
			'org_number'    => preg_replace( '/\D+/', '', (string) $input[ $key ] ),
			'address',
			'description',
			'opening_hours',
			'legal_links'   => sanitize_textarea_field( $input[ $key ] ),
			// Copyright + credits may carry a simple link or emphasis (e.g. a
			// "©" line that links to the company, or a linked agency name), so
			// allow a tiny inline-HTML whitelist instead of stripping tags.
			'copyright',
			'credits'       => wp_kses( (string) $input[ $key ], cb_footer_allowed_inline_html() ),
			// Footer bar colours — '' (inherit) or a slug that exists in the
			// current theme palette, so a stale/spoofed slug can never reach the
			// CSS-var output.
			'bg_color',
			'text_color'    => ( function () use ( $input, $key ) {
				$slug   = sanitize_key( (string) $input[ $key ] );
				$slugs  = function_exists( 'cb_header_theme_palette' )
					? array_filter( array_map( static fn( $sw ) => (string) ( $sw['slug'] ?? '' ), cb_header_theme_palette() ) )
					: [];
				return ( '' !== $slug && in_array( $slug, $slugs, true ) ) ? $slug : '';
			} )(),
			default         => sanitize_text_field( $input[ $key ] ),
		};
	}

	// Retire the legacy DSL once the real fields carry the links. The settings
	// screen pre-fills those fields FROM the legacy string, so the very first
	// save after this update migrates the site automatically — the admin never
	// sees the pipe syntax again, and nothing is lost in between.
	for ( $i = 1; $i <= CB_FOOTER_LEGAL_SLOTS; $i++ ) {
		if ( 0 < (int) ( $sanitized[ "legal_{$i}_page" ] ?? 0 )
			|| '' !== trim( (string) ( $sanitized[ "legal_{$i}_url" ] ?? '' ) ) ) {
			$sanitized['legal_links'] = '';
			break;
		}
	}

	return $sanitized;
}

/* ── Page template ──────────────────────────────────────────────────────────── */

function cb_footer_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// The media modal (logo, badges, credits mark) needs these scripts.
	wp_enqueue_media();
	?>
	<div class="wrap sb-ui" data-sb-page="footer">
		<h1><?php esc_html_e( 'Footer Settings', 'styrk-blocks' ); ?></h1>
		<p class="sb-ui__intro"><?php esc_html_e( 'Open a part to change it. The closed parts show what is chosen now.', 'styrk-blocks' ); ?></p>
		<noscript><style>.sb-part__body[hidden]{display:block}</style></noscript>
		<form method="post" action="options.php">
			<?php settings_fields( 'cb_footer_group' ); ?>
			<div class="sb-panel">
				<h2 class="sb-panel__title"><?php esc_html_e( 'Footer', 'styrk-blocks' ); ?></h2>
				<?php sb_ui_render_parts( 'cb-footer-settings', 'cb_footer_part_summary' ); ?>
			</div>
			<button type="submit" name="submit" class="sb-submit"><?php esc_html_e( 'Save changes', 'styrk-blocks' ); ?></button>
		</form>
	</div>
	<?php
}

/* ── One-shot migration: header.logo_white_id → footer.logo_white_id ─────────
 * Pre-v1.6.5 the white logo lived under Settings → Header. Client sites that
 * had set it there need the value copied into the new footer-settings home.
 * Guard with a marker option so we only run once per site, even if the user
 * deliberately clears the new value later. */
function cb_footer_migrate_white_logo_from_header(): void {
	$marker = 'cb_footer_logo_white_migrated';
	if ( get_option( $marker ) ) {
		return;
	}

	$header = get_option( 'cb_header_settings', [] );
	$source = (int) ( $header['logo_white_id'] ?? 0 );

	if ( $source > 0 ) {
		$footer = get_option( CB_FOOTER_OPTION, [] );
		// Only populate if the target is still empty / unset — never clobber
		// an intentional setting the admin has already made in the new home.
		if ( empty( $footer['logo_white_id'] ) ) {
			$footer['logo_white_id'] = $source;
			update_option( CB_FOOTER_OPTION, $footer );
		}
	}

	update_option( $marker, 1, /* autoload = */ true );
}
add_action( 'admin_init', 'cb_footer_migrate_white_logo_from_header' );

/* ── Seed defaults on first activation ──────────────────────────────────────── */

function cb_footer_seed_defaults(): void {
	if ( get_option( CB_FOOTER_OPTION ) ) {
		return;
	}
	update_option( CB_FOOTER_OPTION, cb_footer_defaults() );
}
add_action( 'admin_init', 'cb_footer_seed_defaults' );

/* ── Output footer CSS vars to <head> ───────────────────────────────────────── */

if ( ! function_exists( 'cb_footer_output_css_vars' ) ) :
/**
 * Emit footer CSS custom properties consumed by the theme footer.
 *  --cb-footer-cert-align : flex justify value for the badge row on desktop
 *                           (mobile is forced to centre in CSS).
 */
function cb_footer_output_css_vars(): void {
	$s     = cb_get_footer_settings();
	$map   = [ 'left' => 'flex-start', 'center' => 'center', 'right' => 'flex-end', 'between' => 'space-between', 'around' => 'space-around', 'evenly' => 'space-evenly' ];
	$align = esc_attr( $map[ $s['cert_align'] ?? 'center' ] ?? 'center' );

	// Footer bar colours — a chosen palette slug becomes
	// var(--wp--preset--color--{slug}); '' emits nothing so the theme CSS keeps
	// its navy-bar/white-text default (the vars carry those as their fallback).
	$palette_var = static function ( $slug ): string {
		$slug = sanitize_key( (string) $slug );
		return '' === $slug ? '' : sprintf( 'var(--wp--preset--color--%s)', $slug );
	};
	$footer_vars = '';
	$bg          = $palette_var( $s['bg_color']   ?? '' );
	$text        = $palette_var( $s['text_color'] ?? '' );
	if ( '' !== $bg ) {
		$footer_vars .= '--cb-footer-bg:' . $bg . ';';
	}
	if ( '' !== $text ) {
		$footer_vars .= '--cb-footer-text:' . $text . ';';
	}

	// Self-contained: the badge row (.site-footer__certs, output by
	// [footer_certs]) is laid out and aligned here so the setting works on
	// every theme — no theme CSS required. !important overrides any theme
	// default. Mobile is always centred.
	printf(
		'<style id="cb-footer-vars">:root{--cb-footer-cert-align:%1$s;%2$s}'
		. '.site-footer .site-footer__certs{display:flex;flex-wrap:wrap;align-items:center;justify-content:%1$s !important}'
		. '@media(max-width:768px){.site-footer .site-footer__certs{justify-content:center !important}}'
		. '</style>' . "\n",
		esc_attr( $align ),
		wp_strip_all_tags( $footer_vars )
	);
}
add_action( 'wp_head', 'cb_footer_output_css_vars', 1 );
endif;

/* ── Footer layout controls → front-end CSS ─────────────────────────────────── */

if ( ! function_exists( 'cb_footer_layout_css' ) ) :
/**
 * CSS for the "Logo and description" and "Last column alignment" settings.
 * Empty for the default choices, so a footer that never touched them renders
 * exactly as before. Built from fixed strings only (the settings pick between
 * branches, nothing they contain is printed), self-contained and !important so
 * it holds on every theme.
 */
function cb_footer_layout_css(): string {
	$s          = cb_get_footer_settings();
	$layout_css = '';
	// Selectors carry .site-footer and the block's own classes so they
	// outrank the theme's `display:flex !important` on the columns row.
	$cols = '.site-footer .site-footer__inner>.wp-block-columns.site-footer__cols';
	if ( 'stacked' === ( $s['brand_layout'] ?? 'side' ) ) {
		$rule        = '1px solid color-mix(in srgb,currentColor 15%,transparent)';
		$layout_css .= $cols . '>.wp-block-column:first-child{margin-top:1.25rem!important;padding-top:1.25rem!important;border-top:' . $rule . '}';
		// Themes leave ~24px under the logo for the side-by-side layout; here the
		// rule's own margin does that job, so the space is equal on both sides.
		$layout_css .= '.site-footer .site-footer__logo-link{margin-bottom:-4px!important}';
		// One column on a phone: every part of the footer starts under the same
		// thin rule the description has, so the parts read as separate.
		$layout_css .= '@media(max-width:767px){.site-footer .site-footer__inner{gap:0!important}' . $cols . '{margin-top:0!important;gap:0!important}'
			. $cols . '>.wp-block-column{width:100%!important;max-width:none!important;flex-basis:auto!important;align-self:stretch!important}'
			. $cols . '>.wp-block-column+.wp-block-column{margin-top:1.75rem!important;padding-top:1.75rem!important;border-top:' . $rule . '}}';
		// grid-template-rows auto 1fr: row 1 is only as tall as the logo, so the
		// columns spanning both rows put their extra height into row 2 instead
		// of opening a gap between the logo and its rule.
		// The brand takes column 1 (logo in row 1, description in row 2); every
		// other column spans both rows and takes the next free column, so the
		// layout holds with or without the page-links column. Three columns
		// echo the bottom bar (left, centre, right); with four they all start
		// at their own left edge.
		$four        = $cols . ':has(>.site-footer__col--pages:has(*))';
		$layout_css .= '@media(min-width:768px){'
			. '.site-footer .site-footer__inner{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr))!important;grid-template-rows:auto 1fr!important;column-gap:clamp(2rem,5vw,4rem)!important;row-gap:0!important;align-items:start!important}'
			. '.site-footer .site-footer__inner:has(>.site-footer__cols>.site-footer__col--pages:has(*)){grid-template-columns:minmax(0,1.5fr) repeat(3,minmax(0,1fr))!important}'
			. $cols . '{display:contents!important}'
			. '.site-footer .site-footer__inner>.site-footer__logo,.site-footer .site-footer__inner>.wp-block-shortcode{grid-column:1;grid-row:1}'
			. '.site-footer .site-footer__inner>.site-footer__certs{grid-column:1/-1}'
			. $cols . '>.wp-block-column:first-child{grid-column:1;grid-row:2;max-width:28rem}'
			. $cols . '>.wp-block-column:not(:first-child){grid-row:1/span 2}'
			. $cols . '>.wp-block-column:nth-child(2):not(.site-footer__col--pages){justify-self:center}'
			. $four . '>.wp-block-column:not(:first-child){justify-self:start}'
			. '}';
	}
	if ( 'right' === ( $s['social_align'] ?? 'left' ) ) {
		$layout_css .= '@media(min-width:768px){' . $cols . '>.wp-block-column:last-child:not(:first-child){display:flex!important;flex-direction:column;align-items:flex-end;justify-self:end;text-align:right}}';
	}

	return $layout_css;
}

/**
 * Attach the layout CSS to the plugin's front-end stylesheet.
 */
function cb_footer_enqueue_layout_css(): void {
	$css = cb_footer_layout_css();
	if ( '' !== $css && wp_style_is( 'styrk-blocks-shared', 'enqueued' ) ) {
		wp_add_inline_style( 'styrk-blocks-shared', $css );
	}
}
// After enqueue_block_assets has enqueued the stylesheet on the front end.
add_action( 'wp_enqueue_scripts', 'cb_footer_enqueue_layout_css', 20 );
endif;

