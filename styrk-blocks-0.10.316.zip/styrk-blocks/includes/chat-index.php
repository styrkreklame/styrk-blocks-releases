<?php
/**
 * Chat index — chunks published content into a FULLTEXT table and retrieves
 * the best matches for a question. Pure helpers first (unit-tested with the
 * stubs), then the WordPress glue.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_CHAT_INDEX_LOADED' ) ) return;
define( 'CB_CHAT_INDEX_LOADED', true );

define( 'CB_CHAT_DB_VERSION', '1' );

/**
 * Plain-text chunks of roughly $size characters, split on paragraph and
 * sentence boundaries. Scripts and styles are dropped, tags stripped.
 *
 * @return string[]
 */
function cb_chat_chunk_text( string $html, int $size = 800 ): array {
	$html = preg_replace( '#<(script|style|noscript|template)\b[^>]*>.*?</\1>#is', ' ', $html ) ?? '';
	$html = preg_replace( '#</(p|div|li|h[1-6]|tr|section|article|blockquote|figcaption)>#i', "$0\n\n", $html ) ?? '';
	$html = preg_replace( '#<br\s*/?>#i', "\n", $html ) ?? '';
	$text = html_entity_decode( wp_strip_all_tags( $html ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
	$text = preg_replace( "/[ \t\x{00A0}]+/u", ' ', $text ) ?? '';
	$text = preg_replace( "/ *\n */", "\n", $text ) ?? '';
	$text = preg_replace( "/\n{3,}/", "\n\n", trim( $text ) ) ?? '';
	if ( '' === $text ) return [];

	$chunks = [];
	$buf    = '';
	foreach ( preg_split( "/\n\n+/", $text ) ?: [] as $para ) {
		$para = trim( $para );
		if ( '' === $para ) continue;
		if ( '' !== $buf && mb_strlen( $buf ) + mb_strlen( $para ) + 1 > $size ) {
			$chunks[] = $buf;
			$buf      = '';
		}
		// One giant paragraph: cut at the last sentence end before the limit.
		while ( mb_strlen( $para ) > $size ) {
			$head = mb_substr( $para, 0, $size );
			$cut  = mb_strrpos( $head, '. ' );
			$cut  = false !== $cut && $cut > (int) ( $size / 3 ) ? $cut + 1 : $size;
			$chunks[] = trim( ( '' !== $buf ? "$buf\n" : '' ) . mb_substr( $para, 0, $cut ) );
			$buf  = '';
			$para = trim( mb_substr( $para, $cut ) );
		}
		if ( '' === $para ) continue;
		$buf = '' !== $buf ? "$buf\n$para" : $para;
	}
	if ( '' !== $buf ) $chunks[] = $buf;
	return $chunks;
}

/**
 * Search terms for BOOLEAN MODE: lowercase, at least 4 characters, no
 * stopwords, at most 8.
 *
 * @return string[]
 */
function cb_chat_query_terms( string $q ): array {
	static $stop = [
		'dere', 'hvor', 'hva', 'hvordan', 'hvem', 'når', 'hvorfor', 'kan', 'har', 'for', 'med', 'som', 'det',
		'den', 'deres', 'eller', 'ikke', 'også', 'noen', 'noe', 'små', 'store', 'hvilke', 'hvilken', 'jeg',
		'meg', 'oss', 'være', 'blir', 'finnes', 'gjør', 'dette', 'denne', 'hvis', 'mulig', 'gjerne',
		'this', 'that', 'what', 'with', 'your', 'have', 'does', 'where', 'when', 'which', 'about',
	];
	$q     = mb_strtolower( $q );
	$words = preg_split( '/[^\p{L}\p{N}]+/u', $q, -1, PREG_SPLIT_NO_EMPTY ) ?: [];
	$out   = [];
	foreach ( $words as $w ) {
		if ( mb_strlen( $w ) < 4 || in_array( $w, $stop, true ) || in_array( $w, $out, true ) ) continue;
		$out[] = $w;
		if ( count( $out ) >= 8 ) break;
	}
	return $out;
}

/* ── WordPress glue ─────────────────────────────────────────────────────────── */

function cb_chat_table(): string {
	global $wpdb;
	return $wpdb->prefix . 'styrk_chat_chunks';
}

function cb_chat_install_table(): void {
	global $wpdb;
	if ( get_option( 'cb_chat_db_version' ) === CB_CHAT_DB_VERSION ) return;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$table   = cb_chat_table();
	$charset = $wpdb->get_charset_collate();
	dbDelta(
		"CREATE TABLE $table (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			post_id BIGINT UNSIGNED NOT NULL,
			chunk_no SMALLINT UNSIGNED NOT NULL,
			title VARCHAR(255) NOT NULL DEFAULT '',
			url VARCHAR(2048) NOT NULL DEFAULT '',
			body TEXT NOT NULL,
			PRIMARY KEY  (id),
			KEY post_id (post_id),
			FULLTEXT KEY ft_body (title,body)
		) $charset;"
	);
	update_option( 'cb_chat_db_version', CB_CHAT_DB_VERSION );
}
add_action( 'init', 'cb_chat_install_table', 5 );

/** @return string[] */
function cb_chat_public_post_types(): array {
	$types = get_post_types( [ 'public' => true ], 'names' );
	unset( $types['attachment'] );
	return array_values( (array) apply_filters( 'styrk_chat_post_types', $types ) );
}

function cb_chat_index_post( int $post_id ): void {
	global $wpdb;
	if ( function_exists( 'cb_chat_cache_flush' ) ) cb_chat_cache_flush();
	$post = get_post( $post_id );
	$wpdb->delete( cb_chat_table(), [ 'post_id' => $post_id ], [ '%d' ] );
	if ( ! $post instanceof WP_Post
		|| 'publish' !== $post->post_status
		|| '' !== $post->post_password
		|| ! in_array( $post->post_type, cb_chat_public_post_types(), true ) ) {
		return;
	}
	$title  = get_the_title( $post );
	// Render as a logged-out visitor: saving runs as the editor, and
	// members-only shortcodes would otherwise put hidden text in the index.
	$user = get_current_user_id();
	wp_set_current_user( 0 );
	try {
		$html = (string) apply_filters( 'the_content', $post->post_content );
	} finally {
		wp_set_current_user( $user );
	}
	$chunks = cb_chat_chunk_text( $title . "\n\n" . $html );
	$url    = (string) get_permalink( $post );
	foreach ( $chunks as $i => $body ) {
		$wpdb->insert(
			cb_chat_table(),
			[
				'post_id'  => $post_id,
				'chunk_no' => $i,
				'title'    => mb_substr( $title, 0, 255 ),
				'url'      => $url,
				'body'     => $body,
			],
			[ '%d', '%d', '%s', '%s', '%s' ]
		);
	}
}

add_action( 'save_post', static function ( $post_id ): void {
	$post_id = (int) $post_id;
	if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) return;
	cb_chat_index_post( $post_id );
}, 20 );
add_action( 'deleted_post', static function ( $post_id ): void {
	cb_chat_index_post( (int) $post_id );
} );
add_action( 'transition_post_status', static function ( $new, $old, $post ): void {
	if ( $new !== $old && $post instanceof WP_Post ) cb_chat_index_post( (int) $post->ID );
}, 10, 3 );

/* ── Site facts (Settings → Footer) ─────────────────────────────────────────── */

/**
 * The footer's contact block as one plain-text chunk: address, e-mail,
 * phones, opening hours and organisation number live in Settings → Footer,
 * not in any page, so the post indexer never sees them.
 *
 * @param array<string,mixed> $footer cb_get_footer_settings() shape.
 */
function cb_chat_site_facts_text( string $site_name, array $footer, array $hour_lines = [] ): string {
	$lines = [ $site_name ];
	foreach ( [ 'tagline', 'description' ] as $k ) {
		if ( ! empty( $footer[ $k ] ) ) $lines[] = (string) $footer[ $k ];
	}
	if ( ! empty( $footer['address'] ) ) $lines[] = 'Adresse: ' . $footer['address'];
	if ( ! empty( $footer['email'] ) ) $lines[] = 'E-post: ' . $footer['email'];
	$phones = array_filter( [ $footer['phone_1'] ?? '', $footer['phone_2'] ?? '' ] );
	if ( $phones ) $lines[] = 'Telefon: ' . implode( ', ', $phones );
	if ( $hour_lines ) {
		$lines[] = 'Åpningstider: ' . implode( '; ', $hour_lines );
	} elseif ( ! empty( $footer['opening_hours'] ) ) {
		$lines[] = 'Åpningstider: ' . preg_replace( '/\s*\n+\s*/', '; ', trim( (string) $footer['opening_hours'] ) );
	}
	if ( ! empty( $footer['org_number'] ) ) $lines[] = 'Organisasjonsnummer: ' . $footer['org_number'];
	return count( $lines ) > 1 ? implode( "\n", $lines ) : '';
}

/** Stored as post_id 0 so a post reindex never touches it. */
function cb_chat_index_site_facts(): void {
	global $wpdb;
	if ( function_exists( 'cb_chat_cache_flush' ) ) cb_chat_cache_flush();
	$wpdb->delete( cb_chat_table(), [ 'post_id' => 0 ], [ '%d' ] );
	if ( ! function_exists( 'cb_get_footer_settings' ) ) return;
	$footer = cb_get_footer_settings();
	$hours  = [];
	if ( function_exists( 'Styrk\\Blocks\\Footer\\hours_are_set' ) && \Styrk\Blocks\Footer\hours_are_set( $footer ) ) {
		$hours = \Styrk\Blocks\Footer\hour_lines( $footer );
	}
	$text = cb_chat_site_facts_text( (string) get_bloginfo( 'name' ), $footer, $hours );
	if ( '' === $text ) return;
	$contact = function_exists( 'cb_chat_get_settings' ) ? (string) cb_chat_get_settings()['contact_url'] : '';
	$wpdb->insert(
		cb_chat_table(),
		[
			'post_id'  => 0,
			'chunk_no' => 0,
			'title'    => 'Kontakt og åpningstider',
			'url'      => $contact ?: home_url( '/' ),
			'body'     => $text,
		],
		[ '%d', '%d', '%s', '%s', '%s' ]
	);
}
// The first save on a fresh site is add_option, not update_option, so hook both.
foreach ( [ defined( 'CB_FOOTER_OPTION' ) ? CB_FOOTER_OPTION : 'cb_footer_settings', 'cb_chat_settings' ] as $cb_chat_facts_option ) {
	add_action( "add_option_$cb_chat_facts_option", 'cb_chat_index_site_facts' );
	add_action( "update_option_$cb_chat_facts_option", 'cb_chat_index_site_facts' );
}
unset( $cb_chat_facts_option );

/** Full reindex in WP-cron batches of 50 posts. */
function cb_chat_schedule_full_reindex(): void {
	global $wpdb;
	$table = cb_chat_table();
	$wpdb->query( "TRUNCATE TABLE $table" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name from $wpdb->prefix.
	update_option( 'cb_chat_index_run', [ 'started' => current_time( 'mysql' ), 'offset' => 0 ], false );
	wp_schedule_single_event( time(), 'cb_chat_reindex_batch' );
	spawn_cron();
}

function cb_chat_reindex_batch(): void {
	$run    = (array) get_option( 'cb_chat_index_run', [ 'offset' => 0 ] );
	$offset = (int) ( $run['offset'] ?? 0 );
	$ids    = get_posts( [
		'post_type'              => cb_chat_public_post_types(),
		'post_status'            => 'publish',
		'posts_per_page'         => 50,
		'offset'                 => $offset,
		'fields'                 => 'ids',
		'orderby'                => 'ID',
		'order'                  => 'ASC',
		'no_found_rows'          => true,
		'update_post_meta_cache' => false,
		'update_post_term_cache' => false,
	] );
	foreach ( $ids as $id ) {
		cb_chat_index_post( (int) $id );
	}
	if ( 50 === count( $ids ) ) {
		$run['offset'] = $offset + 50;
		update_option( 'cb_chat_index_run', $run, false );
		wp_schedule_single_event( time() + 5, 'cb_chat_reindex_batch' );
		return;
	}
	cb_chat_index_site_facts();
	update_option( 'cb_chat_index_last', current_time( 'mysql' ), false );
}
add_action( 'cb_chat_reindex_batch', 'cb_chat_reindex_batch' );

/** @return array{chunks:int,posts:int,last_run:string} */
function cb_chat_index_status(): array {
	global $wpdb;
	$table = cb_chat_table();
	return [
		'chunks'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name from $wpdb->prefix.
		'posts'    => (int) $wpdb->get_var( "SELECT COUNT(DISTINCT post_id) FROM $table" ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name from $wpdb->prefix.
		'last_run' => (string) get_option( 'cb_chat_index_last', '' ),
	];
}

/**
 * The best chunks for a question: at most $limit, at most 2 per page, at most
 * ~4500 characters in total.
 *
 * @return array<int, array{title:string,url:string,body:string}>
 */
function cb_chat_retrieve( string $question, int $limit = 6 ): array {
	global $wpdb;
	$terms = cb_chat_query_terms( $question );
	$table = cb_chat_table();
	$facts = $wpdb->get_row( "SELECT title, url, body FROM $table WHERE post_id = 0 LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name from $wpdb->prefix.
	$facts = $facts ? [ 'title' => (string) $facts['title'], 'url' => (string) $facts['url'], 'body' => (string) $facts['body'] ] : null;
	if ( ! $terms ) return $facts ? [ $facts ] : [];
	$fetch = static function ( string $expr ) use ( $wpdb, $table, $limit ): array {
		// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- $table comes from $wpdb->prefix, the values are placeholders.
		return $wpdb->get_results(
			$wpdb->prepare(
				"SELECT title, url, body, MATCH(title, body) AGAINST (%s IN BOOLEAN MODE) AS score
				 FROM $table
				 WHERE MATCH(title, body) AGAINST (%s IN BOOLEAN MODE)
				 ORDER BY score DESC LIMIT %d",
				$expr,
				$expr,
				$limit * 2
			),
			ARRAY_A
		) ?: [];
		// phpcs:enable
	};
	$rows = $fetch( implode( ' ', array_map( static fn( string $w ): string => '+' . $w . '*', $terms ) ) );
	if ( ! $rows ) {
		$rows = $fetch( implode( ' ', array_map( static fn( string $w ): string => $w . '*', $terms ) ) );
	}
	$out = [];
	$per = [];
	$len = 0;
	foreach ( $rows as $r ) {
		$per[ $r['url'] ] = ( $per[ $r['url'] ] ?? 0 ) + 1;
		if ( $per[ $r['url'] ] > 2 ) continue;
		$len += strlen( $r['body'] );
		if ( $len > 4500 ) break;
		$out[] = [ 'title' => (string) $r['title'], 'url' => (string) $r['url'], 'body' => (string) $r['body'] ];
		if ( count( $out ) >= $limit ) break;
	}
	// Contact facts ride along on every question: "åpent?" has no search terms.
	if ( $facts && ! in_array( $facts['body'], array_column( $out, 'body' ), true ) ) {
		$out[] = $facts;
	}
	return $out;
}
