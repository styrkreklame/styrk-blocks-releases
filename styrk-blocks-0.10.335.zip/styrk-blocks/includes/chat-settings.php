<?php
/**
 * Chat Settings — Settings → Chat.
 *
 * Site-wide AI assistant that answers from the site's own published content
 * (see chat-index.php for the index, chat-api.php for the REST endpoint and
 * chat-widget.php for the frontend). The API key is resolved server-side only
 * — constant first, option second — and is never sent to the browser.
 *
 * Mirrors the structure of search-settings.php so the global settings pages
 * (Header, Footer, Search, Chat) stay consistent under WP's Settings menu.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_CHAT_SETTINGS_LOADED' ) ) return;
define( 'CB_CHAT_SETTINGS_LOADED', true );

require_once __DIR__ . '/admin-ui.php';

define( 'CB_CHAT_OPTION', 'cb_chat_settings' );

function cb_chat_defaults(): array {
	return [
		'enabled'       => false,
		// Test mode: only logged-in administrators see and can use the chat.
		'admin_only'    => false,
		'api_key'       => '',
		'bot_name'      => 'Spør oss',
		'subtitle'      => 'Svarer ut fra innholdet på nettsiden',
		'welcome'       => 'Hei! Jeg kan svare på spørsmål om tjenestene våre og hvordan vi jobber. Hva lurer du på?',
		'suggestions'   => [ 'Hva tilbyr dere?', 'Hvor holder dere til?', 'Hvordan kommer vi i gang?' ],
		'contact_url'   => '',
		'contact_phone' => '',
		'legal'         => 'Svarene lages av KI ut fra nettsidens innhold og kan inneholde feil.',
		// Cost guards (see chat-guard.php). Answers that call Claude, per site.
		'monthly_cap'        => 1000,
		'daily_cap'          => 100,
		'alert_email'        => '',
		'turnstile_site_key' => '',
		'turnstile_secret'   => '',
	];
}

function cb_chat_get_settings(): array {
	$saved = get_option( CB_CHAT_OPTION, [] );
	return ( is_array( $saved ) ? $saved : [] ) + cb_chat_defaults();
}

/** Test mode shows the chat to administrators only, on or off; otherwise «on» decides. */
function cb_chat_visible_to_current_user(): bool {
	$s = cb_chat_get_settings();
	if ( ! empty( $s['admin_only'] ) ) return current_user_can( 'manage_options' );
	return ! empty( $s['enabled'] );
}

/** The constant wins so hosts can keep the key out of the database. */
function cb_chat_api_key(): string {
	if ( cb_chat_key_is_constant() ) {
		return trim( (string) constant( 'STYRK_ANTHROPIC_API_KEY' ) );
	}
	return trim( (string) ( cb_chat_get_settings()['api_key'] ?? '' ) );
}

function cb_chat_key_is_constant(): bool {
	return defined( 'STYRK_ANTHROPIC_API_KEY' ) && '' !== trim( (string) constant( 'STYRK_ANTHROPIC_API_KEY' ) );
}

/**
 * Who may open Settings → Chat: only the Styrk logins listed in wp-config,
 *
 *     define( 'STYRK_CHAT_ADMINS', 'styrk,anders' );
 *
 * Clients usually get the Administrator role, and the chat is a paid Styrk
 * service: a client admin must not be able to paste their own API key or
 * change the model and limits. No constant = no one sees the page (the chat
 * keeps running on the key already set).
 */
function cb_chat_can_manage( int $user_id = 0 ): bool {
	$user = $user_id ? get_userdata( $user_id ) : wp_get_current_user();
	if ( ! $user || ! $user->exists() || ! user_can( $user, 'manage_options' ) ) return false;
	if ( ! defined( 'STYRK_CHAT_ADMINS' ) ) return false;
	$allowed = array_filter( array_map( 'trim', explode( ',', (string) constant( 'STYRK_CHAT_ADMINS' ) ) ) );
	return in_array( $user->user_login, $allowed, true );
}

/** `styrk_manage_chat` is a meta capability: granted only by cb_chat_can_manage(). */
function cb_chat_map_meta_cap( array $caps, string $cap, int $user_id ): array {
	if ( 'styrk_manage_chat' !== $cap ) return $caps;
	return cb_chat_can_manage( $user_id ) ? [ 'manage_options' ] : [ 'do_not_allow' ];
}
add_filter( 'map_meta_cap', 'cb_chat_map_meta_cap', 10, 3 );

/** Saving through options.php needs the same capability as the page. */
add_filter( 'option_page_capability_cb_chat_group', static fn() => 'styrk_manage_chat' );

/** Plain text, trimmed to $max characters. */
function cb_chat_clip( $value, int $max ): string {
	return mb_substr( sanitize_text_field( (string) $value ), 0, $max );
}

/** A new secret when it looks right; otherwise the saved one (blank keeps it). */
function cb_chat_keep_secret( $value, string $saved, string $pattern ): string {
	$value = trim( (string) $value );
	return '' !== $value && preg_match( $pattern, $value ) ? $value : $saved;
}

/** @return string[] Up to four suggestion lines. */
function cb_chat_clean_suggestions( $raw ): array {
	if ( is_string( $raw ) ) {
		$raw = preg_split( '/\r?\n/', $raw ) ?: [];
	}
	return array_values( array_filter( array_map(
		static fn( $s ): string => cb_chat_clip( $s, 60 ),
		array_slice( (array) $raw, 0, 4 )
	) ) );
}

/** Only http(s) or site-relative URLs. */
function cb_chat_clean_url( $raw ): string {
	$url = esc_url_raw( (string) $raw );
	return '' !== $url && ! preg_match( '#^(https?:)?/#', $url ) ? '' : $url;
}

function cb_chat_clean_count( $value, int $fallback ): int {
	return max( 1, min( 100000, (int) ( is_numeric( $value ) ? $value : $fallback ) ) );
}

function cb_chat_sanitize( $input ): array {
	$in   = is_array( $input ) ? $input : [];
	$prev = cb_chat_get_settings();
	$id   = '/^[A-Za-z0-9_\-]{10,}$/';

	$ts_site = trim( (string) ( $in['turnstile_site_key'] ?? '' ) );
	$ts_site = preg_match( $id, $ts_site ) ? $ts_site : '';
	$email   = (string) ( $in['alert_email'] ?? '' );

	return [
		'enabled'            => ! empty( $in['enabled'] ),
		'admin_only'         => ! empty( $in['admin_only'] ),
		'api_key'            => cb_chat_keep_secret( $in['api_key'] ?? '', (string) $prev['api_key'], '/^sk-ant-[A-Za-z0-9_\-]{20,}$/' ),
		'bot_name'           => cb_chat_clip( $in['bot_name'] ?? '', 40 ) ?: (string) $prev['bot_name'],
		'subtitle'           => cb_chat_clip( $in['subtitle'] ?? '', 80 ),
		'welcome'            => cb_chat_clip( $in['welcome'] ?? '', 300 ) ?: (string) $prev['welcome'],
		'suggestions'        => cb_chat_clean_suggestions( $in['suggestions'] ?? [] ),
		'contact_url'        => cb_chat_clean_url( $in['contact_url'] ?? '' ),
		'contact_phone'      => cb_chat_clip( $in['contact_phone'] ?? '', 30 ),
		'legal'              => cb_chat_clip( $in['legal'] ?? '', 160 ),
		'monthly_cap'        => cb_chat_clean_count( $in['monthly_cap'] ?? null, (int) $prev['monthly_cap'] ),
		'daily_cap'          => cb_chat_clean_count( $in['daily_cap'] ?? null, (int) $prev['daily_cap'] ),
		'alert_email'        => is_email( $email ) ? sanitize_email( $email ) : '',
		'turnstile_site_key' => $ts_site,
		'turnstile_secret'   => '' === $ts_site ? '' : cb_chat_keep_secret( $in['turnstile_secret'] ?? '', (string) $prev['turnstile_secret'], $id ),
	];
}

/* ── Admin page ─────────────────────────────────────────────────────────────── */

function cb_chat_settings_menu(): void {
	add_options_page(
		__( 'Chat Settings', 'styrk-blocks' ),
		__( 'Chat', 'styrk-blocks' ),
		'styrk_manage_chat',
		'cb-chat-settings',
		'cb_chat_settings_page'
	);
}
add_action( 'admin_menu', 'cb_chat_settings_menu' );

/**
 * The page is built from the Settings API: every SECTION is one named part of
 * the panel, every FIELD one row of it (see sb_ui_render_parts() in
 * includes/admin-ui.php). The first three parts are the settings form; the
 * "Status" part sits outside that form because it holds forms of its own
 * (reindex, delete feedback). Every saved option key and sanitizer is unchanged.
 */
function cb_chat_settings_init(): void {
	register_setting( 'cb_chat_group', CB_CHAT_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_chat_sanitize',
		'default'           => cb_chat_defaults(),
	] );

	$page = 'cb-chat-settings';

	add_settings_section( 'cb_chat_on', __( 'Slå på', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_chat_row_switch', __( 'Chat', 'styrk-blocks' ), 'cb_chat_row_switch', $page, 'cb_chat_on' );
	add_settings_field( 'cb_chat_row_key', __( 'Nøkkel', 'styrk-blocks' ), 'cb_chat_row_key', $page, 'cb_chat_on' );

	add_settings_section( 'cb_chat_look', __( 'Utseende og tekst', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_chat_row_name', __( 'Navn', 'styrk-blocks' ), 'cb_chat_row_name', $page, 'cb_chat_look' );
	add_settings_field( 'cb_chat_row_welcome', __( 'Velkomst', 'styrk-blocks' ), 'cb_chat_row_welcome', $page, 'cb_chat_look' );
	add_settings_field( 'cb_chat_row_suggestions', __( 'Forslag', 'styrk-blocks' ), 'cb_chat_row_suggestions', $page, 'cb_chat_look' );
	add_settings_field( 'cb_chat_row_legal', __( 'Liten tekst', 'styrk-blocks' ), 'cb_chat_row_legal', $page, 'cb_chat_look' );
	add_settings_field( 'cb_chat_row_contact', __( 'Kontakt', 'styrk-blocks' ), 'cb_chat_row_contact', $page, 'cb_chat_look' );

	add_settings_section( 'cb_chat_guard', __( 'Kostnad og misbruk', 'styrk-blocks' ), '__return_empty_string', $page );
	add_settings_field( 'cb_chat_row_caps', __( 'Maks svar', 'styrk-blocks' ), 'cb_chat_row_caps', $page, 'cb_chat_guard' );
	add_settings_field( 'cb_chat_row_alert', __( 'Varsel', 'styrk-blocks' ), 'cb_chat_row_alert', $page, 'cb_chat_guard' );
	add_settings_field( 'cb_chat_row_turnstile', __( 'Robotsjekk (Cloudflare Turnstile)', 'styrk-blocks' ), 'cb_chat_row_turnstile', $page, 'cb_chat_guard' );

	// Own page slug: printed outside the settings form.
	add_settings_section( 'cb_chat_status', __( 'Status', 'styrk-blocks' ), '__return_empty_string', 'cb-chat-status' );
	add_settings_field( 'cb_chat_row_usage', __( 'Bruk denne måneden', 'styrk-blocks' ), 'cb_chat_row_usage', 'cb-chat-status', 'cb_chat_status' );
	add_settings_field( 'cb_chat_row_index', __( 'Indeks', 'styrk-blocks' ), 'cb_chat_row_index', 'cb-chat-status', 'cb_chat_status' );
	add_settings_field( 'cb_chat_row_feedback', __( 'Tilbakemeldinger', 'styrk-blocks' ), 'cb_chat_row_feedback', 'cb-chat-status', 'cb_chat_status' );
}
add_action( 'admin_init', 'cb_chat_settings_init' );

/** The kit's styles and script on this screen. */
add_filter(
	'sb_ui_pages',
	static function ( $pages ) {
		$pages   = (array) $pages;
		$pages[] = 'settings_page_cb-chat-settings';
		return $pages;
	}
);

/* ── Row helpers ────────────────────────────────────────────────────────────── */

/**
 * Name attribute of one option inside the stored array.
 *
 * @param string $key Option key.
 */
function cb_chat_field_name( string $key ): string {
	return CB_CHAT_OPTION . '[' . $key . ']';
}

/**
 * A single-line field of the saved settings.
 *
 * @param string $key         Option key.
 * @param string $label       Visible label ('' = none; then $aria names it).
 * @param string $aria        Accessible name when there is no visible label.
 * @param string $type        Input type.
 * @param string $placeholder Placeholder.
 * @param bool   $secret      A secret: never printed back, blank keeps the saved one.
 */
function cb_chat_text_input( string $key, string $label, string $aria = '', string $type = 'text', string $placeholder = '', bool $secret = false ): void {
	$s    = cb_chat_get_settings();
	$id   = 'cb_chat_' . $key;
	$val  = $secret ? '' : (string) $s[ $key ];
	$aria = '' === $aria ? '' : ' aria-label="' . esc_attr( $aria ) . '"';
	echo '<label class="sb-inline" for="' . esc_attr( $id ) . '">';
	if ( '' !== $label ) {
		echo '<span>' . esc_html( $label ) . '</span>';
	}
	echo '<input type="' . esc_attr( $type ) . '" class="sb-input' . ( '' === $label ? ' sb-input--wide' : '' ) . '" id="' . esc_attr( $id ) . '" name="' . esc_attr( cb_chat_field_name( $key ) ) . '" value="' . esc_attr( $val ) . '" placeholder="' . esc_attr( $placeholder ) . '"' . ( $secret ? ' autocomplete="new-password"' : '' ) . $aria . ' />'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- $aria is escaped above.
	echo '</label>';
}

/**
 * A number field as the kit's stepper.
 *
 * @param string $key   Option key.
 * @param string $label Accessible name.
 */
function cb_chat_stepper( string $key, string $label ): void {
	$s = cb_chat_get_settings();
	sb_ui_stepper(
		cb_chat_field_name( $key ),
		(string) (int) $s[ $key ],
		1,
		100000,
		(int) cb_chat_defaults()[ $key ],
		[
			'less'  => __( 'Mindre', 'styrk-blocks' ),
			'more'  => __( 'Mer', 'styrk-blocks' ),
			'label' => $label,
		]
	);
}

/* ── Rows: Slå på ───────────────────────────────────────────────────────────── */

function cb_chat_row_switch(): void {
	$s = cb_chat_get_settings();
	sb_ui_stack(
		static function () use ( $s ): void {
			sb_ui_toggle( cb_chat_field_name( 'enabled' ), ! empty( $s['enabled'] ), __( 'Vis chatten på nettstedet', 'styrk-blocks' ) );
			sb_ui_toggle( cb_chat_field_name( 'admin_only' ), ! empty( $s['admin_only'] ), __( 'Testmodus: bare for innloggede', 'styrk-blocks' ) );
		}
	);
	sb_ui_help( __( 'I testmodus ser bare innloggede administratorer chatten. Besøkende ser den ikke.', 'styrk-blocks' ) );
}

function cb_chat_row_key(): void {
	if ( cb_chat_key_is_constant() ) {
		sb_ui_help( __( 'Nøkkelen er satt i wp-config.php (STYRK_ANTHROPIC_API_KEY) og kan ikke endres her.', 'styrk-blocks' ) );
		return;
	}
	$saved = '' !== (string) cb_chat_get_settings()['api_key'];
	cb_chat_text_input(
		'api_key',
		'',
		__( 'Anthropic API-nøkkel', 'styrk-blocks' ),
		'password',
		$saved ? '•••••••• ' . __( '(lagret)', 'styrk-blocks' ) : 'sk-ant-…',
		true
	);
	sb_ui_help( __( 'La feltet stå tomt for å beholde lagret nøkkel.', 'styrk-blocks' ) );
}

/* ── Rows: Utseende og tekst ────────────────────────────────────────────────── */

function cb_chat_row_name(): void {
	sb_ui_stack(
		static function (): void {
			cb_chat_text_input( 'bot_name', '', __( 'Navn', 'styrk-blocks' ) );
			cb_chat_text_input( 'subtitle', '', __( 'Undertittel', 'styrk-blocks' ) );
		}
	);
	sb_ui_help( __( 'Navnet og en kort linje under det, øverst i chatten.', 'styrk-blocks' ) );
}

function cb_chat_row_welcome(): void {
	cb_chat_text_input( 'welcome', '', __( 'Velkomstmelding', 'styrk-blocks' ) );
}

function cb_chat_row_suggestions(): void {
	$s    = cb_chat_get_settings();
	$list = array_values( (array) $s['suggestions'] );
	echo '<div class="sb-stack" data-sb-list>';
	for ( $i = 0; $i < 4; $i++ ) {
		$hide = ! isset( $list[ $i ] ) && $i > 0 && ! isset( $list[ $i - 1 ] );
		printf(
			'<div data-sb-extra%1$s class="sb-sug"><input type="text" class="sb-input sb-input--wide" name="%2$s[]" value="%3$s" maxlength="60" aria-label="%4$s" /></div>',
			$hide ? ' hidden' : '', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- literal.
			esc_attr( cb_chat_field_name( 'suggestions' ) ),
			esc_attr( (string) ( $list[ $i ] ?? '' ) ),
			/* translators: %d: number, 1 to 4 */
			esc_attr( sprintf( __( 'Forslag %d', 'styrk-blocks' ), $i + 1 ) )
		);
	}
	printf(
		'<button type="button" class="sb-btn" data-sb-add>%s</button></div>',
		esc_html__( 'Legg til forslag', 'styrk-blocks' )
	);
	echo '<noscript><style>.sb-sug[hidden]{display:block}</style></noscript>';
	sb_ui_help( __( 'Opptil fire spørsmål besøkende kan trykke på.', 'styrk-blocks' ) );
}

function cb_chat_row_legal(): void {
	cb_chat_text_input( 'legal', '', __( 'Liten tekst under skrivefeltet', 'styrk-blocks' ) );
	sb_ui_help( __( 'Vises under skrivefeltet i chatten.', 'styrk-blocks' ) );
}

function cb_chat_row_contact(): void {
	sb_ui_line(
		static function (): void {
			cb_chat_text_input( 'contact_phone', __( 'Telefon', 'styrk-blocks' ) );
			cb_chat_text_input( 'contact_url', __( 'Kontaktside', 'styrk-blocks' ), '', 'text', '/kontakt/' );
		}
	);
	sb_ui_help( __( 'Chatten viser dette når besøkende trenger en person. Kontaktsiden kan være en side her, som /kontakt/, eller en full adresse.', 'styrk-blocks' ) );
}

/* ── Rows: Kostnad og misbruk ───────────────────────────────────────────────── */

function cb_chat_row_caps(): void {
	sb_ui_line(
		static function (): void {
			echo '<span class="sb-inline"><span>' . esc_html__( 'Per måned', 'styrk-blocks' ) . '</span>';
			cb_chat_stepper( 'monthly_cap', __( 'Maks svar per måned', 'styrk-blocks' ) );
			echo '</span><span class="sb-inline"><span>' . esc_html__( 'Per døgn', 'styrk-blocks' ) . '</span>';
			cb_chat_stepper( 'daily_cap', __( 'Maks svar per døgn', 'styrk-blocks' ) );
			echo '</span>';
		}
	);
	sb_ui_help( __( 'Hver besøkende kan stille 5 spørsmål i minuttet og 50 i døgnet. Når nettstedets kvote er brukt opp, viser chatten kontaktinformasjon i stedet for svar. Gjentatte spørsmål besvares fra lager uten kostnad.', 'styrk-blocks' ) );
}

function cb_chat_row_alert(): void {
	cb_chat_text_input( 'alert_email', '', __( 'Varsel ved 80 % og 100 % til', 'styrk-blocks' ), 'email', (string) get_option( 'admin_email' ) );
	sb_ui_help( __( 'Du får en e-post når 80 % og 100 % av månedens svar er brukt.', 'styrk-blocks' ) );
}

function cb_chat_row_turnstile(): void {
	$s = cb_chat_get_settings();
	sb_ui_stack(
		static function () use ( $s ): void {
			cb_chat_text_input( 'turnstile_site_key', __( 'Offentlig nøkkel', 'styrk-blocks' ) );
			cb_chat_text_input(
				'turnstile_secret',
				__( 'Hemmelig nøkkel', 'styrk-blocks' ),
				'',
				'password',
				'' !== (string) $s['turnstile_secret'] ? '•••••••• ' . __( '(lagret)', 'styrk-blocks' ) : '',
				true
			);
		}
	);
	sb_ui_help( __( 'Robotsjekk før første spørsmål. Begge feltene må fylles ut for å slå den på. La feltet stå tomt for å beholde lagret verdi.', 'styrk-blocks' ) );
}

/* ── Rows: Status (outside the settings form) ───────────────────────────────── */

function cb_chat_row_usage(): void {
	if ( ! function_exists( 'cb_chat_usage_status' ) ) {
		return;
	}
	$u = cb_chat_usage_status();
	echo '<p class="sb-text">';
	printf(
		/* translators: 1: answers used, 2: monthly cap */
		esc_html__( '%1$d av %2$d svar brukt.', 'styrk-blocks' ),
		(int) $u['month_count'],
		(int) $u['monthly_cap']
	);
	echo '</p>';
}

function cb_chat_row_index(): void {
	$status = function_exists( 'cb_chat_index_status' )
		? cb_chat_index_status()
		: [ 'chunks' => 0, 'posts' => 0, 'last_run' => '' ];
	echo '<p class="sb-text">';
	printf(
		/* translators: 1: chunk count, 2: post count, 3: time */
		esc_html__( '%1$d tekstbiter fra %2$d sider. Sist kjørt: %3$s', 'styrk-blocks' ),
		(int) $status['chunks'],
		(int) $status['posts'],
		esc_html( $status['last_run'] ?: __( 'aldri', 'styrk-blocks' ) )
	);
	echo '</p>';
	printf(
		'<form method="post" action="%s"><input type="hidden" name="action" value="cb_chat_reindex">',
		esc_url( admin_url( 'admin-post.php' ) )
	);
	wp_nonce_field( 'cb_chat_reindex' );
	printf( '<button type="submit" class="sb-btn">%s</button></form>', esc_html__( 'Reindekser nå', 'styrk-blocks' ) );
}

function cb_chat_row_feedback(): void {
	echo '<span id="tilbakemeldinger"></span>';
	if ( function_exists( 'cb_chat_feedback_render' ) ) {
		cb_chat_feedback_render( false );
	}
}

/* ── Part summaries ─────────────────────────────────────────────────────────── */

/**
 * One-line summary of a part, shown while it is closed.
 *
 * @param string $id Section id.
 */
function cb_chat_part_summary( string $id ): string {
	$s = cb_chat_get_settings();
	if ( 'cb_chat_on' === $id ) {
		if ( ! empty( $s['admin_only'] ) ) {
			return __( 'Testmodus · bare for innloggede', 'styrk-blocks' );
		}
		return ! empty( $s['enabled'] ) ? __( 'På · synlig for alle', 'styrk-blocks' ) : __( 'Av', 'styrk-blocks' );
	}
	if ( 'cb_chat_look' === $id ) {
		return '«' . (string) $s['bot_name'] . '»';
	}
	if ( 'cb_chat_guard' === $id ) {
		/* translators: %d: answers per month */
		$text = sprintf( __( '%d svar i måneden', 'styrk-blocks' ), (int) $s['monthly_cap'] );
		return '' !== (string) $s['alert_email'] ? $text . ' · ' . __( 'varsel på e-post', 'styrk-blocks' ) : $text;
	}
	if ( function_exists( 'cb_chat_usage_status' ) ) {
		$u = cb_chat_usage_status();
		/* translators: 1: answers used, 2: monthly cap */
		return sprintf( __( '%1$d av %2$d svar brukt.', 'styrk-blocks' ), (int) $u['month_count'], (int) $u['monthly_cap'] );
	}
	return '';
}

function cb_chat_settings_page(): void {
	if ( ! current_user_can( 'styrk_manage_chat' ) ) return;
	?>
	<div class="wrap sb-ui" data-sb-page="chat">
		<h1><?php esc_html_e( 'Chat Settings', 'styrk-blocks' ); ?></h1>
		<p class="sb-ui__intro"><?php esc_html_e( 'En chat nederst til høyre som svarer ut fra publisert innhold på nettsiden. Spørsmålet og relevante tekstutdrag sendes til Anthropic sitt API (brukes ikke til trening). Ingen besøksdata lagres.', 'styrk-blocks' ); ?></p>
		<?php if ( isset( $_GET['reindexed'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag after a nonce-checked redirect. ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Reindeksering er satt i gang.', 'styrk-blocks' ); ?></p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['cleared'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag after a nonce-checked redirect. ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Tilbakemeldingene er slettet.', 'styrk-blocks' ); ?></p></div>
		<?php endif; ?>
		<?php if ( isset( $_GET['deleted'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag after a nonce-checked redirect. ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Tilbakemeldingen er slettet.', 'styrk-blocks' ); ?></p></div>
		<?php endif; ?>
		<noscript><style>.sb-part__body[hidden]{display:block}</style></noscript>
		<div class="sb-panel">
			<h2 class="sb-panel__title"><?php esc_html_e( 'Chat', 'styrk-blocks' ); ?></h2>
			<form method="post" action="options.php" id="cb-chat-form">
				<?php
				settings_fields( 'cb_chat_group' );
				sb_ui_render_parts( 'cb-chat-settings', 'cb_chat_part_summary' );
				?>
			</form>
			<?php sb_ui_render_parts( 'cb-chat-status', 'cb_chat_part_summary', false ); ?>
		</div>
		<button type="submit" form="cb-chat-form" name="submit" class="sb-submit"><?php esc_html_e( 'Lagre endringer', 'styrk-blocks' ); ?></button>
	</div>
	<?php
}

function cb_chat_handle_reindex(): void {
	if ( ! current_user_can( 'styrk_manage_chat' ) ) {
		wp_die( esc_html__( 'Ingen tilgang.', 'styrk-blocks' ), 403 );
	}
	check_admin_referer( 'cb_chat_reindex' );
	if ( function_exists( 'cb_chat_schedule_full_reindex' ) ) {
		cb_chat_schedule_full_reindex();
	}
	wp_safe_redirect( add_query_arg( [ 'page' => 'cb-chat-settings', 'reindexed' => 1 ], admin_url( 'options-general.php' ) ) );
	exit;
}
add_action( 'admin_post_cb_chat_reindex', 'cb_chat_handle_reindex' );
