<?php
/**
 * WCAG-aware color helpers.
 *
 * Used by block templates to guarantee that text placed on a user-picked
 * background colour still meets WCAG AA contrast (4.5:1 for normal text,
 * 3:1 for large text). Keeps the user's background, adjusts the text.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_hex_to_rgb' ) ) {
	function cb_hex_to_rgb( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( strlen( $hex ) === 3 ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( strlen( $hex ) !== 6 || ! ctype_xdigit( $hex ) ) {
			return null;
		}
		return [
			hexdec( substr( $hex, 0, 2 ) ),
			hexdec( substr( $hex, 2, 2 ) ),
			hexdec( substr( $hex, 4, 2 ) ),
		];
	}
}

if ( ! function_exists( 'cb_relative_luminance' ) ) {
	function cb_relative_luminance( $hex ) {
		$rgb = cb_hex_to_rgb( $hex );
		if ( ! $rgb ) return null;
		$lin = array_map( function ( $c ) {
			$s = $c / 255;
			return $s <= 0.03928 ? $s / 12.92 : pow( ( $s + 0.055 ) / 1.055, 2.4 );
		}, $rgb );
		return 0.2126 * $lin[0] + 0.7152 * $lin[1] + 0.0722 * $lin[2];
	}
}

if ( ! function_exists( 'cb_contrast_ratio' ) ) {
	function cb_contrast_ratio( $a, $b ) {
		$la = cb_relative_luminance( $a );
		$lb = cb_relative_luminance( $b );
		if ( $la === null || $lb === null ) return 0.0;
		$lighter = max( $la, $lb );
		$darker  = min( $la, $lb );
		return ( $lighter + 0.05 ) / ( $darker + 0.05 );
	}
}

if ( ! function_exists( 'cb_best_contrast_text' ) ) {
	/**
	 * Pick a WCAG-passing text color for a given background.
	 *
	 * - If $preferred is passed AND meets $min_ratio against $bg → keep it.
	 * - Otherwise pick whichever of #ffffff / #111111 gives the higher ratio.
	 *
	 * @param string $bg         Background colour (hex).
	 * @param string $preferred  User-picked text colour (hex). May be empty.
	 * @param float  $min_ratio  Minimum required contrast. 4.5 = AA normal text,
	 *                           3.0 = AA large text / UI components.
	 * @return string            Hex color with leading #.
	 */
	function cb_best_contrast_text( $bg, $preferred = '', $min_ratio = 4.5 ) {
		if ( $preferred && cb_contrast_ratio( $bg, $preferred ) >= $min_ratio ) {
			return $preferred;
		}
		// Use pure black (not #111111) for the dark fallback so mid-tone
		// brand backgrounds — e.g. Støttefarge 1 #173838 — still pass AA.
		// On #173838: white = 4.22, #111111 = 4.42 (both fail 4.5);
		// #000000 = 4.98 (passes).
		$white_ratio = cb_contrast_ratio( $bg, '#ffffff' );
		$black_ratio = cb_contrast_ratio( $bg, '#000000' );
		return $white_ratio >= $black_ratio ? '#ffffff' : '#000000';
	}
}

if ( ! function_exists( 'cb_is_dark_color' ) ) {
	/**
	 * Is this background dark enough that light-section text defaults become
	 * unreadable on it?
	 *
	 * The library signals "this section is dark" with the `.styrk-dark` class,
	 * which flips a set of CSS custom properties (eyebrow default colour,
	 * placeholder ink, align-picker chrome). Until now only hero ever set that
	 * class, while every other block paints its dark background as an inline
	 * `background-color` style — so on those sections the dark defaults never
	 * applied and the eyebrow/heading rendered dark-on-dark.
	 *
	 * 0.18 relative luminance is the cut: it sits above the darkest brand
	 * surfaces (primary #0a2020 = 0.011) and below the light ones
	 * (#f1ece1 = 0.83), with mid-tones treated as light — those already carry
	 * enough contrast against the dark ink defaults.
	 *
	 * @param string $hex Background colour.
	 * @return bool True when the colour needs the dark-section treatment.
	 */
	function cb_is_dark_color( $hex ) {
		$lum = cb_relative_luminance( $hex );
		return $lum !== null && $lum < 0.18;
	}
}

if ( ! function_exists( 'cb_icon_on_tint_color' ) ) {
	/**
	 * Icon colour for an accent-tinted icon tile on a card.
	 *
	 * The feature-card icon is painted in the accent on a 10% accent tint of
	 * the card. A light accent (a hi-vis yellow, Styrk amber) is barely
	 * visible on white, and invisible on a card whose background is the accent
	 * itself. An icon is a graphical object, so it needs 3:1 against both the
	 * tile and the card around it (WCAG 1.4.11).
	 *
	 * Keeps the accent when it passes. Otherwise tries $preferred (the card's
	 * text colour, or the theme primary), then the better of black and white.
	 *
	 * @param string $accent    Accent colour (hex).
	 * @param string $surface   Card background (hex).
	 * @param string $preferred Fallback to try first (hex). May be empty.
	 * @return string Hex colour, or '' when the pair cannot be judged.
	 */
	function cb_icon_on_tint_color( $accent, $surface, $preferred = '' ) {
		$a = cb_hex_to_rgb( $accent );
		$s = cb_hex_to_rgb( $surface );
		if ( ! $a || ! $s ) {
			return '';
		}
		// color-mix( accent 10%, transparent ) composited over the card.
		$tile = '#';
		foreach ( [ 0, 1, 2 ] as $i ) {
			$tile .= sprintf( '%02x', (int) round( 0.1 * $a[ $i ] + 0.9 * $s[ $i ] ) );
		}
		$passes = static function ( $color ) use ( $surface, $tile ) {
			return min( cb_contrast_ratio( $color, $surface ), cb_contrast_ratio( $color, $tile ) ) >= 3;
		};
		if ( $passes( $accent ) ) {
			return $accent;
		}
		if ( $preferred && $passes( $preferred ) ) {
			return $preferred;
		}
		return cb_best_contrast_text( $tile, '', 3 );
	}
}

if ( ! function_exists( 'cb_pill_text_color' ) ) {
	/**
	 * Text colour for a label pill painted in a solid fill (#491).
	 *
	 * The post-card category pill is small text on the accent. White used to
	 * be hard-coded, which fails on a light accent (Styrk orange #F37523 is
	 * 2.9:1, a hi-vis yellow about 1.2:1). Small text needs 4.5:1.
	 *
	 * Tries, in order: the author's pick, white (the old look), the dark ink
	 * (theme primary). Falls back to the stronger of black and white.
	 *
	 * @param string $fill      Pill background (hex).
	 * @param string $preferred Author-picked text colour (hex). May be empty.
	 * @param string $ink       Dark ink to try after white (hex). May be empty.
	 * @return string Hex colour; $preferred (or '') when the fill cannot be judged.
	 */
	function cb_pill_text_color( $fill, $preferred = '', $ink = '' ) {
		if ( ! cb_hex_to_rgb( $fill ) ) {
			return cb_hex_to_rgb( $preferred ) ? (string) $preferred : '';
		}
		foreach ( [ $preferred, '#ffffff', $ink ] as $candidate ) {
			if ( $candidate && cb_hex_to_rgb( $candidate ) && cb_contrast_ratio( $fill, $candidate ) >= 4.5 ) {
				return $candidate;
			}
		}
		return cb_best_contrast_text( $fill, '', 4.5 );
	}
}

if ( ! function_exists( 'cb_editor_accent_tokens_css' ) ) {
	/**
	 * Editor chrome on the site accent, made readable whatever the accent is.
	 *
	 * The in-canvas labels, outlines and "Add link" tiles used the accent as is,
	 * with white text on it. A light accent (Tydal's lime #D8F21A) gave white on
	 * lime (~1.2:1) and lime on the cream canvas (~1.1:1). Two tokens instead:
	 *
	 *   --cb-ed-accent-ink   text ON an accent fill: black or white, whichever reads.
	 *   --cb-ed-accent-line  accent used as text or a line ON the canvas: the accent
	 *                        when it reaches 3:1 there, else the primary colour.
	 *   --cb-ed-accent-track the align picker's track on the accent bar: darker
	 *                        under white icons, lighter under black ones.
	 *
	 * @return string CSS for the editor stylesheet.
	 */
	function cb_editor_accent_tokens_css(): string {
		$palette = (array) wp_get_global_settings( [ 'color', 'palette', 'theme' ] );
		$colors  = [];
		foreach ( $palette as $entry ) {
			$colors[ (string) ( $entry['slug'] ?? '' ) ] = sanitize_hex_color( (string) ( $entry['color'] ?? '' ) );
		}
		$accent  = $colors['accent'] ?? null;
		$accent  = $accent ? $accent : '#f0a83c';
		$primary = $colors['primary'] ?? null;
		$primary = $primary ? $primary : '#0a2020';

		// The canvas colour: a hex, or a palette reference such as
		// var:preset|color|page-bg / var(--wp--preset--color--page-bg).
		$bg_raw = (string) wp_get_global_styles( [ 'color', 'background' ] );
		$bg     = sanitize_hex_color( $bg_raw );
		if ( ! $bg && preg_match( '/color(?:\||--)([a-z0-9-]+)/', $bg_raw, $m ) ) {
			$bg = $colors[ $m[1] ] ?? null;
		}
		$bg = $bg ? $bg : '#ffffff';

		$line = cb_contrast_ratio( $bg, $accent ) >= 3 ? $accent : $primary;
		$ink  = cb_best_contrast_text( $accent );

		$track = '#ffffff' === $ink ? 'rgba(0,0,0,.28)' : 'rgba(255,255,255,.45)';

		return ':root{--cb-ed-accent-ink:' . $ink . ';--cb-ed-accent-line:' . $line . ';--cb-ed-accent-track:' . $track . ';}';
	}
}
