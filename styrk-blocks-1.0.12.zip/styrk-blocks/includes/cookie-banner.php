<?php
/**
 * Cookie banner (GDPR Cookie Compliance): never hide what has keyboard focus.
 *
 * The plugin's info bar is fixed to the bottom of the screen. At the end of a
 * page it sat on top of the footer's last row, so Tab moved focus to links
 * nobody could see (WCAG 2.2 2.4.11 Focus Not Obscured; Hegra Bygg footer
 * credits). This publishes the bar's live height as --cb-cookie-bar-h while it
 * is shown; style.css reserves that much room under the page and in
 * scroll-padding, so the footer can always scroll clear of it.
 *
 * GDPR Cookie Compliance is part of every Styrk site's standard stack, so the
 * fix lives here rather than in one client theme. Does nothing without it.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'cb_cookie_banner_offset_script' ) ) {
	function cb_cookie_banner_offset_script(): void {
		if ( is_admin() ) {
			return;
		}
		echo "<script>(function(){var b=document.getElementById('moove_gdpr_cookie_info_bar');if(!b||!window.ResizeObserver)return;var r=document.documentElement;function set(){var h=document.body.classList.contains('gdpr-infobar-visible')?b.offsetHeight:0;r.style.setProperty('--cb-cookie-bar-h',h+'px');}new ResizeObserver(set).observe(b);new MutationObserver(set).observe(document.body,{attributes:true,attributeFilter:['class']});set();})();</script>\n";
	}
	add_action( 'wp_footer', 'cb_cookie_banner_offset_script', 100 );
}
