<?php
/**
 * Product catalogue with an enquiry basket (opt-in).
 *
 * A generic catalogue for dealers and manufacturers that quote instead of
 * sell: products grouped in categories, a basket that collects what the
 * visitor is interested in, and an enquiry form that carries the list.
 *
 * Off on every site until switched on, so no client gets a post type, rewrite
 * rules or blocks it did not ask for. Switch on with any of:
 *   - Settings → Writing → «Product catalogue»
 *   - add_theme_support( 'styrk-product-catalog' ) in the (child) theme
 *   - add_filter( 'styrk_blocks_product_catalog', '__return_true' )
 *
 * Data model
 *   Post type `styrk_product`            archive and category pages under /{slug}/
 *   Taxonomy  `styrk_product_cat`        hierarchical, the category pages
 *   Taxonomy  `styrk_product_type`       non-hierarchical, the filter chips
 *   Post meta `_cb_product_*`            brand, axles, volume, weight, facts,
 *                                        specs, equipment, gallery, datasheet
 *
 * The basket itself lives in the visitor's browser (src/product-basket/), so
 * pages stay cacheable. The form is a Forminator form chosen on the enquiry
 * block; Forminator keeps the mail settings and the stored submissions.
 *
 * Rendering helpers are in product-catalog-render.php.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_PRODUCT_CATALOG_LOADED' ) ) {
	return;
}
define( 'CB_PRODUCT_CATALOG_LOADED', true );

define( 'CB_PRODUCT_OPTION', 'cb_product_catalog' );
define( 'CB_PRODUCT_POST_TYPE', 'styrk_product' );
define( 'CB_PRODUCT_CAT', 'styrk_product_cat' );
define( 'CB_PRODUCT_TYPE', 'styrk_product_type' );
define( 'CB_PRODUCT_BRAND', 'styrk_product_brand' );

require_once __DIR__ . '/product-catalog-render.php';

if ( ! function_exists( 'cb_product_catalog_settings' ) ) {
	/**
	 * Saved settings merged with the defaults.
	 *
	 * @return array{enabled: string, slug: string, enquiry_page: int}
	 */
	function cb_product_catalog_settings(): array {
		$saved = get_option( CB_PRODUCT_OPTION, [] );
		$saved = is_array( $saved ) ? $saved : [];
		return [
			'enabled'      => ! empty( $saved['enabled'] ) ? '1' : '0',
			'slug'         => isset( $saved['slug'] ) ? (string) $saved['slug'] : 'produkter',
			'enquiry_page' => isset( $saved['enquiry_page'] ) ? (int) $saved['enquiry_page'] : 0,
		];
	}
}

if ( ! function_exists( 'cb_product_catalog_enabled' ) ) {
	/**
	 * Whether the catalogue is switched on for this site.
	 */
	function cb_product_catalog_enabled(): bool {
		$on = '1' === cb_product_catalog_settings()['enabled'] || current_theme_supports( 'styrk-product-catalog' );
		return (bool) apply_filters( 'styrk_blocks_product_catalog', $on );
	}
}

if ( ! function_exists( 'cb_product_slug' ) ) {
	/**
	 * URL base of the catalogue: /{slug}/, /{slug}/{category}/, /{slug}/{category}/{product}/.
	 */
	function cb_product_slug(): string {
		$slug = sanitize_title( cb_product_catalog_settings()['slug'] );
		$slug = (string) apply_filters( 'styrk_blocks_product_rewrite_slug', '' !== $slug ? $slug : 'produkter' );
		return '' !== $slug ? $slug : 'produkter';
	}
}

if ( ! function_exists( 'cb_product_enquiry_url' ) ) {
	/**
	 * Address of the enquiry page: the page picked in the settings, else /foresporsel/.
	 */
	function cb_product_enquiry_url(): string {
		$page_id = cb_product_catalog_settings()['enquiry_page'];
		$url     = $page_id > 0 && 'publish' === get_post_status( $page_id ) ? (string) get_permalink( $page_id ) : home_url( '/foresporsel/' );
		return (string) apply_filters( 'styrk_blocks_product_enquiry_url', $url );
	}
}

if ( ! function_exists( 'cb_product_labels' ) ) {
	/**
	 * Visitor-facing words the catalogue prints itself (bokmål defaults).
	 * Blocks let editors change the main ones; a theme can translate or
	 * reword the rest with the `styrk_blocks_product_labels` filter.
	 *
	 * @return array<string, string>
	 */
	function cb_product_labels(): array {
		return (array) apply_filters(
			'styrk_blocks_product_labels',
			[
				'archive'       => 'Produkter',
				'uncategorised' => 'andre',
				'home'          => 'Hjem',
				'breadcrumb'    => 'Brødsmuler',
				'call'          => 'Ring',
				'quantity'      => 'Antall',
				'decrease'      => 'Færre',
				'increase'      => 'Flere',
				'noImage'       => 'Bilde mangler',
				'gallery'       => 'Bilder av produktet',
				'showImage'     => 'Vis bilde %d',
			]
		);
	}
}

/* ── Post type, taxonomies, meta ──────────────────────────────────────────── */
if ( ! function_exists( 'cb_product_register' ) ) {
	/**
	 * Registers the post type, the two taxonomies and the product meta.
	 */
	function cb_product_register(): void {
		if ( ! cb_product_catalog_enabled() ) {
			return;
		}
		$slug = cb_product_slug();

		register_taxonomy( CB_PRODUCT_CAT, CB_PRODUCT_POST_TYPE, [
			'labels'            => [
				'name'          => __( 'Product categories', 'styrk-blocks' ),
				'singular_name' => __( 'Product category', 'styrk-blocks' ),
				'add_new_item'  => __( 'Add new product category', 'styrk-blocks' ),
				'edit_item'     => __( 'Edit product category', 'styrk-blocks' ),
			],
			'public'            => true,
			'hierarchical'      => true,
			'show_in_rest'      => true,
			'show_admin_column' => true,
			// One segment: /{slug}/{category}/. A child category is also one
			// segment, so a product's address never depends on a category tree.
			'rewrite'           => [ 'slug' => $slug, 'with_front' => false, 'hierarchical' => false ],
		] );

		register_taxonomy( CB_PRODUCT_TYPE, CB_PRODUCT_POST_TYPE, [
			'labels'             => [
				'name'          => __( 'Product types', 'styrk-blocks' ),
				'singular_name' => __( 'Product type', 'styrk-blocks' ),
				'add_new_item'  => __( 'Add new product type', 'styrk-blocks' ),
				'edit_item'     => __( 'Edit product type', 'styrk-blocks' ),
			],
			// The filter chips on a category page; no pages of their own.
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'hierarchical'       => false,
			'show_in_rest'       => true,
			'show_admin_column'  => true,
			'rewrite'            => false,
		] );

		register_taxonomy( CB_PRODUCT_BRAND, CB_PRODUCT_POST_TYPE, [
			'labels'             => [
				'name'          => __( 'Brands', 'styrk-blocks' ),
				'singular_name' => __( 'Brand', 'styrk-blocks' ),
				'add_new_item'  => __( 'Add new brand', 'styrk-blocks' ),
				'edit_item'     => __( 'Edit brand', 'styrk-blocks' ),
			],
			// The brand filter on the product grid; no pages of their own. The
			// filter is linkable instead: /{slug}/?merke={brand}.
			'public'             => false,
			'publicly_queryable' => false,
			'show_ui'            => true,
			'hierarchical'       => false,
			'show_in_rest'       => true,
			'show_admin_column'  => true,
			'rewrite'            => false,
		] );

		register_post_type( CB_PRODUCT_POST_TYPE, [
			'labels'       => [
				'name'          => __( 'Products', 'styrk-blocks' ),
				'singular_name' => __( 'Product', 'styrk-blocks' ),
				'add_new_item'  => __( 'Add new product', 'styrk-blocks' ),
				'edit_item'     => __( 'Edit product', 'styrk-blocks' ),
				'archives'      => __( 'Products', 'styrk-blocks' ),
			],
			'public'       => true,
			'show_in_rest' => true,
			'has_archive'  => $slug,
			'menu_icon'    => 'dashicons-products',
			// custom-fields exposes the registered meta to the editor over REST.
			'supports'     => [ 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes', 'custom-fields' ],
			// /{slug}/{category}/{product}/ — the category part is filled in by
			// cb_product_permalink().
			'rewrite'      => [ 'slug' => $slug . '/%' . CB_PRODUCT_CAT . '%', 'with_front' => false ],
		] );

		register_term_meta( CB_PRODUCT_CAT, 'thumbnail_id', [
			'single'            => true,
			'type'              => 'integer',
			'default'           => 0,
			'show_in_rest'      => true,
			'sanitize_callback' => 'absint',
			'auth_callback'     => static fn (): bool => current_user_can( 'manage_categories' ),
		] );

		cb_product_register_meta();
	}
}
add_action( 'init', 'cb_product_register', 5 );

if ( ! function_exists( 'cb_product_sanitize_rows' ) ) {
	/**
	 * Label/value rows (specs, key facts): rows without a label are dropped.
	 *
	 * @param mixed $value Raw rows.
	 * @return array<int, array{label: string, value: string}>
	 */
	function cb_product_sanitize_rows( $value ): array {
		$rows = [];
		foreach ( is_array( $value ) ? $value : [] as $row ) {
			$label = is_array( $row ) ? sanitize_text_field( (string) ( $row['label'] ?? '' ) ) : '';
			if ( '' !== $label ) {
				$rows[] = [
					'label' => $label,
					'value' => sanitize_text_field( (string) ( $row['value'] ?? '' ) ),
				];
			}
		}
		return $rows;
	}
}

if ( ! function_exists( 'cb_product_sanitize_lines' ) ) {
	/**
	 * A list of short texts (equipment): empty entries are dropped.
	 *
	 * @param mixed $value Raw list.
	 * @return string[]
	 */
	function cb_product_sanitize_lines( $value ): array {
		$out = [];
		foreach ( is_array( $value ) ? $value : [] as $line ) {
			$line = sanitize_text_field( (string) $line );
			if ( '' !== $line ) {
				$out[] = $line;
			}
		}
		return $out;
	}
}

if ( ! function_exists( 'cb_product_sanitize_ids' ) ) {
	/**
	 * A list of attachment IDs.
	 *
	 * @param mixed $value Raw list.
	 * @return int[]
	 */
	function cb_product_sanitize_ids( $value ): array {
		return array_values( array_filter( array_map( 'absint', is_array( $value ) ? $value : [] ) ) );
	}
}

if ( ! function_exists( 'cb_product_register_meta' ) ) {
	/**
	 * Product fields. All edited in the block editor's sidebar panel
	 * (src/plugins/product-meta.tsx) and read by the product blocks.
	 */
	function cb_product_register_meta(): void {
		foreach ( [ 'brand', 'axles', 'volume', 'weight' ] as $key ) {
			register_post_meta( CB_PRODUCT_POST_TYPE, '_cb_product_' . $key, [
				'single'            => true,
				'type'              => 'string',
				'default'           => '',
				'show_in_rest'      => true,
				'sanitize_callback' => 'sanitize_text_field',
				'auth_callback'     => 'cb_meta_auth',
			] );
		}

		$rows_schema = [
			'schema' => [
				'type'  => 'array',
				'items' => [
					'type'       => 'object',
					'properties' => [
						'label' => [ 'type' => 'string' ],
						'value' => [ 'type' => 'string' ],
					],
				],
			],
		];
		foreach ( [ 'facts', 'specs' ] as $key ) {
			register_post_meta( CB_PRODUCT_POST_TYPE, '_cb_product_' . $key, [
				'single'            => true,
				'type'              => 'array',
				'default'           => [],
				'show_in_rest'      => $rows_schema,
				'sanitize_callback' => 'cb_product_sanitize_rows',
				'auth_callback'     => 'cb_meta_auth',
			] );
		}

		register_post_meta( CB_PRODUCT_POST_TYPE, '_cb_product_equipment', [
			'single'            => true,
			'type'              => 'array',
			'default'           => [],
			'show_in_rest'      => [ 'schema' => [ 'type' => 'array', 'items' => [ 'type' => 'string' ] ] ],
			'sanitize_callback' => 'cb_product_sanitize_lines',
			'auth_callback'     => 'cb_meta_auth',
		] );

		register_post_meta( CB_PRODUCT_POST_TYPE, '_cb_product_gallery_ids', [
			'single'            => true,
			'type'              => 'array',
			'default'           => [],
			'show_in_rest'      => [ 'schema' => [ 'type' => 'array', 'items' => [ 'type' => 'integer' ] ] ],
			'sanitize_callback' => 'cb_product_sanitize_ids',
			'auth_callback'     => 'cb_meta_auth',
		] );

		register_post_meta( CB_PRODUCT_POST_TYPE, '_cb_product_pdf_id', [
			'single'            => true,
			'type'              => 'integer',
			'default'           => 0,
			'show_in_rest'      => true,
			'sanitize_callback' => 'absint',
			'auth_callback'     => 'cb_meta_auth',
		] );
	}
}

/**
 * Fills the category part of a product's address with its first category.
 *
 * @param string  $link Permalink with the %styrk_product_cat% placeholder.
 * @param WP_Post $post The product.
 */
if ( ! function_exists( 'cb_product_permalink' ) ) {
	function cb_product_permalink( $link, $post ) {
		if ( ! $post instanceof WP_Post || CB_PRODUCT_POST_TYPE !== $post->post_type || false === strpos( (string) $link, '%' . CB_PRODUCT_CAT . '%' ) ) {
			return $link;
		}
		$terms = get_the_terms( $post->ID, CB_PRODUCT_CAT );
		$term  = ( $terms && ! is_wp_error( $terms ) ) ? reset( $terms ) : null;
		$slug  = $term ? $term->slug : sanitize_title( cb_product_labels()['uncategorised'] );
		return str_replace( '%' . CB_PRODUCT_CAT . '%', $slug, (string) $link );
	}
}
add_filter( 'post_type_link', 'cb_product_permalink', 10, 2 );

/**
 * The archive heading is the visitor-facing word, not the admin label.
 *
 * @param string $title Archive title.
 */
if ( ! function_exists( 'cb_product_archive_title' ) ) {
	function cb_product_archive_title( $title ) {
		return is_post_type_archive( CB_PRODUCT_POST_TYPE ) ? cb_product_labels()['archive'] : $title;
	}
}
add_filter( 'post_type_archive_title', 'cb_product_archive_title' );

/**
 * Re-saves the rewrite rules once whenever the catalogue is switched on or the
 * address changes, so nobody has to visit Settings → Permalinks.
 */
if ( ! function_exists( 'cb_product_maybe_flush' ) ) {
	function cb_product_maybe_flush(): void {
		$state = cb_product_catalog_enabled() ? cb_product_slug() : 'off';
		if ( get_option( 'cb_product_rewrite_state' ) !== $state ) {
			flush_rewrite_rules( false );
			update_option( 'cb_product_rewrite_state', $state, false );
		}
	}
}
add_action( 'init', 'cb_product_maybe_flush', 99 );

/* ── Heading, intro and crumbs for the category pages (page-header block) ──── */
/**
 * A category page is titled with the category's own name and introduced by its
 * description (WordPress would print «Category: Name» and no intro).
 *
 * @param mixed $text [ 'heading' => string, 'subtitle' => string ].
 * @return mixed
 */
if ( ! function_exists( 'cb_product_page_header_archive' ) ) {
	function cb_product_page_header_archive( $text ) {
		if ( ! is_array( $text ) || ! cb_product_catalog_enabled() ) {
			return $text;
		}
		if ( is_post_type_archive( CB_PRODUCT_POST_TYPE ) ) {
			// «Arkiver: Produkter» → «Produkter».
			$text['heading'] = cb_product_labels()['archive'];
			return $text;
		}
		if ( ! is_tax( CB_PRODUCT_CAT ) ) {
			return $text;
		}
		$text['heading'] = wp_strip_all_tags( single_term_title( '', false ) );
		if ( '' === (string) ( $text['subtitle'] ?? '' ) ) {
			$text['subtitle'] = wp_strip_all_tags( term_description() );
		}
		return $text;
	}
}
add_filter( 'styrk_blocks_page_header_archive', 'cb_product_page_header_archive' );

/* Crumbs: 
/**
 * Hjem / Produkter / [parent categories] on the catalogue's own archives.
 *
 * @param array<int, array{label: string, href: string}> $crumbs The trail up to the archive itself.
 * @return array<int, array{label: string, href: string}>
 */
if ( ! function_exists( 'cb_product_page_header_crumbs' ) ) {
	function cb_product_page_header_crumbs( $crumbs ) {
		if ( ! is_array( $crumbs ) || ! cb_product_catalog_enabled() || ! is_tax( CB_PRODUCT_CAT ) ) {
			return $crumbs;
		}
		$term = get_queried_object();
		if ( ! $term instanceof WP_Term ) {
			return $crumbs;
		}
		$labels   = cb_product_labels();
		$trail    = [ [ 'label' => $labels['archive'], 'href' => (string) get_post_type_archive_link( CB_PRODUCT_POST_TYPE ) ] ];
		$parents  = array_reverse( get_ancestors( $term->term_id, CB_PRODUCT_CAT, 'taxonomy' ) );
		foreach ( $parents as $parent_id ) {
			$parent = get_term( $parent_id, CB_PRODUCT_CAT );
			if ( $parent instanceof WP_Term ) {
				$trail[] = [ 'label' => $parent->name, 'href' => (string) get_term_link( $parent ) ];
			}
		}
		// Insert before the last crumb (the category itself).
		$current = array_pop( $crumbs );
		return array_merge( $crumbs, $trail, $current ? [ $current ] : [] );
	}
}
add_filter( 'styrk_blocks_page_header_crumbs', 'cb_product_page_header_crumbs' );

/* ── Assets ───────────────────────────────────────────────────────────────── */
if ( ! function_exists( 'cb_product_register_assets' ) ) {
	/**
	 * Registers the catalogue's own stylesheet and the basket script. They are
	 * loaded only on pages that print a product block (or the header's basket
	 * link), so the plugin's shared stylesheet stays as light as before.
	 */
	function cb_product_register_assets(): void {
		$dir  = dirname( __DIR__ );
		$css  = $dir . '/build/product-catalog.css';
		if ( file_exists( $css ) ) {
			wp_register_style( 'styrk-blocks-product-catalog', plugins_url( 'build/product-catalog.css', $dir . '/styrk-blocks.php' ), [], (string) filemtime( $css ) );
		}
		$js    = $dir . '/build/product-basket.js';
		$asset = $dir . '/build/product-basket.asset.php';
		if ( file_exists( $js ) && file_exists( $asset ) ) {
			$meta = require $asset;
			wp_register_script(
				'styrk-blocks-product-basket',
				plugins_url( 'build/product-basket.js', $dir . '/styrk-blocks.php' ),
				$meta['dependencies'] ?? [],
				(string) filemtime( $js ),
				[ 'strategy' => 'defer', 'in_footer' => true ]
			);
		}
	}
}
add_action( 'init', 'cb_product_register_assets', 5 );

/**
 * What the editor needs to know: the Forminator forms to choose from.
 */
if ( ! function_exists( 'cb_product_editor_data' ) ) {
	function cb_product_editor_data(): void {
		if ( ! cb_product_catalog_enabled() ) {
			return;
		}
		$forms = [];
		if ( post_type_exists( 'forminator_forms' ) ) {
			foreach ( get_posts( [ 'post_type' => 'forminator_forms', 'post_status' => 'publish', 'posts_per_page' => 100, 'orderby' => 'title', 'order' => 'ASC' ] ) as $form ) {
				$forms[] = [ 'id' => (string) $form->ID, 'title' => (string) $form->post_title ];
			}
		}
		wp_register_script( 'styrk-blocks-product-editor-data', false, [], '1.0.0', false );
		wp_enqueue_script( 'styrk-blocks-product-editor-data' );
		wp_add_inline_script(
			'styrk-blocks-product-editor-data',
			'window.styrkBlocks = window.styrkBlocks || {};'
				. 'window.styrkBlocks.productCatalog = ' . wp_json_encode( [ 'forms' => $forms, 'forminator' => post_type_exists( 'forminator_forms' ) ] ) . ';',
			'before'
		);
	}
}
add_action( 'enqueue_block_editor_assets', 'cb_product_editor_data' );

/* ── Block templates: category, archive and single product ────────────────── */
if ( ! function_exists( 'cb_product_register_templates' ) ) {
	/**
	 * Default layouts, registered like the single-project template. The active
	 * block theme can override each in Site Editor → Templates.
	 */
	function cb_product_register_templates(): void {
		if ( ! function_exists( 'register_block_template' ) || ! cb_product_catalog_enabled() ) {
			return;
		}
		$header = '<!-- wp:template-part {"slug":"header","area":"header","tagName":"header"} /-->';
		$footer = '<!-- wp:template-part {"slug":"footer","area":"footer","tagName":"footer"} /-->';
		$open   = '<!-- wp:group {"tagName":"main","align":"full","layout":{"type":"default"}} --><main class="wp-block-group alignfull">';
		$close  = '</main><!-- /wp:group -->';

		$listing = $header . $open
			. '<!-- wp:styrk-blocks/page-header {"align":"full"} /-->'
			. '<!-- wp:styrk-blocks/product-grid {"align":"full"} /-->'
			. $close . $footer;

		register_block_template( 'styrk-blocks//taxonomy-' . CB_PRODUCT_CAT, [
			'title'       => __( 'Product category', 'styrk-blocks' ),
			'description' => __( 'A product category: page header, filter and product cards, with the enquiry bar.', 'styrk-blocks' ),
			'content'     => $listing,
		] );
		register_block_template( 'styrk-blocks//archive-' . CB_PRODUCT_POST_TYPE, [
			'title'       => __( 'All products', 'styrk-blocks' ),
			'description' => __( 'The product archive: page header, filter and every product.', 'styrk-blocks' ),
			'content'     => $listing,
		] );
		register_block_template( 'styrk-blocks//single-' . CB_PRODUCT_POST_TYPE, [
			'title'       => __( 'Single product', 'styrk-blocks' ),
			'description' => __( 'One product: gallery, key facts, add to enquiry, specifications and related products.', 'styrk-blocks' ),
			'content'     => $header . $open . '<!-- wp:styrk-blocks/product-single {"align":"full"} /-->' . $close . $footer,
			'post_types'  => [ CB_PRODUCT_POST_TYPE ],
		] );
	}
}
add_action( 'init', 'cb_product_register_templates', 20 );

/* ── Settings → Writing ───────────────────────────────────────────────────── */
if ( ! function_exists( 'cb_product_sanitize_settings' ) ) {
	/**
	 * @param mixed $input Posted settings.
	 * @return array{enabled: string, slug: string, enquiry_page: int}
	 */
	function cb_product_sanitize_settings( $input ): array {
		$input = is_array( $input ) ? $input : [];
		$slug  = sanitize_title( (string) ( $input['slug'] ?? '' ) );
		return [
			'enabled'      => ! empty( $input['enabled'] ) ? '1' : '0',
			'slug'         => '' !== $slug ? $slug : 'produkter',
			'enquiry_page' => absint( $input['enquiry_page'] ?? 0 ),
		];
	}
}

add_action( 'admin_init', function (): void {
	register_setting( 'writing', CB_PRODUCT_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_product_sanitize_settings',
		'default'           => [],
	] );
	add_settings_field( 'cb_product_catalog_field', __( 'Product catalogue', 'styrk-blocks' ), 'cb_product_render_settings_field', 'writing', 'default' );
} );

if ( ! function_exists( 'cb_product_render_settings_field' ) ) {
	function cb_product_render_settings_field(): void {
		$s = cb_product_catalog_settings();
		?>
		<label for="cb_product_enabled">
			<input type="checkbox" id="cb_product_enabled" name="<?php echo esc_attr( CB_PRODUCT_OPTION ); ?>[enabled]" value="1" <?php checked( '1', $s['enabled'] ); ?> />
			<?php esc_html_e( 'Turn on products, categories and the enquiry basket', 'styrk-blocks' ); ?>
		</label>
		<p>
			<label for="cb_product_slug"><?php esc_html_e( 'Web address of the catalogue', 'styrk-blocks' ); ?></label><br />
			<input type="text" class="regular-text" id="cb_product_slug" name="<?php echo esc_attr( CB_PRODUCT_OPTION ); ?>[slug]" value="<?php echo esc_attr( $s['slug'] ); ?>" placeholder="produkter" />
		</p>
		<p>
			<label for="cb_product_enquiry_page"><?php esc_html_e( 'Enquiry page', 'styrk-blocks' ); ?></label><br />
			<?php
			echo wp_kses(
				(string) wp_dropdown_pages( [
					'name'              => CB_PRODUCT_OPTION . '[enquiry_page]',
					'id'                => 'cb_product_enquiry_page',
					'selected'          => $s['enquiry_page'],
					'show_option_none'  => __( '— Choose —', 'styrk-blocks' ),
					'option_none_value' => '0',
					'echo'              => 0,
				] ),
				[
					'select' => [ 'name' => true, 'id' => true ],
					'option' => [ 'value' => true, 'selected' => true, 'class' => true ],
				]
			);
			?>
		</p>
		<p class="description">
			<?php esc_html_e( 'Adds the Products post type with categories and types. The enquiry page holds the «Product enquiry» block; the basket bar and the header link point to it.', 'styrk-blocks' ); ?>
		</p>
		<?php
	}
}

/* ── Brand: a taxonomy, with the old text field as fallback ───────────────── */
if ( ! function_exists( 'cb_product_brand_of' ) ) {
	/**
	 * A product's brand: its Brand term, or the older «Brand» text field when
	 * no term has been set yet (sites that filled it in before brands became a
	 * taxonomy keep working without a migration run).
	 *
	 * @param string[] $term_names Names of the product's Brand terms.
	 * @param string   $meta       Value of the older text field.
	 * @return array{name: string, slug: string} Both '' when there is no brand.
	 */
	function cb_product_brand_of( array $term_names, string $meta ): array {
		$name = '' !== ( $term_names[0] ?? '' ) ? (string) $term_names[0] : trim( $meta );
		return [ 'name' => $name, 'slug' => '' !== $name ? sanitize_title( $name ) : '' ];
	}
}

if ( ! function_exists( 'cb_product_brand_to_migrate' ) ) {
	/**
	 * The brand name to turn into a term, or '' when there is nothing to do:
	 * the product already has a term, or has no old text value.
	 *
	 * @param string[] $term_names Names of the product's Brand terms.
	 * @param string   $meta       Value of the older text field.
	 */
	function cb_product_brand_to_migrate( array $term_names, string $meta ): string {
		return array() === array_filter( $term_names ) ? trim( $meta ) : '';
	}
}

if ( ! function_exists( 'cb_product_migrate_brand' ) ) {
	/**
	 * Gives one product a Brand term from its older text field.
	 *
	 * @param int $post_id Product.
	 */
	function cb_product_migrate_brand( int $post_id ): void {
		$terms = wp_get_object_terms( $post_id, CB_PRODUCT_BRAND, [ 'fields' => 'names' ] );
		$name  = cb_product_brand_to_migrate( is_array( $terms ) ? $terms : [], (string) get_post_meta( $post_id, '_cb_product_brand', true ) );
		if ( '' !== $name ) {
			wp_set_object_terms( $post_id, $name, CB_PRODUCT_BRAND );
		}
	}
}

/**
 * Once per site: every product with an old brand value gets its term. Saving a
 * product does the same for that product, so nothing is lost either way.
 */
if ( ! function_exists( 'cb_product_migrate_brands' ) ) {
	function cb_product_migrate_brands(): void {
		if ( ! cb_product_catalog_enabled() || get_option( 'cb_product_brands_migrated' ) ) {
			return;
		}
		$ids = get_posts( [
			'post_type'      => CB_PRODUCT_POST_TYPE,
			'post_status'    => 'any',
			'posts_per_page' => -1,
			'fields'         => 'ids',
			'meta_key'       => '_cb_product_brand', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- once per site.
			'meta_compare'   => '!=',
			'meta_value'     => '', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value -- once per site.
		] );
		foreach ( $ids as $id ) {
			cb_product_migrate_brand( (int) $id );
		}
		update_option( 'cb_product_brands_migrated', '1', false );
	}
}
add_action( 'init', 'cb_product_migrate_brands', 98 );
add_action( 'save_post_' . CB_PRODUCT_POST_TYPE, static function ( $post_id ): void {
	cb_product_migrate_brand( (int) $post_id );
} );

/* ── Category image: term meta `thumbnail_id` (what the collection block reads) */
if ( ! function_exists( 'cb_product_cat_image_field' ) ) {
	/**
	 * The media-picker field on the category's add and edit screens.
	 *
	 * @param WP_Term|string $term The category being edited ('' on the add screen).
	 */
	function cb_product_cat_image_field( $term = '' ): void {
		$id      = $term instanceof WP_Term ? (int) get_term_meta( $term->term_id, 'thumbnail_id', true ) : 0;
		$preview = $id > 0 ? (string) wp_get_attachment_image_url( $id, 'medium' ) : '';
		$edit    = $term instanceof WP_Term;
		wp_nonce_field( 'cb_product_cat_image', 'cb_product_cat_image_nonce' );
		echo $edit ? '<tr class="form-field"><th scope="row"><label for="cb_product_cat_image_pick">' : '<div class="form-field"><label for="cb_product_cat_image_pick">';
		esc_html_e( 'Image', 'styrk-blocks' );
		echo $edit ? '</label></th><td>' : '</label>';
		?>
		<div data-cb-cat-image>
			<img src="<?php echo esc_url( $preview ); ?>" alt="" style="max-width:160px;height:auto;display:<?php echo '' !== $preview ? 'block' : 'none'; ?>;margin-bottom:8px;" />
			<input type="hidden" name="cb_product_cat_image" value="<?php echo esc_attr( (string) $id ); ?>" />
			<button type="button" class="button" id="cb_product_cat_image_pick" data-pick><?php esc_html_e( 'Choose image', 'styrk-blocks' ); ?></button>
			<button type="button" class="button" data-clear<?php echo '' === $preview ? ' hidden' : ''; ?>><?php esc_html_e( 'Remove image', 'styrk-blocks' ); ?></button>
			<p class="description"><?php esc_html_e( 'Shown where the category is listed, for example by the Collection block.', 'styrk-blocks' ); ?></p>
		</div>
		<?php
		echo $edit ? '</td></tr>' : '</div>';
	}
}
add_action( CB_PRODUCT_CAT . '_add_form_fields', 'cb_product_cat_image_field' );
add_action( CB_PRODUCT_CAT . '_edit_form_fields', 'cb_product_cat_image_field' );

if ( ! function_exists( 'cb_product_cat_image_save' ) ) {
	/**
	 * Saves the category image.
	 *
	 * @param int $term_id Category.
	 */
	function cb_product_cat_image_save( $term_id ): void {
		if ( ! current_user_can( 'manage_categories' ) ) {
			return;
		}
		// Quick edit and programmatic saves do not carry the field: leave the image alone.
		if ( ! isset( $_POST['cb_product_cat_image_nonce'] ) ) {
			return;
		}
		check_admin_referer( 'cb_product_cat_image', 'cb_product_cat_image_nonce' );
		$id = isset( $_POST['cb_product_cat_image'] ) ? absint( wp_unslash( $_POST['cb_product_cat_image'] ) ) : 0;
		if ( $id > 0 ) {
			update_term_meta( (int) $term_id, 'thumbnail_id', $id );
		} else {
			delete_term_meta( (int) $term_id, 'thumbnail_id' );
		}
	}
}
add_action( 'created_' . CB_PRODUCT_CAT, 'cb_product_cat_image_save' );
add_action( 'edited_' . CB_PRODUCT_CAT, 'cb_product_cat_image_save' );

if ( ! function_exists( 'cb_product_cat_image_assets' ) ) {
	/**
	 * The media modal and the field's few lines of script, on the category screens only.
	 */
	function cb_product_cat_image_assets(): void {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || CB_PRODUCT_CAT !== $screen->taxonomy ) {
			return;
		}
		wp_enqueue_media();
		wp_register_script( 'cb-product-cat-image', false, [ 'jquery' ], '1.0.0', true );
		wp_enqueue_script( 'cb-product-cat-image' );
		wp_add_inline_script(
			'cb-product-cat-image',
			"jQuery(function(\$){var box=\$('[data-cb-cat-image]');if(!box.length){return;}var frame;"
			. "box.on('click','[data-pick]',function(e){e.preventDefault();if(!frame){frame=wp.media({multiple:false,library:{type:'image'}});"
			. "frame.on('select',function(){var a=frame.state().get('selection').first().toJSON();var u=(a.sizes&&a.sizes.medium)?a.sizes.medium.url:a.url;"
			. "box.find('input').val(a.id);box.find('img').attr('src',u).show();box.find('[data-clear]').prop('hidden',false);});}frame.open();});"
			. "box.on('click','[data-clear]',function(e){e.preventDefault();box.find('input').val('');box.find('img').hide();\$(this).prop('hidden',true);});});"
		);
	}
}
add_action( 'admin_enqueue_scripts', 'cb_product_cat_image_assets' );
