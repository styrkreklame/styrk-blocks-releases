<?php
/**
 * Employee grid: layout, card action and CTA decisions.
 *
 * Kept out of template.php so they can be tested without a WP_Query.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_employee_grid_layout_class' ) ) {
	/**
	 * Classes for the block's inner wrapper.
	 *
	 * `layout: split` puts the header (eyebrow, heading, intro, CTA) in a
	 * column beside the portraits. How the portraits are arranged depends on
	 * how many there are, so the count goes on the wrapper: 1–4 each have their
	 * own arrangement, five or more share one.
	 *
	 * @param array $attributes Block attributes.
	 * @param int   $count      Employees being rendered.
	 * @return string '' for the default grid, so its markup stays as it was.
	 */
	function cb_employee_grid_layout_class( array $attributes, int $count ): string {
		if ( 'split' !== ( $attributes['layout'] ?? 'grid' ) ) {
			return '';
		}
		$bucket = $count >= 5 ? 'many' : (string) max( 1, $count );
		return 'cb-employee-grid__inner--split cb-employee-grid__inner--count-' . $bucket;
	}
}

if ( ! function_exists( 'cb_employee_grid_card_layout_class' ) ) {
	/**
	 * Class for the card grid: `cardLayout: wide` lays a full card out as a
	 * profile (photo left, text and contacts right), two to a row, so a small
	 * team fills the width instead of leaving half the section empty.
	 *
	 * @param array $attributes Block attributes.
	 * @return string '' for the default stacked cards and for compact cards.
	 */
	function cb_employee_grid_card_layout_class( array $attributes ): string {
		if ( ! empty( $attributes['compact'] ) ) {
			return '';
		}
		return 'wide' === ( $attributes['cardLayout'] ?? 'stacked' ) ? 'cb-employee-grid--wide' : '';
	}
}

if ( ! function_exists( 'cb_employee_card_action' ) ) {
	/**
	 * What a card does when clicked: open the popup, or link to the team page.
	 *
	 * Full cards open the popup unless the author chose `cardAction: none` —
	 * a full card already shows name, role and contact lines, so on some sites
	 * the popup only repeats them. Compact cards link to the team page unless
	 * the author chose `compactAction: modal`.
	 *
	 * `cardAction: page` links a full card to the employee's own profile page;
	 * the template falls back to the popup for an employee without one.
	 *
	 * @param array $attributes Block attributes.
	 * @return string 'modal' | 'link' | 'none' | 'page'
	 */
	function cb_employee_card_action( array $attributes ): string {
		if ( empty( $attributes['compact'] ) ) {
			$action = $attributes['cardAction'] ?? 'modal';
			return in_array( $action, [ 'none', 'page' ], true ) ? $action : 'modal';
		}
		return 'modal' === ( $attributes['compactAction'] ?? 'link' ) ? 'modal' : 'link';
	}
}

if ( ! function_exists( 'cb_employee_profile_url' ) ) {
	/**
	 * The employee's profile page URL, for `cardAction: page`.
	 *
	 * Accepts an absolute URL or a site-relative path ("/om/name/").
	 *
	 * @param mixed $raw Stored `_cb_profile_url` meta.
	 * @return string Raw (esc_url_raw) URL, or '' when unset or not allowed.
	 */
	function cb_employee_profile_url( $raw ): string {
		return is_string( $raw ) ? esc_url_raw( trim( $raw ) ) : '';
	}
}

if ( ! function_exists( 'cb_employee_grid_cta_html' ) ) {
	/**
	 * The link under the intro ("Møt teamet").
	 *
	 * In the split layout its ::after is stretched over the whole text column,
	 * so the column is one click target with a single link in the tab order.
	 *
	 * @param string $text Link text (plain).
	 * @param string $url   Link target.
	 * @param string $align left | center | right, same as the intro above it.
	 * @return string HTML, or '' unless both are set and the URL is allowed.
	 */
	function cb_employee_grid_cta_html( string $text, string $url, string $align = 'left' ): string {
		$text = trim( wp_strip_all_tags( $text ) );
		$href = esc_url( trim( $url ) );
		if ( '' === $text || '' === $href ) {
			return '';
		}
		$align = in_array( $align, [ 'left', 'center', 'right' ], true ) ? $align : 'left';
		return '<a class="cb-employee-grid__cta" data-align="' . $align . '" href="' . $href . '">'
			. '<span class="cb-employee-grid__cta-text">' . esc_html( $text ) . '</span>'
			. '<svg class="cb-employee-grid__cta-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true" focusable="false"><path d="M221.66 133.66l-72 72a8 8 0 0 1-11.32-11.32L196.69 136H40a8 8 0 0 1 0-16h156.69l-58.35-58.34a8 8 0 0 1 11.32-11.32l72 72a8 8 0 0 1 0 11.32Z"/></svg>'
			. '</a>';
	}
}

if ( ! function_exists( 'cb_employee_grid_caps_width' ) ) {
	/**
	 * Whether a short grid is capped at 900px so one or two cards don't each
	 * stretch across half the content width.
	 *
	 * Only a grid of one or two columns stretches like that. With three or
	 * more columns each card is already a third of the row or less, and the
	 * cap would shrink it: two grids of the same column count on one page
	 * (Administrasjon with 2 people above Trondheim with 3) then show cards
	 * of visibly different sizes.
	 *
	 * @param array $attributes Block attributes.
	 * @param int   $count      Number of employees shown.
	 */
	function cb_employee_grid_caps_width( array $attributes, int $count ): bool {
		if ( $count > 2 || (int) ( $attributes['columns'] ?? 3 ) > 2 ) {
			return false;
		}
		// The split layout sizes the portraits itself, and wide cards fill the row.
		return 'split' !== ( $attributes['layout'] ?? 'grid' ) && '' === cb_employee_grid_card_layout_class( $attributes );
	}
}
