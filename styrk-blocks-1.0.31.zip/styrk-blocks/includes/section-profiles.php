<?php
/**
 * Site sections: one part of a site (all URLs under a path such as /se/) with
 * its own header and footer details and its own language.
 *
 * Built for a site that keeps a second company or market under a sub-path
 * (oddkolstad.no/se/ for the Swedish sister company): same theme, same blocks,
 * but a different logo, menu, button, phone link, footer text and contact
 * details, and the front end in that section's language.
 *
 * How it works: cb_get_header_settings() and cb_get_footer_settings() pass
 * their result through cb_section_apply(). When the current request path
 * starts with a section's prefix, that section's non-empty values replace the
 * site-wide ones. Every reader of those settings (react header, server-rendered
 * header, footer shortcodes) therefore follows the section without changes of
 * its own. Empty section fields keep the site-wide value.
 *
 * @package styrk-blocks
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const CB_SECTIONS_OPTION = 'cb_section_profiles';

/**
 * The header and footer keys a section may override, with their field type.
 *
 * @return array<string, array<string, string>>
 */
function cb_section_fields(): array {
	return [
		'header' => [
			'logo_id'       => 'image',
			'nav_menu'      => 'menu',
			'cta_label'     => 'text',
			'cta_url'       => 'url',
			'phone_label'   => 'text',
			'phone_url'     => 'url',
			'enquiry_link'  => 'toggle',
			'enquiry_label' => 'text',
			'enquiry_url'   => 'url',
		],
		'footer' => [
			'logo_white_id'   => 'image',
			'description'     => 'textarea',
			'contact_heading' => 'text',
			'address'         => 'textarea',
			'email'           => 'email',
			'phone_1'         => 'text',
			'pages_heading'   => 'text',
			'pages_menu'      => 'menu',
			'pages_2_heading' => 'text',
			'pages_2_menu'    => 'menu',
			'social_heading'  => 'text',
			'copyright'       => 'text',
			'credits'         => 'text',
			'legal'           => 'toggle',
		],
	];
}

/**
 * Saved sections, each with a normalised prefix ("/se/").
 *
 * @return array<int, array<string, mixed>>
 */
function cb_section_profiles(): array {
	$saved = get_option( CB_SECTIONS_OPTION, [] );
	$out   = [];
	foreach ( is_array( $saved ) ? $saved : [] as $profile ) {
		if ( ! is_array( $profile ) ) {
			continue;
		}
		$prefix = cb_section_normalise_prefix( (string) ( $profile['prefix'] ?? '' ) );
		if ( '' === $prefix ) {
			continue;
		}
		$profile['prefix'] = $prefix;
		$out[]             = $profile;
	}
	return $out;
}

/**
 * "se", "/se" and "/se/" all become "/se/". The root ("/") is not a section.
 *
 * @param string $prefix Raw prefix.
 */
function cb_section_normalise_prefix( string $prefix ): string {
	$prefix = trim( strtolower( $prefix ), " \t\n\r\0\x0B/" );
	$prefix = preg_replace( '#[^a-z0-9/_-]#', '', $prefix ) ?? '';
	return '' === $prefix ? '' : '/' . $prefix . '/';
}

/**
 * The section the current front-end request belongs to, or null.
 *
 * The longest matching prefix wins. Admin screens never belong to a section,
 * so the settings pages always show the site-wide values.
 *
 * @param string|null $path Request path to test; defaults to the current one.
 * @return array<string, mixed>|null
 */
function cb_current_section( ?string $path = null ): ?array {
	if ( null === $path ) {
		if ( is_admin() && ! wp_doing_ajax() ) {
			return null;
		}
		$path = (string) wp_parse_url( (string) ( $_SERVER['REQUEST_URI'] ?? '' ), PHP_URL_PATH ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput -- only compared, never output.
	}
	$path = '/' . ltrim( strtolower( rawurldecode( $path ) ), '/' );
	if ( '/' !== substr( $path, -1 ) ) {
		$path .= '/';
	}
	$best = null;
	foreach ( cb_section_profiles() as $profile ) {
		if ( str_starts_with( $path, $profile['prefix'] ) && ( null === $best || strlen( $profile['prefix'] ) > strlen( $best['prefix'] ) ) ) {
			$best = $profile;
		}
	}
	return $best;
}

/**
 * The page at the root of the current section (e.g. /se/), or 0.
 *
 * Breadcrumbs and eyebrows treat it as the section's home page.
 */
function cb_section_root_post_id(): int {
	$section = cb_current_section();
	if ( null === $section ) {
		return 0;
	}
	return (int) url_to_postid( home_url( $section['prefix'] ) );
}

/**
 * Lay the current section's non-empty values over the site-wide settings.
 *
 * @param string               $part     'header' or 'footer'.
 * @param array<string, mixed> $settings Site-wide settings.
 * @return array<string, mixed>
 */
function cb_section_apply( string $part, array $settings ): array {
	$section = cb_current_section();
	if ( ! $section ) {
		return $settings;
	}
	$values = is_array( $section[ $part ] ?? null ) ? $section[ $part ] : [];
	foreach ( cb_section_fields()[ $part ] ?? [] as $key => $type ) {
		$value = $values[ $key ] ?? '';
		if ( 'toggle' === $type ) {
			if ( '' !== (string) $value ) {
				$settings[ $key ] = '1' === (string) $value ? '1' : '0';
			}
			continue;
		}
		if ( '' === (string) $value || ( in_array( $type, [ 'image', 'menu' ], true ) && 0 === (int) $value ) ) {
			continue;
		}
		$settings[ $key ] = $value;
	}
	// "Hide" for the legal link drops it: a Norwegian law page has no place
	// in a Swedish footer.
	if ( 'footer' === $part && '0' === (string) ( $values['legal'] ?? '' ) ) {
		$settings['legal_1_label'] = '';
		$settings['legal_1_page']  = 0;
	}
	// The section's phone link replaces the top bar's links as a whole: a
	// Norwegian number must not show next to a Swedish one.
	if ( 'header' === $part && '' !== (string) ( $values['phone_label'] ?? '' ) ) {
		$settings['extra_links'] = [
			[
				'label'   => (string) $values['phone_label'],
				'url'     => (string) ( $values['phone_url'] ?? '' ),
				'new_tab' => '0',
			],
		];
	}
	return $settings;
}

/**
 * Every menu a section uses (header and footer), so the site-wide header never
 * picks one of them as its default menu.
 *
 * @return int[]
 */
function cb_section_menu_ids(): array {
	$ids = [];
	foreach ( cb_section_profiles() as $profile ) {
		foreach ( [ [ 'header', 'nav_menu' ], [ 'footer', 'pages_menu' ], [ 'footer', 'pages_2_menu' ] ] as [ $part, $key ] ) {
			$id = (int) ( $profile[ $part ][ $key ] ?? 0 );
			if ( $id ) {
				$ids[] = $id;
			}
		}
	}
	return array_values( array_unique( $ids ) );
}

/**
 * The header menu chosen for the current section, or 0 for the site's own.
 */
function cb_section_header_nav(): int {
	$section = cb_current_section();
	return $section ? (int) ( $section['header']['nav_menu'] ?? 0 ) : 0;
}

/**
 * The language of the current section, or '' to keep the site's.
 */
function cb_section_locale(): string {
	if ( is_admin() ) {
		return '';
	}
	$section = cb_current_section();
	return $section ? (string) preg_replace( '/[^A-Za-z_]/', '', (string) ( $section['locale'] ?? '' ) ) : '';
}

// Front end in the section's language: WordPress core, the theme and every
// plugin load that locale's strings for pages under the prefix, and <html lang>
// follows. WordPress may already have worked out (and cached) the site locale
// before this plugin loads, so the cached value is dropped once here.
add_filter(
	'locale',
	static function ( $locale ) {
		$lang = cb_section_locale();
		return '' !== $lang ? $lang : $locale;
	}
);
add_filter(
	'pre_determine_locale',
	static function ( $locale ) {
		$lang = cb_section_locale();
		return '' !== $lang ? $lang : $locale;
	}
);
if ( '' !== cb_section_locale() && isset( $GLOBALS['locale'] ) ) {
	unset( $GLOBALS['locale'] );
}

// The section's company name in page titles, the footer and anywhere else
// the site name is read on its pages.
add_filter(
	'option_blogname',
	static function ( $name ) {
		if ( is_admin() ) {
			return $name;
		}
		$section = cb_current_section();
		$own     = $section ? (string) ( $section['site_name'] ?? '' ) : '';
		return '' !== $own ? $own : $name;
	}
);

/* ── Settings screen: Settings → Site sections ─────────────────────────── */

add_action(
	'admin_menu',
	static function (): void {
		add_options_page(
			__( 'Site sections', 'styrk-blocks' ),
			__( 'Site sections', 'styrk-blocks' ),
			'manage_options',
			'cb-site-sections',
			'cb_section_render_page'
		);
	}
);

add_action(
	'admin_init',
	static function (): void {
		register_setting(
			'cb_sections_group',
			CB_SECTIONS_OPTION,
			[
				'type'              => 'array',
				'sanitize_callback' => 'cb_section_sanitize',
				'default'           => [],
			]
		);
	}
);

/**
 * Sanitise one section field by its type.
 *
 * @param mixed  $raw  Posted value.
 * @param string $type Field type from cb_section_fields().
 * @return int|string
 */
function cb_section_sanitize_value( $raw, string $type ) {
	switch ( $type ) {
		case 'image':
		case 'menu':
			return absint( $raw );
		case 'url':
			return esc_url_raw( trim( (string) $raw ) );
		case 'email':
			return sanitize_email( (string) $raw );
		case 'textarea':
			return sanitize_textarea_field( (string) $raw );
		case 'toggle':
			return in_array( (string) $raw, [ '0', '1' ], true ) ? (string) $raw : '';
		default:
			return sanitize_text_field( (string) $raw );
	}
}

/**
 * Sanitise the posted sections. Rows without a prefix are dropped.
 *
 * @param mixed $input Posted value.
 * @return array<int, array<string, mixed>>
 */
function cb_section_sanitize( $input ): array {
	$out = [];
	foreach ( is_array( $input ) ? $input : [] as $row ) {
		if ( ! is_array( $row ) ) {
			continue;
		}
		$prefix = cb_section_normalise_prefix( (string) ( $row['prefix'] ?? '' ) );
		if ( '' === $prefix ) {
			continue;
		}
		$clean = [
			'prefix' => $prefix,
			'name'   => sanitize_text_field( (string) ( $row['name'] ?? '' ) ),
			'locale' => preg_replace( '/[^A-Za-z_]/', '', (string) ( $row['locale'] ?? '' ) ) ?? '',
			'site_name' => sanitize_text_field( (string) ( $row['site_name'] ?? '' ) ),
		];
		foreach ( cb_section_fields() as $part => $fields ) {
			foreach ( $fields as $key => $type ) {
				$clean[ $part ][ $key ] = cb_section_sanitize_value( $row[ $part ][ $key ] ?? '', $type );
			}
		}
		$out[] = $clean;
	}
	return $out;
}

/**
 * Field labels for the settings screen.
 *
 * @return array<string, string>
 */
function cb_section_labels(): array {
	return [
		'logo_id'         => __( 'Logo', 'styrk-blocks' ),
		'nav_menu'        => __( 'Menu', 'styrk-blocks' ),
		'cta_label'       => __( 'Button text', 'styrk-blocks' ),
		'cta_url'         => __( 'Button link', 'styrk-blocks' ),
		'phone_label'     => __( 'Phone (shown)', 'styrk-blocks' ),
		'phone_url'       => __( 'Phone link (tel:)', 'styrk-blocks' ),
		'enquiry_link'    => __( 'Enquiry basket', 'styrk-blocks' ),
		'enquiry_label'   => __( 'Enquiry text', 'styrk-blocks' ),
		'enquiry_url'     => __( 'Enquiry page', 'styrk-blocks' ),
		'logo_white_id'   => __( 'Logo (light, for dark footer)', 'styrk-blocks' ),
		'description'     => __( 'Description', 'styrk-blocks' ),
		'contact_heading' => __( 'Contact heading', 'styrk-blocks' ),
		'address'         => __( 'Address', 'styrk-blocks' ),
		'email'           => __( 'E-mail', 'styrk-blocks' ),
		'phone_1'         => __( 'Phone', 'styrk-blocks' ),
		'pages_heading'   => __( 'Links heading', 'styrk-blocks' ),
		'pages_menu'      => __( 'Links menu', 'styrk-blocks' ),
		'pages_2_heading' => __( 'Second links heading', 'styrk-blocks' ),
		'pages_2_menu'    => __( 'Second links menu', 'styrk-blocks' ),
		'social_heading'  => __( 'Social heading', 'styrk-blocks' ),
		'copyright'       => __( 'Copyright line', 'styrk-blocks' ),
		'credits'         => __( 'Credits line', 'styrk-blocks' ),
		'legal'           => __( 'Legal link', 'styrk-blocks' ),
	];
}

/**
 * One field of one section row.
 *
 * @param int    $i     Row index.
 * @param string $part  'header' or 'footer'.
 * @param string $key   Field key.
 * @param string $type  Field type.
 * @param mixed  $value Saved value.
 */
function cb_section_render_field( int $i, string $part, string $key, string $type, $value ): void {
	$name = sprintf( '%s[%d][%s][%s]', CB_SECTIONS_OPTION, $i, $part, $key );
	$id   = sprintf( 'cb-section-%d-%s-%s', $i, $part, $key );
	switch ( $type ) {
		case 'image':
			$url = $value ? (string) wp_get_attachment_image_url( (int) $value, 'medium' ) : '';
			printf(
				'<div class="cb-section-image"><input type="hidden" id="%1$s" name="%2$s" value="%3$s"><img src="%4$s" alt="" style="max-height:48px;%5$s"> <button type="button" class="button cb-section-pick" data-target="%1$s">%6$s</button> <button type="button" class="button-link cb-section-clear" data-target="%1$s">%7$s</button></div>',
				esc_attr( $id ),
				esc_attr( $name ),
				esc_attr( (string) (int) $value ),
				esc_url( $url ),
				$url ? '' : 'display:none',
				esc_html__( 'Choose image', 'styrk-blocks' ),
				esc_html__( 'Remove', 'styrk-blocks' )
			);
			break;
		case 'menu':
			echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"><option value="0">' . esc_html__( '— Same as the rest of the site —', 'styrk-blocks' ) . '</option>';
			foreach ( get_posts( [ 'post_type' => 'wp_navigation', 'post_status' => 'publish', 'numberposts' => -1, 'orderby' => 'title', 'order' => 'ASC' ] ) as $nav ) {
				printf( '<option value="%d"%s>%s</option>', (int) $nav->ID, selected( (int) $value, (int) $nav->ID, false ), esc_html( $nav->post_title ?: '#' . $nav->ID ) );
			}
			echo '</select>';
			break;
		case 'toggle':
			echo '<select id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '">';
			foreach ( [ '' => __( '— Same as the rest of the site —', 'styrk-blocks' ), '1' => __( 'Show', 'styrk-blocks' ), '0' => __( 'Hide', 'styrk-blocks' ) ] as $v => $label ) {
				printf( '<option value="%s"%s>%s</option>', esc_attr( (string) $v ), selected( (string) $value, (string) $v, false ), esc_html( $label ) );
			}
			echo '</select>';
			break;
		case 'textarea':
			printf( '<textarea id="%s" name="%s" rows="3" class="large-text">%s</textarea>', esc_attr( $id ), esc_attr( $name ), esc_textarea( (string) $value ) );
			break;
		default:
			printf( '<input type="%s" id="%s" name="%s" value="%s" class="regular-text">', 'email' === $type ? 'email' : ( 'url' === $type ? 'text' : 'text' ), esc_attr( $id ), esc_attr( $name ), esc_attr( (string) $value ) );
	}
}

/**
 * Settings → Site sections.
 */
function cb_section_render_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	wp_enqueue_media();
	$rows   = cb_section_profiles();
	$rows[] = [ 'prefix' => '', 'name' => '', 'locale' => '' ]; // One empty row to add a section.
	$labels = cb_section_labels();
	$langs  = array_merge( [ '' ], get_available_languages() );
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Site sections', 'styrk-blocks' ); ?></h1>
		<p><?php esc_html_e( 'A section is every page under one path, for example /se/. It can have its own logo, menu, button, phone and footer details, and its own language. Empty fields use the values from Header and Footer settings.', 'styrk-blocks' ); ?></p>
		<form method="post" action="options.php">
			<?php settings_fields( 'cb_sections_group' ); ?>
			<?php foreach ( $rows as $i => $row ) : ?>
				<h2><?php echo $row['prefix'] ? esc_html( ( $row['name'] ?: $row['prefix'] ) ) : esc_html__( 'New section', 'styrk-blocks' ); ?></h2>
				<table class="form-table" role="presentation">
					<tr>
						<th scope="row"><label for="cb-section-<?php echo (int) $i; ?>-prefix"><?php esc_html_e( 'Path', 'styrk-blocks' ); ?></label></th>
						<td><input type="text" id="cb-section-<?php echo (int) $i; ?>-prefix" name="<?php echo esc_attr( CB_SECTIONS_OPTION . "[$i][prefix]" ); ?>" value="<?php echo esc_attr( (string) $row['prefix'] ); ?>" class="regular-text" placeholder="/se/">
						<p class="description"><?php esc_html_e( 'Clear the path to delete the section.', 'styrk-blocks' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><label for="cb-section-<?php echo (int) $i; ?>-name"><?php esc_html_e( 'Name', 'styrk-blocks' ); ?></label></th>
						<td><input type="text" id="cb-section-<?php echo (int) $i; ?>-name" name="<?php echo esc_attr( CB_SECTIONS_OPTION . "[$i][name]" ); ?>" value="<?php echo esc_attr( (string) ( $row['name'] ?? '' ) ); ?>" class="regular-text"></td>
					</tr>
					<tr>
						<th scope="row"><label for="cb-section-<?php echo (int) $i; ?>-site-name"><?php esc_html_e( 'Company name', 'styrk-blocks' ); ?></label></th>
						<td><input type="text" id="cb-section-<?php echo (int) $i; ?>-site-name" name="<?php echo esc_attr( CB_SECTIONS_OPTION . "[$i][site_name]" ); ?>" value="<?php echo esc_attr( (string) ( $row['site_name'] ?? '' ) ); ?>" class="regular-text">
						<p class="description"><?php esc_html_e( 'Replaces the site title on these pages (browser tab, search results, footer).', 'styrk-blocks' ); ?></p></td>
					</tr>
					<tr>
						<th scope="row"><label for="cb-section-<?php echo (int) $i; ?>-locale"><?php esc_html_e( 'Language', 'styrk-blocks' ); ?></label></th>
						<td><select id="cb-section-<?php echo (int) $i; ?>-locale" name="<?php echo esc_attr( CB_SECTIONS_OPTION . "[$i][locale]" ); ?>">
							<?php foreach ( $langs as $lang ) : ?>
								<option value="<?php echo esc_attr( $lang ); ?>"<?php selected( (string) ( $row['locale'] ?? '' ), $lang ); ?>><?php echo esc_html( '' === $lang ? __( '— Same as the rest of the site —', 'styrk-blocks' ) : $lang ); ?></option>
							<?php endforeach; ?>
						</select></td>
					</tr>
					<?php foreach ( cb_section_fields() as $part => $fields ) : ?>
						<tr><th colspan="2"><h3 style="margin:1em 0 0"><?php echo 'header' === $part ? esc_html__( 'Header', 'styrk-blocks' ) : esc_html__( 'Footer', 'styrk-blocks' ); ?></h3></th></tr>
						<?php foreach ( $fields as $key => $type ) : ?>
							<tr>
								<th scope="row"><label for="<?php echo esc_attr( sprintf( 'cb-section-%d-%s-%s', $i, $part, $key ) ); ?>"><?php echo esc_html( $labels[ $key ] ?? $key ); ?></label></th>
								<td><?php cb_section_render_field( (int) $i, $part, $key, $type, $row[ $part ][ $key ] ?? '' ); ?></td>
							</tr>
						<?php endforeach; ?>
					<?php endforeach; ?>
				</table>
				<hr>
			<?php endforeach; ?>
			<?php submit_button(); ?>
		</form>
	</div>
	<script>
	( function () {
		document.addEventListener( 'click', function ( e ) {
			var pick = e.target.closest( '.cb-section-pick' );
			var clear = e.target.closest( '.cb-section-clear' );
			if ( clear ) {
				var w = clear.closest( '.cb-section-image' );
				w.querySelector( 'input' ).value = '0';
				w.querySelector( 'img' ).style.display = 'none';
				return;
			}
			if ( ! pick || ! window.wp || ! wp.media ) { return; }
			var wrap = pick.closest( '.cb-section-image' );
			var frame = wp.media( { library: { type: 'image' }, multiple: false } );
			frame.on( 'select', function () {
				var a = frame.state().get( 'selection' ).first().toJSON();
				wrap.querySelector( 'input' ).value = a.id;
				var img = wrap.querySelector( 'img' );
				img.src = ( a.sizes && a.sizes.medium ? a.sizes.medium.url : a.url );
				img.style.display = '';
			} );
			frame.open();
		} );
	} )();
	</script>
	<?php
}
