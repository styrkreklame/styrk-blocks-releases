<?php
/**
 * Product catalogue: data and markup helpers shared by the product blocks.
 *
 * Everything here returns an HTML string (escaped piece by piece) so the block
 * templates stay short and the markup lives in one place. Loaded by
 * product-catalog.php.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'cb_product_attr' ) ) {
	/**
	 * A text attribute, or the default when the editor left it empty.
	 *
	 * @param array<string, mixed> $attributes Block attributes.
	 * @param string               $key        Attribute name.
	 * @param string               $default    Bokmål default.
	 */
	function cb_product_attr( array $attributes, string $key, string $default ): string {
		$value = trim( (string) ( $attributes[ $key ] ?? '' ) );
		return '' !== $value ? $value : $default;
	}
}

if ( ! function_exists( 'cb_product_icon' ) ) {
	/**
	 * Small inline icons, decorative (the button or link carries the name).
	 *
	 * @param string $name phone | check | plus | minus | arrow.
	 */
	function cb_product_icon( string $name ): string {
		$paths = [
			'phone' => '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
			'check' => '<path d="M20 6 9 17l-5-5"/>',
			'plus'  => '<path d="M12 5v14M5 12h14"/>',
			'minus' => '<path d="M5 12h14"/>',
			'arrow' => '<path d="M5 12h14M13 6l6 6-6 6"/>',
		];
		if ( ! isset( $paths[ $name ] ) ) {
			return '';
		}
		return '<svg class="cbp-icon cbp-icon--' . esc_attr( $name ) . '" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $paths[ $name ] . '</svg>';
	}
}

if ( ! function_exists( 'cb_product_phone' ) ) {
	/**
	 * The phone number for the «ring» links: the block's own, else the one in
	 * Settings → Footer.
	 *
	 * @param string $override Number typed on the block ('' = use the footer's).
	 * @return array{display: string, href: string} Both '' when there is none.
	 */
	function cb_product_phone( string $override = '' ): array {
		$raw = trim( $override );
		if ( '' === $raw && function_exists( 'cb_get_footer_settings' ) ) {
			$raw = trim( (string) ( cb_get_footer_settings()['phone_1'] ?? '' ) );
		}
		if ( '' === $raw || ! function_exists( 'cb_employee_tel_href' ) ) {
			return [ 'display' => '', 'href' => '' ];
		}
		return [
			'display' => cb_employee_phone_display( $raw ),
			'href'    => cb_employee_tel_href( $raw ),
		];
	}
}

if ( ! function_exists( 'cb_product_axles_label' ) ) {
	/**
	 * «3» → «3 aksler»; free text («2–3») is shown as typed.
	 */
	function cb_product_axles_label( string $axles ): string {
		$axles = trim( $axles );
		if ( '' === $axles || ! ctype_digit( $axles ) ) {
			return $axles;
		}
		return '1' === $axles ? '1 aksel' : $axles . ' aksler';
	}
}

if ( ! function_exists( 'cb_product_terms' ) ) {
	/**
	 * Terms of a taxonomy on a product, as [ slug, name, id ] rows.
	 *
	 * @return array<int, array{slug: string, name: string, id: int}>
	 */
	function cb_product_terms( int $post_id, string $taxonomy ): array {
		$terms = get_the_terms( $post_id, $taxonomy );
		$out   = [];
		if ( $terms && ! is_wp_error( $terms ) ) {
			foreach ( $terms as $term ) {
				$out[] = [ 'slug' => $term->slug, 'name' => $term->name, 'id' => (int) $term->term_id ];
			}
		}
		return $out;
	}
}

if ( ! function_exists( 'cb_product_data' ) ) {
	/**
	 * Everything the blocks show about one product.
	 *
	 * @return array<string, mixed>
	 */
	function cb_product_data( int $post_id ): array {
		$meta = static fn ( string $key ): string => trim( (string) get_post_meta( $post_id, '_cb_product_' . $key, true ) );
		$list = static function ( string $key ) use ( $post_id ): array {
			$value = get_post_meta( $post_id, '_cb_product_' . $key, true );
			return is_array( $value ) ? $value : [];
		};
		$pdf_id = (int) get_post_meta( $post_id, '_cb_product_pdf_id', true );
		$brands = cb_product_terms( $post_id, CB_PRODUCT_BRAND );
		$brand  = cb_product_brand_of( array_column( $brands, 'name' ), $meta( 'brand' ) );
		$data   = [
			'id'        => $post_id,
			'title'     => get_the_title( $post_id ),
			'url'       => (string) get_permalink( $post_id ),
			'thumb'     => (int) get_post_thumbnail_id( $post_id ),
			'excerpt'   => has_excerpt( $post_id ) ? (string) get_the_excerpt( $post_id ) : '',
			'brand'     => $brand['name'],
			'brands'    => [],
			'axles'     => $meta( 'axles' ),
			'volume'    => $meta( 'volume' ),
			'weight'    => $meta( 'weight' ),
			'facts'     => cb_product_sanitize_rows( $list( 'facts' ) ),
			'specs'     => cb_product_sanitize_rows( $list( 'specs' ) ),
			'equipment' => cb_product_sanitize_lines( $list( 'equipment' ) ),
			'gallery'   => cb_product_sanitize_ids( $list( 'gallery_ids' ) ),
			'pdf'       => $pdf_id > 0 ? (string) wp_get_attachment_url( $pdf_id ) : '',
			'types'     => cb_product_terms( $post_id, CB_PRODUCT_TYPE ),
			'cats'      => cb_product_terms( $post_id, CB_PRODUCT_CAT ),
		];
		// The brand as a filter value: its term, or the older text field's value.
		$data['brands'] = $brands ? $brands : ( '' !== $brand['name'] ? [ [ 'slug' => $brand['slug'], 'name' => $brand['name'], 'id' => 0 ] ] : [] );
		return $data;
	}
}

if ( ! function_exists( 'cb_product_filter_from_query' ) ) {
	/**
	 * The filter a link asks for: /produkter/?type=slepvogn&merke=carnehl.
	 * Only slugs that exist among the shown products count, so a typo or a
	 * crafted value changes nothing.
	 *
	 * @param array<string, mixed>  $query  Usually $_GET.
	 * @param array<string, string> $types  Type slug => name of the shown products.
	 * @param array<string, string> $brands Brand slug => name of the shown products.
	 * @return array{type: string, brand: string}
	 */
	function cb_product_filter_from_query( array $query, array $types, array $brands ): array {
		$pick = static function ( $raw, array $valid ): string {
			$slug = is_string( $raw ) ? sanitize_title( $raw ) : '';
			return isset( $valid[ $slug ] ) ? $slug : '';
		};
		return [
			'type'  => $pick( $query['type'] ?? '', $types ),
			'brand' => $pick( $query['merke'] ?? '', $brands ),
		];
	}
}

if ( ! function_exists( 'cb_product_matches' ) ) {
	/**
	 * Whether a product passes the filter.
	 *
	 * @param array<string, mixed>  $data  From cb_product_data().
	 * @param array{type: string, brand: string} $state From cb_product_filter_from_query().
	 */
	function cb_product_matches( array $data, array $state ): bool {
		$has = static fn ( array $rows, string $slug ): bool => '' === $slug || in_array( $slug, array_column( $rows, 'slug' ), true );
		return $has( $data['types'], $state['type'] ) && $has( $data['brands'], $state['brand'] );
	}
}

if ( ! function_exists( 'cb_product_meta_parts' ) ) {
	/**
	 * The card's meta line: type · axles · brand (what exists).
	 *
	 * @param array<string, mixed> $data From cb_product_data().
	 * @return string[]
	 */
	function cb_product_meta_parts( array $data ): array {
		$type  = $data['types'][0]['name'] ?? '';
		$parts = [ (string) $type, cb_product_axles_label( (string) $data['axles'] ), (string) $data['brand'] ];
		return array_values( array_filter( $parts, static fn ( string $p ): bool => '' !== $p ) );
	}
}

if ( ! function_exists( 'cb_product_image_html' ) ) {
	/**
	 * A product image, or a neutral tile when there is none. The site's card
	 * placeholder (Settings → General) is used for the tile when it is set.
	 *
	 * @param int                  $attachment_id Attachment (0 = none).
	 * @param string               $size          Image size.
	 * @param array<string, mixed> $attr          Extra <img> attributes.
	 */
	function cb_product_image_html( int $attachment_id, string $size, array $attr = [] ): string {
		if ( $attachment_id > 0 ) {
			$html = wp_get_attachment_image( $attachment_id, $size, false, array_merge( [ 'class' => 'cbp-img', 'loading' => 'lazy', 'decoding' => 'async', 'alt' => '' ], $attr ) );
			if ( '' !== $html ) {
				return $html;
			}
		}
		$placeholder_id = function_exists( 'cb_get_card_placeholder_id' ) ? cb_get_card_placeholder_id() : 0;
		if ( $placeholder_id > 0 ) {
			$html = wp_get_attachment_image( $placeholder_id, 'medium', false, [ 'class' => 'cbp-img cbp-img--placeholder', 'loading' => 'lazy', 'decoding' => 'async', 'alt' => '' ] );
			if ( '' !== $html ) {
				return '<span class="cbp-tile cbp-tile--logo">' . $html . '</span>';
			}
		}
		return '<span class="cbp-tile" aria-hidden="true"></span>';
	}
}

if ( ! function_exists( 'cb_product_add_button' ) ) {
	/**
	 * «Legg i forespørsel»: a real button that toggles the product in the
	 * basket. product-basket.js sets aria-pressed, the label and the check.
	 * The product's own details travel as data-* so the basket and the enquiry
	 * page can show it without asking the server.
	 *
	 * @param array<string, mixed> $data  From cb_product_data().
	 * @param array<string, mixed> $opts  add / added labels, class.
	 */
	function cb_product_add_button( array $data, array $opts = [] ): string {
		$add   = (string) ( $opts['add'] ?? 'Legg i forespørsel' );
		$added = (string) ( $opts['added'] ?? 'Lagt til' );
		$img   = $data['thumb'] > 0 ? (string) wp_get_attachment_image_url( (int) $data['thumb'], 'thumbnail' ) : '';
		$class = trim( 'cbp-btn cbp-btn--add ' . (string) ( $opts['class'] ?? '' ) );
		return '<button type="button" class="' . esc_attr( $class ) . '" data-cbp-add aria-pressed="false"'
			. ' aria-label="' . esc_attr( $add . ': ' . $data['title'] ) . '"'
			. ' data-id="' . (int) $data['id'] . '"'
			. ' data-title="' . esc_attr( $data['title'] ) . '"'
			. ' data-meta="' . esc_attr( implode( ' · ', cb_product_meta_parts( $data ) ) ) . '"'
			. ' data-url="' . esc_url( $data['url'] ) . '"'
			. ' data-img="' . esc_url( $img ) . '"'
			. ' data-label="' . esc_attr( $add ) . '" data-label-added="' . esc_attr( $added ) . '">'
			. '<span class="cbp-btn__text">' . esc_html( $add ) . '</span>'
			. cb_product_icon( 'check' )
			. '</button>';
	}
}

if ( ! function_exists( 'cb_product_card' ) ) {
	/**
	 * One product card: image, title, meta line, add button and phone link.
	 *
	 * @param int                  $post_id Product.
	 * @param array<string, mixed> $opts    add / added labels, phone ([display, href]), title_tag.
	 */
	function cb_product_card( int $post_id, array $opts = [] ): string {
		$data  = cb_product_data( $post_id );
		$phone = is_array( $opts['phone'] ?? null ) ? $opts['phone'] : [ 'display' => '', 'href' => '' ];
		$tag   = in_array( ( $opts['title_tag'] ?? '' ), [ 'h2', 'h3', 'h4' ], true ) ? (string) $opts['title_tag'] : 'h3';
		$types = implode( ' ', array_column( $data['types'], 'slug' ) );
		$meta  = implode( ' · ', cb_product_meta_parts( $data ) );

		$brands = implode( ' ', array_column( $data['brands'], 'slug' ) );
		$hide   = ! empty( $opts['hidden'] );

		$h  = '<article class="cbp-card" data-cbp-card data-types="' . esc_attr( $types ) . '" data-brands="' . esc_attr( $brands ) . '"' . ( $hide ? ' hidden' : '' ) . '>';
		$h .= '<a class="cbp-card__media" href="' . esc_url( $data['url'] ) . '" tabindex="-1" aria-hidden="true">'
			. cb_product_image_html( (int) $data['thumb'], 'large', [ 'sizes' => '(min-width: 1024px) 33vw, 100vw' ] ) . '</a>';
		$h .= '<div class="cbp-card__body">';
		$h .= '<' . $tag . ' class="cbp-card__title"><a class="cbp-card__link" href="' . esc_url( $data['url'] ) . '">' . esc_html( $data['title'] ) . '</a></' . $tag . '>';
		if ( '' !== $meta ) {
			$h .= '<p class="cbp-card__meta">' . esc_html( $meta ) . '</p>';
		}
		if ( empty( $opts['no_actions'] ) ) {
			$h .= '<div class="cbp-card__actions">' . cb_product_add_button( $data, $opts );
			if ( '' !== (string) $phone['href'] ) {
				$h .= '<a class="cbp-card__tel" href="' . esc_url( (string) $phone['href'] ) . '" aria-label="' . esc_attr( cb_product_labels()['call'] . ' ' . $phone['display'] ) . '">' . cb_product_icon( 'phone' ) . '</a>';
			}
			$h .= '</div>';
		}
		return $h . '</div></article>';
	}
}

if ( ! function_exists( 'cb_product_query' ) ) {
	/**
	 * Products in menu order, then by title.
	 *
	 * @param array<string, mixed> $args Extra WP_Query arguments.
	 * @return int[] Product IDs.
	 */
	function cb_product_query( array $args = [] ): array {
		$query = new WP_Query( array_merge(
			[
				'post_type'              => CB_PRODUCT_POST_TYPE,
				'post_status'            => 'publish',
				'posts_per_page'         => 48,
				'orderby'                => [ 'menu_order' => 'ASC', 'title' => 'ASC' ],
				'fields'                 => 'ids',
				'no_found_rows'          => true,
				'ignore_sticky_posts'    => true,
			],
			$args
		) );
		return array_map( static fn ( $post ): int => (int) ( is_object( $post ) ? $post->ID : $post ), $query->posts );
	}
}

if ( ! function_exists( 'cb_product_vars' ) ) {
	/**
	 * Text colours that stay readable on this site's own accent and ink: white
	 * or black, whichever reaches AA on the theme's `accent` and `primary`.
	 * CSS cannot compute a contrast, so the block wrapper carries the answer.
	 */
	function cb_product_vars(): string {
		if ( ! function_exists( 'cb_best_contrast_text' ) || ! function_exists( 'cb_theme_color' ) ) {
			return '';
		}
		return '--cbp-on-accent:' . cb_best_contrast_text( cb_theme_color( 'accent', '#f0a83c' ), '#ffffff' ) . ';'
			. '--cbp-on-ink:' . cb_best_contrast_text( cb_theme_color( 'primary', '#0a2020' ), '#ffffff' ) . ';';
	}
}

if ( ! function_exists( 'cb_product_enqueue' ) ) {
	/**
	 * Loads the basket script. The stylesheet comes with the block's `style`
	 * handle, so it also reaches the editor canvas.
	 */
	function cb_product_enqueue(): void {
		wp_enqueue_script( 'styrk-blocks-product-basket' );
	}
}

if ( ! function_exists( 'cb_product_breadcrumbs' ) ) {
	/**
	 * Hjem / Produkter / Category / Product, in the plugin's breadcrumb markup.
	 *
	 * @param array<string, mixed> $data From cb_product_data().
	 * @param string               $home Home label.
	 */
	function cb_product_breadcrumbs( array $data, string $home ): string {
		$labels = cb_product_labels();
		$crumbs = [
			[ $home, home_url( '/' ) ],
			[ $labels['archive'], (string) get_post_type_archive_link( CB_PRODUCT_POST_TYPE ) ],
		];
		$term = $data['cats'][0]['id'] ?? 0;
		if ( $term ) {
			$link = get_term_link( (int) $term, CB_PRODUCT_CAT );
			if ( ! is_wp_error( $link ) ) {
				$crumbs[] = [ (string) $data['cats'][0]['name'], (string) $link ];
			}
		}
		$h = '<nav class="cb-breadcrumbs cbp-crumbs" aria-label="' . esc_attr( $labels['breadcrumb'] ) . '"><ol class="cb-breadcrumbs__list">';
		foreach ( $crumbs as $crumb ) {
			$h .= '<li class="cb-breadcrumbs__item"><a href="' . esc_url( $crumb[1] ) . '">' . esc_html( $crumb[0] ) . '</a></li>'
				. '<li class="cb-breadcrumbs__item cb-breadcrumbs__item--sep"><span class="cb-breadcrumbs__sep" aria-hidden="true">/</span></li>';
		}
		return $h . '<li class="cb-breadcrumbs__item cb-breadcrumbs__item--current"><span aria-current="page">' . esc_html( $data['title'] ) . '</span></li></ol></nav>';
	}
}
