<?php
/**
 * Chat widget — enqueues the floating assistant on the frontend when the
 * site has turned it on and a key is configured. Exposes only public config
 * (never the API key).
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_CHAT_WIDGET_LOADED' ) ) return;
define( 'CB_CHAT_WIDGET_LOADED', true );

function cb_chat_enqueue_widget(): void {
	if ( is_admin() ) return;
	$s = cb_chat_get_settings();
	if ( empty( $s['enabled'] ) || '' === cb_chat_api_key() ) return;

	$plugin_file = dirname( __DIR__ ) . '/styrk-blocks.php';
	$asset_file  = dirname( __DIR__ ) . '/build/plugins/chat-widget/index.asset.php';
	if ( ! file_exists( $asset_file ) ) return;
	$asset = require $asset_file;

	wp_enqueue_script(
		'styrk-chat-widget',
		plugins_url( 'build/plugins/chat-widget/index.js', $plugin_file ),
		$asset['dependencies'] ?? [],
		$asset['version'] ?? null,
		true
	);
	wp_set_script_translations( 'styrk-chat-widget', 'styrk-blocks', dirname( __DIR__ ) . '/languages' );

	$css = dirname( __DIR__ ) . '/build/plugins/chat-widget/chat.css';
	if ( file_exists( $css ) ) {
		wp_enqueue_style(
			'styrk-chat-widget',
			plugins_url( 'build/plugins/chat-widget/chat.css', $plugin_file ),
			[],
			(string) filemtime( $css )
		);
	}

	wp_add_inline_script(
		'styrk-chat-widget',
		'window.styrkChat = ' . wp_json_encode( [
			'endpoint'    => esc_url_raw( rest_url( 'styrk/v1/chat' ) ),
			'nonce'       => wp_create_nonce( 'wp_rest' ),
			'botName'     => (string) $s['bot_name'],
			'subtitle'    => (string) $s['subtitle'],
			'welcome'     => (string) $s['welcome'],
			'suggestions' => array_values( (array) $s['suggestions'] ),
			'legal'       => (string) $s['legal'],
			'maxLength'   => CB_CHAT_MAX_MESSAGE,
			// Public key only; the secret never leaves the server.
			'turnstileSiteKey' => cb_chat_turnstile_enabled() ? (string) $s['turnstile_site_key'] : '',
		] ) . ';',
		'before'
	);
}
add_action( 'wp_enqueue_scripts', 'cb_chat_enqueue_widget', 30 );
