<?php
/**
 * Chat Settings — Settings → Chat.
 *
 * Site-wide AI assistant that answers from the site's own published content
 * (see chat-index.php for the index, chat-api.php for the REST endpoint and
 * chat-widget.php for the frontend). The API key is resolved server-side only
 * — constant first, option second — and is never sent to the browser.
 *
 * Mirrors the structure of search-settings.php so the global settings pages
 * (Header, Footer, Search, Chat) stay consistent under WP's Settings menu.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_CHAT_SETTINGS_LOADED' ) ) return;
define( 'CB_CHAT_SETTINGS_LOADED', true );

define( 'CB_CHAT_OPTION', 'cb_chat_settings' );

function cb_chat_defaults(): array {
	return [
		'enabled'       => false,
		'api_key'       => '',
		'bot_name'      => 'Spør oss',
		'subtitle'      => 'Svarer ut fra innholdet på nettsiden',
		'welcome'       => 'Hei! Jeg kan svare på spørsmål om tjenestene våre og hvordan vi jobber. Hva lurer du på?',
		'suggestions'   => [ 'Hva tilbyr dere?', 'Hvor holder dere til?', 'Hvordan kommer vi i gang?' ],
		'contact_url'   => '',
		'contact_phone' => '',
		'legal'         => 'Svarene lages av KI ut fra nettsidens innhold og kan inneholde feil.',
		// Cost guards (see chat-guard.php). Answers that call Claude, per site.
		'monthly_cap'        => 1000,
		'daily_cap'          => 100,
		'alert_email'        => '',
		'turnstile_site_key' => '',
		'turnstile_secret'   => '',
	];
}

function cb_chat_get_settings(): array {
	$saved = get_option( CB_CHAT_OPTION, [] );
	return ( is_array( $saved ) ? $saved : [] ) + cb_chat_defaults();
}

/** The constant wins so hosts can keep the key out of the database. */
function cb_chat_api_key(): string {
	if ( cb_chat_key_is_constant() ) {
		return trim( (string) constant( 'STYRK_ANTHROPIC_API_KEY' ) );
	}
	return trim( (string) ( cb_chat_get_settings()['api_key'] ?? '' ) );
}

function cb_chat_key_is_constant(): bool {
	return defined( 'STYRK_ANTHROPIC_API_KEY' ) && '' !== trim( (string) constant( 'STYRK_ANTHROPIC_API_KEY' ) );
}

/** Plain text, trimmed to $max characters. */
function cb_chat_clip( $value, int $max ): string {
	return mb_substr( sanitize_text_field( (string) $value ), 0, $max );
}

/** A new secret when it looks right; otherwise the saved one (blank keeps it). */
function cb_chat_keep_secret( $value, string $saved, string $pattern ): string {
	$value = trim( (string) $value );
	return '' !== $value && preg_match( $pattern, $value ) ? $value : $saved;
}

/** @return string[] Up to four suggestion lines. */
function cb_chat_clean_suggestions( $raw ): array {
	if ( is_string( $raw ) ) {
		$raw = preg_split( '/\r?\n/', $raw ) ?: [];
	}
	return array_values( array_filter( array_map(
		static fn( $s ): string => cb_chat_clip( $s, 60 ),
		array_slice( (array) $raw, 0, 4 )
	) ) );
}

/** Only http(s) or site-relative URLs. */
function cb_chat_clean_url( $raw ): string {
	$url = esc_url_raw( (string) $raw );
	return '' !== $url && ! preg_match( '#^(https?:)?/#', $url ) ? '' : $url;
}

function cb_chat_clean_count( $value, int $fallback ): int {
	return max( 1, min( 100000, (int) ( is_numeric( $value ) ? $value : $fallback ) ) );
}

function cb_chat_sanitize( $input ): array {
	$in   = is_array( $input ) ? $input : [];
	$prev = cb_chat_get_settings();
	$id   = '/^[A-Za-z0-9_\-]{10,}$/';

	$ts_site = trim( (string) ( $in['turnstile_site_key'] ?? '' ) );
	$ts_site = preg_match( $id, $ts_site ) ? $ts_site : '';
	$email   = (string) ( $in['alert_email'] ?? '' );

	return [
		'enabled'            => ! empty( $in['enabled'] ),
		'api_key'            => cb_chat_keep_secret( $in['api_key'] ?? '', (string) $prev['api_key'], '/^sk-ant-[A-Za-z0-9_\-]{20,}$/' ),
		'bot_name'           => cb_chat_clip( $in['bot_name'] ?? '', 40 ) ?: (string) $prev['bot_name'],
		'subtitle'           => cb_chat_clip( $in['subtitle'] ?? '', 80 ),
		'welcome'            => cb_chat_clip( $in['welcome'] ?? '', 300 ) ?: (string) $prev['welcome'],
		'suggestions'        => cb_chat_clean_suggestions( $in['suggestions'] ?? [] ),
		'contact_url'        => cb_chat_clean_url( $in['contact_url'] ?? '' ),
		'contact_phone'      => cb_chat_clip( $in['contact_phone'] ?? '', 30 ),
		'legal'              => cb_chat_clip( $in['legal'] ?? '', 160 ),
		'monthly_cap'        => cb_chat_clean_count( $in['monthly_cap'] ?? null, (int) $prev['monthly_cap'] ),
		'daily_cap'          => cb_chat_clean_count( $in['daily_cap'] ?? null, (int) $prev['daily_cap'] ),
		'alert_email'        => is_email( $email ) ? sanitize_email( $email ) : '',
		'turnstile_site_key' => $ts_site,
		'turnstile_secret'   => '' === $ts_site ? '' : cb_chat_keep_secret( $in['turnstile_secret'] ?? '', (string) $prev['turnstile_secret'], $id ),
	];
}

/* ── Admin page ─────────────────────────────────────────────────────────────── */

function cb_chat_settings_menu(): void {
	add_options_page(
		__( 'Chat Settings', 'styrk-blocks' ),
		__( 'Chat', 'styrk-blocks' ),
		'manage_options',
		'cb-chat-settings',
		'cb_chat_settings_page'
	);
}
add_action( 'admin_menu', 'cb_chat_settings_menu' );

function cb_chat_settings_init(): void {
	register_setting( 'cb_chat_group', CB_CHAT_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_chat_sanitize',
		'default'           => cb_chat_defaults(),
	] );

	add_settings_section(
		'cb_chat_main',
		__( 'Assistent', 'styrk-blocks' ),
		static function (): void {
			printf(
				'<p style="max-width:720px;">%s</p>',
				esc_html__( 'En chat nederst til høyre som svarer ut fra publisert innhold på nettsiden. Spørsmålet og relevante tekstutdrag sendes til Anthropic sitt API (brukes ikke til trening). Ingen besøksdata lagres.', 'styrk-blocks' )
			);
		},
		'cb-chat-settings'
	);

	$fields = [
		[ 'enabled',       __( 'Slå på chat', 'styrk-blocks' ),            'checkbox' ],
		[ 'api_key',       __( 'Anthropic API-nøkkel', 'styrk-blocks' ),   'password' ],
		[ 'bot_name',      __( 'Navn', 'styrk-blocks' ),                   'text' ],
		[ 'subtitle',      __( 'Undertittel', 'styrk-blocks' ),            'text' ],
		[ 'welcome',       __( 'Velkomstmelding', 'styrk-blocks' ),        'textarea' ],
		[ 'suggestions',   __( 'Forslag til spørsmål (ett per linje, maks 4)', 'styrk-blocks' ), 'textarea' ],
		[ 'contact_url',   __( 'Kontaktside (URL)', 'styrk-blocks' ),      'text' ],
		[ 'contact_phone', __( 'Telefon', 'styrk-blocks' ),                'text' ],
		[ 'legal',         __( 'Liten tekst under skrivefeltet', 'styrk-blocks' ), 'text' ],
	];
	foreach ( $fields as [ $key, $label, $type ] ) {
		add_settings_field(
			"cb_chat_$key",
			$label,
			'cb_chat_render_field',
			'cb-chat-settings',
			'cb_chat_main',
			[ 'key' => $key, 'type' => $type ]
		);
	}

	add_settings_section(
		'cb_chat_guard',
		__( 'Kostnad og misbruk', 'styrk-blocks' ),
		static function (): void {
			printf(
				'<p style="max-width:720px;">%s</p>',
				esc_html__( 'Hver besøkende kan stille 5 spørsmål i minuttet og 50 i døgnet. Når nettstedets kvote er brukt opp, viser chatten kontaktinformasjon i stedet for svar. Gjentatte spørsmål besvares fra lager uten kostnad.', 'styrk-blocks' )
			);
		},
		'cb-chat-settings'
	);
	$guard = [
		[ 'monthly_cap',        __( 'Maks svar per måned', 'styrk-blocks' ), 'number' ],
		[ 'daily_cap',          __( 'Maks svar per døgn', 'styrk-blocks' ),  'number' ],
		[ 'alert_email',        __( 'Varsel ved 80 % og 100 % til', 'styrk-blocks' ), 'email' ],
		[ 'turnstile_site_key', __( 'Cloudflare Turnstile site key (valgfri)', 'styrk-blocks' ), 'text' ],
		[ 'turnstile_secret',   __( 'Cloudflare Turnstile secret', 'styrk-blocks' ), 'secret' ],
	];
	foreach ( $guard as [ $key, $label, $type ] ) {
		add_settings_field(
			"cb_chat_$key",
			$label,
			'cb_chat_render_field',
			'cb-chat-settings',
			'cb_chat_guard',
			[ 'key' => $key, 'type' => $type ]
		);
	}
}
add_action( 'admin_init', 'cb_chat_settings_init' );

function cb_chat_render_field( array $args ): void {
	$s    = cb_chat_get_settings();
	$key  = (string) $args['key'];
	$name = CB_CHAT_OPTION . "[$key]";
	$val  = $s[ $key ];

	switch ( $args['type'] ) {
		case 'checkbox':
			printf(
				'<label><input type="checkbox" name="%s" value="1"%s> %s</label>',
				esc_attr( $name ),
				checked( (bool) $val, true, false ),
				esc_html__( 'Vis chatten på alle sider', 'styrk-blocks' )
			);
			break;

		case 'password':
			if ( cb_chat_key_is_constant() ) {
				printf(
					'<p class="description">%s</p>',
					esc_html__( 'Nøkkelen er satt i wp-config.php (STYRK_ANTHROPIC_API_KEY) og kan ikke endres her.', 'styrk-blocks' )
				);
				break;
			}
			printf(
				'<input type="password" class="regular-text" name="%s" value="" autocomplete="new-password" placeholder="%s"><p class="description">%s</p>',
				esc_attr( $name ),
				esc_attr( $val ? '•••••••• ' . __( '(lagret)', 'styrk-blocks' ) : 'sk-ant-…' ),
				esc_html__( 'La feltet stå tomt for å beholde lagret nøkkel.', 'styrk-blocks' )
			);
			break;

		case 'number':
			printf(
				'<input type="number" class="small-text" min="1" max="100000" name="%s" value="%d">',
				esc_attr( $name ),
				(int) $val
			);
			break;

		case 'email':
			printf(
				'<input type="email" class="regular-text" name="%s" value="%s" placeholder="%s">',
				esc_attr( $name ),
				esc_attr( (string) $val ),
				esc_attr( (string) get_option( 'admin_email' ) )
			);
			break;

		case 'secret':
			printf(
				'<input type="password" class="regular-text" name="%s" value="" autocomplete="new-password" placeholder="%s"><p class="description">%s</p>',
				esc_attr( $name ),
				esc_attr( $val ? '•••••••• ' . __( '(lagret)', 'styrk-blocks' ) : '' ),
				esc_html__( 'Bot-sjekk før første spørsmål. Begge feltene må fylles ut for å slå den på. La feltet stå tomt for å beholde lagret verdi.', 'styrk-blocks' )
			);
			break;

		case 'textarea':
			$text = is_array( $val ) ? implode( "\n", $val ) : (string) $val;
			printf(
				'<textarea class="large-text" rows="3" name="%s">%s</textarea>',
				esc_attr( $name ),
				esc_textarea( $text )
			);
			break;

		default:
			printf(
				'<input type="text" class="regular-text" name="%s" value="%s">',
				esc_attr( $name ),
				esc_attr( (string) $val )
			);
	}
}

function cb_chat_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) return;
	$status = function_exists( 'cb_chat_index_status' )
		? cb_chat_index_status()
		: [ 'chunks' => 0, 'posts' => 0, 'last_run' => '' ];
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Chat Settings', 'styrk-blocks' ); ?></h1>
		<?php if ( isset( $_GET['reindexed'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- display-only flag after a nonce-checked redirect. ?>
			<div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Reindeksering er satt i gang.', 'styrk-blocks' ); ?></p></div>
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'cb_chat_group' );
			do_settings_sections( 'cb-chat-settings' );
			submit_button();
			?>
		</form>
		<hr>
		<?php if ( function_exists( 'cb_chat_usage_status' ) ) : $cb_usage = cb_chat_usage_status(); ?>
			<h2><?php esc_html_e( 'Bruk denne måneden', 'styrk-blocks' ); ?></h2>
			<p>
				<?php
				printf(
					/* translators: 1: answers used, 2: monthly cap */
					esc_html__( '%1$d av %2$d svar brukt.', 'styrk-blocks' ),
					(int) $cb_usage['month_count'],
					(int) $cb_usage['monthly_cap']
				);
				?>
			</p>
		<?php endif; ?>
		<h2><?php esc_html_e( 'Indeks', 'styrk-blocks' ); ?></h2>
		<p>
			<?php
			printf(
				/* translators: 1: chunk count, 2: post count, 3: time */
				esc_html__( '%1$d tekstbiter fra %2$d sider. Sist kjørt: %3$s', 'styrk-blocks' ),
				(int) $status['chunks'],
				(int) $status['posts'],
				esc_html( $status['last_run'] ?: __( 'aldri', 'styrk-blocks' ) )
			);
			?>
		</p>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="cb_chat_reindex">
			<?php
			wp_nonce_field( 'cb_chat_reindex' );
			submit_button( __( 'Reindekser nå', 'styrk-blocks' ), 'secondary' );
			?>
		</form>
	</div>
	<?php
}

function cb_chat_handle_reindex(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'Ingen tilgang.', 'styrk-blocks' ), 403 );
	}
	check_admin_referer( 'cb_chat_reindex' );
	if ( function_exists( 'cb_chat_schedule_full_reindex' ) ) {
		cb_chat_schedule_full_reindex();
	}
	wp_safe_redirect( add_query_arg( [ 'page' => 'cb-chat-settings', 'reindexed' => 1 ], admin_url( 'options-general.php' ) ) );
	exit;
}
add_action( 'admin_post_cb_chat_reindex', 'cb_chat_handle_reindex' );
