<?php
/**
 * Chat guards — the limits that keep one site, or one bot, from spending
 * the shared AI credits.
 *
 *   1. Per visitor (IP): 5 questions a minute, 50 a day.
 *   2. Per site: a daily and a monthly cap on answers that call Claude, set in
 *      Settings → Chat. At the cap the chat replies with the contact details
 *      instead, and an e-mail goes out at 80 % and 100 % of the month.
 *   3. Repeated questions (the suggestion chips above all) are answered from a
 *      cache, free, until the site's content changes.
 *   4. Optional Cloudflare Turnstile check before the first question; a pass
 *      signed with the site's salt covers the visitor for 30 minutes.
 *
 * The hard ceiling outside the plugin is the spend limit on the client's
 * workspace in the Anthropic console (see the HiveMind runbook).
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_CHAT_GUARD_LOADED' ) ) return;
define( 'CB_CHAT_GUARD_LOADED', true );

define( 'CB_CHAT_IP_PER_MINUTE', 5 );
define( 'CB_CHAT_IP_PER_DAY', 50 );
define( 'CB_CHAT_PASS_TTL', 1800 );
define( 'CB_CHAT_CACHE_TTL', 12 * 3600 );

/* ── Locking ───────────────────────────────────────────────────────────────── */

/**
 * Runs $fn while holding a MySQL named lock, so parallel requests cannot all
 * read the same counter and slip past a cap. Fails closed: when the lock
 * cannot be taken in 2 seconds, $busy is returned instead.
 *
 * @template T
 * @param callable():T $fn
 * @param T            $busy
 * @return T
 */
function cb_chat_locked( string $name, callable $fn, $busy ) {
	global $wpdb;
	if ( ! is_object( $wpdb ) || ! method_exists( $wpdb, 'get_var' ) ) {
		return $fn(); // Unit tests: no database.
	}
	$lock = 'cb_chat_' . md5( $name . '|' . $wpdb->prefix );
	if ( '1' !== (string) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 2)', $lock ) ) ) {
		return $busy;
	}
	try {
		return $fn();
	} finally {
		$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock ) );
	}
}

/* ── Per visitor ────────────────────────────────────────────────────────────── */

/** Counts this request and says whether the visitor is over a limit. */
function cb_chat_ip_limited( string $ip, int $now ): bool {
	return (bool) cb_chat_locked( 'ip|' . $ip, static fn(): bool => cb_chat_ip_count( $ip, $now ), true );
}

function cb_chat_ip_count( string $ip, int $now ): bool {
	$id      = md5( $ip );
	$buckets = [
		[ 'cb_chat_rl_m_' . $id . '_' . intdiv( $now, 60 ), CB_CHAT_IP_PER_MINUTE, 60 ],
		[ 'cb_chat_rl_d_' . $id . '_' . gmdate( 'Ymd', $now ), CB_CHAT_IP_PER_DAY, 86400 ],
	];
	foreach ( $buckets as [ $key, $max ] ) {
		if ( (int) get_transient( $key ) >= $max ) return true;
	}
	foreach ( $buckets as [ $key, , $ttl ] ) {
		set_transient( $key, (int) get_transient( $key ) + 1, $ttl );
	}
	return false;
}

/* ── Per site ───────────────────────────────────────────────────────────────── */

/**
 * Pure: counts one answer against the site's caps.
 *
 * @param array<string,mixed> $usage Stored counters (may be empty).
 * @return array{allowed:bool,usage:array<string,mixed>,alert:int|null}
 */
function cb_chat_usage_check( array $usage, string $month, string $day, int $monthly_cap, int $daily_cap ): array {
	if ( ( $usage['month'] ?? '' ) !== $month ) {
		$usage = [ 'month' => $month, 'month_count' => 0, 'alerted' => [] ];
	}
	if ( ( $usage['day'] ?? '' ) !== $day ) {
		$usage['day']       = $day;
		$usage['day_count'] = 0;
	}
	$month_count = (int) ( $usage['month_count'] ?? 0 );
	$day_count   = (int) ( $usage['day_count'] ?? 0 );
	if ( $month_count >= $monthly_cap || $day_count >= $daily_cap ) {
		return [ 'allowed' => false, 'usage' => $usage, 'alert' => null ];
	}
	$usage['month_count'] = ++$month_count;
	$usage['day_count']   = ++$day_count;

	$alert   = null;
	$alerted = (array) ( $usage['alerted'] ?? [] );
	foreach ( [ 100, 80 ] as $pct ) {
		if ( $month_count * 100 >= $monthly_cap * $pct && ! in_array( $pct, $alerted, true ) ) {
			$alert     = $pct;
			$alerted[] = $pct;
			if ( 100 === $pct ) $alerted[] = 80;
			break;
		}
	}
	$usage['alerted'] = array_values( array_unique( $alerted ) );
	return [ 'allowed' => true, 'usage' => $usage, 'alert' => $alert ];
}

/** Counts one paid answer for this site; false when a cap is reached. */
function cb_chat_consume_quota(): bool {
	return (bool) cb_chat_locked( 'quota', 'cb_chat_consume_quota_unlocked', false );
}

function cb_chat_consume_quota_unlocked(): bool {
	$s = cb_chat_get_settings();
	$r = cb_chat_usage_check(
		(array) get_option( 'cb_chat_usage', [] ),
		current_time( 'Y-m' ),
		current_time( 'Y-m-d' ),
		(int) $s['monthly_cap'],
		(int) $s['daily_cap']
	);
	update_option( 'cb_chat_usage', $r['usage'], false );
	if ( null !== $r['alert'] ) {
		cb_chat_send_alert( (int) $r['alert'], (int) $r['usage']['month_count'], (int) $s['monthly_cap'] );
	}
	return $r['allowed'];
}

function cb_chat_send_alert( int $pct, int $count, int $cap ): void {
	$s  = cb_chat_get_settings();
	$to = is_email( (string) $s['alert_email'] ) ? (string) $s['alert_email'] : (string) get_option( 'admin_email' );
	$site = (string) get_bloginfo( 'name' );
	wp_mail(
		$to,
		sprintf( '[%s] Chat: %d %% av månedskvoten brukt', $site, $pct ),
		sprintf(
			"Chatten på %s har gitt %d av %d svar denne måneden.\n\n%s\n\nInnstillinger: %s",
			home_url( '/' ),
			$count,
			$cap,
			100 === $pct
				? 'Kvoten er brukt opp. Chatten viser nå kontaktinformasjon i stedet for svar, til neste måned eller til kvoten økes.'
				: 'Ved 100 % viser chatten kontaktinformasjon i stedet for svar.',
			admin_url( 'options-general.php?page=cb-chat-settings' )
		)
	);
}

/** @return array{month_count:int,monthly_cap:int} */
function cb_chat_usage_status(): array {
	$u = (array) get_option( 'cb_chat_usage', [] );
	return [
		'month_count' => ( $u['month'] ?? '' ) === current_time( 'Y-m' ) ? (int) ( $u['month_count'] ?? 0 ) : 0,
		'monthly_cap' => (int) cb_chat_get_settings()['monthly_cap'],
	];
}

/** What the visitor sees when the site's cap is reached. */
function cb_chat_limit_reply( array $settings ): string {
	$ways = array_filter( [
		! empty( $settings['contact_phone'] ) ? 'ring oss på ' . $settings['contact_phone'] : '',
		! empty( $settings['contact_url'] ) ? 'skriv til oss via ' . $settings['contact_url'] : '',
	] );
	return 'Chatten tar en liten pause akkurat nå.'
		. ( $ways ? ' Ta gjerne kontakt direkte: ' . implode( ' eller ', $ways ) . '.' : ' Ta gjerne kontakt med oss direkte.' );
}

/* ── Answer cache ───────────────────────────────────────────────────────────── */

function cb_chat_cache_key( string $question, int $generation ): string {
	$q = mb_strtolower( trim( $question ) );
	$q = (string) preg_replace( '/\s+/u', ' ', $q );
	$q = (string) preg_replace( '/[\s?!.,;:]+$/u', '', $q );
	return 'cb_chat_ans_' . md5( $generation . '|' . $q );
}

function cb_chat_cache_generation(): int {
	return (int) get_option( 'cb_chat_cache_gen', 1 );
}

/** New content means old cached answers may be wrong: start a new generation. */
function cb_chat_cache_flush(): void {
	update_option( 'cb_chat_cache_gen', cb_chat_cache_generation() + 1, false );
}

/** @return array{answer:string,sources:array<int,array{title:string,url:string}>}|null */
function cb_chat_cache_get( string $question ): ?array {
	$hit = get_transient( cb_chat_cache_key( $question, cb_chat_cache_generation() ) );
	return is_array( $hit ) ? $hit : null;
}

function cb_chat_cache_set( string $question, array $answer ): void {
	set_transient( cb_chat_cache_key( $question, cb_chat_cache_generation() ), $answer, CB_CHAT_CACHE_TTL );
}

/* ── Bot check (Cloudflare Turnstile, optional) ─────────────────────────────── */

function cb_chat_turnstile_enabled(): bool {
	$s = cb_chat_get_settings();
	return '' !== (string) $s['turnstile_site_key'] && '' !== (string) $s['turnstile_secret'];
}

function cb_chat_make_pass( string $ip, int $expires, string $secret ): string {
	return $expires . '.' . hash_hmac( 'sha256', $ip . '|' . $expires, $secret );
}

function cb_chat_check_pass( string $pass, string $ip, int $now, string $secret ): bool {
	$parts = explode( '.', $pass, 2 );
	if ( 2 !== count( $parts ) || ! ctype_digit( $parts[0] ) ) return false;
	if ( (int) $parts[0] < $now ) return false;
	return hash_equals( cb_chat_make_pass( $ip, (int) $parts[0], $secret ), $pass );
}

function cb_chat_pass_secret(): string {
	return function_exists( 'wp_salt' ) ? wp_salt( 'auth' ) . 'styrk-chat' : 'styrk-chat';
}

/** Asks Cloudflare whether the widget token is real. */
function cb_chat_verify_turnstile( string $token, string $ip ): bool {
	if ( '' === $token ) return false;
	$res = wp_remote_post( 'https://challenges.cloudflare.com/turnstile/v0/siteverify', [
		'timeout' => 8,
		'body'    => [
			'secret'   => (string) cb_chat_get_settings()['turnstile_secret'],
			'response' => $token,
			'remoteip' => $ip,
		],
	] );
	if ( is_wp_error( $res ) ) return false;
	$data = json_decode( (string) wp_remote_retrieve_body( $res ), true );
	return is_array( $data ) && ! empty( $data['success'] );
}
