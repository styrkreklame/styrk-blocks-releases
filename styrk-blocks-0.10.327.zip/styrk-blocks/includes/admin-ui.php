<?php
/**
 * Admin UI kit — the shared building blocks of the plugin's settings pages.
 *
 * One panel, named parts that open and close (each shows a one-line summary of
 * its current values while closed), rows of "label | controls". Header uses it
 * first; Footer, Search and Chat follow in later slices.
 *
 * Every control is a real form input underneath (checkbox, radio, number,
 * select), so keyboard, screen readers and "save" behave natively. The CSS and
 * JS in assets/admin/ only dress and enhance them, and load only on the
 * screens listed in sb_ui_pages().
 *
 * Every helper here ECHOES and escapes its own output.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'SB_ADMIN_UI_LOADED' ) ) {
	return;
}
define( 'SB_ADMIN_UI_LOADED', true );

/* ── Assets ─────────────────────────────────────────────────────────────────── */

/**
 * Admin screens (hook suffixes) that use the kit. Each slice adds its own.
 *
 * @return string[]
 */
function sb_ui_pages(): array {
	return (array) apply_filters( 'sb_ui_pages', [ 'settings_page_cb-header-settings' ] );
}

/**
 * Enqueue the kit's CSS + JS on the screens that use it, and nowhere else.
 *
 * @param string $hook Admin page hook suffix.
 */
function sb_ui_enqueue( $hook ): void {
	if ( ! in_array( (string) $hook, sb_ui_pages(), true ) ) {
		return;
	}
	$dir  = dirname( __DIR__ ) . '/assets/admin/';
	$base = plugins_url( 'assets/admin/', dirname( __DIR__ ) . '/styrk-blocks.php' );
	$css  = (string) @filemtime( $dir . 'styrk-admin-ui.css' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- missing file just means no cache-bust.
	$js   = (string) @filemtime( $dir . 'styrk-admin-ui.js' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
	wp_enqueue_style( 'sb-admin-ui', $base . 'styrk-admin-ui.css', [], $css ?: null );
	wp_enqueue_script( 'sb-admin-ui', $base . 'styrk-admin-ui.js', [], $js ?: null, true );
}
add_action( 'admin_enqueue_scripts', 'sb_ui_enqueue' );

/* ── Small helpers ──────────────────────────────────────────────────────────── */

/**
 * Printed as the `data-sb-when` attribute: dim + lock a control unless the
 * named field currently has one of the values ("field[name]:a|b").
 *
 * @param string $when Spec, or '' for none.
 */
function sb_ui_when_attr( string $when ): string {
	return '' === $when ? '' : ' data-sb-when="' . esc_attr( $when ) . '"';
}

/**
 * One-sentence help line under a row's controls.
 *
 * @param string $text Already-translated plain text.
 */
function sb_ui_help( string $text ): void {
	if ( '' !== $text ) {
		echo '<p class="sb-help">' . esc_html( $text ) . '</p>';
	}
}

/**
 * Wrap controls in a flex line (controls side by side, wrapping on narrow
 * screens). Optionally dimmed unless a condition holds.
 *
 * @param callable $inner Prints the controls.
 * @param string   $when  Optional "field[name]:a|b" condition.
 */
function sb_ui_line( callable $inner, string $when = '' ): void {
	echo '<div class="sb-line"' . sb_ui_when_attr( $when ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in sb_ui_when_attr().
	$inner();
	echo '</div>';
}

/**
 * Wrap controls in a vertical stack. Optionally dimmed unless a condition holds.
 *
 * @param callable $inner Prints the controls.
 * @param string   $when  Optional "field[name]:a|b" condition.
 */
function sb_ui_stack( callable $inner, string $when = '' ): void {
	echo '<div class="sb-stack"' . sb_ui_when_attr( $when ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in sb_ui_when_attr().
	$inner();
	echo '</div>';
}

/* ── Controls ───────────────────────────────────────────────────────────────── */

/**
 * On/off switch (a checkbox). Unchecked posts nothing, same as before.
 *
 * @param string $name  Input name.
 * @param bool   $on    Current state.
 * @param string $label Text beside the switch.
 * @param string $when  Optional "field[name]:a|b" condition.
 */
function sb_ui_toggle( string $name, bool $on, string $label, string $when = '' ): void {
	printf(
		'<label class="sb-toggle"%4$s><input type="checkbox" class="sb-toggle__input" role="switch" name="%1$s" value="1" %2$s /><span class="sb-toggle__track" aria-hidden="true"><span class="sb-toggle__knob"></span></span><span class="sb-toggle__text">%3$s</span></label>',
		esc_attr( $name ),
		checked( $on, true, false ),
		esc_html( $label ),
		sb_ui_when_attr( $when ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in sb_ui_when_attr().
	);
}

/**
 * Segmented control: a radio group dressed as one pill. Arrow keys move
 * between the options natively.
 *
 * @param string               $name    Input name.
 * @param string               $current Saved value.
 * @param array<int|string,string> $options value => label.
 * @param string               $label   Accessible name of the group.
 * @param string               $when    Optional "field[name]:a|b" condition.
 */
function sb_ui_segmented( string $name, string $current, array $options, string $label, string $when = '' ): void {
	// Fallback: keeps an unlisted saved value when nothing is picked.
	printf( '<input type="hidden" data-sb-fallback name="%s" value="%s" />', esc_attr( $name ), esc_attr( $current ) );
	printf(
		'<div class="sb-seg" role="radiogroup" aria-label="%s"%s>', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in sb_ui_when_attr().
		esc_attr( $label ),
		sb_ui_when_attr( $when ) // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	);
	foreach ( $options as $value => $text ) {
		printf(
			'<label class="sb-seg__opt"><input type="radio" name="%1$s" value="%2$s" %3$s /><span>%4$s</span></label>',
			esc_attr( $name ),
			esc_attr( (string) $value ),
			checked( $current === (string) $value, true, false ),
			esc_html( $text )
		);
	}
	echo '</div>';
}

/**
 * Picture tiles: a radio group where each option is a small drawing + a name.
 *
 * Each option: [ 'label' => string, 'svg' => hardcoded svg, 'quiet' => bool ].
 * A "quiet" option is drawn dashed and stays hidden unless it is the saved
 * value (the "not set" choice), so nobody is invited to pick it by accident.
 *
 * @param string               $name    Input name.
 * @param string               $current Saved value ('' allowed).
 * @param array<int|string,array> $options value => option.
 * @param string               $label   Accessible name of the group.
 * @param string               $variant 'wide' | 'corners' (tile size).
 * @param bool                 $match   False = no tile is checked (unlisted saved value).
 */
function sb_ui_tiles( string $name, string $current, array $options, string $label, string $variant = 'wide', bool $match = true ): void {
	printf( '<input type="hidden" data-sb-fallback name="%s" value="%s" />', esc_attr( $name ), esc_attr( $current ) );
	printf(
		'<div class="sb-tiles sb-tiles--%s" role="radiogroup" aria-label="%s">',
		esc_attr( $variant ),
		esc_attr( $label )
	);
	foreach ( $options as $value => $opt ) {
		$value = (string) $value;
		$quiet = ! empty( $opt['quiet'] );
		$is_on = $match && $current === $value;
		printf(
			'<label class="sb-tile%1$s"%2$s><input type="radio" name="%3$s" value="%4$s" %5$s /><span class="sb-tile__card"><span class="sb-tile__pic">%6$s</span><span class="sb-tile__label">%7$s</span></span></label>',
			$quiet ? ' sb-tile--quiet' : '',
			( $quiet && ! $is_on ) ? ' hidden' : '',
			esc_attr( $name ),
			esc_attr( $value ),
			checked( $is_on, true, false ),
			(string) ( $opt['svg'] ?? '' ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- hardcoded SVG literals from this file.
			esc_html( (string) ( $opt['label'] ?? '' ) )
		);
	}
	echo '</div>';
}

/**
 * "Back to not set" link for a picture-tile group (see sb_ui_tiles()). Hidden
 * while the group already is "not set".
 *
 * @param string $name  Input name of the tile group.
 * @param string $text  Link text.
 * @param bool   $show  Show it now (a value is set).
 */
function sb_ui_reset_link( string $name, string $text, bool $show ): void {
	printf(
		'<button type="button" class="sb-link" data-sb-reset="%1$s"%3$s>%2$s</button>',
		esc_attr( $name ),
		esc_html( $text ),
		$show ? '' : ' hidden'
	);
}

/**
 * Colour button: a dot + a name that opens the theme palette. The palette is a
 * set of real radio inputs, so nothing is typed and nothing off-palette can be
 * posted.
 *
 * @param string                               $name        Input name.
 * @param string                               $current     Saved value (slug or hex).
 * @param string                               $label       Button text ("Bakgrunn").
 * @param array<int,array<string,string>> $palette Theme colours.
 * @param string                               $mode        'slug' (stores the palette slug) or 'hex'.
 * @param bool                                 $has_default Offer a "keep the default look" choice (value '').
 * @param string                               $default_label Accessible name of that choice.
 * @param string                               $when        Optional "field[name]:a|b" condition.
 */
function sb_ui_color( string $name, string $current, string $label, array $palette, string $mode = 'slug', bool $has_default = true, string $default_label = '', string $when = '' ): void {
	static $n = 0;
	++$n;
	$pop_id = 'sb-pop-' . $n;

	// What the dot shows right now.
	$dot_color = '';
	if ( 'hex' === $mode ) {
		$dot_color = preg_match( '/^#[0-9a-fA-F]{6}$/', $current ) ? $current : '';
	} else {
		foreach ( $palette as $sw ) {
			if ( '' !== $current && (string) ( $sw['slug'] ?? '' ) === $current ) {
				$dot_color = (string) $sw['color'];
				break;
			}
		}
	}

	echo '<div class="sb-color"' . sb_ui_when_attr( $when ) . '>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in sb_ui_when_attr().
	// Fallback so an off-palette saved value survives a save.
	printf( '<input type="hidden" data-sb-fallback name="%s" value="%s" />', esc_attr( $name ), esc_attr( $current ) );
	printf(
		'<button type="button" class="sb-color__btn" aria-expanded="false" aria-controls="%1$s"><span class="sb-dot%2$s"%3$s aria-hidden="true"></span><span>%4$s</span></button>',
		esc_attr( $pop_id ),
		'' === $dot_color ? ' sb-dot--default' : '',
		'' === $dot_color ? '' : ' style="--sb-dot:' . esc_attr( $dot_color ) . '"', // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped here.
		esc_html( $label )
	);
	printf( '<div class="sb-color__pop" id="%s" role="group" aria-label="%s" hidden>', esc_attr( $pop_id ), esc_attr( $label ) );

	if ( $has_default ) {
		printf(
			'<label class="sb-sw" title="%1$s"><input type="radio" name="%2$s" value="" %3$s /><span class="sb-sw__box sb-sw__box--default"></span><span class="sb-sr">%1$s</span></label>',
			esc_attr( $default_label ),
			esc_attr( $name ),
			checked( $current, '', false )
		);
	}
	foreach ( $palette as $sw ) {
		$slug  = (string) ( $sw['slug'] ?? '' );
		$color = (string) ( $sw['color'] ?? '' );
		$value = 'slug' === $mode ? $slug : $color;
		if ( '' === $value || '' === $color ) {
			continue;
		}
		$text = (string) ( $sw['name'] ?? $slug );
		printf(
			'<label class="sb-sw" title="%1$s"><input type="radio" name="%2$s" value="%3$s" data-color="%4$s" %5$s /><span class="sb-sw__box" style="background:%4$s"></span><span class="sb-sr">%1$s</span></label>',
			esc_attr( $text ),
			esc_attr( $name ),
			esc_attr( $value ),
			esc_attr( $color ),
			checked( strcasecmp( $current, $value ) === 0, true, false )
		);
	}
	echo '</div></div>';
}

/**
 * Logo picker: a preview, a pick/change button and a remove link, wired to the
 * WordPress media library by the kit's JS.
 *
 * @param string $name    Input name (stores the attachment ID).
 * @param int    $id      Saved attachment ID (0 = none).
 * @param array  $text    Strings: title, button, change, upload, remove, alt.
 * @param bool   $dark    Preview on a dark chip (for white logos).
 */
function sb_ui_media( string $name, int $id, array $text, bool $dark = false ): void {
	$url = $id ? (string) wp_get_attachment_image_url( $id, 'medium' ) : '';
	printf(
		'<div class="sb-media" data-sb-media data-title="%1$s" data-button="%2$s" data-label-change="%3$s" data-label-upload="%4$s">',
		esc_attr( (string) ( $text['title'] ?? '' ) ),
		esc_attr( (string) ( $text['button'] ?? '' ) ),
		esc_attr( (string) ( $text['change'] ?? '' ) ),
		esc_attr( (string) ( $text['upload'] ?? '' ) )
	);
	printf( '<input type="hidden" name="%s" value="%d" />', esc_attr( $name ), (int) $id );
	printf(
		'<div class="sb-media__preview%1$s"%2$s><img src="%3$s" alt="" /></div>',
		$dark ? ' sb-media__preview--dark' : '',
		'' === $url ? ' hidden' : '',
		esc_url( $url )
	);
	printf(
		'<button type="button" class="sb-btn" data-sb-media-pick>%s</button>',
		esc_html( '' === $url ? (string) ( $text['upload'] ?? '' ) : (string) ( $text['change'] ?? '' ) )
	);
	printf(
		'<button type="button" class="sb-link" data-sb-media-clear%2$s>%1$s</button>',
		esc_html( (string) ( $text['remove'] ?? '' ) ),
		'' === $url ? ' hidden' : ''
	);
	echo '</div>';
}

/**
 * Number stepper: − [ n ] +. An empty value is allowed (means "default").
 *
 * @param string $name  Input name.
 * @param string $value Saved value ('' allowed).
 * @param int    $min   Lowest value.
 * @param int    $max   Highest value.
 * @param int    $start Where the first press of − / + starts from when empty.
 * @param array  $text  Strings: less, more, label, placeholder.
 * @param string $when  Optional "field[name]:a|b" condition.
 */
function sb_ui_stepper( string $name, string $value, int $min, int $max, int $start, array $text, string $when = '' ): void {
	printf(
		'<div class="sb-stepper"%1$s><button type="button" data-sb-step="-1" aria-label="%2$s">&minus;</button><input type="number" name="%3$s" value="%4$s" min="%5$d" max="%6$d" step="1" inputmode="numeric" data-start="%7$d" placeholder="%8$s" aria-label="%9$s" /><button type="button" data-sb-step="1" aria-label="%10$s">+</button></div>',
		sb_ui_when_attr( $when ), // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped in sb_ui_when_attr().
		esc_attr( (string) ( $text['less'] ?? '' ) ),
		esc_attr( $name ),
		esc_attr( $value ),
		absint( $min ),
		absint( $max ),
		absint( $start ),
		esc_attr( (string) ( $text['placeholder'] ?? '' ) ),
		esc_attr( (string) ( $text['label'] ?? '' ) ),
		esc_attr( (string) ( $text['more'] ?? '' ) )
	);
}

/**
 * Dropdown for a long list (short lists use sb_ui_segmented()).
 *
 * @param string               $name    Input name.
 * @param string               $current Saved value.
 * @param array<int|string,string> $options value => label.
 * @param string               $label   Accessible name.
 */
function sb_ui_select( string $name, string $current, array $options, string $label ): void {
	printf( '<select class="sb-select" name="%s" aria-label="%s">', esc_attr( $name ), esc_attr( $label ) );
	foreach ( $options as $value => $text ) {
		printf(
			'<option value="%s" %s>%s</option>',
			esc_attr( (string) $value ),
			selected( $current, (string) $value, false ),
			esc_html( $text )
		);
	}
	echo '</select>';
}

/**
 * A labelled single-line text field ("Tekst [ ... ]").
 *
 * @param string $name        Input name.
 * @param string $value       Saved value.
 * @param string $label       Visible label.
 * @param string $placeholder Placeholder.
 * @param string $id          Element id.
 */
function sb_ui_text( string $name, string $value, string $label, string $placeholder, string $id ): void {
	printf(
		'<label class="sb-inline" for="%1$s"><span>%2$s</span><input type="text" class="sb-input" id="%1$s" name="%3$s" value="%4$s" placeholder="%5$s" /></label>',
		esc_attr( $id ),
		esc_html( $label ),
		esc_attr( $name ),
		esc_attr( $value ),
		esc_attr( $placeholder )
	);
}

/* ── Pictures for the tiles (hardcoded SVG literals) ───────────────────────── */

/**
 * Header-width pictures: a header bar of three widths on a page.
 *
 * @param string $kind 'full' | 'wide' | 'content' | 'none'.
 */
function sb_ui_width_svg( string $kind ): string {
	$bars = [
		'full'    => [ 6, 88 ],
		'wide'    => [ 16, 68 ],
		'content' => [ 26, 48 ],
	];
	$open = '<svg viewBox="0 0 100 52" aria-hidden="true" focusable="false"><rect x="1" y="1" width="98" height="50" rx="6" fill="#fff" stroke="#dcdcde"/>';
	if ( ! isset( $bars[ $kind ] ) ) {
		return $open . '<rect x="26" y="14" width="48" height="5" rx="2.5" fill="#c3c4c7"/><rect x="26" y="26" width="48" height="3" rx="1.5" fill="#dcdcde"/></svg>';
	}
	[ $x, $w ] = $bars[ $kind ];
	return $open
		. '<rect x="' . $x . '" y="12" width="' . $w . '" height="6" rx="3" fill="#1d2327"/>'
		. '<rect x="' . $x . '" y="26" width="' . $w . '" height="3" rx="1.5" fill="#c3c4c7"/>'
		. '<rect x="' . $x . '" y="34" width="' . (int) ( $w * 0.6 ) . '" height="3" rx="1.5" fill="#c3c4c7"/></svg>';
}

/**
 * Corner pictures: the top-left corner of a box, square → round.
 *
 * @param string $kind 'sharp' | 'soft' | 'round'.
 */
function sb_ui_corner_svg( string $kind ): string {
	$r = [
		'sharp' => 0,
		'soft'  => 8,
		'round' => 18,
	][ $kind ] ?? 0;
	$edge  = 'M4 40 V' . ( 4 + $r ) . ( $r ? ' A' . $r . ' ' . $r . ' 0 0 1 ' . ( 4 + $r ) . ' 4' : '' ) . ' H60';
	return '<svg viewBox="0 0 64 44" aria-hidden="true" focusable="false"><path d="' . $edge . ' V40 Z" fill="#dcdcde"/><path d="' . $edge . '" fill="none" stroke="#1d2327" stroke-width="2.5" stroke-linecap="round"/></svg>';
}

/* ── Page frame ─────────────────────────────────────────────────────────────── */

/**
 * Print the parts of a settings screen from the Settings API registrations:
 * each registered SECTION becomes a collapsible part, each registered FIELD a
 * row ("label | controls") whose callback prints the controls.
 *
 * @param string   $page       Settings page slug (the add_settings_section $page).
 * @param callable $summary_cb fn( string $section_id ): string — the one-line summary shown while closed.
 */
function sb_ui_render_parts( string $page, callable $summary_cb ): void {
	global $wp_settings_sections, $wp_settings_fields;
	if ( ! isset( $wp_settings_sections[ $page ] ) ) {
		return;
	}
	$first = true;
	foreach ( (array) $wp_settings_sections[ $page ] as $section ) {
		$id      = (string) ( $section['id'] ?? '' );
		$body_id = 'sb-body-' . $id;
		$head_id = 'sb-head-' . $id;
		$open    = $first;
		$first   = false;
		?>
		<section class="sb-part" data-sb-part="<?php echo esc_attr( $id ); ?>">
			<h3 class="sb-part__heading">
				<button type="button" class="sb-part__toggle" id="<?php echo esc_attr( $head_id ); ?>" aria-expanded="<?php echo $open ? 'true' : 'false'; ?>" aria-controls="<?php echo esc_attr( $body_id ); ?>">
					<span class="sb-part__chevron" aria-hidden="true"></span>
					<span class="sb-part__title"><?php echo esc_html( (string) $section['title'] ); ?></span>
					<span class="sb-part__summary"><?php echo esc_html( (string) $summary_cb( $id ) ); ?></span>
				</button>
			</h3>
			<div class="sb-part__body" id="<?php echo esc_attr( $body_id ); ?>" role="region" aria-labelledby="<?php echo esc_attr( $head_id ); ?>"<?php echo $open ? '' : ' hidden'; ?>>
				<?php
				foreach ( (array) ( $wp_settings_fields[ $page ][ $id ] ?? [] ) as $field ) {
					$row_id = 'sb-row-' . (string) $field['id'];
					?>
					<div class="sb-row" role="group" aria-labelledby="<?php echo esc_attr( $row_id ); ?>">
						<div class="sb-row__label" id="<?php echo esc_attr( $row_id ); ?>"><?php echo esc_html( (string) $field['title'] ); ?></div>
						<div class="sb-row__ctl">
							<?php call_user_func( $field['callback'], $field['args'] ); ?>
						</div>
					</div>
					<?php
				}
				?>
			</div>
		</section>
		<?php
	}
}
