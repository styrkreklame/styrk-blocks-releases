/*
 * Styrk admin UI kit — behaviour for the shared settings-page controls.
 * Vanilla JS, no build step. Pairs with styrk-admin-ui.css and the PHP
 * helpers in includes/admin-ui.php. Every control works as a plain form
 * without this file; this only adds the open/close parts, the colour palette
 * popover, the logo picker, the stepper and "only when ..." dimming.
 */
( function () {
	'use strict';

	var root = document.querySelector( '.sb-ui' );
	if ( ! root ) {
		return;
	}
	var form = root.querySelector( 'form' ) || root;

	/* ── Storage (never trusted: private windows throw) ─────────────────── */
	function store( key, value ) {
		try {
			if ( undefined === value ) {
				return window.localStorage.getItem( key );
			}
			window.localStorage.setItem( key, value );
		} catch ( e ) {
			return null;
		}
		return null;
	}

	/* ── Collapsible parts ──────────────────────────────────────────────── */
	var pageKey = 'sbui:' + ( root.getAttribute( 'data-sb-page' ) || 'page' ) + ':';

	function setPart( part, open ) {
		var btn = part.querySelector( '.sb-part__toggle' );
		var body = part.querySelector( '.sb-part__body' );
		if ( ! btn || ! body ) {
			return;
		}
		btn.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		body.hidden = ! open;
	}

	root.querySelectorAll( '.sb-part' ).forEach( function ( part ) {
		var id = part.getAttribute( 'data-sb-part' );
		var saved = store( pageKey + id );
		if ( 'open' === saved ) {
			setPart( part, true );
		} else if ( 'closed' === saved ) {
			setPart( part, false );
		}
		var btn = part.querySelector( '.sb-part__toggle' );
		if ( btn ) {
			btn.addEventListener( 'click', function () {
				var open = 'true' !== btn.getAttribute( 'aria-expanded' );
				setPart( part, open );
				store( pageKey + id, open ? 'open' : 'closed' );
			} );
		}
	} );

	/* ── Colour palette popover ─────────────────────────────────────────── */
	function closePops( except ) {
		root.querySelectorAll( '.sb-color' ).forEach( function ( c ) {
			if ( c === except ) {
				return;
			}
			var pop = c.querySelector( '.sb-color__pop' );
			var btn = c.querySelector( '.sb-color__btn' );
			if ( pop && ! pop.hidden ) {
				pop.hidden = true;
				btn.setAttribute( 'aria-expanded', 'false' );
			}
		} );
	}

	root.querySelectorAll( '.sb-color' ).forEach( function ( c ) {
		var btn = c.querySelector( '.sb-color__btn' );
		var pop = c.querySelector( '.sb-color__pop' );
		var dot = c.querySelector( '.sb-dot' );
		if ( ! btn || ! pop ) {
			return;
		}
		btn.addEventListener( 'click', function () {
			var open = pop.hidden;
			closePops( c );
			pop.hidden = ! open;
			btn.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
			if ( open ) {
				var on = pop.querySelector( 'input:checked' ) || pop.querySelector( 'input' );
				if ( on ) {
					on.focus();
				}
			}
		} );
		pop.addEventListener( 'change', function ( e ) {
			var input = e.target;
			if ( ! input || 'radio' !== input.type ) {
				return;
			}
			var fallback = c.querySelector( 'input[data-sb-fallback]' );
			if ( fallback ) {
				fallback.value = input.value;
			}
			var color = input.getAttribute( 'data-color' );
			if ( color ) {
				dot.style.setProperty( '--sb-dot', color );
				dot.classList.remove( 'sb-dot--default' );
			} else {
				dot.style.removeProperty( '--sb-dot' );
				dot.classList.add( 'sb-dot--default' );
			}
			pop.hidden = true;
			btn.setAttribute( 'aria-expanded', 'false' );
			btn.focus();
		} );
		c.addEventListener( 'keydown', function ( e ) {
			if ( 'Escape' === e.key && ! pop.hidden ) {
				e.preventDefault();
				e.stopPropagation();
				pop.hidden = true;
				btn.setAttribute( 'aria-expanded', 'false' );
				btn.focus();
			}
		} );
	} );

	document.addEventListener( 'click', function ( e ) {
		if ( ! e.target.closest || ! e.target.closest( '.sb-color' ) ) {
			closePops( null );
		}
	} );

	/* ── "Only when ..." dimming ────────────────────────────────────────── */
	// data-sb-when="field[name]:a|b" dims (and makes unreachable) the element
	// unless the named field currently has one of the listed values. The
	// element stays in the form, so its saved value is never lost.
	function currentValue( name ) {
		var checked = form.querySelector( 'input[name="' + name + '"]:checked' );
		if ( checked ) {
			return checked.value;
		}
		var fallback = form.querySelector( 'input[type="hidden"][name="' + name + '"]' );
		return fallback ? fallback.value : '';
	}

	function applyWhen() {
		root.querySelectorAll( '[data-sb-when]' ).forEach( function ( el ) {
			var spec = el.getAttribute( 'data-sb-when' );
			var cut = spec.lastIndexOf( ':' );
			var name = spec.slice( 0, cut );
			var values = spec.slice( cut + 1 ).split( '|' );
			var on = -1 !== values.indexOf( currentValue( name ) );
			el.classList.toggle( 'sb-is-dim', ! on );
			if ( on ) {
				el.removeAttribute( 'inert' );
			} else {
				el.setAttribute( 'inert', '' );
			}
		} );
	}
	form.addEventListener( 'change', applyWhen );
	applyWhen();

	/* ── Reset link ("Ikke valgt") ──────────────────────────────────────── */
	root.querySelectorAll( '[data-sb-reset]' ).forEach( function ( link ) {
		link.addEventListener( 'click', function () {
			var name = link.getAttribute( 'data-sb-reset' );
			var empty = form.querySelector( 'input[type="radio"][name="' + name + '"][value=""]' );
			if ( empty ) {
				var tile = empty.closest( '.sb-tile' );
				if ( tile ) {
					tile.hidden = false;
				}
				empty.checked = true;
				empty.dispatchEvent( new Event( 'change', { bubbles: true } ) );
				empty.focus();
			}
			link.hidden = true;
		} );
	} );
	form.addEventListener( 'change', function ( e ) {
		var t = e.target;
		if ( ! t || 'radio' !== t.type ) {
			return;
		}
		var link = root.querySelector( '[data-sb-reset="' + t.name + '"]' );
		if ( link ) {
			link.hidden = '' === t.value;
		}
	} );

	/* ── Stepper ────────────────────────────────────────────────────────── */
	root.querySelectorAll( '.sb-stepper' ).forEach( function ( box ) {
		var input = box.querySelector( 'input' );
		box.querySelectorAll( '[data-sb-step]' ).forEach( function ( b ) {
			b.addEventListener( 'click', function () {
				var step = parseInt( b.getAttribute( 'data-sb-step' ), 10 ) || 0;
				var min = input.min === '' ? -Infinity : parseInt( input.min, 10 );
				var max = input.max === '' ? Infinity : parseInt( input.max, 10 );
				var start = parseInt( input.getAttribute( 'data-start' ) || '0', 10 );
				var cur = input.value === '' ? start : parseInt( input.value, 10 );
				if ( isNaN( cur ) ) {
					cur = start;
				}
				var next = input.value === '' ? cur : cur + step;
				input.value = String( Math.max( min, Math.min( max, next ) ) );
				input.dispatchEvent( new Event( 'change', { bubbles: true } ) );
			} );
		} );
	} );

	/* ── Logo picker (WordPress media library) ──────────────────────────── */
	root.querySelectorAll( '[data-sb-media]' ).forEach( function ( box ) {
		var input = box.querySelector( 'input[type="hidden"]' );
		var pick = box.querySelector( '[data-sb-media-pick]' );
		var clear = box.querySelector( '[data-sb-media-clear]' );
		var preview = box.querySelector( '.sb-media__preview' );
		var img = preview ? preview.querySelector( 'img' ) : null;
		var frame = null;

		function show( url ) {
			if ( url ) {
				img.setAttribute( 'src', url );
				preview.hidden = false;
				pick.textContent = box.getAttribute( 'data-label-change' );
				clear.hidden = false;
			} else {
				img.removeAttribute( 'src' );
				preview.hidden = true;
				pick.textContent = box.getAttribute( 'data-label-upload' );
				clear.hidden = true;
			}
		}

		pick.addEventListener( 'click', function () {
			if ( ! window.wp || ! window.wp.media ) {
				return;
			}
			if ( ! frame ) {
				frame = window.wp.media( {
					title: box.getAttribute( 'data-title' ),
					button: { text: box.getAttribute( 'data-button' ) },
					multiple: false,
					library: { type: [ 'image', 'image/svg+xml' ] },
				} );
				frame.on( 'select', function () {
					var a = frame.state().get( 'selection' ).first().toJSON();
					input.value = String( a.id );
					show( a.sizes && a.sizes.medium ? a.sizes.medium.url : a.url );
				} );
			}
			frame.open();
		} );

		clear.addEventListener( 'click', function () {
			input.value = '0';
			show( '' );
			pick.focus();
		} );
	} );
} )();
