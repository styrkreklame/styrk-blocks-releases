<?php
/**
 * Page-level meta: section eyebrow opt-out.
 *
 * Every non-top-level page automatically renders a section eyebrow above
 * its h1 (the top-level ancestor's title, uppercase) so readers know
 * which section they're in. Admins who want a landing-style page without
 * that orientation chrome can tick "Skjul kategori-label" in the Page
 * document sidebar — that sets `_cb_hide_section_eyebrow = true`, which
 * page-auto-hero/template.php reads to skip the eyebrow output.
 *
 * Registered as `show_in_rest` so the Gutenberg sidebar panel in
 * `src/plugins/page-header.tsx` can read/write it via `useEntityProp`.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_PAGE_META_LOADED' ) ) return;
define( 'CB_PAGE_META_LOADED', true );

add_action( 'init', function () {
	register_post_meta( 'page', '_cb_hide_section_eyebrow', [
		'single'            => true,
		'type'              => 'boolean',
		'default'           => false,
		'show_in_rest'      => true,
		'sanitize_callback' => 'rest_sanitize_boolean',
		'auth_callback'     => fn() => current_user_can( 'edit_posts' ),
	] );
} );
