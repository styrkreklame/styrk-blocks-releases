<?php
/**
 * Plugin Name: Styrk Blocks
 * Description: Styrk Reklame's block + admin-UX toolkit — hero, CTA, employee grid, testimonial, rich-text section, logo strip, stats row, feature cards, FAQ accordion, split section, and more.
 * Version:     0.7.23
 * Author:      Styrk Reklame AS
 * Requires at least: 6.4
 * Requires PHP: 8.1
 * Text Domain: styrk-blocks
 * Update URI:  https://github.com/styrkreklame/styrk-blocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard: protects against double-load scenarios (symlink + mu
// plugin, manual include, etc.) that would otherwise fatal on function
// redeclaration below.
if ( defined( 'CB_CUSTOM_BLOCKS_LOADED' ) ) return;
define( 'CB_CUSTOM_BLOCKS_LOADED', true );

/* ── Fix asset URLs when plugin is symlinked ──────────────────────────────── */
add_filter( 'plugins_url', function ( string $url, string $path, string $plugin ): string {
	static $real = null, $sym = null;
	if ( $real === null ) {
		$sym  = wp_normalize_path( dirname( __FILE__ ) );
		$real = wp_normalize_path( dirname( realpath( __FILE__ ) ) );
	}
	if ( $real !== $sym ) {
		$url = str_replace(
			wp_normalize_path( $real ),
			wp_normalize_path( $sym ),
			wp_normalize_path( $url )
		);
	}
	return $url;
}, 10, 3 );

/* ── Includes ─────────────────────────────────────────────────────────────── */
require_once __DIR__ . '/includes/a11y-color.php';
require_once __DIR__ . '/includes/updater.php';
require_once __DIR__ . '/includes/companion-theme.php';
require_once __DIR__ . '/includes/header-settings.php';
require_once __DIR__ . '/includes/footer-settings.php';
require_once __DIR__ . '/includes/footer-shortcodes.php';
require_once __DIR__ . '/includes/icons.php';
require_once __DIR__ . '/includes/webp-converter.php';
require_once __DIR__ . '/includes/search-settings.php';
require_once __DIR__ . '/includes/search-render.php';
require_once __DIR__ . '/includes/schema-person.php';

add_action( 'init', function () {
	/* Register shared block CSS so it loads on frontend AND inside the editor iframe. */
	$css_file = __DIR__ . '/build/style-index.css';
	if ( file_exists( $css_file ) ) {
		wp_register_style(
			'styrk-blocks-shared',
			plugins_url( 'build/style-index.css', __FILE__ ),
			[],
			(string) filemtime( $css_file )
		);
	}

	foreach ( glob( __DIR__ . '/build/blocks/*', GLOB_ONLYDIR ) as $block ) {
		register_block_type( $block );

		// Backward-compat: the plugin was previously named "Custom Blocks"
		// and blocks shipped under the `custom-blocks/` namespace. Posts
		// and template parts saved before the rename still reference those
		// old names. Register each block a SECOND time under its legacy
		// name so existing content keeps rendering without a DB migration.
		// New content saves under `styrk-blocks/` — no harm.
		$block_json = $block . '/block.json';
		if ( file_exists( $block_json ) ) {
			$data = json_decode( (string) file_get_contents( $block_json ), true );
			$new_name = is_array( $data ) ? ( $data['name'] ?? '' ) : '';
			if ( is_string( $new_name ) && strpos( $new_name, 'styrk-blocks/' ) === 0 ) {
				$legacy_name = 'custom-blocks/' . substr( $new_name, strlen( 'styrk-blocks/' ) );
				if ( ! \WP_Block_Type_Registry::get_instance()->is_registered( $legacy_name ) ) {
					register_block_type( $block, [ 'name' => $legacy_name ] );
				}
			}
		}
	}

	/*
	 * OPcache caches index.asset.php files, so register_block_type() may read
	 * stale version hashes after a webpack rebuild. Fix this by re-stamping every
	 * styrk-blocks script version using filemtime() — a plain stat() call that
	 * OPcache never touches.
	 */
	$wp_scripts = wp_scripts();
	foreach ( $wp_scripts->registered as $handle => $script ) {
		if ( ! str_starts_with( $handle, 'styrk-blocks-' ) ) {
			continue;
		}
		// Resolve the handle's src to an absolute path.
		$src = $script->src;
		// Strip query-string and WP site URL prefix to get a relative path.
		$src = strtok( $src, '?' );
		$abs = str_replace(
			content_url( 'plugins/styrk-blocks/' ),
			__DIR__ . '/',
			$src
		);
		if ( file_exists( $abs ) ) {
			$script->ver = (string) filemtime( $abs );
		}
	}
} );

/* Enqueue the shared CSS both on the frontend and inside the block editor canvas. */
add_action( 'enqueue_block_assets', function () {
	if ( wp_style_is( 'styrk-blocks-shared', 'registered' ) ) {
		wp_enqueue_style( 'styrk-blocks-shared' );
	}
} );

/* Load Fraunces (display serif used by page-header) inside the editor iframe
   so the editor preview matches the rendered frontend. On the frontend, the
   page-header block's render.php lazy-enqueues this stylesheet only on pages
   that actually render the block. */
add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style(
		'styrk-blocks-fraunces',
		'https://fonts.bunny.net/css?family=fraunces:400,500&display=swap',
		[],
		null
	);

	/* Editor-side plugins (PluginDocumentSettingPanel, etc.) live under
	 * build/plugins/<name>/index.js, each with a webpack-generated
	 * index.asset.php declaring WP deps. Enqueue every one automatically —
	 * new editor plugins just need to drop a folder in src/plugins/ and
	 * webpack.config.js to register the entry, no PHP boilerplate. */
	$plugins_dir = __DIR__ . '/build/plugins';
	if ( ! is_dir( $plugins_dir ) ) return;
	foreach ( glob( $plugins_dir . '/*', GLOB_ONLYDIR ) as $plugin_dir ) {
		$slug     = basename( $plugin_dir );
		$js_file  = $plugin_dir . '/index.js';
		$asset_php= $plugin_dir . '/index.asset.php';
		if ( ! file_exists( $js_file ) || ! file_exists( $asset_php ) ) continue;

		$asset   = include $asset_php;
		$deps    = is_array( $asset['dependencies'] ?? null ) ? $asset['dependencies'] : [];
		$version = (string) ( $asset['version'] ?? filemtime( $js_file ) );

		wp_enqueue_script(
			'styrk-blocks-plugin-' . $slug,
			plugins_url( 'build/plugins/' . $slug . '/index.js', __FILE__ ),
			$deps,
			$version,
			true
		);
	}
} );

function custom_blocks_register_cpt(): void {
	register_post_type( 'employee', [
		'labels' => [
			'name'          => __( 'Employees',        'styrk-blocks' ),
			'singular_name' => __( 'Employee',         'styrk-blocks' ),
			'add_new_item'  => __( 'Add New Employee', 'styrk-blocks' ),
			'edit_item'     => __( 'Edit Employee',    'styrk-blocks' ),
		],
		'public'       => true,
		'show_in_rest' => true,
		'supports'     => [ 'title', 'thumbnail', 'custom-fields' ],
		'menu_icon'    => 'dashicons-id',
		'has_archive'  => true,
		'rewrite'      => [ 'slug' => 'team' ],
	] );

	register_taxonomy( 'employee_department', 'employee', [
		'labels'       => [ 'name' => __( 'Departments', 'styrk-blocks' ) ],
		'public'       => true,
		'show_in_rest' => true,
		'hierarchical' => true,
	] );
}
add_action( 'init', 'custom_blocks_register_cpt' );

function custom_blocks_register_meta(): void {
	$fields = [
		'_cb_occupation' => [ 'sanitize_callback' => 'sanitize_text_field' ],
		'_cb_email'      => [ 'sanitize_callback' => 'sanitize_email' ],
		'_cb_phone'      => [ 'sanitize_callback' => 'sanitize_text_field' ],
		'_cb_background' => [ 'sanitize_callback' => 'sanitize_textarea_field', 'type' => 'string' ],
		'_cb_linkedin'   => [ 'sanitize_callback' => 'esc_url_raw' ],
	];

	foreach ( $fields as $key => $extra ) {
		register_post_meta( 'employee', $key, array_merge( [
			'single'        => true,
			'type'          => 'string',
			'default'       => '',
			'show_in_rest'  => true,
			'auth_callback' => fn() => current_user_can( 'edit_posts' ),
		], $extra ) );
	}
}
add_action( 'init', 'custom_blocks_register_meta' );



function custom_blocks_categories( array $categories ): array {
	return array_merge(
		[ [ 'slug' => 'styrk-blocks', 'title' => __( 'Site Blocks', 'styrk-blocks' ) ] ],
		$categories
	);
}
add_filter( 'block_categories_all', 'custom_blocks_categories' );


/* ── Block pattern category ──────────────────────────────────────────────────
 * Groups all patterns under one labelled tab in the block inserter.
 * -------------------------------------------------------------------------- */
function custom_blocks_register_pattern_category(): void {
	register_block_pattern_category(
		'styrk-blocks',
		[ 'label' => __( 'Styrk Blocks', 'styrk-blocks' ) ]
	);
}
add_action( 'init', 'custom_blocks_register_pattern_category' );

/* ── Block patterns ──────────────────────────────────────────────────────────
 * Pre-built section templates. Each pattern injects one or more blocks with
 * sensible defaults so the user just swaps text/media rather than configuring
 * every setting from scratch.
 * -------------------------------------------------------------------------- */
function custom_blocks_register_patterns(): void {

	// ── Hero ─────────────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/hero-dark', [
		'title'       => __( 'Dark Hero', 'styrk-blocks' ),
		'description' => __( 'Full-screen dark hero with headline, sub-text and a CTA button.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/hero {"align":"full","heading":"Din overskrift her","subtext":"Kort, beskrivende ingress som forteller hva bedriften tilbyr og til hvem.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt","overlayOpacity":40} /-->',
	] );

	// ── Rich text section ────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/rich-text-left', [
		'title'       => __( 'Text Section', 'styrk-blocks' ),
		'description' => __( 'Left-aligned eyebrow, heading, body text and optional CTA link.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/rich-text-section {"align":"full","eyebrow":"Eyebrow","heading":"Seksjonens overskrift","body":"<p>Erstatt denne teksten med en kort beskrivelse av seksjonen. To eller tre setninger fungerer best.</p>","ctaLabel":"Les mer","ctaUrl":"#"} /-->',
	] );

	// ── Split section — image left ────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/split-image-left', [
		'title'       => __( 'Split — Image Left', 'styrk-blocks' ),
		'description' => __( 'Two-column layout: image on the left, heading + body + CTA on the right.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/split-section {"align":"full","eyebrow":"Eyebrow","heading":"Overskrift for to-kolonne-seksjon","body":"Plass til en kort beskrivende tekst som passer ved siden av et bilde eller en video.","ctaLabel":"Lenketekst","ctaUrl":"#","imageRight":false} /-->',
	] );

	// ── Split section — image right ───────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/split-image-right', [
		'title'       => __( 'Split — Image Right', 'styrk-blocks' ),
		'description' => __( 'Two-column layout: heading + body + CTA on the left, image on the right.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/split-section {"align":"full","eyebrow":"Eyebrow","heading":"Overskrift for to-kolonne-seksjon","body":"Plass til en kort beskrivende tekst som passer ved siden av et bilde eller en video.","ctaLabel":"Lenketekst","ctaUrl":"#","imageRight":true} /-->',
	] );

	// ── Feature cards ────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/feature-cards', [
		'title'       => __( 'Feature Cards (3 col)', 'styrk-blocks' ),
		'description' => __( 'Three icon cards — great for services, benefits or key points.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/feature-cards {"align":"full","eyebrow":"Eyebrow","heading":"Seksjonsoverskrift","columns":3,"items":[{"icon":"","heading":"Korttittel 1","body":"Beskrivende tekst for det første kortet."},{"icon":"","heading":"Korttittel 2","body":"Beskrivende tekst for det andre kortet."},{"icon":"","heading":"Korttittel 3","body":"Beskrivende tekst for det tredje kortet."}]} /-->',
	] );

	// ── Media grid — portrait ─────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/media-grid-portrait', [
		'title'       => __( 'Media Grid — Portrait', 'styrk-blocks' ),
		'description' => __( '4 portrait-format image or video slots in a row. Great for portfolios.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/media-grid {"align":"full","aspectRatio":"portrait","columns":4,"gap":"sm","radius":8,"sectionPad":true} /-->',
	] );

	// ── Stats row ────────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/stats-row', [
		'title'       => __( 'Stats Row', 'styrk-blocks' ),
		'description' => __( 'Three key numbers side by side — great for social proof.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/stats-row {"align":"full"} /-->',
	] );

	// ── Testimonial ──────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/testimonial', [
		'title'       => __( 'Testimonial', 'styrk-blocks' ),
		'description' => __( 'A single large quote with attribution — great for social proof.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/testimonial {"align":"full","quote":"Et kort, troverdig sitat fra en kunde går her. To eller tre setninger fungerer best.","authorName":"Kundens navn","authorRole":"Stilling, Bedrift"} /-->',
	] );

	// ── CTA section ──────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/cta-dark', [
		'title'       => __( 'CTA — Dark Banner', 'styrk-blocks' ),
		'description' => __( 'Full-width call-to-action banner with headline and button.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/cta-section {"align":"full","heading":"Klar for å komme i gang?","subtext":"Kort sluttoppfordring som leder leseren videre.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt"} /-->',
	] );

	// ── FAQ accordion ────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/faq', [
		'title'       => __( 'FAQ Accordion', 'styrk-blocks' ),
		'description' => __( 'Expandable questions and answers — great for common objections.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/faq-accordion {"align":"full","eyebrow":"Spørsmål og svar","heading":"Ofte stilte spørsmål"} /-->',
	] );

	// ── Logo strip ───────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/logo-strip', [
		'title'       => __( 'Partner Logo Strip', 'styrk-blocks' ),
		'description' => __( 'Horizontal scrolling ticker of partner or client logos.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/logo-strip {"align":"full","eyebrow":"Samarbeidspartnere"} /-->',
	] );

	// ── Full landing page ─────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/landing-page', [
		'title'       => __( 'Complete Landing Page', 'styrk-blocks' ),
		'description' => __( 'Hero → Features → Split → Stats → Testimonial → CTA. A full page in one click.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     =>
			'<!-- wp:styrk-blocks/hero {"align":"full","heading":"Din overskrift her","subtext":"Kort, beskrivende ingress som forteller hva bedriften tilbyr og til hvem.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt","overlayOpacity":40} /-->'
			. "\n" .
			'<!-- wp:styrk-blocks/feature-cards {"align":"full","eyebrow":"Eyebrow","heading":"Seksjonsoverskrift","columns":3,"items":[{"icon":"","heading":"Korttittel 1","body":"Beskrivende tekst for det første kortet."},{"icon":"","heading":"Korttittel 2","body":"Beskrivende tekst for det andre kortet."},{"icon":"","heading":"Korttittel 3","body":"Beskrivende tekst for det tredje kortet."}]} /-->'
			. "\n" .
			'<!-- wp:styrk-blocks/split-section {"align":"full","eyebrow":"Eyebrow","heading":"Overskrift for to-kolonne-seksjon","body":"Plass til en kort beskrivende tekst som passer ved siden av et bilde eller en video.","ctaLabel":"Les mer","ctaUrl":"#","imageRight":false} /-->'
			. "\n" .
			'<!-- wp:styrk-blocks/stats-row {"align":"full","items":[{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"},{"value":"00","label":"Beskrivelse","prefix":"","suffix":""},{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"}]} /-->'
			. "\n" .
			'<!-- wp:styrk-blocks/testimonial {"align":"full","quote":"Et kort, troverdig sitat fra en kunde går her. To eller tre setninger fungerer best.","authorName":"Kundens navn","authorRole":"Stilling, Bedrift"} /-->'
			. "\n" .
			'<!-- wp:styrk-blocks/cta-section {"align":"full","heading":"Klar for å komme i gang?","subtext":"Kort sluttoppfordring som leder leseren videre.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt"} /-->',
	] );

	// ── Page Header (inner page default) ──────────────────────────────────────
	register_block_pattern( 'styrk-blocks/page-header-default', [
		'title'       => __( 'Page Header — Inner Page', 'styrk-blocks' ),
		'description' => __( 'Editorial header for inner pages: serif title on light surface with auto breadcrumb, teal hairline and optional subtitle. Insert at the top of non-frontpage content, replacing any existing hero block.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/page-header {"align":"full","subtitle":"Kort ingress som rammer inn hva denne siden handler om.","useTitleFromPost":true} /-->',
	] );
}
add_action( 'init', 'custom_blocks_register_patterns' );

function custom_blocks_add_meta_box(): void {
	add_meta_box(
		'cb_employee_details',
		__( 'Employee Details', 'styrk-blocks' ),
		'custom_blocks_meta_box_html',
		'employee',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'custom_blocks_add_meta_box' );

function custom_blocks_meta_box_html( WP_Post $post ): void {
	wp_nonce_field( 'cb_employee_save', 'cb_employee_nonce' );

	$fields = [
		'_cb_occupation' => [
			'label'       => __( 'Occupation / Title', 'styrk-blocks' ),
			'type'        => 'text',
			'placeholder' => __( 'e.g. Senior Developer', 'styrk-blocks' ),
		],
		'_cb_email' => [
			'label'       => __( 'Email', 'styrk-blocks' ),
			'type'        => 'email',
			'placeholder' => 'name@example.com',
		],
		'_cb_phone' => [
			'label'       => __( 'Phone', 'styrk-blocks' ),
			'type'        => 'tel',
			'placeholder' => '+47 900 00 000',
		],
		'_cb_linkedin' => [
			'label'       => __( 'LinkedIn URL', 'styrk-blocks' ),
			'type'        => 'url',
			'placeholder' => 'https://linkedin.com/in/…',
		],
	];
	?>
	<style>
		#cb_employee_details .cb-field { display:flex; flex-direction:column; gap:4px; margin-bottom:16px; }
		#cb_employee_details .cb-field:last-child { margin-bottom:0; }
		#cb_employee_details label { font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:.04em; color:#1e1e1e; }
		#cb_employee_details input[type=text],
		#cb_employee_details input[type=email],
		#cb_employee_details input[type=tel],
		#cb_employee_details input[type=url],
		#cb_employee_details textarea { width:100%; padding:8px 10px; border:1px solid #c3c4c7; border-radius:4px; font-size:14px; line-height:1.5; box-shadow:inset 0 1px 2px rgba(0,0,0,.07); }
		#cb_employee_details input:focus,
		#cb_employee_details textarea:focus { border-color:#2271b1; box-shadow:0 0 0 1px #2271b1; outline:none; }
		#cb_employee_details textarea { resize:vertical; min-height:90px; }
	</style>

	<?php foreach ( $fields as $key => $field ) :
		$value = get_post_meta( $post->ID, $key, true );
	?>
		<div class="cb-field">
			<label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
			<input
				type="<?php echo esc_attr( $field['type'] ); ?>"
				id="<?php echo esc_attr( $key ); ?>"
				name="<?php echo esc_attr( $key ); ?>"
				value="<?php echo esc_attr( $value ); ?>"
				placeholder="<?php echo esc_attr( $field['placeholder'] ); ?>"
			/>
		</div>
	<?php endforeach;

	$background = get_post_meta( $post->ID, '_cb_background', true );
	?>
	<div class="cb-field">
		<label for="_cb_background"><?php esc_html_e( 'Background', 'styrk-blocks' ); ?></label>
		<textarea
			id="_cb_background"
			name="_cb_background"
			placeholder="<?php esc_attr_e( 'Short professional bio shown on the team page.', 'styrk-blocks' ); ?>"
		><?php echo esc_textarea( $background ); ?></textarea>
	</div>
	<?php
}

function custom_blocks_save_meta( int $post_id ): void {
	if (
		! isset( $_POST['cb_employee_nonce'] ) ||
		! wp_verify_nonce( sanitize_key( $_POST['cb_employee_nonce'] ), 'cb_employee_save' ) ||
		( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ||
		! current_user_can( 'edit_post', $post_id )
	) {
		return;
	}

	$text_fields = [ '_cb_occupation', '_cb_phone' ];
	foreach ( $text_fields as $key ) {
		if ( isset( $_POST[ $key ] ) ) {
			update_post_meta( $post_id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
		}
	}

	if ( isset( $_POST['_cb_email'] ) ) {
		update_post_meta( $post_id, '_cb_email', sanitize_email( wp_unslash( $_POST['_cb_email'] ) ) );
	}
	if ( isset( $_POST['_cb_linkedin'] ) ) {
		update_post_meta( $post_id, '_cb_linkedin', esc_url_raw( wp_unslash( $_POST['_cb_linkedin'] ) ) );
	}
	if ( isset( $_POST['_cb_background'] ) ) {
		update_post_meta( $post_id, '_cb_background', sanitize_textarea_field( wp_unslash( $_POST['_cb_background'] ) ) );
	}
}
add_action( 'save_post_employee', 'custom_blocks_save_meta' );

add_action( 'wp_loaded', function () {
	if ( get_option( 'viken_pages_v8' ) ) return;

	$services_content = '<!-- wp:styrk-blocks/hero {"align":"full","heading":"Tjenester","subtext":"Kort, beskrivende ingress om hvilke tjenester bedriften tilbyr.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt","overlayOpacity":50} /-->

<!-- wp:styrk-blocks/rich-text-section {"align":"full","eyebrow":"Eyebrow","heading":"Seksjonens overskrift","body":"<p>Erstatt denne teksten med en kort beskrivelse av hva bedriften tilbyr. Hold det enkelt – to eller tre setninger fungerer ofte best.</p>","centered":true} /-->

<!-- wp:styrk-blocks/feature-cards {"align":"full","eyebrow":"Eyebrow","heading":"Seksjonsoverskrift","centered":true,"columns":3,"items":[{"icon":"","heading":"Tjeneste 1","body":"Beskrivende tekst for den første tjenesten."},{"icon":"","heading":"Tjeneste 2","body":"Beskrivende tekst for den andre tjenesten."},{"icon":"","heading":"Tjeneste 3","body":"Beskrivende tekst for den tredje tjenesten."},{"icon":"","heading":"Tjeneste 4","body":"Beskrivende tekst for den fjerde tjenesten."},{"icon":"","heading":"Tjeneste 5","body":"Beskrivende tekst for den femte tjenesten."},{"icon":"","heading":"Tjeneste 6","body":"Beskrivende tekst for den sjette tjenesten."}]} /-->

<!-- wp:styrk-blocks/stats-row {"align":"full","eyebrow":"Eyebrow","heading":"Tall som teller","centered":true,"items":[{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"},{"value":"00","label":"Beskrivelse","prefix":"","suffix":""},{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"},{"value":"00","label":"Beskrivelse","prefix":"","suffix":"%"}]} /-->

<!-- wp:styrk-blocks/testimonial {"align":"full","quote":"Et kort, troverdig sitat fra en kunde går her. To eller tre setninger fungerer best.","authorName":"Kundens navn","authorRole":"Stilling, Bedrift"} /-->

<!-- wp:styrk-blocks/cta-section {"align":"full","heading":"Klar for å komme i gang?","body":"Kort sluttoppfordring som leder leseren videre.","primaryLabel":"Ta kontakt","primaryUrl":"/kontakt","accentBg":true} /-->';

	$contact_content = '<!-- wp:styrk-blocks/hero {"align":"full","heading":"Kontakt","subtext":"Kort ingress som forteller hvordan kunder kan ta kontakt.","ctaLabel":"","ctaUrl":"","overlayOpacity":55} /-->

<!-- wp:styrk-blocks/rich-text-section {"align":"full","eyebrow":"Eyebrow","heading":"Vi hører gjerne fra deg","body":"Erstatt denne teksten med en kort kontaktinvitasjon. To eller tre setninger fungerer best.","centered":true} /-->

<!-- wp:styrk-blocks/contact-section {"align":"full"} /-->

<!-- wp:styrk-blocks/faq-accordion {"align":"full","eyebrow":"Spørsmål og svar","heading":"Ofte stilte spørsmål","items":[{"question":"Spørsmål 1?","answer":"Plass til et tydelig, kort svar på spørsmålet over."},{"question":"Spørsmål 2?","answer":"Plass til et tydelig, kort svar på spørsmålet over."},{"question":"Spørsmål 3?","answer":"Plass til et tydelig, kort svar på spørsmålet over."},{"question":"Spørsmål 4?","answer":"Plass til et tydelig, kort svar på spørsmålet over."}]} /-->

<!-- wp:styrk-blocks/cta-section {"align":"full","heading":"Ring oss direkte","body":"+47 00 00 00 00 eller send e-post til post@bedriftsnavn.no","primaryLabel":"Send e-post","primaryUrl":"mailto:post@bedriftsnavn.no","accentBg":false} /-->';

	$find_services = get_posts( [ 'post_type' => 'page', 'name' => 'services', 'numberposts' => 1, 'post_status' => 'any' ] );
	$find_contact  = get_posts( [ 'post_type' => 'page', 'name' => 'contact',  'numberposts' => 1, 'post_status' => 'any' ] );

	$services_data = [
		'post_title'   => 'Tjenester',
		'post_name'    => 'services',
		'post_content' => $services_content,
		'post_status'  => 'publish',
		'post_type'    => 'page',
		'post_author'  => 1,
	];
	$contact_data = [
		'post_title'   => 'Kontakt',
		'post_name'    => 'contact',
		'post_content' => $contact_content,
		'post_status'  => 'publish',
		'post_type'    => 'page',
		'post_author'  => 1,
	];

	if ( ! empty( $find_services ) ) {
		$services_data['ID'] = $find_services[0]->ID;
		$services_id = wp_update_post( $services_data );
	} else {
		$services_id = wp_insert_post( $services_data );
	}

	if ( ! empty( $find_contact ) ) {
		$contact_data['ID'] = $find_contact[0]->ID;
		$contact_id = wp_update_post( $contact_data );
	} else {
		$contact_id = wp_insert_post( $contact_data );
	}

	if ( $services_id && $contact_id && ! is_wp_error( $services_id ) && ! is_wp_error( $contact_id ) ) {
		update_option( 'viken_pages_v8', true );
	}
} );

/* ── Homepage content updater ────────────────────────────────────────────────
 * Sets/updates the static front page with neutral placeholder content
 * the first time the plugin runs. Existing installs (where the option
 * key is already set) are skipped — the seeder never overwrites real
 * content once a site has gone past first-run.
 * -------------------------------------------------------------------------- */
add_action( 'wp_loaded', function () {
	if ( get_option( 'viken_homepage_v3' ) ) return;

	$homepage_content = '<!-- wp:styrk-blocks/hero {"align":"full","heading":"Din overskrift her","subtext":"Kort, beskrivende ingress som forteller hva bedriften tilbyr og til hvem.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt","overlayOpacity":40} /-->

<!-- wp:styrk-blocks/rich-text-section {"align":"full","eyebrow":"Om oss","heading":"Seksjonens overskrift","body":"<p>Erstatt denne teksten med en kort presentasjon av bedriften. To korte avsnitt på to–tre setninger fungerer ofte best.</p><p>Snakk om hvem dere er, hva dere brenner for, og hvordan dere skiller dere fra konkurrentene.</p>","ctaLabel":"Les mer","ctaUrl":"/om-oss"} /-->

<!-- wp:styrk-blocks/feature-cards {"align":"full","eyebrow":"Eyebrow","heading":"Hva vi tilbyr","centered":true,"columns":3,"items":[{"icon":"","heading":"Tjeneste 1","body":"Kort, beskrivende tekst for det første tilbudet."},{"icon":"","heading":"Tjeneste 2","body":"Kort, beskrivende tekst for det andre tilbudet."},{"icon":"","heading":"Tjeneste 3","body":"Kort, beskrivende tekst for det tredje tilbudet."},{"icon":"","heading":"Tjeneste 4","body":"Kort, beskrivende tekst for det fjerde tilbudet."},{"icon":"","heading":"Tjeneste 5","body":"Kort, beskrivende tekst for det femte tilbudet."},{"icon":"","heading":"Tjeneste 6","body":"Kort, beskrivende tekst for det sjette tilbudet."}]} /-->

<!-- wp:styrk-blocks/stats-row {"align":"full","eyebrow":"Eyebrow","heading":"Tall som teller","centered":true,"items":[{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"},{"value":"00","label":"Beskrivelse","prefix":"","suffix":""},{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"},{"value":"00","label":"Beskrivelse","prefix":"","suffix":"%"}]} /-->

<!-- wp:styrk-blocks/split-section {"align":"full","eyebrow":"Eyebrow","heading":"Overskrift for to-kolonne-seksjon","body":"Plass til en kort beskrivende tekst som passer ved siden av et bilde eller en video.","ctaLabel":"Lenketekst","ctaUrl":"#","imageRight":true} /-->

<!-- wp:styrk-blocks/cta-section {"align":"full","heading":"Klar for å komme i gang?","subtext":"Kort sluttoppfordring som leder leseren videre.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt"} /-->';

	// Find or create the front page
	$front_page_id = (int) get_option( 'page_on_front' );
	if ( ! $front_page_id ) {
		$find_home = get_posts( [ 'post_type' => 'page', 'name' => 'home', 'numberposts' => 1, 'post_status' => 'any' ] );
		if ( ! empty( $find_home ) ) {
			$front_page_id = $find_home[0]->ID;
		}
	}
	if ( ! $front_page_id ) {
		$find_front = get_posts( [ 'post_type' => 'page', 'name' => 'front-page', 'numberposts' => 1, 'post_status' => 'any' ] );
		if ( ! empty( $find_front ) ) {
			$front_page_id = $find_front[0]->ID;
		}
	}

	if ( $front_page_id ) {
		wp_update_post( [
			'ID'           => $front_page_id,
			'post_content' => $homepage_content,
			'post_status'  => 'publish',
		] );
	} else {
		$front_page_id = wp_insert_post( [
			'post_title'   => 'Hjem',
			'post_name'    => 'home',
			'post_content' => $homepage_content,
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_author'  => 1,
		] );
	}

	if ( $front_page_id && ! is_wp_error( $front_page_id ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id );
		update_option( 'viken_homepage_v3', true );
	}
} );

/*
 * ── Header template-part updater ────────────────────────────────────────────
 * Replaces whatever is in the DB header template-part with the react-header
 * block so ALL pages use the React header consistently.
 * The react-header render.php reads the logo from WP Customizer (custom-logo)
 * so no hardcoded logo path is needed here.
 * Bump the option key (viken_header_v2) to force a re-run after changes.
 */
add_action( 'wp_loaded', function () {
	if ( get_option( 'viken_header_v2' ) ) return;

	// Header block with no hardcoded logo — render.php resolves it from Customizer
	$react_header_content =
		'<!-- wp:styrk-blocks/react-header {"align":"full"} -->' . "\n"
		. '<div class="wp-block-styrk-blocks-react-header react-header-mount-point alignfull"></div>' . "\n"
		. '<!-- /wp:styrk-blocks/react-header -->';

	$parts = get_posts( [
		'post_type'      => 'wp_template_part',
		'posts_per_page' => -1,
		'post_status'    => 'publish',
	] );

	$updated = false;
	foreach ( $parts as $part ) {
		if ( strpos( $part->post_name, 'header' ) !== false ) {
			wp_update_post( [
				'ID'           => $part->ID,
				'post_content' => $react_header_content,
			] );
			$updated = true;
		}
	}

	if ( $updated ) {
		update_option( 'viken_header_v2', true );
	}
} );

/*
 * ── Footer template-part updater ─────────────────────────────────────────────
 * Uses wp:site-logo and wp:site-title core blocks so the footer reads from
 * Appearance → Customize → Site Identity (no hardcoded logo/name).
 * Bump version key (viken_footer_v4) to force a re-run after changes.
 */
/* ── Social Link CPT ─────────────────────────────────────────────────────────
 * Manageable social media links for the footer.
 * Admin can add/remove platforms (Facebook, Instagram, LinkedIn, etc.)
 * with a URL and icon selection. Rendered dynamically in the footer.
 * -------------------------------------------------------------------------- */
function custom_blocks_register_social_link_cpt(): void {
	register_post_type( 'social_link', [
		'labels' => [
			'name'          => __( 'Social Links',       'styrk-blocks' ),
			'singular_name' => __( 'Social Link',        'styrk-blocks' ),
			'add_new_item'  => __( 'Add New Social Link','styrk-blocks' ),
			'edit_item'     => __( 'Edit Social Link',   'styrk-blocks' ),
			'menu_name'     => __( 'Social Links',       'styrk-blocks' ),
		],
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => true,
		'show_in_rest' => true,
		'supports'     => [ 'title' ],
		'menu_icon'    => 'dashicons-share',
		'rewrite'      => false,
	] );

	register_post_meta( 'social_link', '_cb_social_url', [
		'single'        => true,
		'type'          => 'string',
		'default'       => '',
		'show_in_rest'  => true,
		'sanitize_callback' => 'esc_url_raw',
		'auth_callback' => fn() => current_user_can( 'edit_posts' ),
	] );

	register_post_meta( 'social_link', '_cb_social_platform', [
		'single'        => true,
		'type'          => 'string',
		'default'       => 'website',
		'show_in_rest'  => true,
		'sanitize_callback' => 'sanitize_text_field',
		'auth_callback' => fn() => current_user_can( 'edit_posts' ),
	] );
}
add_action( 'init', 'custom_blocks_register_social_link_cpt' );

/* Social Link meta box */
function custom_blocks_social_link_meta_box(): void {
	add_meta_box(
		'cb_social_link_details',
		__( 'Social Link Details', 'styrk-blocks' ),
		'custom_blocks_social_link_meta_box_html',
		'social_link',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'custom_blocks_social_link_meta_box' );

function custom_blocks_social_link_meta_box_html( WP_Post $post ): void {
	wp_nonce_field( 'cb_social_link_save', 'cb_social_link_nonce' );
	$url      = get_post_meta( $post->ID, '_cb_social_url', true );
	$platform = get_post_meta( $post->ID, '_cb_social_platform', true ) ?: 'website';
	$platforms = [ 'facebook', 'instagram', 'linkedin', 'twitter', 'youtube', 'tiktok', 'website' ];
	?>
	<style>
		#cb_social_link_details .cb-field { display:flex; flex-direction:column; gap:4px; margin-bottom:16px; }
		#cb_social_link_details label { font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:.04em; }
		#cb_social_link_details input, #cb_social_link_details select { width:100%; padding:8px 10px; border:1px solid #c3c4c7; border-radius:4px; font-size:14px; }
	</style>
	<div class="cb-field">
		<label for="_cb_social_platform"><?php esc_html_e( 'Platform', 'styrk-blocks' ); ?></label>
		<select id="_cb_social_platform" name="_cb_social_platform">
			<?php foreach ( $platforms as $p ) : ?>
				<option value="<?php echo esc_attr( $p ); ?>" <?php selected( $platform, $p ); ?>><?php echo esc_html( ucfirst( $p ) ); ?></option>
			<?php endforeach; ?>
		</select>
	</div>
	<div class="cb-field">
		<label for="_cb_social_url"><?php esc_html_e( 'URL', 'styrk-blocks' ); ?></label>
		<input type="url" id="_cb_social_url" name="_cb_social_url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://..." />
	</div>
	<?php
}

function custom_blocks_save_social_link_meta( int $post_id ): void {
	if (
		! isset( $_POST['cb_social_link_nonce'] ) ||
		! wp_verify_nonce( sanitize_key( $_POST['cb_social_link_nonce'] ), 'cb_social_link_save' ) ||
		( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ||
		! current_user_can( 'edit_post', $post_id )
	) {
		return;
	}
	if ( isset( $_POST['_cb_social_url'] ) ) {
		update_post_meta( $post_id, '_cb_social_url', esc_url_raw( wp_unslash( $_POST['_cb_social_url'] ) ) );
	}
	if ( isset( $_POST['_cb_social_platform'] ) ) {
		update_post_meta( $post_id, '_cb_social_platform', sanitize_text_field( wp_unslash( $_POST['_cb_social_platform'] ) ) );
	}
}
add_action( 'save_post_social_link', 'custom_blocks_save_social_link_meta' );

/* ── Render social links in footer (PHP helper) ─────────────────────────────
 * Called from the footer template part via a shortcode [social_links].
 * -------------------------------------------------------------------------- */
function custom_blocks_social_links_shortcode(): string {
	$links = get_posts( [
		'post_type'      => 'social_link',
		'posts_per_page' => 20,
		'post_status'    => 'publish',
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
	] );

	if ( empty( $links ) ) return '';

	$svg_icons = [
		'facebook'  => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
		'instagram' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>',
		'linkedin'  => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
		'twitter'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
		'youtube'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814z"/><polygon fill="#fff" points="9.545,15.568 15.818,12 9.545,8.432"/></svg>',
		'tiktok'    => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/></svg>',
		'website'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
	];

	$html = '<div class="site-footer__social">';
	foreach ( $links as $link ) {
		$url      = get_post_meta( $link->ID, '_cb_social_url', true );
		$platform = get_post_meta( $link->ID, '_cb_social_platform', true ) ?: 'website';
		if ( ! $url ) continue;
		$icon  = $svg_icons[ $platform ] ?? $svg_icons['website'];
		$label = esc_attr( $link->post_title );
		$html .= '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . $label . '" class="site-footer__social-link">' . $icon . '</a>';
	}
	$html .= '</div>';
	return $html;
}
add_shortcode( 'social_links', 'custom_blocks_social_links_shortcode' );

/* ── Seed default social link entries ────────────────────────────────────────
 * Creates blank-URL placeholder entries so admins see the platforms they can
 * fill in. URLs default to '#' — admin must supply real URLs via the CPT
 * editor before the [social_links] shortcode renders the icons.
 * -------------------------------------------------------------------------- */
add_action( 'wp_loaded', function () {
	if ( get_option( 'viken_social_links_v1' ) ) return;

	$defaults = [
		[ 'title' => 'Facebook',  'platform' => 'facebook',  'url' => '' ],
		[ 'title' => 'Instagram', 'platform' => 'instagram', 'url' => '' ],
		[ 'title' => 'LinkedIn',  'platform' => 'linkedin',  'url' => '' ],
	];

	foreach ( $defaults as $i => $social ) {
		$id = wp_insert_post( [
			'post_title'  => $social['title'],
			'post_type'   => 'social_link',
			'post_status' => 'publish',
			'menu_order'  => $i,
		] );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_cb_social_platform', $social['platform'] );
			update_post_meta( $id, '_cb_social_url',      $social['url'] );
		}
	}

	update_option( 'viken_social_links_v1', true );
} );

/*
 * ── Footer template-part updater ─────────────────────────────────────────────
 * Uses wp:site-logo and wp:site-title core blocks so the footer reads from
 * Appearance → Customize → Site Identity (no hardcoded logo/name).
 * Includes social links via [social_links] shortcode (reads from CPT).
 * Bump version key to force a re-run after changes.
 */
add_action( 'wp_loaded', function () {
	if ( get_option( 'viken_footer_v9' ) ) return;

	$footer_content = '<!-- wp:group {"align":"full","className":"site-footer","layout":{"type":"default"}} -->
<div class="wp-block-group alignfull site-footer">

	<!-- wp:group {"className":"site-footer__inner","layout":{"type":"default"}} -->
	<div class="wp-block-group site-footer__inner">

		<!-- wp:shortcode -->[footer_logo]<!-- /wp:shortcode -->

		<!-- wp:columns {"className":"site-footer__cols"} -->
		<div class="wp-block-columns site-footer__cols">

			<!-- wp:column -->
			<div class="wp-block-column">
				<!-- wp:site-title {"className":"site-footer__col-heading","isLink":false} /-->
				<!-- wp:shortcode -->[footer_description]<!-- /wp:shortcode -->
			</div>
			<!-- /wp:column -->

			<!-- wp:column -->
			<div class="wp-block-column">
				<!-- wp:paragraph {"className":"site-footer__col-heading"} -->
				<p class="site-footer__col-heading">Kontakt</p>
				<!-- /wp:paragraph -->
				<!-- wp:shortcode -->[footer_contact]<!-- /wp:shortcode -->
			</div>
			<!-- /wp:column -->

			<!-- wp:column -->
			<div class="wp-block-column">
				<!-- wp:shortcode -->[footer_social_heading]<!-- /wp:shortcode -->
				<!-- wp:shortcode -->[social_links]<!-- /wp:shortcode -->
			</div>
			<!-- /wp:column -->

		</div>
		<!-- /wp:columns -->

	</div>
	<!-- /wp:group -->

	<!-- wp:group {"className":"site-footer__bar","layout":{"type":"default"}} -->
	<div class="wp-block-group site-footer__bar">
		<!-- wp:shortcode -->[footer_copyright]<!-- /wp:shortcode -->
	</div>
	<!-- /wp:group -->

</div>
<!-- /wp:group -->';

	$parts = get_posts( [
		'post_type'      => 'wp_template_part',
		'posts_per_page' => -1,
		'post_status'    => [ 'publish', 'auto-draft', 'draft' ],
	] );

	foreach ( $parts as $part ) {
		$name  = strtolower( $part->post_name  ?? '' );
		$title = strtolower( $part->post_title ?? '' );
		if ( strpos( $name, 'footer' ) !== false || strpos( $title, 'footer' ) !== false ) {
			wp_update_post( [
				'ID'           => $part->ID,
				'post_content' => $footer_content,
				'post_status'  => 'publish',
			] );
		}
	}

	update_option( 'viken_footer_v9', true );
} );