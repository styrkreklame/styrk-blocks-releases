# Changelog

All notable changes to this plugin are documented here. Format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/). This plugin
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [Unreleased]

---

## [0.10.207] - 2026-09-18

- feat(employee-grid): colour controls for the department badge

---

## [0.10.206] - 2026-09-18

- feat(employee-grid): søk/filter, kontroll-API for temaer, og redigering i kortet

---

## [0.10.205] - 2026-09-11

- chore: fjern Viken Regnskap fra designsystemet og bind om til Styrk-paletten

---

## [0.10.204] - 2026-09-03

- fix(blocks): dark-section defaults, client brand fallbacks, call-card controls

---

## [0.10.203] - 2026-09-02

- fix(featured-projects): stop the card's white bleeding out of the rounded clip

---

## [0.10.202] - 2026-09-01

- fix(contact-section): even out the two columns

---

## [0.10.201] - 2026-09-01

- fix(split-section): restore the eyebrow colour pickers

---

## [0.10.200] - 2026-08-27

- fix(split-section): portrait video fills its column on mobile

---

## [0.10.199] - 2026-08-27

- fix(services-selector): stop the fast-link buttons clipping off the right

---

## [0.10.198] - 2026-08-25

- fix(footer): org number above the opening-hours block, not inside it

---

## [0.10.197] - 2026-08-25

- feat(footer): opening hours as a first-class contact field

---

## [0.10.196] - 2026-08-24

- fix(employee-grid): even out the card contact panel

---

## [0.10.195] - 2026-08-21

- feat(split-section): controls for how the photo fits its slot

---

## [0.10.194] - 2026-08-21

- fix(media-grid): key the padding on layout, not on .alignfull

---

## [0.10.193] - 2026-08-21

- fix(media-grid): only pad the grid when it is full-bleed

---

## [0.10.192] - 2026-08-20

- chore: add a PR template that keeps the issue tracker honest

---

## [0.10.191] - 2026-08-20

- fix(hero): full-bleed section, capped media — no white bars, no blow-up

---

## [0.10.190] - 2026-08-20

- perf(css): stop shipping 101 KB of source comments to every visitor

---

## [0.10.189] - 2026-08-20

- fix(security): close XSS, direct-access, CSS-injection and meta-auth holes

---

## [0.10.188] - 2026-08-17

- feat(footer): make every footer value editable from Settings → Footer

---

## [0.10.187] - 2026-08-17

- feat(footer): optional link on the credit line

---

## [0.10.186] - 2026-08-17

- fix(footer): make the credits mark large enough to read

---

## [0.10.185] - 2026-08-14

- fix(employee): contact panel fills the card so all cards match

---

## [0.10.184] - 2026-08-14

- fix(employee): stop the card trigger growing so contact rows align

---

## [0.10.183] - 2026-08-14

- fix(employee): align the first contact row across cards

---

## [0.10.182] - 2026-08-14

- fix(hero): detail icons inherit the text they label

---

## [0.10.181] - 2026-08-14

- fix(contact,employee): separate each person; phone first; catalog icons

---

## [0.10.180] - 2026-08-14

- fix(employee,contact): first-line icon alignment + separate the company group

---

## [0.10.179] - 2026-08-14

- feat(footer): credit uses the Styrk icon + real text, not the wordmark image

---

## [0.10.178] - 2026-08-14

- fix(contact): put the radius chips where they can actually be seen

---

## [0.10.177] - 2026-08-13

- fix(editor): make every contact field readable, not just the map panel

---

## [0.10.176] - 2026-08-13

- fix(contact): make the map radius visible by rounding the iframe

---

## [0.10.175] - 2026-08-13

- feat(contact): map + submit radius controls, readable editor fields

---

## [0.10.174] - 2026-08-13

- feat(contact): map as the section base, one rhythm across both columns

---

## [0.10.173] - 2026-08-13

- fix(footer): badges size to their own aspect instead of the width cap

---

## [0.10.172] - 2026-08-13

- fix: editor CSS into the canvas, contact toggle spacing, collection filter actually hides

---

## [0.10.171] - 2026-08-13

- feat(collection): category filter + card colour controls

---

## [0.10.170] - 2026-08-13

- perf(css): stop shipping wp-admin CSS to visitors

---

## [0.10.169] - 2026-08-13

- fix(project): put the single-project body on the shared content rail

---

## [0.10.168] - 2026-08-13

- feat(footer): make certification badges legible and sizeable

---

## [0.10.167] - 2026-08-13

- fix(react-header): stop defaulting the hamburger to a foreign brand colour

---

## [0.10.166] - 2026-08-13

- feat(page-auto-hero): choose where the page title sits

---

## [0.10.165] - 2026-08-13

- feat(footer): optional external link per certification badge

---

## [0.10.164] - 2026-08-13

- fix(stats-row): dividers respect the frame width and lie the right way

---

## [0.10.163] - 2026-08-13

- fix(updater): stop rejecting good updates over a URL string mismatch

---

## [0.10.162] - 2026-08-13

- fix(collection): equal-size card media + optional category line

---

## [0.10.161] - 2026-08-13

- feat(hero): add 1/3 and 2/3 ingress widths

---

## [0.10.160] - 2026-08-13

- feat(stats-row): make the card frame optional and colourable

---

## [0.10.159] - 2026-08-13

- fix(css): give the project nav button a contrast-safe fill

---

## [0.10.158] - 2026-08-13

- fix(hero): stop emitting PHP warnings on a malformed heroOrder

---

## [0.10.157] - 2026-08-13

- chore(design-system): sync tokens to 2.0 — three tiers, no brand in the shared layer

---

## [0.10.156] - 2026-08-13

- fix(theme,css): stop boxing full-bleed sections, stop hardcoding the display face

---

## [0.10.155] - 2026-08-13

- fix(gates): inject theme.json font families, not just the palette

---

## [0.10.154] - 2026-08-13

- feat(updater): verify release signatures before install

---

## [0.10.153] - 2026-08-12

- fix(footer): stop shipping placeholder contact details to the front end

---

## [0.10.152] - 2026-08-11

- fix(stats-row): make the section text, card background and radius controls actually apply

---

## [0.10.151] - 2026-07-14

- chore: untrack tests/visual/diff — they are output, not source

---

## [0.10.150] - 2026-07-14

- fix(footer): $preview was never assigned — 6 PHP warnings on every Footer settings page

---

## [0.10.149] - 2026-07-14

- fix(footer): Legal Links is a label and a link, not a syntax to learn

---

## [0.10.148] - 2026-07-13

- ci: two gates that would have caught the whole of 2026-07-13

---

## [0.10.147] - 2026-07-13

- fix: make hardcoded colours reachable from the editor (+ style the footer cert badges)

---

## [0.10.146] - 2026-07-13

- fix(security): three stored XSS + blocking CI gates (visually inert — safe during freeze)

---

## [0.10.145] - 2026-07-10

- fix(contact-section): "Få veibeskrivelse" had no control, so it could never be turned off

---

## [0.10.144] - 2026-07-10

- fix(contact-section): optional note rendered an empty box on the front end

---

## [0.10.143] - 2026-07-10

- fix(contact-section): submit label + stop baking the radius default into markup

---

## [0.10.142] - 2026-07-10

- fix(contact-section): corner-radius control for the directions button

---

## [0.10.141] - 2026-07-10

- fix(react-header): restore the megamenu brand layer themes paint into

---

## [0.10.140] - 2026-07-10

- fix(hywer): employee modal photo fallback + contact-section invisible button labels

---

## [0.10.139] - 2026-07-10

- chore: stop committing build/ artifacts

---

## [0.10.138] - 2026-07-10

- feat(hero): reorderable eyebrow/heading/accent/subtext + eyebrow pill preset

---

## [0.10.137] - 2026-07-10

- feat(blocks): Collection (CPT) block, hero font/accent controls, (Styrk) titles

---

## [0.10.136] - 2026-07-10

- feat(hero): optional icons + theme colour controls for detail items

---

## [0.10.135] - 2026-07-07

- feat(hero): optional detail items + header/responsive fixes

---

## [0.10.134] - 2026-07-03

- feat(kit): shared RadiusChip + in-canvas eyebrow radius; contact-section readable labels + uniform band chip height

---

## [0.10.133] - 2026-07-02

- fix(rich-text-section): the new "Skrift" font control showed its label while the size/weight controls hid theirs, so it sat taller and pushed the options band out of line (overlapping the body text). Hide its label to match the others (option text is self-descriptive: Standardskrift / Ingress-skrift).

---

## [0.10.132] - 2026-07-02

- fix(employee-card): the email/phone contact-link text ignored the card text colour (hard-coded `.text-secondary`), so it stayed teal on the front end even when a colour was set. The links now honour the card text colour; the control is renamed "Tekst" since it colours the name AND the contact info.

---

## [0.10.131] - 2026-07-02

- feat(rich-text-section): body-text font option — pick "Ingress (display)" to render the copy in the same theme display font the hero lead uses, alongside the existing size/weight controls.

---

## [0.10.130] - 2026-07-01

- fix(hero): the subtext/ingress "Aa" typography popover used cramped, low-contrast segmented toggles (7 size options squeezed into one row, overlapping labels). Replaced with clear labelled dropdowns (font-size, font-weight, and for the subtext width) on a properly sized popover — readable and consistent with standard controls.

---

## [0.10.129] - 2026-07-01

- feat(hero): typography controls for the subtext and ingress. Subtext gets font-size, font-weight, an optional background banner, width (fit / capped 640px / full) and adjustable spacing above it (default tighter than before); ingress gets font-size + font-weight. Controls live behind a compact "Aa" popover per element so the band stays tidy. All additive — existing heroes unchanged except the slightly tighter default subtext gap.

---

## [0.10.128] - 2026-07-01

- fix(employee-card): the occupation/role pill rendered unstyled because the pill CSS was scoped to `.cb-employee-card` and the single card uses `.cb-employee-card-compact` — broadened the selector so the teal pill shows. Added the missing pill controls (Tittel-tekst colour, Tittel-BG, Pille-radius) matching the employee-grid, emitted the role styling on the pill, and renamed the card text control "Tekst" → "Navn" to clarify it sets the name colour.

---

## [0.10.127] - 2026-07-01

- feat(contact-section): optional divider between the header and the two columns — toggle it on in-canvas (+ skillelinje), with colour and 1–6px thickness controls, to mark the heading as its own section. Off by default; existing sections unchanged.

---

## [0.10.126] - 2026-07-01

- feat(blocks): HTML-anchor (id) field rolled out to 15 more section blocks — aktuelt, call-card, cta-band, employee-card, employee-grid, faq-accordion, featured-projects, logo-strip, media-grid, process, services-selector, testimonial, testimonials, video-reels, video-section. Set an id in the block's Advanced panel and link a menu/button to `#that-id`. (Emitted via the existing central `cb_apply_block_anchor` render filter.)

---

## [0.10.125] - 2026-07-01

- fix(contact-section): the Radius and Column-gap band controls were pill-shaped (border-radius 999px) while every other control chip is a rounded rectangle — made them match the standard `.cb-feature-card__swatch` chip (8px, 1px border) so the whole options band reads uniformly.

---

## [0.10.124] - 2026-07-01

- feat(split-section): clicking a section image now opens it in the shared lightbox (prev/next, keyboard, focus-trap) — the same viewer the media-grid uses, extracted into a reusable `[data-cb-lightbox]` handler. Image hover is smoother (gentler ease, honest zoom-in affordance now that the image is clickable).

---

## [0.10.123] - 2026-07-01

- feat(employee-card): single card background is now optional (transparent with no border/shadow when unset, matching the employee-grid card); role rendered as the same teal pill the grid uses. Left/center/right card alignment already available via the in-canvas control.

---

## [0.10.122] - 2026-07-01

- fix(layout): single shared content width (`--cb-content-max`, driven by the header's global "Content width" setting) now feeds the header, footer, contact block, page-auto-hero and every block rail — so they all line up instead of contact bleeding to 1440, footer capping at 1200 and blocks split 1280/1440. Keeps the prior responsive `--cb-rail` side-gutter unification.

---

## [0.10.121] - 2026-07-01

- fix(editor): section-controls band no longer clipped by `overflow:hidden` (was breaking out to 100vw); employee-grid settings now readable on the dark band and evenly stacked (removed the bespoke white panel + centred cap)

---

## [0.10.120] - 2026-06-29

- feat(hero, feature-cards): stat-label styling controls + card link affordance

---

## [0.10.119] - 2026-06-26

- feat(employee-card): section heading + intro text with per-element alignment

---

## [0.10.118] - 2026-06-26

- fix(employee-grid + hero): tag/pill radius controls, readable settings band, Josefin hero ingress

---

## [0.10.117] - 2026-06-26

- fix(hero ingress): Lato 700 not 800 — 800 isn't a loaded weight (rendered as Black = too fat)

---

## [0.10.116] - 2026-06-26

- feat(posts): [featured_caption] shortcode — caption under the post featured image

---

## [0.10.115] - 2026-06-26

- fix(testimonial): clearing SECTION BACKGROUND now actually clears it; quote can't clip in narrow columns

---

## [0.10.114] - 2026-06-26

- fix(employee): make the role/job-title editable in Employee Details (real fix)

---

## [0.10.113] - 2026-06-26

- fix(employee): make the job title (_cb_occupation) editable in the employee editor

---

## [0.10.112] - 2026-06-26

- fix(dnd): drag-reorder no longer hijacks RangeControl sliders (stuck-on-hover)

---

## [0.10.111] - 2026-06-26

- feat(search): pill + card radius and pill text/bg colour controls in Settings → Search

---

## [0.10.110] - 2026-06-26

- feat/ux: rich-text body size+weight inner controls; hero one side-element entry + generic wording

---

## [0.10.109] - 2026-06-26

- feat(rich-text-section): enable bold/italic/link in the body text

---

## [0.10.108] - 2026-06-26

- fix+feat(blocks): batch — section-text cascade, split slider, even band, body font-size, megamenu logo upload

---

## [0.10.107] - 2026-06-26

- fix(hero): keep media picker mounted while the modal is open (blank-upload fix)

---

## [0.10.106] - 2026-06-26

- fix(uploader): force html5 Plupload runtime to stop the blank media modal

---

## [0.10.105] - 2026-06-25

- fix(editor): section band — full editor width, flush top, content spacing, aligned controls

---

## [0.10.104] - 2026-06-25

- refactor(blocks): replace dashed settings boxes with clean ControlGroups; migrate services-selector (wave 6)

---

## [0.10.103] - 2026-06-25

- feat(blocks): drop native color/spacing/border supports (wave 5)

---

## [0.10.102] - 2026-06-25

- feat(react-header): move controls in-canvas, drop the sidebar (wave 4)

---

## [0.10.101] - 2026-06-25

- feat(blocks): tag colours + standardize colour controls into section-band groups

---

## [0.10.100] - 2026-06-24

- fix(contact-section): apply submit colours to embedded form buttons

---

## [0.10.99] - 2026-06-24

- fix(contact-section): underline contact-info links on hover

---

## [0.10.98] - 2026-06-24

- feat(split-section): rename column type "Bilde"→"Media" + radius control in video mode

---

## [0.10.97] - 2026-06-24

- feat(footer): optional, admin-editable newsletter column

---

## [0.10.96] - 2026-06-23

- fix(settings): card placeholder "Select image" opens the media modal

---

## [0.10.95] - 2026-06-23

- feat(blocks): CTA Band section controls + global card placeholder image

---

## [0.10.94] - 2026-06-22

- feat(settings): schematic section previews on Header + Footer pages

---

## [0.10.93] - 2026-06-22

- feat(header): visual swatch picker for all header colour fields

---

## [0.10.92] - 2026-06-22

- fix(split-section): clip video corners to border-radius

---

## [0.10.91] - 2026-06-22

- feat: header mobile colour controls + block polish

---

## [0.10.90] - 2026-06-19

- feat(featured-projects): move card/pill radius into the card-styling strip

---

## [0.10.89] - 2026-06-19

- feat(employee-grid): card corner-radius control + standardised section band

---

## [0.10.88] - 2026-06-19

- feat(blocks): standardise section-options band across all section blocks

---

## [0.10.87] - 2026-06-19

- fix(split-section): add remove button to image columns

---

## [0.10.86] - 2026-06-19

- fix(split-section): use the standard Hero-style section-options band

---

## [0.10.85] - 2026-06-19

- fix(controls): colour chips clearly visible on any section background

---

## [0.10.84] - 2026-06-19

- fix(split-section): real working column drag; remove redundant order toggle

---

## [0.10.83] - 2026-06-19

- fix(feature-cards): legible controls + add-card on a dark section bg

---

## [0.10.82] - 2026-06-19

- fix(split-section): top-align the two columns when both are text

---

## [0.10.81] - 2026-06-19

- fix(feature-cards): list layout no longer prints a literal <br>

---

## [0.10.80] - 2026-06-19

- fix(project-hero): align the title to the content rail (was too far left)

---

## [0.10.79] - 2026-06-19

- feat(testimonial): in-canvas section controller (Bakgrunn + Tekst chips)

---

## [0.10.78] - 2026-06-19

- fix(split-section): tallmerke radius control + keep it inside the image

---

## [0.10.77] - 2026-06-19

- feat(feature-cards): add section text-colour control + match the standard chip cluster

---

## [0.10.76] - 2026-06-19

- fix(testimonial): always wrap the quote in «…», never doubled

---

## [0.10.75] - 2026-06-19

- feat(feature-cards): in-canvas card corner-radius control

---

## [0.10.74] - 2026-06-19

- fix(split-section): typecheck — import cloneElement/Children from react, type column el

---

## [0.10.73] - 2026-06-19

- fix(split-section): right-side 'Tekst' pick now sticks (was snapping to 'Bilde')

---

## [0.10.72] - 2026-06-19

- feat(rich-text-section): add the standard in-canvas section control band

---

## [0.10.71] - 2026-06-18

- fix(employee-grid): honour header alignment on the frontend

---

## [0.10.70] - 2026-06-18

- fix(aktuelt): clamp card title to 2 lines + reserve 2-line height

---

## [0.10.69] - 2026-06-18

- fix(rich-text-section): centred body centres on the section, not the column

---

## [0.10.68] - 2026-06-18

- fix(footer): make the company-name heading explicit, drop site-name fallback

---

## [0.10.67] - 2026-06-18

- fix(hero): ingress "center" centers the text (centred flow), not flush-left

---

## [0.10.66] - 2026-06-18

- feat(services-selector): optional column titles + confirm heading is optional

---

## [0.10.65] - 2026-06-18

- feat(hero band): flush-to-top band + conditional media controls

---

## [0.10.64] - 2026-06-18

- feat(footer): add space-between/around/evenly to badge alignment

---

## [0.10.63] - 2026-06-18

- fix(section band): bakgrunnsform as a neutral chip; band never overlaps content

---

## [0.10.62] - 2026-06-18

- fix(section band): one consistent control chrome; drop duplicate label

---

## [0.10.61] - 2026-06-18

- feat: roll the pinned full-width options band out to all section blocks

---

## [0.10.60] - 2026-06-18

- feat(icons): add Phosphor fill construction/trades icon set

---

## [0.10.59] - 2026-06-18

- feat(hero): grouped, compact options band across the section top

---

## [0.10.58] - 2026-06-18

- fix(footer): render certification badges in the footer template

---

## [0.10.57] - 2026-06-18

- feat(footer): footer column heading as a Settings → Footer option

---

## [0.10.56] - 2026-06-18

- fix(section-controls): pin the hero options cluster to the top line

---

## [0.10.55] - 2026-06-18

- feat(split-section): text+text columns + column reorder

---

## [0.10.54] - 2026-06-17

- feat(aktuelt): full news archive — per-page, tags, pagination

---

## [0.10.53] - 2026-06-17

- fix(hero): keep eyebrow/heading clear of the bottom ingress band

---

## [0.10.52] - 2026-06-17

- fix(testimonials): auto «…» guillemets on all testimonials

---

## [0.10.51] - 2026-06-16

- fix(contact-section): map shows automatically from the address

---

## [0.10.50] - 2026-06-16

- fix(contact-section): restore map + stop HTML bleed; media-grid polish

---

## [0.10.49] - 2026-06-16

- feat(media-grid): readable controls, add rows, optional heading/intro

---

## [0.10.48] - 2026-06-16

- fix(footer): bigger credits logo + hide social heading when unset

---

## [0.10.47] - 2026-06-16

- fix(section-controls): solid teal bgShape button (readable, not pale)

---

## [0.10.46] - 2026-06-16

- fix(section-controls): readable bgShape button (no white-on-light-grey)

---

## [0.10.45] - 2026-06-16

- fix(section-controls): top-right in-flow on every block (stats-row order, hero overlap + segment fit)

---

## [0.10.44] - 2026-06-16

- chore: rebuild build/ to match src (unblocks CI verify-build + release)

---

## [0.10.43] - 2026-06-16

- feat(employee): brand symbol fallback when no photo

---

## [0.10.42] - 2026-06-16

- fix(hero): stop placeholder text leaking to the front end

---

## [0.10.41] - 2026-06-16

- refactor(blocks): cluster polish — fold bg colour in, widen, normalize chrome

---

## [0.10.40] - 2026-06-16

- feat(blocks): group editor options into a top-right cluster

---

## [0.10.39] - 2026-06-16

- fix(stats-row): one column on mobile (was two)

---

## [0.10.38] - 2026-06-16

- fix(stats-row): re-tune S/M/L/XL number sizes to fit the cards

---

## [0.10.37] - 2026-06-15

- fix(testimonial): configurable background shape (replaces hardcoded dråpe)

---

## [0.10.36] - 2026-06-15

- fix(testimonial): editor matches front end + per-block «dråpe» toggle

---

## [0.10.35] - 2026-06-15

- feat(split-section): list-item spacing control for body lists

---

## [0.10.34] - 2026-06-15

- fix(hero): rename 'Bildespill' → 'Bildekarusell'

---

## [0.10.33] - 2026-06-15

- feat: section bg shapes, hero bg picker, media-grid widths, FP CTA, stats size, split-section multipurpose

---

## [0.10.32] - 2026-06-12

- fix(media): guard the uploader scripts against CDN script-mangling

---

## [0.10.31] - 2026-06-12

- feat(single-project): prev/next project navigation on the single template

---

## [0.10.30] - 2026-06-12

- fix(stats-row): make the editor preview match the rendered front end

---

## [0.10.29] - 2026-06-12

- fix(employee-grid): align the 1–2 card grid to the heading, not centre

---

## [0.10.28] - 2026-06-12

- fix(employee): Norwegian labels + list column for the Departments taxonomy

---

## [0.10.27] - 2026-06-12

- fix(featured-projects): stop editor preview rendering a bare "0" meta

---

## [0.10.26] - 2026-06-12

- feat(featured-projects): in-canvas card corner radius control

---

## [0.10.25] - 2026-06-11

- fix(split-section): editor regressions + tallmerke/breadcrumb colours + employee-grid spacing

---

## [0.10.24] - 2026-06-11

- fix(split-section): editor regressions from #137 + tallmerke colours

---

## [0.10.23] - 2026-06-11

- feat(split-section): headings/lists in the body via InnerBlocks

---

## [0.10.22] - 2026-06-11

- Feat/header nav modes ingress align

---

## [0.10.21] - 2026-06-10

- feat: editor parity + section-colors — hero, video, split, services-selector/editorial

---

## [0.10.20] - 2026-06-10

- fix(hero): slider editor matches other blocks (no dark box, icon-only remove)

---

## [0.10.19] - 2026-06-04

- feat(hero): drag-sort slider UI + opt-in nested slider

---

## [0.10.18] - 2026-06-04

- Feat/header footer rail alignment

---

## [0.10.17] - 2026-06-04

- feat: header/footer rail alignment + footer badge & element-alignment settings

---

## [0.10.16] - 2026-06-03

- Feat/services selector and hero slider

---

## [0.10.15] - 2026-06-03

- fix(header-settings): default header width/padding to inherit, don't clobber block attrs

---

## [0.10.14] - 2026-06-02

- feat(react-header): content-width + side-padding controls in Settings → Header

---

## [0.10.13] - 2026-06-02

- fix(page-header): rename editor label to 'Sidetittel med brødsmuler'

---

## [0.10.12] - 2026-06-02

- feat(react-header): add navLayout inspector control (compact / spread)

---

## [0.10.11] - 2026-06-02

- fix(react-header,feature-cards): remove duplicate arrow + fix search overlay

---

## [0.10.10] - 2026-06-02

- chore: bump minimum PHP requirement 8.1 → 8.3

---

## [0.10.8] - 2026-06-02

- fix(react-header): lock html scroll when search overlay is open

---

## [0.10.7] - 2026-06-02

- fix: block UX/UI kinks from 2026-05-27 audit

---

## [0.10.6] - 2026-06-01

- feat: video-reels CSS backport + layout rail unification

---

## [0.10.5] - 2026-05-26

- Feat/video reels improvements

---

## [0.10.4] - 2026-05-26

- fix(types): resolve 12 TS build errors exposed by PR #98

---

## [0.10.3] - 2026-05-19

### Added
- Subtle accent-coloured radial flare in the top-right of `.site-footer`,
  mirroring the same effect on dark Split Section blocks. Soft,
  blurred, low-alpha — reads as ambient lighting, not a shape.
  Uses the active theme's `--wp--preset--color--accent` so it
  respects each brand's palette without per-site CSS.

---

## [0.10.2] - 2026-05-19

### Fixed
- Gutenberg block-appender placeholder ("Type / to choose a block")
  was barely visible on themes with cream/off-white editor canvases.
  Plugin now bumps its colour to navy at 55% opacity via a single
  scoped CSS rule. Only targets `.block-editor-default-block-appender__content`
  — no broader placeholder selectors, no opacity manipulation
  (which broke the page in an earlier attempt).

---

## [0.10.1] - 2026-05-19

### Fixed
- Hit-title on the results page went invisible on hover when admin's
  "Page accent" core was a light slug (white/surface). The theme
  rule double-bound hit-hover and submit-button to the same
  `--cb-search-results-link-hover` var; admins picking a light
  accent for the button broke the hover state on hits.
  Plugin now forces hit-title hover to stay body-text colour
  (underline alone carries the hover feedback). Submit button
  remains driven by the accent core.

### Changed
- "Page accent" core renamed to "Submit button colour" in the admin UI.
  Description clarifies it's the brand action colour and that hit
  hover is no longer derived from it.

---

## [0.10.0] - 2026-05-19

### Changed — Settings → Search reduced from 23 controls to 7 cores

Admin UI now exposes 7 swatch pickers. Everything else is auto-derived
at render time. Less rope, less overwhelm.

**Overlay (4 cores):**
- Panel background
- Panel text *(drives muted text, placeholder, icons, "See all results" link)*
- Brand accent *(drives result-row hover, close-button hover, "See all results" hover bg — all as low-alpha tints)*
- Backdrop colour + opacity slider

**Results page (3 cores):**
- Heading *(drives heading + eyebrow)*
- Body text *(drives result titles, excerpts, empty-state copy, input text, input border, muted helpers — opacity-derived where needed)*
- Page accent *(drives submit button, hit-title hover, submit-button hover (auto-darkened), submit text auto-contrasts)*

### Backwards compatibility
- All 23 underlying DB keys are preserved. The 16 derived keys still
  exist as overrides in the option store; if you previously saved an
  explicit value for one of them via pre-v0.10 admin, that value is
  still respected by the CSS-var emitter. The cores only fill in
  EMPTY/unset derived keys.
- The sanitiser now preserves existing saved values for keys not in
  the submitted form (the 16 hidden fields) so saving the simplified
  form doesn't reset your legacy per-state overrides.
- No data migration. Just a UI reduction.

---

## [0.9.6] - 2026-05-19

### Fixed
- **"Se alle treff" hover went white-on-light when the active theme had
  a `.rh-search-overlay .rh-search-all` rule.** Plugin's wp_head emit
  used single-class selectors (specificity 0,1,0). Theme had two-class
  selectors (0,2,0). Even with `!important` + priority-100 cascade,
  theme won on specificity. Plugin selectors now prefix with
  `.rh-search-overlay` to match.

### Changed
- **Settings → Search admin page is collapsible.** Each section is
  now a `<details>` card; color-heavy sections collapse by default.
  Less wall, more scannable. Swatch chips slightly smaller (28×28).
  Holding action until the v0.10.0 redesign reduces the 23 controls
  down to ~7 cores with a live preview.

---

## [0.9.5] - 2026-05-19

### Fixed
- Single-project page: "Beskrivelse" eyebrow and meta-strip values
  (Kategori/Sted/År/Omfang/Kunde) were rendering invisible on themes
  where a broad `color: inherit` / cream rule cascaded over them on a
  light body bg. Plugin now ships a visibility floor that pins the
  eyebrow + dt labels to `--wp--preset--color--accent` and dd values
  to `--wp--preset--color--primary` via `!important`. Same priority-100
  cascade trick used elsewhere — wins over equal-specificity theme
  rules without needing a theme update.

### Caveats
- These elements are still NOT admin-customizable (the eyebrow + meta
  strip are theme-rendered via `the_content` filters, no block, no
  picker). The block-conversion refactor planned for the next release
  exposes per-element controls. Treat v0.9.5 as the visibility floor
  until then.

---

## [0.9.4] - 2026-05-18

### Added
- New admin field **"See all results" hover text color**
  (`overlay_all_results_hover_color`) — sits between the existing link
  color and hover-background controls. Falls back to the rest colour
  if unset.

### Fixed
- **Header nav submenu didn't close when keyboard focus moved past it.**
  The trigger had a `handleChildKeyDown` that called `setOpen(false)`
  on Tab, but it was never wired to any element — dead code. The
  submenu would render until the next mouse interaction. Replaced
  with a focus-out listener on the trigger wrapper: when keyboard
  focus leaves the trigger + flyout subtree (via Tab, Shift+Tab,
  click elsewhere — any focus change), the submenu collapses.

---

## [0.9.3] - 2026-05-18

### Fixed
- Overlay anchors (the "See all results" link and result-row links)
  no longer go white-on-white on hover when the host theme has a broad
  `.cb-site-header a:hover { color: #fff !important; }` rule (a
  very common pattern). The plugin's wp_head emit now ships dedicated
  rules for these selectors that include `:hover`/`:focus-visible` and
  print after theme stylesheets — equal-specificity `!important`
  loses to declaration order, so the plugin wins.
- "See all results" link hover background and result-row hover
  background now reliably consume `--cb-search-all-results-hover-bg`
  and `--cb-search-result-hover-bg` respectively. Admin settings take
  effect without theme assistance.

---

## [0.9.2] - 2026-05-18

### Fixed
- **Search-page heading + eyebrow now respect their dedicated admin
  controls** (`results_heading_color`, `results_eyebrow_color`).
  Previously, themes with stale CSS lumped these selectors under a
  single bulk rule that pointed at `--cb-search-results-text`, so
  picking "White" for heading in Settings → Search had no effect —
  the heading kept inheriting the body-text colour.

### Changed
- Plugin now ships baseline CSS that consumes its own emitted vars
  (`.cb-search-page__heading`, `.cb-search-page__eyebrow`). Themes
  can still override with higher specificity, but they no longer
  have to ship the CSS to get the admin controls working. Self-
  contained.
- `cb_search_emit_css_vars` hook priority bumped from 5 → 100 so
  the plugin's `!important` rules cascade after theme stylesheets.

---

## [0.9.1] - 2026-05-18

### Fixed
- **Swatch picker (v0.9.0) had no visual feedback on click.** The
  "selected" ring was emitted by PHP as an inline style based on the
  saved value at page-load time, so clicking a different swatch toggled
  the underlying radio but the ring stayed on the old swatch. Admins
  reasonably thought the picker was completely broken.
- Selected state is now driven by CSS (`:checked ~ .cb-swatch__chip-wrap
  .cb-swatch__chip`) so the ring jumps to whichever swatch is currently
  selected, with no page reload needed.
- Hidden radio uses the standard screen-reader-only clip pattern
  instead of `position:absolute; opacity:0; width:0; height:0;` which
  in some browsers/contexts can interfere with the label→input click
  association.
- **Layout no longer shifts when selection changes.** Each swatch label
  now has a fixed width (96px) and the chip lives inside a 44×44px
  reserved cell, so the hover scale + selected ring stay contained
  within their own slot — no more "everything moves" when hovering or
  clicking neighbours.
- **Bold-on-selected removed.** Bold widens letters which used to
  shift the row whenever the selection moved. Selected state is now a
  colour change only (gray → WP-admin blue); the chip's ring carries
  the primary "selected" signal.
- Gap between chip and label name doubled (6px → 12px) so the name
  isn't crammed against the chip.
- Admin CSS for the picker is enqueued via a real `wp_add_inline_style`
  block on the search settings screen — no more per-swatch inline
  styles, cleaner inspector view.

---

## [0.9.0] - 2026-05-18

### Changed — search-color admin lockdown (theme-palette only)

**No more rainbow color picker, no more free-form hex.** Every color
field on Settings → Search is now a swatch picker locked to the active
theme's theme.json palette. It is impossible to introduce a non-brand
color through the settings UI — the design system can't drift via this
page anymore.

What this changes from an admin's perspective:
- Each color setting renders as a row of swatches labelled with the
  theme palette's color names (e.g. "Primær (mørk)", "Skotnes blå",
  "Lys flate", "Hvit" on Skotnes).
- The "Default" reset button and the Iris/jQuery color wheel are gone.
- Adding or removing colors from the picker = edit `theme.json`'s
  `settings.color.palette` in the active theme.

What this changes under the hood:
- Option store now holds theme.json slugs (e.g. `primary`) instead of
  hex strings.
- CSS-var emitter outputs `var(--wp--preset--color--SLUG, HEX)` so the
  active palette drives the live color with a hex fallback.
- Defaults are filterable per child theme via the new
  `styrk_blocks_search_default_colors` filter — themes with a dark
  page bg ship light-on-dark defaults; light-bg themes get the
  baseline. No more admin-side guessing for which color works on
  which background.
- Hover backgrounds (`*_hover_bg`) auto-compose at 8% alpha via
  `color-mix(in srgb, var(--slug) 8%, transparent)` so a "Surface"
  hover on a "Surface" panel is still visible.
- One-shot migration (`cb_search_color_migration_v1`) maps every
  legacy hex saved in `cb_search_settings` to the nearest swatch in
  the active palette via RGB Euclidean distance. Runs once on the
  next `admin_init` after upgrade. Sites where the migration hasn't
  fired yet keep rendering — the emitter passes legacy hex values
  through unchanged.

### Removed
- `cb_search_palette()` filter (replaced by reading theme.json directly
  via `cb_get_theme_palette()` — single source of truth)
- WP color-picker (Iris) admin enqueue — no longer needed

---

## [0.8.1] - 2026-05-18

### Added — comprehensive search color controls

Closes the gap left by v0.8.0, which added two overlay icon controls but
left hover states + the standalone results-page heading/eyebrow either
hardcoded or sharing a control that didn't fit. Every interactive state
in both the overlay dropdown and the standalone /?s= results page is
now admin-tunable via Settings → Search.

Six new fields:

**Overlay (header dropdown):**
- `overlay_result_hover_bg` — background tint when a result row is
  hovered or keyboard-active (arrow keys)
- `overlay_all_results_color` — "See all results for X →" link color
- `overlay_all_results_hover_bg` — hover/focus background for the same link

**Results page (/?s=…):**
- `results_eyebrow_color` — the small "SØKERESULTATER" label (was sharing
  `results_text`; couldn't be tuned independently of body text)
- `results_heading_color` — the big H1 heading (same issue)
- `results_submit_hover_bg` — submit button hover background (was hardcoded
  to `filter: brightness(1.08)`)

Six new CSS vars on :root:
- `--cb-search-result-hover-bg`
- `--cb-search-all-results-color`
- `--cb-search-all-results-hover-bg`
- `--cb-search-results-eyebrow`
- `--cb-search-results-heading`
- `--cb-search-results-submit-hover-bg`

### Fixed
- The plugin's `.rh-search-result.is-active` / `.rh-search-result:hover`
  CSS now consumes `--cb-search-result-hover-bg` (was hardcoded
  `rgba(0, 72, 106, 0.06)` which silently ignored admin config)
- The plugin's `.rh-search-all` color now consumes
  `--cb-search-all-results-color` with a sensible fallback chain
  (was hardcoded `--cb-primary`)

---

## [0.8.0] - 2026-05-18

### Added
- feat(cpts): Projects + Testimonials custom post types with editor sidebar meta panels
- feat(blocks): featured-projects — Projects CPT loop with eyebrow, heading, columns, per-page
- feat(blocks): project-hero, project-meta — single-project page primitives
- feat(blocks): testimonials — Testimonials CPT loop
- feat(search): admin-configurable overlay + results-page colors in Settings → Search
- feat(blocks): contact-section gains columnsGap + infoItemsOrder attributes
- feat(blocks): split-section enables link color customization

### Changed
- fix(split-section): stretched card-link only kicks in when there's exactly ONE actionable CTA URL (was hijacking the second CTA before)
- refactor(seeder): cb_seed_project_terms() now seeds neutral example terms; existing sites that already ran the v1 seeder are untouched (v1 + v2 option flags both short-circuit re-seeding)
- refactor(search): brand-color defaults in search-settings replaced with neutral grays/blues; child themes register a curated palette via the new `styrk_blocks_search_palette` filter
- refactor: neutralize remaining Skotnes-specific defaults so the plugin ships as a clean cross-project baseline

---

## [0.7.27] - 2026-05-05

- feat(footer): editable certification badges via Settings → Footer

---

## [0.7.26] - 2026-05-05

- feat(employee-grid): optional section heading + intro, editor↔frontend parity

---

## [0.7.25] - 2026-05-05

- chore(release): sync package.json + publish GitHub Release card per version

---

## [0.7.24] - 2026-05-05

- refactor(blocks): extract InspectorControls panels for hero + process

---

## [0.7.23] - 2026-05-05

- refactor(blocks): extract shared hooks and utils to remove cross-file duplication

---

## [0.7.22] - 2026-05-04

- fix(theme/hero): restore admin's hero on inner pages + use immediate parent for eyebrow

---

## [0.7.21] - 2026-05-03

- refactor(cta): extract CtaInspectorPanels + useCtas across 4 blocks

---

## [0.7.20] - 2026-05-03

- fix(alignment): anchor narrow text columns to the wide rail's left edge

---

## [0.7.19] - 2026-05-03

- fix(react-header): focus trap + restore on search overlay

---

## [0.7.18] - 2026-05-03

- refactor(SectionHeader): decompose into HoverPickerZone + InspectorPanels

---

## [0.7.17] - 2026-05-03

- fix(faq-accordion): add inner px-6 so heading isn't pinned to viewport edge

---

## [0.7.16] - 2026-04-28

- feat(seo): Person JSON-LD schema for employee CPT

---

## [0.7.15] - 2026-04-28

- fix(search): broken empty-anchor result cards + raw block JSON in excerpts

---

## [0.7.14] - 2026-04-28

- feat(search): editable copy via Settings → Search

---

## [0.7.13] - 2026-04-28

- fix(companion-theme): detect version drift in either direction

---

## [0.7.12] - 2026-04-28

- fix(search): proper Norwegian results page with loud empty state

---

## [0.7.11] - 2026-04-28

- feat(react-header): native site search — icon + overlay + pre-warm + dropdown

---

## [0.7.10] - 2026-04-28

- feat(process-block): symmetric Heading inspector panel — visibility, alignment, text color

---

## [0.7.9] - 2026-04-28

- fix(process-block): rename "CTA below steps" → "CTA"; add bg + text color pickers

---

## [0.7.8] - 2026-04-28

- fix(process-block): eyebrow alignment no longer drags heading along with it

---

## [0.7.7] - 2026-04-28

- feat(process-block): add Eyebrow inspector panel — visibility, alignment, bg/text color, radius

---

## [0.7.6] - 2026-04-28

- fix(process-block): CTA preview rendered as flush navy underlined box in editor

---

## [0.7.5] - 2026-04-28

- fix(process-block): editor-side bugs — eyebrow, list items, drag, CTA preview

---

## [0.7.4] - 2026-04-28

- chore(process-block): rename inserter title to Norwegian "Prosess" + add keywords

---

## [0.7.3] - 2026-04-27

- feat(blocks): new "process" block — vertical numbered cards for "Slik jobber vi"

---

## [0.7.2] - 2026-04-27

- fix(media-grid): escape URLs/attrs at output, not just at assignment

---

## [0.7.1] - 2026-04-27

- fix(react-header): resolve nav URLs from id at render time, not from frozen attribute

---

## [0.7.0] - 2026-04-27

### Changed

- Reset version line to pre-launch convention. The plugin had been
  auto-bumping patch on every merge during prototype, climbing to
  v1.6.20. Per [semver §4](https://semver.org/#spec-item-4) — "Major
  version zero is for initial development. Anything MAY change at any
  time. The public API SHOULD NOT be considered stable." — a private
  unlaunched plugin should sit in `0.x.y` and only cut `1.0.0` at
  first stable public release. Reset to `0.7.0` to mirror the rough
  volume of work shipped so far while honestly signalling the API is
  still in motion.
- Companion theme version reset 1.4.3 → 0.4.0 for the same reason.
- **Sites currently running v1.6.x will not auto-update to 0.7.x via
  PUC** because 0.x < 1.x in monotonic version compare. One-time
  manual reinstall is required to drop down to the 0.x line; from
  there every future patch updates normally.

---

## [1.6.20] - 2026-04-24

- fix(css): respect admin's CTA colour picks — stop forcing accent/navy via !important

---

## [1.6.19] - 2026-04-24

- feat(page-header): auto-derive eyebrow from top-level ancestor; kill the Sidehode sidebar panel

---

## [1.6.18] - 2026-04-24

- hotfix(css): remove dead body.has-page-header override that nuked header nav + logo

---

## [1.6.17] - 2026-04-24

- fix(auto-hero + breadcrumbs): kill 'f' glyph smudge; suppress when page-header present; reserve header space

---

## [1.6.16] - 2026-04-24

- feat: section eyebrow on sub-pages + breadcrumbs block + black palette + editor-plugin loader

---

## [1.6.15] - 2026-04-24

- fix(cta-section + theme): admin bg wins over accent gradient; alignfull last-block hugs footer

---

## [1.6.14] - 2026-04-24

- fix(styrk-theme): collapse main breathing-padding when first block is alignfull

---

## [1.6.13] - 2026-04-24

- fix(page-auto-hero): align h1 with post-content column, not site-wide container

---

## [1.6.12] - 2026-04-24

- fix(react-header): nav polish — mobile type scale + chevrons, desktop instant-switch

---

## [1.6.11] - 2026-04-24

- feat(footer): add optional organisasjonsnummer field to Settings → Footer

---

## [1.6.10] - 2026-04-24

- feat(react-header + page-auto-hero): 3-level mobile menu, Fraunces display type, auto page hero

---

## [1.6.9] - 2026-04-24

- fix(react-header): pick most-recent nav post, skip stale empties

---

## [1.6.8] - 2026-04-24

- fix(react-header): build hierarchical nav fallback instead of flat dump

---

## [1.6.7] - 2026-04-24

- fix(footer-logo): render at 200×64 regardless of SVG intrinsic dims

---

## [1.6.6] - 2026-04-24

- docs(claude): align CLAUDE.md with official brand book palette

---

## [1.6.5] - 2026-04-24

- fix(footer-logo): move white-logo setting to Footer Settings + fallback

---

## [1.6.4] - 2026-04-24

- fix(footer): align to header — match max-width + side padding

---

## [1.6.3] - 2026-04-24

- fix(a11y): employee-grid — split card into semantic button + sibling links

---

## [1.6.2] - 2026-04-24

- fix(a11y): clear WAVE-reported errors + video alerts on every page

---

## [1.6.1] - 2026-04-23

- fix(design-system): retune --surface from iced-teal to warm off-white

---

## [1.6.0] — 2026-04-23

### Changed
- **Global footer redesigned end-to-end against the design system.**
  - Palette: was `color: --cb-secondary` (teal on navy — **1.9:1**,
    a WCAG AA failure). Now: headings white (9.9:1 AAA), body
    `rgba(255,255,255,0.85)` (6.7:1 AA), muted bottom-bar
    `rgba(255,255,255,0.70)` (5.8:1 AA). All three verified ≥ 4.5:1
    against the navy primary.
  - Typography: documented eyebrow spec for column headings (14px
    Inter 600, 0.14em tracking, UPPERCASE) — was 18px 700 0.08em.
    Body 16px 1.65 line-height; bottom bar 14px 1.5.
  - Content width: `max-w-site-md` (1200px) — was 1280px (off-token).
  - Focus ring on every interactive element: 2px
    `var(--wp--preset--color--accent)` at 3px offset (design-system
    spec). Previously invisible to keyboard nav.
  - Link hover: underline appears at 2px thickness, 4px offset, no
    colour change (matches design-system CTA spec). Previously
    swapped colour to `--cb-surface`, breaking consistency.
  - `prefers-reduced-motion: reduce` killswitch on the entire footer
    subtree. Zero motion-respect previously.
  - Minimum 44×44 px tap targets on all links and social circles
    (logo link, legal nav, social buttons).

### Added
- **`[footer_legal]` shortcode + Settings → Footer → Legal Links
  field.** Admin enters one `Label|URL` per line (e.g.
  `Personvern|/personvern`); shortcode renders an inline `<nav
  aria-label="Juridisk">` list with hairline `·` separators between
  items. Empty setting collapses the row — sites without legal
  links keep their existing two-slot bottom bar.
- **Semantic heading hierarchy in the footer.** Column labels are
  now `<h2>` elements (site-name, Kontakt, Følg oss), so screen
  readers can navigate the footer via heading shortcuts, not just
  landmark nav. Updated shortcodes `[footer_site_name]` /
  `[footer_social_heading]` + hardcoded "Kontakt" in
  `styrk-theme/parts/footer.html`.
- **Focus-ring + reduced-motion killswitch on social circles** in
  the companion theme (previously invisible to keyboard users).

### Fixed
- **Specificity conflict between plugin and theme CSS.**
  `styrk-theme/style.css` carried a duplicated copy of the footer
  stylesheet that fought the plugin's rules on source order.
  Removed from theme — plugin's `src/style.css` is now the single
  source of truth. Theme keeps only the social-icon chrome and the
  `wp:site-logo` fallback invert.
- **WP `:where(.is-layout-flow) > * { margin-block: 0 }` was
  zeroing column-heading bottom margins.** Plugin selector raised
  to `.site-footer h2.site-footer__col-heading` (0,2,1) so the
  20px gap to the first line in each column survives.

### Companion theme
- **`styrk-theme` 1.2.0 → 1.3.0.** Footer template-part uses
  semantic `<h2>` column heading and adds `[footer_legal]`
  placeholder in the bottom bar. Client sites see the usual
  "Update Styrk Theme" admin notice after the plugin refreshes.

---

## [1.5.0] — 2026-04-23

### Fixed (design-system conformance — audit round 2)

- **`hero` block** — English placeholder copy ("We craft bold digital
  experiences." / "A senior team of designers and engineers…") replaced
  with neutral Norwegian bokmål defaults. Plugin ships as a reusable
  shell, so the defaults are generic enough to fit any vertical.
  Also: CTA button arrow was the same inline Phosphor-filled 256×256
  SVG we replaced in rich-text-section — now uses
  `cb_render_icon('arrow-right')` at 18×18.
- **`feature-cards`** — `addItem()` no longer seeds a `★` emoji on new
  cards. The design system reserves the star glyph for testimonial
  ratings; new items now default to an empty icon so the editor
  prompts a catalog pick directly.
- **`testimonial`** — `.cb-block-testimonial` section background had a
  `linear-gradient(180deg, var(--cb-surface) 0%, #fff 100%)`, which
  violates the "no gradients on backgrounds" rule (stat numbers are
  the one documented exception). Now uses solid
  `var(--wp--preset--color--surface, …)` which preserves the
  alternating-section rhythm.
- **`react-header`** — six inline `transition: …` styles in `view.tsx`
  were not respecting `prefers-reduced-motion`. Added a CSS killswitch
  in `src/style.css` that zeroes `transition` and `animation` for
  everything inside `.site-header-react` / `.react-header-live-wrapper`
  under the reduce-motion media query. Also: admin-picked header
  `bg_color + text_color` pair now routes through
  `cb_best_contrast_text($bg, $preferred, 4.5)` in `render.php` so a
  bad colour choice in Settings → Header can't ship unreadable
  navigation to every page.

### Clean on audit (no changes)

- `cta-section`, `employee-card` (Phosphor-filled contact icons at
  20×20 are a documented exception in `design-system/README.md`, not
  a deviation), `employee-grid`, `split-section`, `faq-accordion`,
  `stats-row`, `page-header`.

---

## [1.4.1] - 2026-04-23

- fix(ci): configure git identity once for all release-workflow steps

---

## [1.4.0] — 2026-04-23

### Added
- **Canonical design system at `/design-system/`** — single source of
  truth for palette, typography, spacing, iconography, motion, and
  content conventions. Contains `README.md`, `SKILL.md` (invokable as
  `/styrk-blocks-design`), `colors_and_type.css` (every token as a
  CSS custom property), asset references, HTML specimens, and JSX
  ui-kit components. Not shipped to client sites (`/design-system`
  excluded via `.distignore`).
- **Plugin-root `CLAUDE.md`** — tells Claude sessions to load the
  design system before any design/UI/copy work and enumerates the
  non-negotiable rules so the guidance survives across sessions.
- **Three new Feather-style icons** in the catalog: `arrow-right`,
  `upload`, `film`. Registered in both `IconPicker.tsx` (editor) and
  `includes/icons.php` (PHP render via `cb_render_icon`). Catalog
  count 27 → 30.
- **`IconRenderer` now accepts an optional `size` prop** (default 24).
  Lets callers override the 24×24 default without hand-rolling SVGs.

### Changed
- **Tailwind config palette fallbacks re-aligned to brand hexes.**
  `bg-primary` / `text-accent` / `surface` / `muted` had been
  resolving to Tailwind's stock slate / indigo / slate-50 defaults
  when `theme.json` hadn't loaded (static previews, editor pre-init).
  Now fallbacks are the actual brand hexes (`#00486A`, `#0084AF`,
  `#F5833C`, `#f0f7fa`, `#d6eef5`).

### Fixed (design-system conformance audit)
- **`rich-text-section` container widths.** Outer container was
  `max-w-site` (1440px); now uses the purpose-built `max-w-screen-rts`
  (1024px). Body prose was `max-w-[780px]`; now `max-w-prose` (720px /
  ≈64ch). Matches the documented reading-shell cap.
- **`rich-text-section` CTA arrow** replaced an inline Phosphor-filled
  256×256 SVG with `cb_render_icon('arrow-right')` at 18×18.
- **`rich-text-section` Inspector copy.** "Link N" panels → "CTA N"
  (they render as filled buttons, not text links). "Section Settings"
  → "Button styling" (the panel only contained button-radius).
- **`logo-strip` WCAG AA** — eyebrow `bg+text` pair now routed through
  `cb_best_contrast_text($bg, $preferred, 4.5)` so editor-picked
  colour combinations can't produce unreadable pills.
- **`media-grid`** — empty-slot background `#1a1a2e` (off-palette) →
  `var(--wp--preset--color--primary, #00486A)`. Active-slot focus
  ring `3px solid #5c60f5` (off-palette purple, wrong thickness) →
  `2px solid var(--wp--preset--color--accent, #F5833C)` with 3px
  offset, matching the documented focus-ring spec. Inline `UploadIcon`
  / `VideoIcon` React components → catalog `upload` / `film`.
- **`video-section`** editor preview background `#0f172a` (Tailwind
  slate-900) → `var(--wp--preset--color--primary, #00486A)`.
- **`contact-section`** Inspector hint text switched from an inline
  `color: '#757575'` to the standard `.components-base-control__help`
  class so it inherits WP's Gutenberg chrome muted-text colour.
- **`call-card`** phone glyph + hint chevron replaced with
  `cb_render_icon('phone')` at 48px and `cb_render_icon('arrow-right')`
  at 14px respectively (editor side uses `IconRenderer` with the new
  `size` prop). Drops two duplicated inline SVGs.

---

## [1.3.8] - 2026-04-21

- fix(drag): stop Gutenberg from sticking parent block at scale 0.24 / opacity 0.9 after fast card drag

---

## [1.3.7] - 2026-04-21

- fix(ci): add workflow_dispatch trigger to release workflow

---

## [1.3.6] — 2026-04-21

### Fixed
- **Eyebrow text/background color pickers were empty on sites whose
  theme.json has no `color.palette`.** SectionHeader's `<ColorPalette>`
  was passing `disableCustomColors` *and* relying on `useSetting('color
  .palette')` for the swatch list — if the palette was empty (default
  on a fresh theme), the panel rendered just a "Clear" button with no
  way to set a colour. Removed `disableCustomColors` so the standard
  WP custom-colour picker is always available, and theme-palette
  swatches still appear when present.

- **User-authored hero (and any first block) was silently hidden on
  every inner page** by the bundled styrk-theme. The theme's
  `templates/page.html` auto-injected a `<div class="cb-page-hero">`
  wrapper containing only `wp:post-title`, AND its stylesheet had a
  rule `.cb-page-hero ~ main … .cb-hero:first-child { display: none
  !important }`. So pages /services, /contact, etc. always rendered
  the theme's stripped-down title bar instead of whatever block the
  editor showed at the top. Removed both the auto-injection and the
  `display: none` rule — the user's first block (hero, page-header, or
  anything else) now renders as authored. Companion theme bumped to
  v1.2.0; the plugin's existing companion-theme installer detects the
  version delta and prompts to update on each client site.

- **Cards stayed visually collapsed (opacity 0.4, dashed outline)
  forever after a fast drag that released outside the iframe.** The
  v1.3.5 fix to the drop-commit bug removed the iframe-document
  pointerup listener entirely — which closed the commit hole but
  reopened a stuck-state hole: if the pointer left the iframe before
  release, neither React's bubble-phase handler nor the outer-document
  capture-phase handler ever fired, so `dragRef.current` and
  `dragIndex` state stayed set indefinitely. The hook now binds
  pointerup/pointercancel to the iframe document in BUBBLE phase
  (after React commits), restoring the safety-net reset without
  pre-empting the commit. Verified end-to-end: long-press + drag
  reorders the array, AND a release outside the card resets opacity
  to 1.

### Added
- **`.github/workflows/ci.yml` — GitHub Actions pipeline.** Required
  status check before any merge to main. Runs `php -l` on every
  shipped `.php` file (would have caught the v1.3.4 fatal), then
  `tsc --noEmit`, `eslint`, `stylelint`, and `pnpm build`, and
  finally fails if `build/` differs from what's committed (i.e.
  someone forgot to rebuild). Set the branch protection rule on
  GitHub once: Settings → Branches → main → Require status checks →
  select "ci / lint-and-build".

---

## [1.3.5] — 2026-04-20

### Fixed
- **v1.3.4 was unactivatable (fatal parse error) on any site that
  tried to install it.** The v1.3.3 regex that removed the
  `/* one-time patch */ add_action( 'init', ... }, 99 );` block from
  `styrk-blocks.php` only matched the opening half — it stopped at the
  first `}, 99 );` inside the self-destruct code's *string* literal
  (`"}, 99 );\n"`), leaving the tail (`\n", $s ); if ( $e !== false )
  { ... }, 99 );`) orphan and unparseable. Every v1.3.4 zip had a PHP
  parse error at `styrk-blocks.php` line 845. Removed the dangling
  tail, verified `php -l` clean, shipping v1.3.5 with the corrected
  file.

---

## [1.3.4] — 2026-04-20

### Changed
- **Update channel rewritten to use a JSON manifest, no GitHub API.**
  `includes/updater.php` used to point PUC at the private GitHub repo
  and ask every client site to set `CB_UPDATE_AUTH_TOKEN` to a personal
  access token. That was a deal-breaker for distribution — every new
  customer install would otherwise nag in wp-admin with GitHub 404s.
  The new config is a single public URL (default
  `https://raw.githubusercontent.com/styrkreklame/styrk-blocks-releases/main/manifest.json`) that
  PUC reads on each check; the manifest points at the zip download URL.
  No tokens anywhere. Source stays in the existing private GitHub repo.

### Added
- `scripts/write-manifest.js` — emits `release/manifest.json` from the
  current plugin header + CHANGELOG section.
- `scripts/release-publish.js` — rewritten. Now builds zip, writes
  manifest, tags + pushes, and (optionally) rsyncs zip + manifest to
  the public host via `STYRK_UPDATE_SSH_TARGET`. If that env var is
  unset, it stops after the local build and prints the two files to
  upload manually.

### Removed
- `CB_UPDATE_REPO`, `CB_UPDATE_AUTH_TOKEN`, `CB_UPDATE_BRANCH` constants
  — replaced by the single `CB_UPDATE_MANIFEST_URL`. Client sites that
  were previously setting the old constants can remove them from
  `wp-config.php`; they are no-ops now.

---

## [1.3.3] — 2026-04-20

### Removed
- **Malicious `init`-hook patch block in `styrk-blocks.php`.** A
  `/* one-time patch */` block was overwriting
  `src/blocks/feature-cards/edit.tsx` with a base64-encoded copy of
  the buggy overlay version on *every* WordPress request, then trying
  to self-remove. The self-removal regex searched for `}, 99 );\n`,
  but `styrk-blocks.php` uses CRLF line endings (`}, 99 );\r\n`), so
  `strpos` never found the pattern and the block re-ran on every init.
  That's what was silently reverting the source file every ~4 seconds
  during development and will have been firing on the live site too.
  Block removed; reverter confirmed dead (20-second write-and-wait
  test — file stays intact).

---

## [1.3.2] — 2026-04-20

### Fixed
- **Drag-and-drop reorder broken in v1.3.1.** The iframe-doc `pointerup`
  capture-phase listener (added in v1.3.1 to fix the parent-block drag
  bug) was nulling `dragRef.current` via `hardReset` *before* React's
  bubble-phase `handlePointerUp` could read it. `wasDrag` was always
  `false` at commit time, so the reorder never persisted. The hook
  now binds `pointerup` / `pointercancel` / `visibilitychange` to the
  outer document only (their original behaviour); only `dragstart`
  binds to both the outer and the editor-canvas iframe document, since
  that's the only listener that needs to defend against Gutenberg's
  parent `draggable=true` block wrapper.

---

## [1.3.1] — 2026-04-20

### Fixed
- **`feature-cards` editor regression** — clicking a card heading or
  body in the Gutenberg editor again focuses the correct RichText field
  (v1.2.0 re-introduced the editability bug by putting an absolute
  `position: absolute; inset: 0; z-index: 5` overlay over the whole
  card that caught every pointer event). Pointer handlers are back on
  the `<li>` itself (v1.1.9 pattern); the visible drag-dots badge is
  the explicit, immediate drag trigger via `[data-drag-handle]`.
- **Parent-block drag triggered by fast card flick** — a quick
  pointerdown-plus-drag on a card used to start an HTML5 drag of the
  entire Feature Cards block, because the `useDragSort` `dragstart`
  capture listener was bound only to the outer document, and the
  Gutenberg editor canvas runs in an iframe whose events don't bubble
  to the parent. The hook now also binds to the editor-canvas iframe
  document and matches both descendant and ancestor relationships
  between the event target and any `[data-drag-index]` element.

### Added
- **Editor-only reorder hint** above the Feature Cards grid —
  "Tips: hold ned i et kort eller bruk håndtaket øverst til høyre for
  å sortere kortene." — addresses the zero-affordance UX complaint
  from production.

---

## [1.3.0] — 2026-04-20

### Added
- **`page-header` block** — editorial band for inner pages ("Atelier"
  direction). Light `surface` background, Fraunces display serif title
  at 104 px, teal hairline rule under the title, Inter subtitle, and an
  auto-generated breadcrumb with orange `•` separators. Reads as a
  "reading room" mood — the deliberate inversion of the homepage's
  dark marketing hero. Dynamic block (PHP render); title defaults to
  the current post title; breadcrumb walks `get_post_ancestors()`.
- **`styrk-blocks/page-header-default` block pattern** for quick
  insertion from the inserter.
- **Fraunces variable serif**, lazy-loaded from Bunny Fonts only on
  pages that render the block (and in the editor iframe so previews
  match). ~60 KB woff2, privacy-respecting CDN, no Google.
- **`body.has-page-header` class** set by the block's view script,
  used by the shared stylesheet to flip the site header's
  white-on-transparent default to navy-on-light when a page-header is
  present — prevents the existing header from going invisible against
  the new light band.

### Fixed
- **`react-header` now renders correctly on non-frontpage pages.**
  Previously the header was always `position: absolute` with a
  transparent background and white text — designed for the dark
  homepage hero. On inner pages (made light by the v1.2.0 reskin) the
  white header text was invisible and the header floated over content.
  `render.php` now detects `is_front_page()` and forces solid-navy
  mode with `position: relative` on non-frontpage pages. Frontpage
  keeps its transparent overlay for the dark hero.
- **`react-header` hidden from the block inserter** (`inserter: false`).
  The header is a global component managed via Settings → Header and
  rendered by the theme's `parts/header.html` template part; editors
  should never insert it per-page.
- **Post-title visibility + spacing reset scoped correctly.**
  `.wp-block-post-title { display: none }` is now scoped to `body.home`
  only, so inner pages show their H1 by default. The shared spacing
  reset on `.wp-site-blocks > main` now exempts `.cb-page-main` so the
  page template's own padding applies, and the selector matches the
  page-header block's wrapper class.

### Design commitments (for the page-header block)
- Palette: reuses `--cb-surface`, `--cb-primary`, `--cb-secondary`
  (teal), `--cb-accent` (orange). No off-palette colours. Teal —
  previously underused — now anchors the signature hairline rule.
- Typography: Fraunces for display title (400 weight, opsz 144 via
  font-variation-settings), Inter for body text, eyebrow, breadcrumb,
  subtitle. The font mix itself is the strongest red-thread break
  from the all-Inter homepage hero.
- Responsive: 3 breakpoints (desktop / 1024 / 640); title scales
  104 → 72 → 44 px, padding tightens, layout stays single-column.

### Notes for theme integrators
- **Do not** auto-insert the page-header block from `templates/page.html`.
  On pages that already have a hero block, the result is two stacked
  full-width bands. Instead, editors insert the Page Header block (or
  its pattern) manually at the top of each inner page, replacing the
  hero.

---

## [1.2.0] — 2026-04-20

### Added
- **Reskin v2.** New visual pass across hero, CTA section, employee card
  + grid, FAQ accordion, feature cards, rich-text section, split section,
  stats row, testimonial, and `SectionHeader`. Backed by refreshed
  Tailwind theme tokens and `style.css` base layer. Follows the design
  system + process docs merged in v1.1.9 (PRs #4, #5).
- **Companion theme source in-repo.** The Styrk Theme source now lives
  at `/styrk-theme/` inside the plugin repo and ships as a bundled
  `assets/styrk-theme.zip` on each release (installable from the
  plugin's admin notice). Bumps theme to **1.1.0** to match the reskin.

### Changed
- **`scripts/release-zip.js`** — reads companion theme from the in-repo
  `./styrk-theme/` instead of the sibling `../../themes/styrk-theme/`.
  Release output unchanged on the consumer side.
- **`.distignore`** — excludes `/styrk-theme` from the plugin zip so
  the theme source isn't double-shipped alongside `assets/styrk-theme.zip`.

### Dev workflow
- Local dev: `wp-content/themes/styrk-theme` now symlinks to
  `../plugins/styrk-blocks/styrk-theme`, so theme edits are versioned
  in the same repo + PR as the plugin.

---

## [1.1.9] — 2026-04-15

### Fixed
- **Card RichText stays editable after drag-reorder.** v1.1.8 introduced
  a regression where the dragged card could land with
  `contenteditable="false"` on its heading + body, making the text
  un-editable until the user clicked elsewhere and clicked back. Root
  cause in `useDragSort.handlePointerUp`: `stopPropagation()` was
  preventing Gutenberg's pointerup focus manager from reconciling
  RichText state, and pointer capture was being released **after**
  `commit()` triggered `setAttributes` → re-render. Fix: release
  pointer capture before commit, and drop the `stopPropagation` (keep
  `preventDefault` to suppress the synthesized click on the drop
  target).

---

## [1.1.8] — 2026-04-15

### Added
- **Long-press drag engagement** (500 ms) for card-style child items
  inside parent blocks. Drag now starts without requiring a 5 px movement
  threshold — better on touch devices.
- **Explicit drag handle support.** Any element with `[data-drag-handle]`
  engages drag immediately on pointerdown (no threshold, no long-press
  wait).
- **Editor hover affordance.** Outline on `[data-drag-index]` elements
  and an emphasised state on `[data-drag-handle]`, visible only in the
  editor.

### Changed
- **`useDragSort.ts`** — accepts three engagement triggers: movement
  ≥ 5 px, long-press ≥ 500 ms, or handle-initiated pointerdown.
- **`feature-cards/edit.tsx`** — integrates the new handle pattern,
  removes duplicated drag plumbing (~200 LOC simplification).

### Fixed
- **HTML5 `dragstart` killed globally on `[data-drag-index]`** —
  prevents Gutenberg's parent-block drag from stealing a pointer that
  started inside a child card.

---

## [1.1.7] — 2026-04-14

### Fixed
- **CTA button underline on hover now applies everywhere**, including
  Split Section's primary action. Earlier rule was losing the cascade
  to Tailwind's `.no-underline` utility on some templates; now forced
  via `!important` on the four text-decoration longhands. Uniform
  hover affordance across hero, rich-text-section, cta-section,
  split-section, and feature-cards.

---

## [1.1.6] — 2026-04-14

### Added
- **Header nav link hover / focus underline.** Desktop and mobile menu
  anchors now show a 2 px underline with 4 px offset on hover and
  keyboard focus, matching the rest of the site's link hover
  convention. Focus outline removed in favour of the underline for a
  cleaner visual.

---

## [1.1.5] — 2026-04-14

### Changed
- **Styrk Theme bumped to 1.0.2** with a proper `screenshot.png` (1200×900)
  showing the Styrk Reklame logo centered on a clean white canvas.
  Appears as the tile in **Appearance → Themes** instead of the previous
  empty checkered placeholder.
- Plugin carries the new theme bundle; sites with the "Update Styrk
  Theme" notice get the updated screenshot on next reinstall.

---

## [1.1.4] — 2026-04-14

### Fixed
- **Backward-compat for the `custom-blocks/*` namespace.** Sites that had
  saved page content before the plugin was renamed from "Custom Blocks"
  to "Styrk Blocks" were showing *"Your site doesn't include support for
  the custom-blocks/hero block"* errors because the block namespace
  changed from `custom-blocks/*` → `styrk-blocks/*`. Each block is now
  registered under BOTH names; old posts render without a DB migration,
  new posts save under the new namespace.
- Same fix also recovers footer template parts that used
  `wp:custom-blocks/react-header` markup from the pre-rename era.

### Notes
- If the plugin's *folder* on disk was renamed from `plugins/custom-blocks/`
  to `plugins/styrk-blocks/` while WP was running, WP silently drops the
  plugin from `active_plugins` because it can't find the old path. Users
  need to re-activate the plugin once via **Plugins** admin. This
  release's namespace backward-compat only kicks in once the plugin is
  active again.

---

## [1.1.3] — 2026-04-14

### Added
- **Block-level background + text color pickers** now appear in the
  WordPress sidebar for 15 blocks (everything except `react-header`,
  which has its own colour controls via Settings → Header). Users can
  pick any theme-palette colour for the block's outer container; WP
  renders the generated `has-X-background-color` / `has-X-color` classes
  via the block wrapper attributes.
- **Companion theme auto-upgrade detection.** The plugin now compares
  the bundled `styrk-theme.zip`'s version header against the theme
  installed on disk. If the bundled copy is newer, an admin notice
  prompts the user to click a single button that overwrites the on-disk
  theme with the bundled version (keeping it active if it was).
  Eliminates the stale-assets bug where updating the plugin left the
  theme files unchanged on disk.

### Changed
- Styrk Theme bumped to **1.0.1** — first version to exercise the
  auto-upgrade path. Any existing client site with theme 1.0.0 on disk
  will see the new "Update Styrk Theme" notice after this plugin update.

### Fixed
- Previously every block shipped with `supports.color: false`, which
  meant WP's color UI never rendered for our blocks. Users who saw a
  color picker when a custom block was selected were actually editing
  an *inner* core block (Row / Columns). That's now resolved — picking
  a colour in the sidebar applies to the block itself.
- The companion-theme installer used to be a one-shot: once the theme
  was on disk, subsequent plugin updates never refreshed it. Now fixed
  via the auto-upgrade notice above.

---

## [1.1.2] — 2026-04-14

### Changed
- **Companion theme** ships with neutral baseline logos:
  - `assets/logo.svg` — color version for the header
  - `assets/logo-hvit.svg` — all-white version for footers / dark
    backgrounds
- `parts/header.html` alt text neutralized to "Bedriftslogo".

### Added
- `pnpm run release:publish` — single-command release: builds the zip,
  pushes the tag, creates the GitHub release with notes pulled from
  CHANGELOG. Replaces the manual copy-paste flow.

---

## [1.1.1] — 2026-04-14

### Changed
- **All Viken Regnskap content removed from defaults, fallbacks, patterns,
  and seeders.** Plugin now ships with brand-neutral Norwegian
  placeholder copy that demonstrates each block's purpose without leaking
  another company's content. Affects:
  - `contact-section` block defaults + template fallbacks (companyName,
    address, email, phone, etc.)
  - `react-header` empty-logo fallback (now uses `bloginfo('name')` or
    "Bedriftsnavn")
  - All 12 registered block patterns in the inserter
  - Auto-seeded homepage, "Tjenester", and "Kontakt" pages
  - `cb_footer_defaults()` (description, address, email, phone,
    copyright)
  - Default social-link CPT entries (URLs blank — admin must fill in)
  - Pattern category renamed `studio-nord` → `styrk-blocks`
- **Existing installs unaffected.** Seeders use option-key guards
  (`viken_pages_v8`, `viken_homepage_v3`, etc.) — sites that have
  already run them skip the new content. Only fresh installs see the
  neutral defaults.

---

## [1.1.0] — 2026-04-14

### Added
- **Companion theme installer**: the plugin now bundles a current copy of
  the Styrk Theme zip at `assets/styrk-theme.zip` and shows an admin
  notice on every screen until the theme is installed and active.
  Single-click "Install &amp; activate" button uses WP's native
  `Theme_Upgrader` to install offline (no network round-trip needed).
  Eliminates the "I forgot to install the theme" failure mode for
  manual installs that bypass the Rocket.net template workflow.
- Notice can be dismissed per-user; activating the plugin again
  resets the dismiss flag so future versions can re-prompt.
- Release script now builds the companion theme zip as part of every
  `pnpm run release` so the bundled copy is always in sync with
  `themes/styrk-theme/`.

### Notes
- Plugin zip grew by ~140 KB to accommodate the bundled theme — still
  ~500 KB total, well under any host's upload limit.

---

## [1.0.1] — 2026-04-14

### Fixed
- **Feature Cards**: card body text was not editable in the canvas — a
  full-card invisible drag overlay was intercepting all clicks. Drag is
  now constrained to the visible handle in the top-right corner; the rest
  of the card is freely click-and-edit-able (heading + body RichText both
  responsive).
- **Feature Cards**: removed Viken-specific default content
  ("Fast delivery / Quality work / Client focused"). Block now ships with
  three blank cards so it's brand-neutral out of the box.

### Notes
- First update delivered through the self-hosted update channel — proves
  the GitHub release → plugin-update-checker → client site round-trip.


### Added
- Self-hosted update channel via `yahnis-elsts/plugin-update-checker`
  (see [`includes/updater.php`](includes/updater.php)).
- `README.md`, `CONTRIBUTING.md`, `CHANGELOG.md` documenting ship +
  release workflow and the additive-only schema rule.
- `types/wordpress.d.ts` ambient shims so TypeScript resolves
  `@wordpress/*` imports in the IDE.
- WCAG AA auto-contrast helper (`includes/a11y-color.php`) applied to
  eyebrow pills + CTA buttons across rich-text-section, split-section,
  hero, cta-section, contact-section submit + column text.
- Employee modal focus trap — Tab / Shift+Tab now cycle within the open
  dialog; Escape closes.
- Media Grid: autoplay mutex (only one video slot can autoplay at a time);
  play-button overlay on non-autoplay videos with gradient backdrop;
  optional "Border around video slots" toggle; captions moved under the
  cell so clicking caption no longer opens the media picker.

### Changed
- `feature-cards` items now carry a stable `id` for React keys during
  drag-reorder (one-shot migration backfills `id` on existing items).
- Testimonial: removed decorative `::before` on `.cb-testimonial-quote`;
  `::after` decoration repositioned under the author line.
- `styrk-blocks.php` + all `includes/*.php` now use file-level
  idempotency guards (`defined()/return` pattern) to protect against
  double-load redeclaration fatals.

### Fixed
- `call-card/template.php`: defensive escaping on inline styles and href
  (`esc_url`/`esc_attr`/`(int)`).
- Testimonial block: fallback initial-letter avatar removed (showed stray
  letter when no image was set); editor gained a "Remove avatar" action.
- Missing `align` attribute in the TypeScript `Attributes` types for
  `employee-grid`, `faq-accordion`, and `contact-section`.

### Notes
- Ships for WordPress 6.5+, PHP 8.1+. Requires a block theme for
  `parts/header.html` auto-placement of the `react-header` block;
  otherwise insert it manually via the Site Editor.

---

## [1.0.0] — 2026-04-13

Initial release by **Styrk Reklame AS**. Reference deployment: Viken
Regnskap og rådgivning AS.

### Blocks shipped
`call-card`, `contact-section`, `cta-section`, `employee-card`,
`employee-grid`, `faq-accordion`, `feature-cards`, `hero`, `logo-strip`,
`media-grid`, `react-header`, `rich-text-section`, `split-section`,
`stats-row`, `testimonial`, `video-section`.

### Platform features
- Custom post types: `employee`, `social_link`.
- Admin pages: **Settings → Header**, **Settings → Footer**.
- Footer shortcodes: `[footer_logo]`, `[footer_description]`,
  `[footer_contact]`, `[footer_copyright]`, `[social_links]`.
- WebP auto-converter for uploaded JPEG/PNG media.
- Tailwind-compiled shared stylesheet (`build/style-index.css`).
