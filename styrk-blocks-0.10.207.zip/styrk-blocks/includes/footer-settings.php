<?php
/**
 * Footer Settings — admin page and helpers.
 *
 * Registers an options page under Settings → Footer where site admins
 * can manage company description, address, phone, email, copyright,
 * and the "follow us" column heading. Social links themselves are
 * managed via the social_link CPT (see styrk-blocks.php).
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard — see header-settings.php for the rationale.
if ( defined( 'CB_FOOTER_SETTINGS_LOADED' ) ) return;
define( 'CB_FOOTER_SETTINGS_LOADED', true );

/* ── Option key (all stored under one serialized option) ────────────────────── */
define( 'CB_FOOTER_OPTION', 'cb_footer_settings' );

/**
 * Default values for every footer field.
 */
function cb_footer_defaults(): array {
	$site_name = get_bloginfo( 'name' ) ?: 'Bedriftsnavn';
	return [
		// Attachment ID of the white/light logo variant used in the dark
		// footer. Zero = no custom logo uploaded; the shortcode falls back
		// to the main header logo (CSS-inverted) or the theme asset.
		// (This used to live under cb_header_settings as logo_white_id —
		// moved to footer settings in v1.6.5 to group with other footer
		// fields. A one-shot migration copies the old value across.)
		'logo_white_id'  => 0,
		// Footer bar colours — theme palette SLUGS (resolved to CSS vars in
		// cb_footer_output_css_vars). '' = inherit: keep the historical navy bar
		// with white text.
		'bg_color'       => '',
		'text_color'     => '',
		// Heading of the first footer column (the company name). Empty =
		// no heading rendered — it is NOT auto-filled from the global site
		// name, so the footer only shows what an admin explicitly sets here.
		'site_name_heading' => '',
		// Contact + description default to EMPTY, never to sample text.
		// A default that looks like real content ships to the front end of
		// every site that has not yet saved this screen — visitors saw
		// "Gateadresse 1 / 0000 Sted, Norge / post@bedriftsnavn.no". The
		// example wording now lives in the field's placeholder attribute,
		// where it guides the admin without ever rendering. Matches how
		// `org_number` below has always behaved.
		'description'    => '',
		// Heading of the Kontakt column. Defaults to "Kontakt" so existing
		// sites keep the label they already show; it is suppressed anyway
		// when every contact field is empty.
		'contact_heading' => 'Kontakt',
		// Optional SEPARATE heading for the address, for footers whose design
		// splits "Adresse" and "Kontakt" into two labelled stacks inside one
		// column. Empty by default, so the historical single-heading layout
		// ([footer_contact_heading] over address + email + phone) is unchanged
		// on every site that does not set it.
		'address_heading' => '',
		'address'        => '',
		'email'          => '',
		'phone_1'        => '',
		'phone_2'        => '',
		// Opening hours, free text, one line per row (e.g.
		// "Mandag-fredag 07:00-15:30"). Empty by default so no existing
		// site suddenly grows an hours line in its footer. Rendered by
		// [footer_contact] (part `hours`) and read by any site-level
		// LocalBusiness schema, so the client edits the hours in one place.
		'opening_hours'  => '',
		// Norwegian organisasjonsnummer (9 digits). Empty by default — the
		// shortcode output is silently skipped when unset, so sites outside
		// NO or without a registered entity don't get a broken "Org.nr."
		// label. Formatted for display as "NNN NNN NNN" regardless of how
		// the admin enters it.
		'org_number'     => '',
		'copyright'      => '© ' . gmdate( 'Y' ) . ' ' . $site_name . '. Alle rettigheter forbeholdt.',
		'social_heading' => 'Følg oss',
		'credits'        => 'Utvikling og design av Styrk Reklame AS',
		'credits_url'    => 'https://styrkreklame.no/',
		// Optional small mark/icon shown to the LEFT of the credits text
		// (e.g. an agency logo). Attachment ID; 0 = use the bundled
		// styrk-reklame-logo.webp when the credits text mentions Styrk
		// Reklame, otherwise no mark.
		'credits_icon_id' => 0,
		// Where the credits logo sits relative to the credits text.
		//   inline — replace the spot next to "Styrk Reklame" (default,
		//            back-compat with sites built before this setting existed)
		//   start  — before the credits sentence (e.g. "[logo] Utvikling og…")
		//   end    — after the credits sentence (e.g. "Utvikling og… [logo]")
		'credits_logo_position' => 'inline',
		// LEGACY. The old "one link per line, Label|URL" textarea.
		//
		// It made admins learn a private mini-language — a pipe, or a bare
		// path, and a slash meant something else again. Typing
		// "Personvern/personvern" (slash instead of pipe) silently produced
		// <a href="http://Personvern/personvern"> — an off-site link to a
		// host called "Personvern" — with no warning anywhere.
		//
		// Replaced by the legal_{1..4}_* slots below: a label, and a link you
		// either pick from a page or type. Still READ, so no existing site
		// loses its links, and still migrated into the new fields on the
		// settings screen — but no longer editable as a DSL.
		'legal_links'    => '',

		// Legal links — up to four, each a plain label plus a destination.
		//   *_label  the visible text  ("Personvern")
		//   *_page   an internal page, chosen from a dropdown (0 = none)
		//   *_url    a URL, used when no page is picked. Internal ("/sti")
		//            or external ("https://…") — both work, no syntax to learn.
		// The page wins when both are set.
		'legal_1_label'  => '',
		'legal_1_page'   => 0,
		'legal_1_url'    => '',
		'legal_2_label'  => '',
		'legal_2_page'   => 0,
		'legal_2_url'    => '',
		'legal_3_label'  => '',
		'legal_3_page'   => 0,
		'legal_3_url'    => '',
		'legal_4_label'  => '',
		'legal_4_page'   => 0,
		'legal_4_url'    => '',
		// Certification badges shown in the footer top row (paired with
		// the logo). Up to three. Each is an attachment ID — empty/0
		// means no badge, and the [footer_certs] shortcode renders only
		// the slots that are set, so a site with one cert doesn't get
		// two empty placeholders. Optional one-line text under each
		// badge for screen readers + a tooltip.
		'cert_1_id'      => 0,
		'cert_1_label'   => '',
		'cert_1_url'     => '',
		'cert_2_id'      => 0,
		'cert_2_label'   => '',
		'cert_2_url'     => '',
		'cert_3_id'      => 0,
		'cert_3_label'   => '',
		'cert_3_url'     => '',
		// Horizontal alignment of the certification-badge row on desktop:
		// 'left' | 'center' | 'right'. Mobile is ALWAYS centred (handled in
		// CSS). Default 'center' — a badge/cert strip reads best centred.
		'cert_align'     => 'center',
		'cert_height'    => 96,
		// Newsletter signup column. Optional + OFF by default — the
		// [footer_newsletter] shortcode renders nothing until an admin
		// ticks "Show newsletter signup". When on, the heading + consent
		// body + a trailing privacy link + the email form are shown.
		'newsletter_enabled'       => 0,
		'newsletter_heading'       => 'Motta vårt nyhetsbrev',
		// Consent sentence. The privacy link (label + URL below) is
		// appended after this text by the shortcode, so the body ends just
		// before the link — keep it ending with "… i vår".
		'newsletter_body'          => 'Ved å registrere deg samtykker du til at vi kan samle inn og behandle opplysninger om deg. Les mer i vår',
		'newsletter_privacy_url'   => '/personvern',
		'newsletter_privacy_label' => 'personvernerklæringen',
	];
}

/**
 * Return merged (saved + defaults) footer settings.
 */
function cb_get_footer_settings(): array {
	$saved = get_option( CB_FOOTER_OPTION, [] );
	return wp_parse_args( $saved, cb_footer_defaults() );
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_footer_settings_menu(): void {
	add_options_page(
		__( 'Footer Settings', 'styrk-blocks' ),
		__( 'Footer', 'styrk-blocks' ),
		'manage_options',
		'cb-footer-settings',
		'cb_footer_settings_page'
	);
}
add_action( 'admin_menu', 'cb_footer_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

function cb_footer_settings_init(): void {
	register_setting( 'cb_footer_group', CB_FOOTER_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_footer_sanitize',
		'default'           => cb_footer_defaults(),
	] );

	/* ── Section: Logo ────────────────────────────────────────────────────────
	 * Footer-specific logo (white variant on the dark bar). Previously lived
	 * under Settings → Header, which was confusing UX — the logo shown in
	 * the footer should be edited from the footer settings page. */
	add_settings_section(
		'cb_footer_logo',
		__( 'Logo', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'White-variant logo used in the dark footer bar. Falls back to the main header logo (auto-inverted) or the theme asset if not set.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_logo_white',
		__( 'White Logo (footer)', 'styrk-blocks' ),
		'cb_footer_render_media_field',
		'cb-footer-settings',
		'cb_footer_logo',
		[
			'key'         => 'logo_white_id',
			'description' => __( 'SVG or PNG recommended. Should be a white/light logo on transparent background — it sits on the navy footer bar.', 'styrk-blocks' ),
		]
	);

	/* ── Section: Appearance ──────────────────────────────────────────────────
	 * Footer background + text colour. Both are theme-palette swatches; leaving
	 * them on "Default" keeps the historical navy bar with white text. */
	add_settings_section(
		'cb_footer_appearance',
		__( 'Footer Appearance', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Background and text colour for the footer bar. Locked to the theme palette — "Default" keeps the navy bar with white text. Make sure the two colours pass contrast.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_bg_color',
		__( 'Background', 'styrk-blocks' ),
		'cb_footer_render_palette_field',
		'cb-footer-settings',
		'cb_footer_appearance',
		[
			'key'         => 'bg_color',
			'description' => __( 'Footer bar background. "Default" keeps the navy.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_footer_text_color',
		__( 'Text colour', 'styrk-blocks' ),
		'cb_footer_render_palette_field',
		'cb-footer-settings',
		'cb_footer_appearance',
		[
			'key'         => 'text_color',
			'description' => __( 'Footer text + links. "Default" keeps white.', 'styrk-blocks' ),
		]
	);

	/* ── Section: Certification badges ────────────────────────────────────────
	 * Up to three small marks shown next to the footer logo (Mester, Lærling,
	 * Sentral Godkjenning, Miljøfyrtårn, etc.). Slots are independent — set
	 * one, two, or three; empty slots are skipped at render time. */
	add_settings_section(
		'cb_footer_certs',
		__( 'Certification Badges', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__(
				'Up to three certification logos shown on the footer top row beside the company logo. SVG or transparent PNG strongly recommended — they sit on the dark footer bar and look best as monochrome marks. Empty slots are hidden automatically.',
				'styrk-blocks'
			)
		),
		'cb-footer-settings'
	);

	for ( $i = 1; $i <= 3; $i++ ) {
		add_settings_field(
			"cb_footer_cert_{$i}",
			sprintf( __( 'Badge %d', 'styrk-blocks' ), $i ),
			'cb_footer_render_media_field',
			'cb-footer-settings',
			'cb_footer_certs',
			[
				'key'         => "cert_{$i}_id",
				'description' => __( 'Recommended: a transparent SVG or PNG of a single mark. White or light strokes on transparent background work best on the dark footer.', 'styrk-blocks' ),
			]
		);
		add_settings_field(
			"cb_footer_cert_{$i}_url",
			sprintf( __( 'Badge %d link (optional)', 'styrk-blocks' ), $i ),
			'cb_footer_render_field',
			'cb-footer-settings',
			'cb_footer_certs',
			[
				'key'         => "cert_{$i}_url",
				'type'        => 'text',
				'description' => __( 'Optional. Link the badge to the issuing body (e.g. the Startbank or Mesterbrev register). Leave empty to render the badge as a plain image. External links open in a new tab.', 'styrk-blocks' ),
			]
		);
		add_settings_field(
			"cb_footer_cert_{$i}_label",
			sprintf( __( 'Badge %d alt text', 'styrk-blocks' ), $i ),
			'cb_footer_render_field',
			'cb-footer-settings',
			'cb_footer_certs',
			[
				'key'         => "cert_{$i}_label",
				'type'        => 'text',
				'description' => __( 'Short description for screen readers, shown as a tooltip on hover (e.g. "Mesterbedrift", "Godkjent for ansvarsrett").', 'styrk-blocks' ),
			]
		);
	}

	// Alignment of the badge row — lives in THIS section with the uploads it
	// controls (not a separate duplicate section).
	add_settings_field(
		'cb_footer_cert_height',
		__( 'Badge height (px)', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_certs',
		[
			'key'         => 'cert_height',
			'type'        => 'number',
			'description' => __( 'Height of each badge, 40–160 px. Certification marks usually contain text ("Godkjent for ansvarsrett", "Miljøfyrtårn"), which is unreadable at small sizes — raise this until the wording is legible. Default 96.', 'styrk-blocks' ),
		]
	);
	add_settings_field(
		'cb_footer_cert_align',
		__( 'Badge alignment (desktop)', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_certs',
		[
			'key'         => 'cert_align',
			'type'        => 'select',
			'choices'     => [
				'left'   => __( 'Left', 'styrk-blocks' ),
				'center' => __( 'Center', 'styrk-blocks' ),
				'right'  => __( 'Right', 'styrk-blocks' ),
				'between' => __( 'Space between (push to both edges)', 'styrk-blocks' ),
				'around'  => __( 'Space around (equal space around each)', 'styrk-blocks' ),
				'evenly'  => __( 'Space evenly (equal gaps incl. ends)', 'styrk-blocks' ),
			],
			'description' => __( 'Horizontal alignment of the badge row on desktop. On mobile the badges are always centred.', 'styrk-blocks' ),
		]
	);

	/* ── Section: Newsletter ──────────────────────────────────────────────────
	 * Optional newsletter-signup column. OFF by default — the
	 * [footer_newsletter] shortcode renders nothing until "Show newsletter
	 * signup" is ticked, so sites that don't run a newsletter get a clean
	 * footer (matches the [footer_certs] opt-in pattern). */
	add_settings_section(
		'cb_footer_newsletter',
		__( 'Newsletter', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Optional newsletter-signup column. Hidden until you tick "Show newsletter signup". The heading, consent text, and privacy link below are all editable.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_newsletter_enabled',
		__( 'Show newsletter signup', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_newsletter',
		[
			'key'         => 'newsletter_enabled',
			'type'        => 'checkbox',
			'label'       => __( 'Show the newsletter signup in the footer', 'styrk-blocks' ),
			'description' => __( 'When off, the newsletter column is hidden entirely.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_footer_newsletter_heading',
		__( 'Heading', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_newsletter',
		[
			'key'         => 'newsletter_heading',
			'type'        => 'text',
			'description' => __( 'Column heading, e.g. "Motta vårt nyhetsbrev". Leave empty to hide the heading.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_footer_newsletter_body',
		__( 'Consent text', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_newsletter',
		[
			'key'         => 'newsletter_body',
			'type'        => 'textarea',
			'description' => __( 'Short consent sentence shown above the email field. The privacy link below is appended to the end of this text, so end it with something like "… Les mer i vår".', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_footer_newsletter_privacy_label',
		__( 'Privacy link label', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_newsletter',
		[
			'key'         => 'newsletter_privacy_label',
			'type'        => 'text',
			'description' => __( 'Link text for the privacy policy, e.g. "personvernerklæringen". Appended after the consent text. Leave empty (or clear the URL) to omit the link.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_footer_newsletter_privacy_url',
		__( 'Privacy link URL', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_newsletter',
		[
			'key'         => 'newsletter_privacy_url',
			'type'        => 'text',
			'description' => __( 'Where the privacy link points, e.g. "/personvern" or a full https:// URL.', 'styrk-blocks' ),
		]
	);

	/* ── Section: Company info ──────────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_company',
		__( 'Company Information', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Text shown in the first footer column, below the company name.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_site_name_heading',
		__( 'Company name (footer heading)', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_company',
		[
			'key'         => 'site_name_heading',
			'type'        => 'text',
			'description' => __( 'Shown as the heading of the first footer column, above the description. Leave empty to hide the heading entirely — it is no longer pulled from the global site name.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_footer_description',
		__( 'Company Description', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_company',
		[ 'key' => 'description', 'type' => 'textarea' ]
	);

	/* ── Section: Contact details ───────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_contact',
		__( 'Contact Details', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Shown in the "Kontakt" footer column.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	$contact_fields = [
		'contact_heading' => [
			'label'       => __( 'Column Heading', 'styrk-blocks' ),
			'type'        => 'text',
			'placeholder' => 'Kontakt',
			'description' => __( 'Heading above the contact details. Leave empty to hide it. It is hidden automatically when every field below is empty.', 'styrk-blocks' ),
		],
		'address_heading' => [
			'label'       => __( 'Address Heading', 'styrk-blocks' ),
			'type'        => 'text',
			'placeholder' => 'Adresse',
			'description' => __( 'Optional separate heading above the address, for footers that label "Adresse" and "Kontakt" separately. Leave empty to keep the address under the column heading above. Requires the theme to output [footer_address_heading].', 'styrk-blocks' ),
		],
		'address'    => [
			'label'       => __( 'Address', 'styrk-blocks' ),
			'type'        => 'textarea',
			'placeholder' => "Gateadresse 1\n0000 Sted, Norge",
			'description' => __( 'Leave empty to hide the address entirely.', 'styrk-blocks' ),
		],
		'email'      => [
			'label'       => __( 'Email', 'styrk-blocks' ),
			'type'        => 'email',
			'placeholder' => 'post@bedriftsnavn.no',
		],
		'phone_1'    => [
			'label'       => __( 'Phone 1', 'styrk-blocks' ),
			'type'        => 'tel',
			'placeholder' => '+47 00 00 00 00',
		],
		'phone_2'    => [ 'label' => __( 'Phone 2', 'styrk-blocks' ),  'type' => 'tel' ],
		'opening_hours' => [
			'label'       => __( 'Opening Hours', 'styrk-blocks' ),
			'type'        => 'textarea',
			'placeholder' => "Mandag-fredag 07:00-15:30",
			'description' => __( 'One line per row. Leave empty to hide opening hours entirely. Written exactly as entered, so "Mandag-fredag 07:00-15:30" and "Stengt i juli" both work.', 'styrk-blocks' ),
		],
		'org_number' => [
			'label'       => __( 'Organisasjonsnummer', 'styrk-blocks' ),
			'type'        => 'text',
			'description' => __( '9-digit Norwegian org number (e.g. 987 654 321). Leave empty if not applicable. Displays as "Org.nr. NNN NNN NNN" in the contact column.', 'styrk-blocks' ),
		],
	];

	foreach ( $contact_fields as $key => $field ) {
		add_settings_field(
			"cb_footer_{$key}",
			$field['label'],
			'cb_footer_render_field',
			'cb-footer-settings',
			'cb_footer_contact',
			[
				'key'         => $key,
				'type'        => $field['type'],
				'placeholder' => $field['placeholder'] ?? '',
				'description' => $field['description'] ?? '',
			]
		);
	}

	/* ── Section: Social / Følg oss ─────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_social',
		__( 'Social Media Column', 'styrk-blocks' ),
		'cb_footer_social_section_description',
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_social_heading',
		__( 'Column Heading', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_social',
		[ 'key' => 'social_heading', 'type' => 'text' ]
	);

	/* ── Section: Copyright ─────────────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_bottom',
		__( 'Bottom Bar', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'The small text shown at the very bottom of the footer.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_copyright',
		__( 'Copyright Text', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_bottom',
		[
			'key'         => 'copyright',
			'type'        => 'text',
			'description' => __( 'Basic links and emphasis are allowed, e.g. <code>&copy; 2026 &lt;a href="/"&gt;Bedriften&lt;/a&gt;</code>.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_footer_credits',
		__( 'Credits', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_bottom',
		[
			'key'         => 'credits',
			'type'        => 'text',
			'description' => __( 'Basic links and emphasis are allowed. To link the agency name, use the Credits link field below rather than writing HTML here.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_footer_credits_url',
		__( 'Credits link', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_bottom',
		[
			'key'         => 'credits_url',
			'type'        => 'text',
			'description' => __( 'Optional. Links the agency name (and its mark) in the credit line. Leave empty for plain text. External links open in a new tab.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_footer_credits_icon',
		__( 'Credits Icon', 'styrk-blocks' ),
		'cb_footer_render_media_field',
		'cb-footer-settings',
		'cb_footer_bottom',
		[
			'key'         => 'credits_icon_id',
			'description' => __( 'Small mark shown to the left of the credits text (e.g. agency logo). Rendered as a CSS-mask so it inherits the footer text colour. Leave empty to use the bundled mark when the credits mention "Styrk Reklame".', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_footer_credits_logo_position',
		__( 'Credits Logo Position', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_bottom',
		[
			'key'         => 'credits_logo_position',
			'type'        => 'select',
			'choices'     => [
				'inline' => __( 'Inline — next to "Styrk Reklame" in the sentence', 'styrk-blocks' ),
				'start'  => __( 'Start — before the credits text', 'styrk-blocks' ),
				'end'    => __( 'End — after the credits text', 'styrk-blocks' ),
			],
			'description' => __( 'Where the agency logo appears in the credits line. Use Start or End when the uploaded logo already includes the brand name and you don\'t want it overlapping the text.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_footer_legal_links',
		__( 'Legal Links', 'styrk-blocks' ),
		'cb_footer_render_legal_links',
		'cb-footer-settings',
		'cb_footer_bottom',
		[
			'description' => __(
				'Shown in the bottom bar. Write the text, then either pick a page or type a URL. Leave a row empty to skip it.',
				'styrk-blocks'
			),
		]
	);

}
add_action( 'admin_init', 'cb_footer_settings_init' );

/**
 * Social section description — includes a link to manage social links.
 */
function cb_footer_social_section_description(): void {
	$social_url = admin_url( 'edit.php?post_type=social_link' );
	$add_url    = admin_url( 'post-new.php?post_type=social_link' );
	printf(
		'<p>%s</p><p><a href="%s" class="button">%s</a> &nbsp; <a href="%s" class="button button-primary">%s</a></p>',
		esc_html__( 'The social media icons are managed as individual posts. Use the links below to add or edit them.', 'styrk-blocks' ),
		esc_url( $social_url ),
		esc_html__( 'Manage Social Links', 'styrk-blocks' ),
		esc_url( $add_url ),
		esc_html__( '+ Add Social Link', 'styrk-blocks' )
	);
}

/* ── Field renderer ─────────────────────────────────────────────────────────── */

/**
 * Theme-palette swatch picker for the footer bg / text colour. Reuses the shared
 * swatch UI defined in header-settings.php (cb_header_render_swatches), so the
 * footer colours look + behave exactly like the header ones and stay locked to
 * the theme palette. Stores a palette slug (or '' for "keep the default look").
 */
function cb_footer_render_palette_field( array $args ): void {
	$settings    = cb_get_footer_settings();
	$key         = $args['key'];
	$current     = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_FOOTER_OPTION . "[{$key}]";
	$description = $args['description'] ?? '';

	if ( function_exists( 'cb_header_render_swatches' ) ) {
		cb_header_render_swatches( $name, $current, 'slug', true );
	} else {
		// Fallback: plain text input if the header helper isn't loaded.
		printf( '<input type="text" name="%s" value="%s" class="regular-text" />', esc_attr( $name ), esc_attr( $current ) );
	}

	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/**
 * The number of legal-link slots offered in the UI and read by the shortcode.
 * Both sides derive from this, so they can never disagree.
 */
const CB_FOOTER_LEGAL_SLOTS = 4;

/**
 * Legal Links — a label, and a link you either pick or type.
 *
 * Replaces the "Label|URL, one per line" textarea. That field asked admins to
 * learn a private syntax (a pipe; or a bare path; and a slash meant something
 * else again) and then punished a typo silently: "Personvern/personvern" —
 * slash where the pipe went — produced <a href="http://Personvern/personvern">,
 * an off-site link to a host called "Personvern", with no warning anywhere.
 *
 * Nothing here needs explaining: type the text, pick a page OR type a URL.
 *
 * Existing sites are pre-filled from their legacy `legal_links` string, so the
 * links they already have simply appear in the new fields. Saving writes the
 * slots and retires the legacy value.
 */
function cb_footer_render_legal_links( array $args ): void {
	$settings = cb_get_footer_settings();

	// Pre-fill from the legacy DSL when the new slots are still empty, so an
	// existing site's links show up here instead of looking wiped.
	$rows = cb_footer_legal_rows( $settings );

	$pages = get_pages( [ 'sort_column' => 'post_title', 'number' => 200 ] );

	echo '<table class="widefat striped" style="max-width:820px;">';
	printf(
		'<thead><tr><th style="width:26%%;">%s</th><th style="width:34%%;">%s</th><th>%s</th></tr></thead><tbody>',
		esc_html__( 'Text', 'styrk-blocks' ),
		esc_html__( 'Page', 'styrk-blocks' ),
		esc_html__( '…or URL', 'styrk-blocks' )
	);

	for ( $i = 1; $i <= CB_FOOTER_LEGAL_SLOTS; $i++ ) {
		$row   = $rows[ $i - 1 ] ?? [ 'label' => '', 'page' => 0, 'url' => '' ];
		$label = (string) $row['label'];
		$page  = (int) $row['page'];
		$url   = (string) $row['url'];

		echo '<tr>';

		printf(
			'<td><input type="text" name="%s" value="%s" class="regular-text" style="width:100%%;" placeholder="%s" aria-label="%s" /></td>',
			esc_attr( CB_FOOTER_OPTION . "[legal_{$i}_label]" ),
			esc_attr( $label ),
			esc_attr__( 'Personvern', 'styrk-blocks' ),
			/* translators: %d: row number */
			esc_attr( sprintf( __( 'Legal link %d text', 'styrk-blocks' ), $i ) )
		);

		printf(
			'<td><select name="%s" style="width:100%%;" aria-label="%s"><option value="0">%s</option>',
			esc_attr( CB_FOOTER_OPTION . "[legal_{$i}_page]" ),
			/* translators: %d: row number */
			esc_attr( sprintf( __( 'Legal link %d page', 'styrk-blocks' ), $i ) ),
			esc_html__( '— none —', 'styrk-blocks' )
		);
		foreach ( $pages as $p ) {
			printf(
				'<option value="%d"%s>%s</option>',
				(int) $p->ID,
				selected( $page, (int) $p->ID, false ),
				esc_html( get_the_title( $p ) )
			);
		}
		echo '</select></td>';

		printf(
			'<td><input type="text" name="%s" value="%s" class="regular-text" style="width:100%%;" placeholder="%s" aria-label="%s" /></td>',
			esc_attr( CB_FOOTER_OPTION . "[legal_{$i}_url]" ),
			esc_attr( $url ),
			esc_attr__( 'https://example.com  or  /en-side', 'styrk-blocks' ),
			/* translators: %d: row number */
			esc_attr( sprintf( __( 'Legal link %d URL', 'styrk-blocks' ), $i ) )
		);

		echo '</tr>';
	}

	echo '</tbody></table>';

	$description = (string) ( $args['description'] ?? '' );
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
	printf(
		'<p class="description">%s</p>',
		esc_html__( 'If you pick a page, the URL box is ignored. A URL may be internal (/en-side) or external (https://…).', 'styrk-blocks' )
	);
}

/**
 * The single source of truth for "what legal links does this site have?".
 *
 * Used by BOTH the settings screen and the [footer_legal] shortcode, so the
 * admin UI can never show something different from what the footer renders —
 * the editor/renderer parity that scripts/parity-gate.js exists to protect.
 *
 * Returns a list of [ 'label' => string, 'page' => int, 'url' => string ].
 *
 * @param array<string,mixed> $settings
 * @return array<int,array{label:string,page:int,url:string}>
 */
function cb_footer_legal_rows( array $settings ): array {
	$rows = [];

	for ( $i = 1; $i <= CB_FOOTER_LEGAL_SLOTS; $i++ ) {
		$label = trim( (string) ( $settings[ "legal_{$i}_label" ] ?? '' ) );
		$page  = (int) ( $settings[ "legal_{$i}_page" ] ?? 0 );
		$url   = trim( (string) ( $settings[ "legal_{$i}_url" ] ?? '' ) );
		if ( $page > 0 || '' !== $url ) {
			$rows[] = [ 'label' => $label, 'page' => $page, 'url' => $url ];
		}
	}

	if ( $rows ) {
		return $rows;
	}

	// Nothing in the new slots — fall back to the legacy "Label|URL" lines so
	// a site that has not been re-saved keeps the links it already had.
	$legacy = (string) ( $settings['legal_links'] ?? '' );
	if ( '' === trim( $legacy ) ) {
		return [];
	}

	foreach ( preg_split( '/\r\n|\r|\n/', $legacy ) as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		$parts = explode( '|', $line, 2 );
		if ( 2 === count( $parts ) ) {
			$rows[] = [
				'label' => trim( $parts[0] ),
				'page'  => 0,
				'url'   => trim( $parts[1] ),
			];
		} else {
			$url = trim( $parts[0] );
			$rows[] = [
				'label' => cb_footer_label_from_url( $url ),
				'page'  => 0,
				'url'   => $url,
			];
		}
		if ( count( $rows ) >= CB_FOOTER_LEGAL_SLOTS ) {
			break;
		}
	}

	return $rows;
}

/**
 * Resolve one row to a final [ label, href ] pair, or null if it cannot make
 * a usable link.
 *
 * @param array{label:string,page:int,url:string} $row
 * @return array{0:string,1:string}|null
 */
function cb_footer_legal_resolve( array $row ): ?array {
	$label = trim( (string) $row['label'] );
	$page  = (int) $row['page'];
	$url   = trim( (string) $row['url'] );

	// A picked page always wins — it is the unambiguous choice.
	if ( $page > 0 ) {
		$permalink = get_permalink( $page );
		if ( ! $permalink ) {
			return null;
		}
		$href = wp_make_link_relative( $permalink );
		if ( '' === $label ) {
			$label = (string) get_the_title( $page );
		}
	} else {
		if ( '' === $url ) {
			return null;
		}
		$href = cb_footer_normalise_url( $url );
		if ( '' === $href ) {
			return null;
		}
		if ( '' === $label ) {
			$label = cb_footer_label_from_url( $href );
		}
	}

	if ( '' === $label || '' === $href ) {
		return null;
	}

	return [ $label, $href ];
}

/**
 * Make a typed URL safe and unsurprising.
 *
 * THE BUG THIS KILLS: esc_url() sees "Personvern/personvern" — no scheme, no
 * leading slash — decides "Personvern" must be a HOSTNAME, and silently returns
 * "http://Personvern/personvern". The admin typed a typo and got a working-
 * looking link to a domain that does not exist. Nothing warned them.
 *
 * A bare token with no scheme and no leading slash is, on a footer legal link,
 * always meant to be a path on THIS site. Treat it as one.
 */
function cb_footer_normalise_url( string $url ): string {
	$url = trim( $url );
	if ( '' === $url ) {
		return '';
	}

	// Explicit scheme, or protocol-relative, or an anchor/mailto/tel — leave it.
	//
	// Delimiter is ~, not #. The second pattern has to match a literal '#'
	// (an on-page anchor), and with # as the delimiter that character ENDED
	// the pattern: PHP read '#^(mailto:|tel:|#' and choked on the ')' after
	// it — "Unknown modifier ')'", printed above the settings screen on every
	// save. preg_match then returned false, so anchors and mailto: links fell
	// through to the path branch below and were rewritten as '/#kontakt' and
	// '/mailto:post@…'.
	if ( preg_match( '~^(https?:)?//~i', $url ) || preg_match( '~^(mailto:|tel:|#)~i', $url ) ) {
		return (string) esc_url_raw( $url );
	}

	// Anything else is a path on this site. Guarantee the leading slash so
	// esc_url_raw() can never mistake the first segment for a hostname.
	if ( '/' !== $url[0] ) {
		$url = '/' . ltrim( $url, '/' );
	}

	return (string) esc_url_raw( $url );
}

function cb_footer_render_field( array $args ): void {
	$settings    = cb_get_footer_settings();
	$key         = $args['key'];
	$type        = $args['type'];
	$description = $args['description'] ?? '';
	$value       = $settings[ $key ] ?? '';
	$name        = CB_FOOTER_OPTION . "[{$key}]";
	$id          = "cb_footer_{$key}";
	// Sample wording lives here, not in the defaults — a placeholder guides
	// the admin without ever reaching the front end.
	$placeholder = (string) ( $args['placeholder'] ?? '' );

	if ( $type === 'checkbox' ) {
		$label = (string) ( $args['label'] ?? '' );
		// Hidden companion submits "0" when the box is unticked, so an
		// unchecked box reliably persists as off (the box itself only
		// submits when checked).
		printf(
			'<input type="hidden" name="%s" value="0" />'
			. '<label for="%s"><input type="checkbox" id="%s" name="%s" value="1"%s aria-label="%s"/> %s</label>',
			esc_attr( $name ),
			esc_attr( $id ),
			esc_attr( $id ),
			esc_attr( $name ),
			checked( (string) $value, '1', false ),
			esc_attr( $key ),
			esc_html( $label )
		);
	} elseif ( $type === 'textarea' ) {
		printf(
			'<textarea id="%s" name="%s" rows="4" class="large-text" aria-label="%s" placeholder="%s">%s</textarea>',
			esc_attr( $id ),
			esc_attr( $name ),
			esc_attr( $key ),
			esc_attr( $placeholder ),
			esc_textarea( $value )
		);
	} elseif ( $type === 'select' ) {
		$choices = is_array( $args['choices'] ?? null ) ? $args['choices'] : [];
		printf(
			'<select id="%s" name="%s" aria-label="%s">',
			esc_attr( $id ),
			esc_attr( $name ),
			esc_attr( $key )
		);
		foreach ( $choices as $choice_value => $choice_label ) {
			printf(
				'<option value="%s"%s>%s</option>',
				esc_attr( $choice_value ),
				selected( $value, $choice_value, false ),
				esc_html( $choice_label )
			);
		}
		echo '</select>';
	} else {
		printf(
			'<input type="%s" id="%s" name="%s" value="%s" class="regular-text" aria-label="%s" placeholder="%s"/>',
			esc_attr( $type ),
			esc_attr( $id ),
			esc_attr( $name ),
			esc_attr( $value ),
			esc_attr( $key ),
			esc_attr( $placeholder )
		);
	}

	if ( $description ) {
		// wp_kses_post allows the <br> + <code> tags used in the inline
		// help text without opening up arbitrary markup.
		printf( '<p class="description">%s</p>', wp_kses_post( $description ) );
	}
}

/* ── Media-uploader field ──────────────────────────────────────────────────── */

/**
 * Render the logo-picker (hidden attachment-ID input + preview + upload button).
 * The inline JS on cb_footer_settings_page wires this up to wp.media.
 */
function cb_footer_render_media_field( array $args ): void {
	$settings      = cb_get_footer_settings();
	$key           = $args['key'];
	$description   = $args['description'] ?? '';
	$attachment_id = (int) ( $settings[ $key ] ?? 0 );
	$name          = CB_FOOTER_OPTION . "[{$key}]";
	$field_id      = "cb_footer_{$key}";
	$preview_url   = $attachment_id ? wp_get_attachment_image_url( $attachment_id, 'medium' ) : '';
	// White logo is meant to sit on the navy footer bar — preview on navy so
	// the admin sees what it'll actually look like.
	$bg            = '#0a2020';
	?>
	<div class="cb-media-field" id="<?php echo esc_attr( $field_id ); ?>_wrapper">
		<div class="cb-media-preview" style="margin-bottom:10px;padding:16px;background:<?php echo esc_attr( $bg ); ?>;border-radius:8px;display:<?php echo $preview_url ? 'block' : 'none'; ?>;max-width:320px;">
			<img id="<?php echo esc_attr( $field_id ); ?>_preview" src="<?php echo esc_url( $preview_url ); ?>" alt="" style="max-width:100%;max-height:120px;width:auto;height:auto;display:block;" />
		</div>
		<input type="hidden" id="<?php echo esc_attr( $field_id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $attachment_id ); ?>" />
		<button type="button" class="button cb-upload-btn" data-target="<?php echo esc_attr( $field_id ); ?>" data-preview-bg="<?php echo esc_attr( $bg ); ?>">
			<?php echo $preview_url ? esc_html__( 'Change Logo', 'styrk-blocks' ) : esc_html__( 'Upload Logo', 'styrk-blocks' ); ?>
		</button>
		<?php if ( $preview_url ) : ?>
			<button type="button" class="button cb-remove-btn" data-target="<?php echo esc_attr( $field_id ); ?>" style="margin-left:8px;color:#b32d2e;">
				<?php esc_html_e( 'Remove', 'styrk-blocks' ); ?>
			</button>
		<?php endif; ?>
		<?php if ( $description ) : ?>
			<p class="description" style="margin-top:8px;"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

/**
 * Allowed inline HTML for the copyright + credits fields — just enough to let
 * an admin add a link or basic emphasis, nothing that could break the footer
 * bar layout or open an XSS hole. Shared by the sanitiser (on save) and the
 * render shortcodes (on output). Relative hrefs ("/personvern") are preserved
 * by wp_kses; javascript:/data: schemes are rejected.
 */
function cb_footer_allowed_inline_html(): array {
	return [
		'a'      => [ 'href' => true, 'title' => true, 'target' => true, 'rel' => true ],
		'br'     => [],
		'strong' => [],
		'em'     => [],
		'span'   => [ 'class' => true ],
	];
}

/**
 * Derive a human label from a bare URL when a Legal Links line omits the
 * "Label|" prefix — e.g. "/personvernerklaering" → "Personvernerklaering".
 * Lets admins paste a plain path and still get a labelled link.
 */
function cb_footer_label_from_url( string $url ): string {
	$path = (string) wp_parse_url( $url, PHP_URL_PATH );
	if ( '' === $path ) {
		$path = $url;
	}
	$slug = trim( $path, '/' );
	if ( '' === $slug ) {
		return '';
	}

	// Prefer the real page title when the path resolves to an internal page —
	// e.g. "/personvernerklaering" → "Personvernerklæring" (correct æ), no
	// guessing. Only for same-site relative/absolute paths.
	$is_internal = ! preg_match( '#^https?://#i', $url )
		|| 0 === stripos( $url, home_url() );
	if ( $is_internal && function_exists( 'get_page_by_path' ) ) {
		$last = (string) preg_replace( '#^.*/#', '', $slug );
		$page = get_page_by_path( $last ) ?: get_page_by_path( $slug );
		if ( $page instanceof \WP_Post ) {
			$title = get_the_title( $page );
			if ( '' !== $title ) {
				return $title;
			}
		}
	}

	// Fallback: humanise the last path segment.
	$last = (string) preg_replace( '#^.*/#', '', $slug );
	$last = str_replace( [ '-', '_' ], ' ', urldecode( $last ) );
	return function_exists( 'mb_convert_case' )
		? mb_convert_case( $last, MB_CASE_TITLE, 'UTF-8' )
		: ucwords( $last );
}

function cb_footer_sanitize( $input ): array {
	$defaults  = cb_footer_defaults();
	$current   = cb_get_footer_settings();
	$sanitized = [];

	foreach ( $defaults as $key => $default ) {
		if ( ! isset( $input[ $key ] ) ) {
			// `legal_links` is the retired DSL. It no longer has a form field,
			// so it is never submitted — and falling back to the default ('')
			// here would DELETE the links of every site that has not yet been
			// re-saved through the new fields. Keep whatever is stored until
			// the new slots actually carry something (see the retire step at
			// the end of this function).
			$sanitized[ $key ] = ( 'legal_links' === $key )
				? (string) ( $current['legal_links'] ?? $default )
				: $default;
			continue;
		}
		$sanitized[ $key ] = match ( $key ) {
			'logo_white_id',
			'cert_1_id',
			'cert_2_id',
			'cert_3_id',
			'legal_1_page',
			'legal_2_page',
			'legal_3_page',
			'legal_4_page',
			'credits_icon_id' => absint( $input[ $key ] ),
			// Not esc_url_raw() directly: that is what turned the typo
			// "Personvern/personvern" into "http://Personvern/personvern".
			// cb_footer_normalise_url() forces a leading slash on anything
			// schemeless, so a path can never be read as a hostname.
			'legal_1_url',
			'legal_2_url',
			'legal_3_url',
			'legal_4_url',
			// Cert links get the same treatment: a schemeless value is a path,
			// never a hostname, so "startbank.no" cannot become a broken
			// relative link and "/side" stays site-relative.
			'cert_1_url',
			'cert_2_url',
			'cert_3_url',
			'credits_url' => cb_footer_normalise_url( (string) $input[ $key ] ),
			'newsletter_enabled' => empty( $input[ $key ] ) ? 0 : 1,
			'newsletter_body'    => sanitize_textarea_field( $input[ $key ] ),
			// esc_url_raw keeps relative paths ("/personvern") and validates
			// absolute URLs, stripping javascript:/data: schemes.
			'newsletter_privacy_url' => esc_url_raw( $input[ $key ] ),
			'credits_logo_position' => in_array( (string) $input[ $key ], [ 'inline', 'start', 'end' ], true ) ? (string) $input[ $key ] : 'inline',
			// Clamped, not just absint: a badge at 4px is invisible and one at
			// 900px breaks the footer layout.
			'cert_height'   => max( 40, min( 160, absint( $input[ $key ] ) ) ),
			'cert_align'    => in_array( (string) $input[ $key ], [ 'left', 'center', 'right', 'between', 'around', 'evenly' ], true ) ? (string) $input[ $key ] : 'center',
			'email'         => sanitize_email( $input[ $key ] ),
			// Strip anything that isn't a digit. Storing bare digits keeps
			// the display formatter in one place (see cb_format_org_number)
			// and lets admins paste "987 654 321", "987-654-321", or
			// "Org.nr. 987654321" interchangeably.
			'org_number'    => preg_replace( '/\D+/', '', (string) $input[ $key ] ),
			'address',
			'description',
			'opening_hours',
			'legal_links'   => sanitize_textarea_field( $input[ $key ] ),
			// Copyright + credits may carry a simple link or emphasis (e.g. a
			// "©" line that links to the company, or a linked agency name), so
			// allow a tiny inline-HTML whitelist instead of stripping tags.
			'copyright',
			'credits'       => wp_kses( (string) $input[ $key ], cb_footer_allowed_inline_html() ),
			// Footer bar colours — '' (inherit) or a slug that exists in the
			// current theme palette, so a stale/spoofed slug can never reach the
			// CSS-var output.
			'bg_color',
			'text_color'    => ( function () use ( $input, $key ) {
				$slug   = sanitize_key( (string) $input[ $key ] );
				$slugs  = function_exists( 'cb_header_theme_palette' )
					? array_filter( array_map( static fn( $sw ) => (string) ( $sw['slug'] ?? '' ), cb_header_theme_palette() ) )
					: [];
				return ( '' !== $slug && in_array( $slug, $slugs, true ) ) ? $slug : '';
			} )(),
			default         => sanitize_text_field( $input[ $key ] ),
		};
	}

	// Retire the legacy DSL once the real fields carry the links. The settings
	// screen pre-fills those fields FROM the legacy string, so the very first
	// save after this update migrates the site automatically — the admin never
	// sees the pipe syntax again, and nothing is lost in between.
	for ( $i = 1; $i <= CB_FOOTER_LEGAL_SLOTS; $i++ ) {
		if ( 0 < (int) ( $sanitized[ "legal_{$i}_page" ] ?? 0 )
			|| '' !== trim( (string) ( $sanitized[ "legal_{$i}_url" ] ?? '' ) ) ) {
			$sanitized['legal_links'] = '';
			break;
		}
	}

	return $sanitized;
}

/* ── Page template ──────────────────────────────────────────────────────────── */

/**
 * Collapsible-section CSS (cards + chevron + schematic preview beside the intro
 * copy). Mirrors the Search + Header settings pages. Printed once, inline.
 */
function cb_footer_print_admin_css(): void {
	echo '<style>'
		. '.cb-footer-settings-wrap .cb-footer-section{background:#fff;border:1px solid #c3c4c7;border-radius:6px;margin:0 0 14px;padding:0}'
		. '.cb-footer-settings-wrap .cb-footer-section__summary{list-style:none;cursor:pointer;padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:12px;user-select:none}'
		. '.cb-footer-settings-wrap .cb-footer-section__summary::-webkit-details-marker{display:none}'
		. '.cb-footer-settings-wrap .cb-footer-section__title{font-size:14px;font-weight:600;color:#1d2327}'
		. '.cb-footer-settings-wrap .cb-footer-section__chevron{font-size:12px;color:#646970;transition:transform .15s ease}'
		. '.cb-footer-settings-wrap .cb-footer-section[open] .cb-footer-section__chevron{transform:rotate(180deg)}'
		. '.cb-footer-settings-wrap .cb-footer-section__body{padding:4px 18px 18px;border-top:1px solid #f0f0f1}'
		. '.cb-footer-settings-wrap .cb-footer-section__intro{display:flex;gap:20px;align-items:flex-start;justify-content:space-between}'
		. '.cb-footer-settings-wrap .cb-footer-section__intro-text{flex:1 1 auto;min-width:0}'
		. '.cb-footer-settings-wrap .cb-footer-section__intro-text>p{color:#50575e;margin:12px 0 4px;max-width:720px}'
		. '.cb-footer-settings-wrap .cb-footer-preview{flex:0 0 116px;width:116px;margin:14px 2px 0 0;padding:0}'
		. '.cb-footer-settings-wrap .cb-footer-preview svg{display:block;width:100%;height:auto}'
		. '@media screen and (max-width:782px){.cb-footer-settings-wrap .cb-footer-section__intro{flex-direction:column;gap:6px}.cb-footer-settings-wrap .cb-footer-preview{order:-1;margin:12px 0 0}}'
		. '.cb-footer-settings-wrap .cb-footer-section .form-table th{padding-top:12px;padding-bottom:12px;width:200px}'
		. '.cb-footer-settings-wrap .cb-footer-section .form-table td{padding-top:8px;padding-bottom:8px}'
		. '</style>';
}

/**
 * Tiny schematic SVG preview per footer section — same visual language as the
 * Search/Header previews (grey = neutral chrome, WP-admin blue = the region
 * this section controls). Each shows the footer band with the relevant zone
 * highlighted. All markup is hardcoded, so it is emitted verbatim.
 */
function cb_footer_section_preview_svg( string $id ): string {
	$frame = '<rect x="1.5" y="1.5" width="129" height="93" rx="7" fill="#fff" stroke="#c3c4c7" stroke-width="1.5"/>';
	// Shared base: faint page content up top + the footer band below.
	$base  = '<rect x="14" y="12" width="104" height="4" rx="2" fill="#eaeaec"/>'
		. '<rect x="14" y="20" width="104" height="4" rx="2" fill="#eaeaec"/>'
		. '<rect x="8" y="32" width="116" height="56" rx="4" fill="#f0f0f1"/>';
	$open  = '<svg viewBox="0 0 132 96" role="img" focusable="false" aria-label="%s">' . $frame . $base;

	switch ( $id ) {
		case 'cb_footer_logo': // Footer logo block, top-left of the band.
			return sprintf( $open, esc_attr__( 'Preview: footer logo at the top-left of the footer', 'styrk-blocks' ) )
				. '<rect x="16" y="40" width="32" height="14" rx="2" fill="#2271b1"/>'
				. '<rect x="60" y="42" width="24" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="60" y="49" width="20" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="94" y="42" width="22" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="94" y="49" width="18" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="16" y="78" width="50" height="3" rx="1.5" fill="#dcdcde"/>'
				. '</svg>';

		case 'cb_footer_certs': // Certification badge shapes.
			return sprintf( $open, esc_attr__( 'Preview: certification badges in the footer', 'styrk-blocks' ) )
				. '<rect x="16" y="44" width="18" height="18" rx="3" fill="#2271b1"/>'
				. '<circle cx="48" cy="53" r="9" fill="none" stroke="#2271b1" stroke-width="2"/>'
				. '<rect x="70" y="46" width="24" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="70" y="53" width="20" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="70" y="60" width="22" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="16" y="78" width="50" height="3" rx="1.5" fill="#dcdcde"/>'
				. '</svg>';

		case 'cb_footer_company': // Company name + address block.
			return sprintf( $open, esc_attr__( 'Preview: company name and address column', 'styrk-blocks' ) )
				. '<rect x="16" y="42" width="40" height="5" rx="2.5" fill="#2271b1"/>'
				. '<rect x="16" y="52" width="56" height="3" rx="1.5" fill="#9cb8d4"/>'
				. '<rect x="16" y="59" width="48" height="3" rx="1.5" fill="#9cb8d4"/>'
				. '<rect x="16" y="66" width="52" height="3" rx="1.5" fill="#9cb8d4"/>'
				. '<rect x="92" y="42" width="24" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="92" y="49" width="20" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="16" y="80" width="50" height="3" rx="1.5" fill="#dcdcde"/>'
				. '</svg>';

		case 'cb_footer_contact': // Phone / email / address rows with icons.
			return sprintf( $open, esc_attr__( 'Preview: contact details (phone, email, address)', 'styrk-blocks' ) )
				. '<rect x="16" y="44" width="6" height="6" rx="1.5" fill="#2271b1"/>'
				. '<rect x="26" y="45" width="42" height="4" rx="2" fill="#9cb8d4"/>'
				. '<rect x="16" y="54" width="6" height="6" rx="1.5" fill="#2271b1"/>'
				. '<rect x="26" y="55" width="34" height="4" rx="2" fill="#9cb8d4"/>'
				. '<rect x="16" y="64" width="6" height="6" rx="1.5" fill="#2271b1"/>'
				. '<rect x="26" y="65" width="38" height="4" rx="2" fill="#9cb8d4"/>'
				. '<rect x="86" y="44" width="28" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="86" y="51" width="24" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="16" y="80" width="50" height="3" rx="1.5" fill="#dcdcde"/>'
				. '</svg>';

		case 'cb_footer_social': // Row of social icon circles.
			return sprintf( $open, esc_attr__( 'Preview: social media icons column', 'styrk-blocks' ) )
				. '<rect x="16" y="42" width="34" height="4" rx="2" fill="#c9c9ce"/>'
				. '<circle cx="21" cy="60" r="6" fill="#2271b1"/>'
				. '<circle cx="38" cy="60" r="6" fill="#2271b1"/>'
				. '<circle cx="55" cy="60" r="6" fill="#2271b1"/>'
				. '<circle cx="72" cy="60" r="6" fill="#9cb8d4"/>'
				. '<rect x="94" y="42" width="22" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="94" y="49" width="18" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="16" y="80" width="50" height="3" rx="1.5" fill="#dcdcde"/>'
				. '</svg>';

		case 'cb_footer_bottom': // The thin copyright/legal strip at the very bottom.
			return sprintf( $open, esc_attr__( 'Preview: bottom bar with copyright and legal links', 'styrk-blocks' ) )
				. '<rect x="16" y="42" width="30" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="60" y="42" width="28" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="96" y="42" width="20" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="16" y="50" width="24" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="60" y="50" width="22" height="3" rx="1.5" fill="#dcdcde"/>'
				. '<rect x="12" y="70" width="108" height="12" rx="3" fill="#e7f0f8" stroke="#2271b1"/>'
				. '<rect x="18" y="74" width="44" height="4" rx="2" fill="#2271b1"/>'
				. '<rect x="92" y="74" width="22" height="4" rx="2" fill="#9cb8d4"/>'
				. '</svg>';
	}

	return '';
}

/**
 * Drop-in replacement for do_settings_sections() — wraps each section in a
 * collapsible card with its schematic preview beside the intro copy.
 */
function cb_footer_render_collapsible_sections( string $page ): void {
	global $wp_settings_sections, $wp_settings_fields;
	if ( ! isset( $wp_settings_sections[ $page ] ) ) {
		return;
	}
	foreach ( (array) $wp_settings_sections[ $page ] as $section ) {
		$id    = (string) ( $section['id'] ?? '' );
		$intro = '';
		if ( ! empty( $section['callback'] ) ) {
			ob_start();
			call_user_func( $section['callback'], $section );
			$intro = (string) ob_get_clean();
		}

		// This assignment was missing. $preview was READ twice below and never
		// set, so PHP emitted "Undefined variable $preview" once per section —
		// six warnings across the Footer settings screen, on every client site,
		// written to the error log even where WP_DEBUG hides them.
		//
		// It was not merely noisy: an unset variable is null, and `null !== ''`
		// is TRUE, so the preview branch fired unconditionally. The thumbnails
		// only looked right because cb_footer_section_preview_svg() happens to
		// return '' for a section that has no artwork — the guard was doing
		// nothing, and a section without a preview would have rendered an empty
		// <figure>.
		$preview = cb_footer_section_preview_svg( $id );
		?>
		<details class="cb-footer-section" open>
			<summary class="cb-footer-section__summary">
				<span class="cb-footer-section__title"><?php echo esc_html( (string) $section['title'] ); ?></span>
				<span class="cb-footer-section__chevron" aria-hidden="true">▾</span>
			</summary>
			<div class="cb-footer-section__body">
				<?php if ( $intro !== '' || $preview !== '' ) : ?>
					<div class="cb-footer-section__intro">
						<div class="cb-footer-section__intro-text"><?php echo $intro; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped — section callback output ?></div>
						<?php if ( $preview !== '' ) : ?>
							<figure class="cb-footer-preview"><?php echo cb_footer_section_preview_svg( $id ); ?></figure>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<?php
				if ( isset( $wp_settings_fields[ $page ][ $id ] ) ) {
					echo '<table class="form-table" role="presentation">';
					do_settings_fields( $page, $id );
					echo '</table>';
				}
				?>
			</div>
		</details>
		<?php
	}
}

function cb_footer_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// Media modal requires these scripts — enqueue explicitly so the page
	// works even on WP installs where the admin doesn't auto-load them.
	wp_enqueue_media();
	cb_footer_print_admin_css();
	?>
	<div class="wrap cb-footer-settings-wrap">
		<h1><?php esc_html_e( 'Footer Settings', 'styrk-blocks' ); ?></h1>
		<p class="description" style="max-width:720px;">
			<?php esc_html_e( 'Logo, badges, company details, contact info and the bottom bar for the site footer.', 'styrk-blocks' ); ?>
		</p>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'cb_footer_group' );
			cb_footer_render_collapsible_sections( 'cb-footer-settings' );
			submit_button();
			?>
		</form>
	</div>

	<script>
	(function($){
		'use strict';

		/* ── Media upload ─────────────────────────────────────────────────────
		 * Same pattern as header-settings.php — one wp.media frame per
		 * click, writes the chosen attachment ID to the hidden input and
		 * the preview image to the sibling <img>. */
		$(document).on('click', '.cb-upload-btn', function(e) {
			e.preventDefault();
			var btn      = $(this);
			var targetId = btn.data('target');
			var bgColor  = btn.data('preview-bg') || '#f0f0f1';
			var frame    = wp.media({
				title:    '<?php echo esc_js( __( 'Select Logo', 'styrk-blocks' ) ); ?>',
				button:   { text: '<?php echo esc_js( __( 'Use as Logo', 'styrk-blocks' ) ); ?>' },
				multiple: false,
				library:  { type: ['image', 'image/svg+xml'] }
			});

			frame.on('select', function() {
				var attachment = frame.state().get('selection').first().toJSON();
				var previewUrl = attachment.sizes && attachment.sizes.medium
					? attachment.sizes.medium.url
					: attachment.url;

				$('#' + targetId).val(attachment.id);
				$('#' + targetId + '_preview').attr('src', previewUrl);
				$('#' + targetId + '_wrapper .cb-media-preview')
					.css({ display: 'block', background: bgColor }).show();
				btn.text('<?php echo esc_js( __( 'Change Logo', 'styrk-blocks' ) ); ?>');

				if ( ! btn.siblings('.cb-remove-btn').length ) {
					$('<button type="button" class="button cb-remove-btn" data-target="' + targetId + '" style="margin-left:8px;color:#b32d2e;"><?php echo esc_js( __( 'Remove', 'styrk-blocks' ) ); ?></button>')
						.insertAfter(btn);
				}
			});
			frame.open();
		});

		$(document).on('click', '.cb-remove-btn', function(e) {
			e.preventDefault();
			var targetId = $(this).data('target');
			$('#' + targetId).val('0');
			$('#' + targetId + '_preview').attr('src', '');
			$('#' + targetId + '_wrapper .cb-media-preview').hide();
			$(this).siblings('.cb-upload-btn').text('<?php echo esc_js( __( 'Upload Logo', 'styrk-blocks' ) ); ?>');
			$(this).remove();
		});
	})(jQuery);
	</script>
	<?php
}

/* ── One-shot migration: header.logo_white_id → footer.logo_white_id ─────────
 * Pre-v1.6.5 the white logo lived under Settings → Header. Client sites that
 * had set it there need the value copied into the new footer-settings home.
 * Guard with a marker option so we only run once per site, even if the user
 * deliberately clears the new value later. */
function cb_footer_migrate_white_logo_from_header(): void {
	$marker = 'cb_footer_logo_white_migrated';
	if ( get_option( $marker ) ) {
		return;
	}

	$header = get_option( 'cb_header_settings', [] );
	$source = (int) ( $header['logo_white_id'] ?? 0 );

	if ( $source > 0 ) {
		$footer = get_option( CB_FOOTER_OPTION, [] );
		// Only populate if the target is still empty / unset — never clobber
		// an intentional setting the admin has already made in the new home.
		if ( empty( $footer['logo_white_id'] ) ) {
			$footer['logo_white_id'] = $source;
			update_option( CB_FOOTER_OPTION, $footer );
		}
	}

	update_option( $marker, 1, /* autoload = */ true );
}
add_action( 'admin_init', 'cb_footer_migrate_white_logo_from_header' );

/* ── Seed defaults on first activation ──────────────────────────────────────── */

function cb_footer_seed_defaults(): void {
	if ( get_option( CB_FOOTER_OPTION ) ) {
		return;
	}
	update_option( CB_FOOTER_OPTION, cb_footer_defaults() );
}
add_action( 'admin_init', 'cb_footer_seed_defaults' );

/* ── Output footer CSS vars to <head> ───────────────────────────────────────── */

if ( ! function_exists( 'cb_footer_output_css_vars' ) ) :
/**
 * Emit footer CSS custom properties consumed by the theme footer.
 *  --cb-footer-cert-align : flex justify value for the badge row on desktop
 *                           (mobile is forced to centre in CSS).
 */
function cb_footer_output_css_vars(): void {
	$s     = cb_get_footer_settings();
	$map   = [ 'left' => 'flex-start', 'center' => 'center', 'right' => 'flex-end', 'between' => 'space-between', 'around' => 'space-around', 'evenly' => 'space-evenly' ];
	$align = esc_attr( $map[ $s['cert_align'] ?? 'center' ] ?? 'center' );

	// Footer bar colours — a chosen palette slug becomes
	// var(--wp--preset--color--{slug}); '' emits nothing so the theme CSS keeps
	// its navy-bar/white-text default (the vars carry those as their fallback).
	$palette_var = static function ( $slug ): string {
		$slug = sanitize_key( (string) $slug );
		return '' === $slug ? '' : sprintf( 'var(--wp--preset--color--%s)', $slug );
	};
	$footer_vars = '';
	$bg          = $palette_var( $s['bg_color']   ?? '' );
	$text        = $palette_var( $s['text_color'] ?? '' );
	if ( '' !== $bg ) {
		$footer_vars .= '--cb-footer-bg:' . $bg . ';';
	}
	if ( '' !== $text ) {
		$footer_vars .= '--cb-footer-text:' . $text . ';';
	}

	// Self-contained: the badge row (.site-footer__certs, output by
	// [footer_certs]) is laid out and aligned here so the setting works on
	// every theme — no theme CSS required. !important overrides any theme
	// default. Mobile is always centred.
	printf(
		'<style id="cb-footer-vars">:root{--cb-footer-cert-align:%1$s;%2$s}'
		. '.site-footer .site-footer__certs{display:flex;flex-wrap:wrap;align-items:center;justify-content:%1$s !important}'
		. '@media(max-width:768px){.site-footer .site-footer__certs{justify-content:center !important}}'
		. '</style>' . "\n",
		esc_attr( $align ),
		wp_strip_all_tags( $footer_vars )
	);
}
add_action( 'wp_head', 'cb_footer_output_css_vars', 1 );
endif;
