<?php
/**
 * Search Settings — admin page for the search results hero + copy.
 *
 * Settings → Search lets admins manage the editable Norwegian copy
 * surfaced by `[styrk_search_results]` (see search-render.php):
 *  - Eyebrow text above the heading
 *  - Heading templates (with-query / no-query)
 *  - Empty-state copy
 *  - Form placeholder + button label
 *  - Number of results per page
 *
 * Deliberately content-only — no color or typography pickers. The
 * hero's visual style (navy bg, Fraunces display, orange accent)
 * comes from the design system tokens in theme.json + style.css and
 * applies globally. Per-instance styling controls would encourage
 * brand drift; copy-only keeps the page brand-locked.
 *
 * Mirrors the structure of header-settings.php / footer-settings.php
 * so the three "global" settings pages (Header, Footer, Search) stay
 * consistent under WP's Settings menu.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_SEARCH_SETTINGS_LOADED' ) ) return;
define( 'CB_SEARCH_SETTINGS_LOADED', true );

/* ── Option key ─────────────────────────────────────────────────────────────── */
define( 'CB_SEARCH_OPTION', 'cb_search_settings' );

/**
 * Default values for search settings. The {query} token in heading
 * and empty-line templates is replaced at render time with the
 * user's actual search term (already escaped).
 */
function cb_search_defaults(): array {
	return [
		'eyebrow_text'        => 'SØKERESULTATER',
		'heading_with_query'  => 'Søkeresultater for «{query}»',
		'heading_no_query'    => 'Søk på siden',
		'hint_no_query'       => 'Skriv et søkeord over for å finne sider, ansatte eller innlegg.',
		'empty_line'          => 'Ingen treff for «{query}».',
		'empty_hint'          => 'Sjekk stavemåten eller prøv et annet søkeord.',
		'empty_back_label'    => 'gå tilbake til forsiden',
		'form_placeholder'    => 'Søk på siden…',
		'form_button'         => 'Søk',
		'posts_per_page'      => 20,
		'radius'              => 16,
		'pill_radius'         => 999,
		'card_radius'         => 12,

	] + cb_search_default_color_slugs();
}

/**
 * Default theme-palette slugs for every search color setting. These are
 * filterable so child themes can ship sensible defaults that fit their
 * page background (e.g. Skotnes has a dark page body, so it filters in
 * 'surface' for text colors instead of the light-bg-default 'primary').
 *
 *   add_filter( 'styrk_blocks_search_default_colors', function( $defaults ) {
 *       $defaults['results_text']    = 'surface';
 *       $defaults['results_heading_color'] = 'surface';
 *       return $defaults;
 *   } );
 *
 * Plugin-side defaults assume a LIGHT page bg + a 4-slug palette
 * (primary, accent, surface, white) — the lowest common denominator
 * across our themes. Anything else is the child theme's job.
 */
function cb_search_default_color_slugs(): array {
	$defaults = [
		// Overlay (header dropdown — light card on translucent dark backdrop).
		'overlay_panel_bg'              => 'surface',
		'overlay_panel_text'            => 'primary',
		'overlay_panel_muted'           => 'primary',
		'overlay_panel_placeholder'     => 'primary',
		'overlay_icon_color'            => 'primary',
		'overlay_close_hover_bg'        => 'surface',
		'overlay_result_hover_bg'       => 'surface',
		'overlay_all_results_color'        => 'primary',
		'overlay_all_results_hover_color'  => 'primary',
		'overlay_all_results_hover_bg'     => 'surface',
		'overlay_backdrop_color'        => 'primary',
		'overlay_backdrop_opacity'      => 55,

		// Result-card type pill/tag (shared by dropdown + /?s= page).
		// Current look: accent text on an accent tint background.
		'pill_text'                     => 'accent',
		'pill_bg'                       => 'accent',

		// Standalone results page (/?s=…) — assumes light page bg.
		'results_eyebrow_color'      => 'primary',
		'results_heading_color'      => 'primary',
		'results_text'               => 'primary',
		'results_muted'              => 'primary',
		'results_input_bg'           => 'surface',
		'results_input_text'         => 'primary',
		'results_input_border'       => 'primary',
		'results_link_hover'         => 'accent',
		'results_submit_bg'          => 'accent',
		'results_submit_text'        => 'white',
		'results_submit_hover_bg'    => 'primary',
	];
	return (array) apply_filters( 'styrk_blocks_search_default_colors', $defaults );
}

/**
 * Read the active theme's color palette from theme.json. Returns an array of
 * `[ slug, name, color ]` entries. This is the SINGLE source of truth for
 * what colors admins can pick in Settings → Search — there is no free-form
 * hex input, the picker is locked to brand swatches. To change what colors
 * appear, edit theme.json's `settings.color.palette`.
 */
function cb_get_theme_palette(): array {
	$palette = wp_get_global_settings( [ 'color', 'palette' ] );
	if ( isset( $palette['theme'] ) && is_array( $palette['theme'] ) ) {
		return $palette['theme'];
	}
	if ( isset( $palette['default'] ) && is_array( $palette['default'] ) ) {
		return $palette['default'];
	}
	if ( is_array( $palette ) && isset( $palette[0]['slug'] ) ) {
		return $palette;
	}
	return [];
}

/**
 * Resolve a saved color value (slug or legacy hex) to a CSS string suitable
 * for emitting into a custom property. Slugs become `var(--wp--preset--color--SLUG, HEX)`
 * with a hex fallback so the value remains valid even if the slug is later
 * removed from theme.json. Legacy hex values are passed through unchanged so
 * sites that haven't yet run the migration keep rendering.
 */
function cb_search_resolve_color_to_css( string $value, array $palette ): string {
	if ( $value === '' ) return 'transparent';
	if ( $value[0] === '#' ) return $value; // legacy hex
	$hex = '';
	foreach ( $palette as $entry ) {
		if ( ( $entry['slug'] ?? '' ) === $value ) {
			$hex = (string) ( $entry['color'] ?? '' );
			break;
		}
	}
	if ( $hex === '' ) return 'currentColor'; // unknown slug — safe inert fallback
	return "var(--wp--preset--color--{$value}, {$hex})";
}

/**
 * Resolve a saved color value to its raw hex (for server-side rgba composition,
 * e.g. the backdrop opacity slider). Returns empty string if unresolvable.
 */
function cb_search_resolve_color_to_hex( string $value, array $palette ): string {
	if ( $value === '' ) return '';
	if ( $value[0] === '#' ) return $value;
	foreach ( $palette as $entry ) {
		if ( ( $entry['slug'] ?? '' ) === $value ) {
			return (string) ( $entry['color'] ?? '' );
		}
	}
	return '';
}

/**
 * Return effective search settings — saved values merged with defaults,
 * with derived keys auto-filled from cores when the admin hasn't explicitly
 * set them. The cores (7 swatches admin actually sees) drive everything
 * else via `cb_search_derivations()`.
 *
 * Backwards compat: if a derived key has an explicit saved value (from
 * pre-v0.10.0 when admin could set each individually), that value is
 * respected. Only unsaved/empty derived keys get auto-filled.
 */
function cb_get_search_settings(): array {
	$saved    = get_option( CB_SEARCH_OPTION, [] );
	if ( ! is_array( $saved ) ) $saved = [];
	$defaults = cb_search_defaults();
	$merged   = wp_parse_args( $saved, $defaults );

	// Cores ALWAYS drive derived keys. The simplified admin UI doesn't
	// expose individual control for the 16 derived keys, so any
	// pre-v0.10 explicit saves were band-aids for a buggy cascade —
	// not intentional design choices we should preserve. Overriding
	// them universally restores a single source of truth.
	foreach ( cb_search_derivations() as $derived_key => $core_key ) {
		$merged[ $derived_key ] = $merged[ $core_key ] ?? '';
	}
	return $merged;
}

/**
 * Mapping: derived key → core key it inherits from when not explicitly
 * set. The 7 cores (panel_bg, panel_text, overlay_all_results_color,
 * overlay_backdrop_color, results_heading_color, results_text,
 * results_link_hover) drive every other colour.
 */
function cb_search_derivations(): array {
	return [
		// Overlay derivations from panel-text core
		'overlay_panel_muted'             => 'overlay_panel_text',
		'overlay_panel_placeholder'       => 'overlay_panel_text',
		'overlay_icon_color'              => 'overlay_panel_text',
		'overlay_all_results_hover_color' => 'overlay_panel_text',
		// Overlay derivations from accent core (drive hover tints)
		'overlay_close_hover_bg'          => 'overlay_all_results_color',
		'overlay_result_hover_bg'         => 'overlay_all_results_color',
		'overlay_all_results_hover_bg'    => 'overlay_all_results_color',
		// Results-page derivations from heading core
		'results_eyebrow_color'           => 'results_heading_color',
		// Results-page derivations from text core
		'results_muted'                   => 'results_text',
		'results_input_text'              => 'results_text',
		'results_input_border'            => 'results_text',
		// Results-page derivations from page-accent core
		'results_submit_bg'               => 'results_link_hover',
		'results_submit_hover_bg'         => 'results_link_hover',
		// Results-page input bg defaults to panel bg (light surface look)
		'results_input_bg'                => 'overlay_panel_bg',
		// Submit text contrasts the accent — falls back to panel bg
		// (which is usually the light/surface slug)
		'results_submit_text'             => 'overlay_panel_bg',
	];
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_search_settings_menu(): void {
	add_options_page(
		__( 'Search Settings', 'styrk-blocks' ),
		__( 'Search', 'styrk-blocks' ),
		'manage_options',
		'cb-search-settings',
		'cb_search_settings_page'
	);
}
add_action( 'admin_menu', 'cb_search_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

function cb_search_settings_init(): void {
	register_setting( 'cb_search_group', CB_SEARCH_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_search_sanitize',
		'default'           => cb_search_defaults(),
	] );

	/* ── Section: Heading & eyebrow ──────────────────────────────────────────── */
	add_settings_section(
		'cb_search_heading',
		__( 'Heading & eyebrow', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Copy shown in the navy hero band at the top of the search results page. Use {query} as a placeholder for the user\'s search term — it is replaced safely at render time.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_eyebrow_text', __( 'Eyebrow text', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'eyebrow_text', 'description' => __( 'Small all-caps label above the heading.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_heading_with_query', __( 'Heading (with query)', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'heading_with_query', 'description' => __( 'Shown when the visitor has a search term. Use {query} for the term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_heading_no_query', __( 'Heading (no query)', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'heading_no_query', 'description' => __( 'Shown when the visitor lands on /?s= with no term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_hint_no_query', __( 'Hint (no query)', 'styrk-blocks' ), 'cb_search_render_textarea_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'hint_no_query', 'description' => __( 'Helper paragraph below the heading when no term is entered yet.', 'styrk-blocks' ) ] );

	/* ── Section: Empty state ────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_empty',
		__( 'No-results state', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Copy shown when the search returns zero results. Keep it warm — visitors are mid-task.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_empty_line', __( 'Headline', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_line', 'description' => __( 'Use {query} for the searched term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_empty_hint', __( 'Hint', 'styrk-blocks' ), 'cb_search_render_textarea_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_hint', 'description' => __( 'Suggestion paragraph (without the home link — that is rendered separately).', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_empty_back_label', __( 'Back-to-home link label', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_back_label', 'description' => __( 'Visible label of the inline link back to the home page.', 'styrk-blocks' ) ] );

	/* ── Section: Search form ────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_form',
		__( 'Search form', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Strings shown inside the inline search-again form in the hero.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_form_placeholder', __( 'Input placeholder', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_form',
		[ 'key' => 'form_placeholder' ] );

	add_settings_field( 'cb_search_form_button', __( 'Button label', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_form',
		[ 'key' => 'form_button' ] );

	/* ── Section: Behaviour ──────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_behaviour',
		__( 'Behaviour', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Pagination size and other non-content options.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_posts_per_page', __( 'Results per page', 'styrk-blocks' ), 'cb_search_render_number_field', 'cb-search-settings', 'cb_search_behaviour',
		[ 'key' => 'posts_per_page', 'min' => 1, 'max' => 100, 'description' => __( 'How many hits to show per results page (1–100).', 'styrk-blocks' ) ] );

	/* ── Section: Overlay colors (4 cores — the rest are auto-derived) ──────── */
	add_settings_section(
		'cb_search_overlay_colors',
		__( 'Search dropdown colours', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Colours used inside the dropdown that opens when a visitor clicks the search icon in the header. Four swatches drive everything — hover tints, muted text, placeholders, icon colour all derive automatically.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);
	add_settings_field( 'cb_search_overlay_panel_bg', __( 'Panel background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_panel_bg', 'description' => __( 'Background of the dropdown card.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_panel_text', __( 'Panel text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_panel_text', 'description' => __( 'Drives: input text, result titles, the "See all results" link, icons. Muted text and placeholder are derived from this at lower opacity.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_all_results_color', __( 'Brand accent', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_all_results_color', 'description' => __( 'Drives the result-row hover tint, close-button hover tint, and the "See all results" hover background. Tints are auto-composed at low alpha.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_backdrop_color', __( 'Backdrop colour', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_backdrop_color', 'description' => __( 'The translucent layer behind the panel. Use the opacity slider below to tune transparency.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_backdrop_opacity', __( 'Backdrop opacity', 'styrk-blocks' ), 'cb_search_render_opacity_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_backdrop_opacity', 'description' => __( '0 = fully transparent, 100 = solid.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_radius', __( 'Corner radius (px)', 'styrk-blocks' ), 'cb_search_render_number_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'radius', 'min' => 0, 'max' => 40, 'description' => __( 'Rounds the corners of the search modal, AND the search input box on the standalone results page. 0 = square.', 'styrk-blocks' ) ] );

	/* ── Section: Results-page colors (3 cores) ─────────────────────────────── */
	add_settings_section(
		'cb_search_results_colors',
		__( 'Search results page colours', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Colours on the full-page search results screen (where visitors land after submitting a search). Three swatches drive everything — eyebrow, muted text, input chrome, button states all derive automatically. Pick swatches that contrast the page background.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);
	add_settings_field( 'cb_search_results_heading_color', __( 'Heading', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_heading_color', 'description' => __( 'Drives the H1 and the eyebrow above it.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_text', __( 'Body text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_text', 'description' => __( 'Drives result titles, excerpts, empty-state copy, search-input text and border. Muted text and helpers are derived at lower opacity.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_link_hover', __( 'Submit button colour', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_link_hover', 'description' => __( 'Background colour of the "Søk" button on the results page. Submit text auto-contrasts; hover state is auto-darkened. Pick a brand colour, not a neutral.', 'styrk-blocks' ) ] );

	/* ── Section: Result cards & type labels (pills) ────────────────────────── */
	add_settings_section(
		'cb_search_pills',
		__( 'Resultatkort og type-etiketter', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Runding på resultatkortene og på den lille type-etiketten («SIDE», «INNLEGG») som vises på hvert treff. Gjelder både søke-nedtrekket i toppen og den fulle /?s=-resultatsiden.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);
	add_settings_field( 'cb_search_card_radius', __( 'Resultatkort – hjørneradius (px)', 'styrk-blocks' ), 'cb_search_render_number_field', 'cb-search-settings', 'cb_search_pills',
		[ 'key' => 'card_radius', 'min' => 0, 'max' => 40, 'description' => __( 'Runder hjørnene på hvert resultatkort. 0 = firkantet.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_pill_radius', __( 'Type-etikett – hjørneradius (px)', 'styrk-blocks' ), 'cb_search_render_number_field', 'cb-search-settings', 'cb_search_pills',
		[ 'key' => 'pill_radius', 'min' => 0, 'max' => 999, 'description' => __( 'Runder hjørnene på type-etiketten. 999 = helt avrundet (pille-form), 0 = firkantet.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_pill_text', __( 'Type-etikett – tekstfarge', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_pills',
		[ 'key' => 'pill_text', 'description' => __( 'Tekstfargen i type-etiketten.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_pill_bg', __( 'Type-etikett – bakgrunnsfarge', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_pills',
		[ 'key' => 'pill_bg', 'description' => __( 'Bakgrunnsfargen bak type-etiketten. Vises som en lett tone (10 %) av valgt farge, slik dagens design.', 'styrk-blocks' ) ] );
}
add_action( 'admin_init', 'cb_search_settings_init' );

/* ── Field renderers ────────────────────────────────────────────────────────── */

function cb_search_render_text_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<input type="text" id="%s" name="%s" value="%s" class="regular-text" style="max-width:520px;" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_attr( $value )
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

function cb_search_render_textarea_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<textarea id="%s" name="%s" rows="3" class="large-text" style="max-width:520px;">%s</textarea>',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_textarea( $value )
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/**
 * Render a theme-palette-only color picker. Admin sees brand swatches and
 * picks one — there is no rainbow wheel, no hex input, no "Default" escape
 * hatch. The choice is locked to slugs declared in theme.json. This is the
 * point: it must be impossible to introduce a non-brand color through this
 * UI, so the design system can't drift via the settings page.
 *
 * Selected state is driven by CSS (`:checked + .cb-swatch__chip`) so the
 * ring updates live as the admin clicks — not via a PHP-baked inline style
 * that only reflects the value at page load.
 */
function cb_search_render_color_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = (string) $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';
	$palette     = cb_get_theme_palette();

	if ( empty( $palette ) ) {
		printf(
			'<p class="description" style="color:#b32d2e;">%s</p>',
			esc_html__( 'No theme palette found. Add colors to theme.json → settings.color.palette to enable this picker.', 'styrk-blocks' )
		);
		// Fall back to a hidden input so the option isn't lost on save.
		printf( '<input type="hidden" name="%s" value="%s" />', esc_attr( $name ), esc_attr( $value ) );
		return;
	}

	echo '<fieldset class="cb-swatch-group">';
	foreach ( $palette as $entry ) {
		$slug    = (string) ( $entry['slug'] ?? '' );
		$name_l  = (string) ( $entry['name'] ?? $slug );
		$color   = (string) ( $entry['color'] ?? '#000' );
		if ( $slug === '' ) continue;
		$checked = $value === $slug ? 'checked' : '';
		$radio_id = $field_id . '-' . preg_replace( '/[^a-z0-9_-]/i', '', $slug );
		printf(
			'<label class="cb-swatch" for="%s" title="%s">'
			. '<input type="radio" id="%s" name="%s" value="%s" %s class="cb-swatch__input" />'
			. '<span class="cb-swatch__chip-wrap"><span aria-hidden="true" class="cb-swatch__chip" style="background:%s"></span></span>'
			. '<span class="cb-swatch__name">%s</span>'
			. '</label>',
			esc_attr( $radio_id ),
			esc_attr( $name_l ),
			esc_attr( $radio_id ),
			esc_attr( $name ),
			esc_attr( $slug ),
			esc_attr( $checked ),
			esc_attr( $color ),
			esc_html( $name_l )
		);
	}
	echo '</fieldset>';

	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/**
 * Enqueue the admin CSS for the swatch picker. Only loads on the search
 * settings screen — no need to ship it everywhere in wp-admin.
 */
function cb_search_enqueue_admin_assets( $hook ): void {
	if ( $hook !== 'settings_page_cb-search-settings' ) return;
	wp_register_style( 'cb-search-admin', false, [], '0.9.1' );
	wp_enqueue_style( 'cb-search-admin' );
	wp_add_inline_style( 'cb-search-admin', <<<'CSS'
/* ── Collapsible section cards ────────────────────────────────────── */
.cb-search-settings-wrap .cb-search-section {
	background: #fff;
	border: 1px solid #c3c4c7;
	border-radius: 6px;
	margin: 0 0 14px;
	padding: 0;
}
.cb-search-settings-wrap .cb-search-section__summary {
	list-style: none;
	cursor: pointer;
	padding: 14px 18px;
	display: flex;
	align-items: center;
	justify-content: space-between;
	gap: 12px;
	user-select: none;
}
.cb-search-settings-wrap .cb-search-section__summary::-webkit-details-marker { display: none; }
.cb-search-settings-wrap .cb-search-section__title {
	font-size: 14px;
	font-weight: 600;
	color: #1d2327;
}
.cb-search-settings-wrap .cb-search-section__chevron {
	font-size: 12px;
	color: #646970;
	transition: transform 0.15s ease;
}
.cb-search-settings-wrap .cb-search-section[open] .cb-search-section__chevron {
	transform: rotate(180deg);
}
.cb-search-settings-wrap .cb-search-section__body {
	padding: 4px 18px 18px;
	border-top: 1px solid #f0f0f1;
}
.cb-search-settings-wrap .cb-search-section__body > p,
.cb-search-settings-wrap .cb-search-section__intro-text > p {
	color: #50575e;
	margin: 12px 0 4px;
	max-width: 720px;
}
/* ── Per-section schematic preview (small, beside the intro copy) ──── */
.cb-search-settings-wrap .cb-search-section__intro {
	display: flex;
	gap: 20px;
	align-items: flex-start;
	justify-content: space-between;
}
.cb-search-settings-wrap .cb-search-section__intro-text {
	flex: 1 1 auto;
	min-width: 0;
}
.cb-search-settings-wrap .cb-search-section__intro-text > p:first-child {
	margin-top: 12px;
}
.cb-search-settings-wrap .cb-search-preview {
	flex: 0 0 116px;
	width: 116px;
	margin: 14px 2px 0 0;
	padding: 0;
}
.cb-search-settings-wrap .cb-search-preview svg {
	display: block;
	width: 100%;
	height: auto;
}
@media screen and (max-width: 782px) {
	.cb-search-settings-wrap .cb-search-section__intro { flex-direction: column; gap: 6px; }
	.cb-search-settings-wrap .cb-search-preview { order: -1; margin: 12px 0 0; }
}
.cb-search-settings-wrap .cb-search-section .form-table {
	margin-top: 4px;
}
.cb-search-settings-wrap .cb-search-section .form-table th {
	padding-top: 12px;
	padding-bottom: 12px;
	width: 200px;
}
.cb-search-settings-wrap .cb-search-section .form-table td {
	padding-top: 8px;
	padding-bottom: 8px;
}

/* ── Theme palette swatches (compact) ─────────────────────────────── */
.cb-swatch-group {
	display: flex;
	flex-wrap: wrap;
	gap: 14px;
	margin: 0;
	padding: 0;
	border: 0;
}
/* `!important` defeats wp-admin's `.form-table td fieldset label
   { display: inline-block; margin: 0.35em 0 0.5em !important; }` */
.form-table td fieldset .cb-swatch,
.cb-swatch {
	position: relative !important;
	display: inline-flex !important;
	flex-direction: column !important;
	align-items: center !important;
	gap: 10px !important;
	cursor: pointer;
	width: 78px;
	flex: 0 0 78px;
	margin: 0 !important;
	padding: 0;
	font-size: 11px;
	line-height: 1.3;
	text-align: center;
}
.cb-swatch__input {
	position: absolute;
	width: 1px;
	height: 1px;
	margin: -1px;
	padding: 0;
	overflow: hidden;
	clip: rect(0, 0, 0, 0);
	border: 0;
	white-space: nowrap;
}
.cb-swatch__chip-wrap {
	width: 32px;
	height: 32px;
	display: flex;
	align-items: center;
	justify-content: center;
}
.cb-swatch__chip {
	display: block;
	width: 28px;
	height: 28px;
	border-radius: 6px;
	box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.15);
	transition: box-shadow 0.12s ease, transform 0.12s ease;
}
.cb-swatch:hover .cb-swatch__chip {
	transform: scale(1.08);
	box-shadow: 0 0 0 2px rgba(34, 113, 177, 0.45);
}
.cb-swatch__input:checked ~ .cb-swatch__chip-wrap .cb-swatch__chip {
	box-shadow: 0 0 0 2px #2271b1, 0 0 0 3px #fff;
}
.cb-swatch__input:focus-visible ~ .cb-swatch__chip-wrap .cb-swatch__chip {
	box-shadow: 0 0 0 2px #2271b1, 0 0 0 3px #fff;
}
.cb-swatch__name {
	color: #50575e;
	width: 100%;
	word-break: break-word;
}
.cb-swatch__input:checked ~ .cb-swatch__name {
	color: #2271b1;
}
CSS
	);
}
add_action( 'admin_enqueue_scripts', 'cb_search_enqueue_admin_assets' );

function cb_search_render_opacity_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (int) ( $settings[ $key ] ?? 0 );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<input type="range" id="%1$s" name="%2$s" value="%3$d" min="0" max="100" step="1" oninput="document.getElementById(\'%1$s-val\').textContent=this.value+\'%%\'" style="vertical-align:middle;width:240px;" />'
		. ' <output id="%1$s-val" style="margin-left:8px;font-variant-numeric:tabular-nums;">%3$d%%</output>',
		esc_attr( $field_id ),
		esc_attr( $name ),
		(int) $value
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

function cb_search_render_number_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (int) ( $settings[ $key ] ?? 0 );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';
	$min         = (int) ( $args['min'] ?? 1 );
	$max         = (int) ( $args['max'] ?? 100 );

	printf(
		'<input type="number" id="%s" name="%s" value="%d" min="%d" max="%d" step="1" style="width:90px;" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		(int) $value,
		(int) $min,
		(int) $max
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

function cb_search_sanitize( $input ): array {
	$defaults  = cb_search_defaults();
	$sanitized = [];

	$text_keys = [
		'eyebrow_text', 'heading_with_query', 'heading_no_query',
		'empty_line', 'empty_back_label', 'form_placeholder', 'form_button',
	];
	foreach ( $text_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) $input[ $k ] : '';
		$clean = sanitize_text_field( wp_unslash( $raw ) );
		$sanitized[ $k ] = $clean !== '' ? $clean : $defaults[ $k ];
	}

	$textarea_keys = [ 'hint_no_query', 'empty_hint' ];
	foreach ( $textarea_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) $input[ $k ] : '';
		$clean = sanitize_textarea_field( wp_unslash( $raw ) );
		$sanitized[ $k ] = $clean !== '' ? $clean : $defaults[ $k ];
	}

	$ppp = isset( $input['posts_per_page'] ) ? (int) $input['posts_per_page'] : $defaults['posts_per_page'];
	$sanitized['posts_per_page'] = max( 1, min( 100, $ppp ) );

	$rad = isset( $input['radius'] ) ? (int) $input['radius'] : $defaults['radius'];
	$sanitized['radius'] = max( 0, min( 40, $rad ) );

	$card_rad = isset( $input['card_radius'] ) ? (int) $input['card_radius'] : $defaults['card_radius'];
	$sanitized['card_radius'] = max( 0, min( 40, $card_rad ) );

	$pill_rad = isset( $input['pill_radius'] ) ? (int) $input['pill_radius'] : $defaults['pill_radius'];
	$sanitized['pill_radius'] = max( 0, min( 999, $pill_rad ) );

	/* Color keys — slug-only. Each value must match a slug declared in the
	   active theme's theme.json palette. Anything else (legacy hex, junk,
	   slug for a color that's been removed from theme.json) falls back to
	   the default slug. This is the design-system lockdown. */
	$color_keys = [
		'overlay_panel_bg', 'overlay_panel_text', 'overlay_panel_muted',
		'overlay_panel_placeholder', 'overlay_icon_color',
		'overlay_close_hover_bg', 'overlay_result_hover_bg',
		'overlay_all_results_color', 'overlay_all_results_hover_color',
		'overlay_all_results_hover_bg',
		'overlay_backdrop_color',
		'results_eyebrow_color', 'results_heading_color',
		'results_text', 'results_muted',
		'results_input_bg', 'results_input_text', 'results_input_border',
		'results_submit_bg', 'results_submit_text', 'results_submit_hover_bg',
		'results_link_hover',
		'pill_text', 'pill_bg',
	];
	$palette     = cb_get_theme_palette();
	$valid_slugs = array_column( $palette, 'slug' );
	$existing    = get_option( CB_SEARCH_OPTION, [] );
	if ( ! is_array( $existing ) ) $existing = [];
	foreach ( $color_keys as $k ) {
		// Field not submitted (hidden derived field in v0.10+ admin UI):
		// preserve whatever was previously saved so legacy per-state
		// overrides survive a save action on the simplified form.
		if ( ! array_key_exists( $k, $input ) ) {
			if ( array_key_exists( $k, $existing ) ) {
				$sanitized[ $k ] = (string) $existing[ $k ];
			}
			continue;
		}
		$raw = trim( (string) wp_unslash( $input[ $k ] ) );
		if ( in_array( $raw, $valid_slugs, true ) ) {
			$sanitized[ $k ] = $raw;
		} else {
			$sanitized[ $k ] = $defaults[ $k ];
		}
	}

	$op_raw = isset( $input['overlay_backdrop_opacity'] ) ? (int) $input['overlay_backdrop_opacity'] : $defaults['overlay_backdrop_opacity'];
	$sanitized['overlay_backdrop_opacity'] = max( 0, min( 100, $op_raw ) );

	return $sanitized;
}

/* ── Frontend CSS injector ──────────────────────────────────────────────────── */

/**
 * Emit a <style> block in <head> that publishes the configured colors as
 * CSS custom properties on :root. The theme's stylesheet reads these vars
 * (--cb-search-panel-bg, --cb-search-panel-text, etc.) so the admin's
 * picks become the live values without touching the stylesheet.
 */
function cb_search_emit_css_vars(): void {
	$s       = cb_get_search_settings();
	$palette = cb_get_theme_palette();

	// Compose the translucent backdrop from the slug's hex + 0–100 opacity.
	// Slug → hex lookup happens server-side so the rgba() string is fully
	// resolved (CSS can't natively turn `var(...)` into an rgba channel).
	$backdrop_hex = cb_search_resolve_color_to_hex( (string) $s['overlay_backdrop_color'], $palette );
	$bd           = ltrim( $backdrop_hex, '#' );
	if ( strlen( $bd ) === 3 ) {
		$bd = $bd[0] . $bd[0] . $bd[1] . $bd[1] . $bd[2] . $bd[2];
	}
	$r = strlen( $bd ) === 6 ? hexdec( substr( $bd, 0, 2 ) ) : 0;
	$g = strlen( $bd ) === 6 ? hexdec( substr( $bd, 2, 2 ) ) : 0;
	$b = strlen( $bd ) === 6 ? hexdec( substr( $bd, 4, 2 ) ) : 0;
	$a = number_format( ( (int) $s['overlay_backdrop_opacity'] ) / 100, 2, '.', '' );
	$backdrop_rgba = "rgba({$r},{$g},{$b},{$a})";

	// Map each setting key to its CSS-var name. Each value becomes
	// `var(--wp--preset--color--SLUG, HEX)` so the active theme.json palette
	// drives the live color, with a hex fallback for cache-misses.
	// Keys in $tint_pct emit at low alpha via color-mix() — hover tints need
	// to be translucent or they're indistinguishable from the panel they
	// sit on (e.g. surface hover on a surface panel = invisible).
	$mapping = [
		'overlay_panel_bg'              => '--cb-search-panel-bg',
		'overlay_panel_text'            => '--cb-search-panel-text',
		'overlay_panel_muted'           => '--cb-search-panel-muted',
		'overlay_panel_placeholder'     => '--cb-search-panel-placeholder',
		'overlay_icon_color'            => '--cb-search-icon-color',
		'overlay_close_hover_bg'        => '--cb-search-close-hover-bg',
		'overlay_result_hover_bg'       => '--cb-search-result-hover-bg',
		'overlay_all_results_color'        => '--cb-search-all-results-color',
		'overlay_all_results_hover_color'  => '--cb-search-all-results-hover-color',
		'overlay_all_results_hover_bg'     => '--cb-search-all-results-hover-bg',
		'results_eyebrow_color'         => '--cb-search-results-eyebrow',
		'results_heading_color'         => '--cb-search-results-heading',
		'results_text'                  => '--cb-search-results-text',
		'results_muted'                 => '--cb-search-results-muted',
		'results_input_bg'              => '--cb-search-results-input-bg',
		'results_input_text'            => '--cb-search-results-input-text',
		'results_input_border'          => '--cb-search-results-input-border',
		'results_submit_bg'             => '--cb-search-results-submit-bg',
		'results_submit_text'           => '--cb-search-results-submit-text',
		'results_submit_hover_bg'       => '--cb-search-results-submit-hover-bg',
		'results_link_hover'            => '--cb-search-results-link-hover',
		'pill_text'                     => '--cb-search-pill-text',
		'pill_bg'                       => '--cb-search-pill-bg',
	];
	$tint_pct = [
		'overlay_close_hover_bg'       => 8,
		'overlay_result_hover_bg'      => 8,
		'overlay_all_results_hover_bg' => 8,
		// Pill bg shows as a light 10% tone of the chosen colour, matching
		// the current hardcoded rgba(accent, 0.10) look.
		'pill_bg'                      => 10,
	];

	$decls = [];
	foreach ( $mapping as $key => $var ) {
		$resolved = cb_search_resolve_color_to_css( (string) $s[ $key ], $palette );
		if ( isset( $tint_pct[ $key ] ) && $resolved !== 'transparent' && $resolved !== 'currentColor' ) {
			$pct      = (int) $tint_pct[ $key ];
			$resolved = "color-mix(in srgb, {$resolved} {$pct}%, transparent)";
		}
		$decls[] = $var . ':' . $resolved;
	}
	$decls[] = '--cb-search-backdrop-bg:' . $backdrop_rgba;
	$decls[] = '--cb-search-radius:' . (int) $s['radius'] . 'px';
	$decls[] = '--cb-search-card-radius:' . (int) $s['card_radius'] . 'px';
	$decls[] = '--cb-search-pill-radius:' . (int) $s['pill_radius'] . 'px';

	// Baseline rules that read the vars emitted above. Shipped here in the
	// plugin (not the theme) so the search UI respects admin choices on
	// EVERY site, even when the active theme has stale CSS or a broad
	// `.cb-site-header a:hover { color: #fff !important; ... }` rule that
	// would otherwise repaint overlay anchors white on hover.
	//
	// !important + plain class specificity wins over equal-specificity
	// theme `!important` rules by declaration order — this <style> tag is
	// emitted at wp_head priority 100, after theme stylesheets.
	$rules = (
		// Standalone results page
		'.cb-search-page__eyebrow{color:var(--cb-search-results-eyebrow, var(--cb-search-results-muted, currentColor)) !important;}'
		. '.cb-search-page__heading{color:var(--cb-search-results-heading, var(--cb-search-results-text, currentColor)) !important;}'

		// Header dropdown — admin controls drive every interactive state.
		// Selectors are prefixed with `.rh-search-overlay` so specificity
		// matches the common theme pattern
		//   `.rh-search-overlay .rh-search-all { color: ... !important; }`
		// — without the prefix, the theme's two-class selector beats our
		// one-class !important even with the priority-100 cascade trick.
		// `text-decoration: none` everywhere defeats the broad
		// `header a:hover { text-decoration: underline !important; }`
		// patterns common in themes.
		. '.rh-search-overlay .rh-search-all{'
		.   'color:var(--cb-search-all-results-color, currentColor) !important;'
		.   'text-decoration:none !important;'
		. '}'
		. '.rh-search-overlay .rh-search-all:hover,.rh-search-overlay .rh-search-all:focus-visible{'
		.   'color:var(--cb-search-all-results-hover-color, var(--cb-search-all-results-color, currentColor)) !important;'
		.   'background:var(--cb-search-all-results-hover-bg, transparent) !important;'
		.   'text-decoration:none !important;'
		. '}'
		. '.rh-search-overlay .rh-search-result,.rh-search-overlay .rh-search-result:hover,.rh-search-overlay .rh-search-result:focus-visible{'
		.   'text-decoration:none !important;'
		. '}'
		. '.rh-search-overlay .rh-search-result.is-active,.rh-search-overlay .rh-search-result:hover{'
		.   'background:var(--cb-search-result-hover-bg, transparent) !important;'
		. '}'
	);

	// ── Results-page hit-title hover ────────────────────────────────────────
	// Theme groups hit-title under --cb-search-results-link-hover on hover,
	// which doubles as the "Page accent" core (submit-button colour). When
	// admins pick a light accent (e.g. White) for the button, hit-titles
	// went invisible on hover. Force hit-title hover to stay body-text
	// colour — underline alone carries the hover feedback. Submit button
	// keeps the bright accent independently.
	$rules .= '.cb-search-page__hit-link:hover .cb-search-page__hit-title,'
		. '.cb-search-page__hit-link:focus-visible .cb-search-page__hit-title{'
		. 'color:var(--cb-search-results-text, currentColor) !important;'
		. '}';

	// ── Single-project page visibility floor ────────────────────────────────
	// The "Beskrivelse" eyebrow and the meta-strip values are rendered by
	// theme-side `the_content` filters that ship no colour API. On themes
	// where a broad cream/`color:inherit` rule turns these invisible on a
	// light body bg, force the brand palette via !important. NOT
	// admin-customizable yet — the block-conversion refactor planned for
	// the next release exposes per-element controls. Until then, these
	// rules guarantee these elements have legible contrast out of the box.
	$rules .= '.cb-project-body__eyebrow{'
		. 'color:var(--wp--preset--color--accent, currentColor) !important;'
		. '}'
		. '.cb-project-meta-strip dt{'
		. 'color:var(--wp--preset--color--accent, currentColor) !important;'
		. '}'
		. '.cb-project-meta-strip dd{'
		. 'color:var(--wp--preset--color--primary, currentColor) !important;'
		. '}';

	// ── Orphaned-var wiring ─────────────────────────────────────────────────
	// The built stylesheet hardcodes the dropdown panel bg, the backdrop, and
	// the ENTIRE results-page palette (input box, submit button, body text) —
	// so those admin settings published vars that nothing read ("colours don't
	// work"). Wire them here (priority-100 !important so they win the cascade),
	// each with the built CSS's previous hardcoded value as the fallback.
	$rules .=
		// Header dropdown
		'.rh-search-panel{background:var(--cb-search-panel-bg, var(--wp--preset--color--surface, #f1ece1)) !important;}'
		. '.rh-search-overlay{background:var(--cb-search-backdrop-bg, rgba(10,15,30,0.55)) !important;}'
		// Results page — input box
		. '.cb-search-page__form{background:var(--cb-search-results-input-bg, rgba(255,255,255,0.08)) !important;border-color:var(--cb-search-results-input-border, rgba(255,255,255,0.15)) !important;}'
		. '.cb-search-page__form input[type="search"]{color:var(--cb-search-results-input-text, #fff) !important;}'
		// Results page — submit button
		. '.cb-search-page__form button{background:var(--cb-search-results-submit-bg, currentColor) !important;color:var(--cb-search-results-submit-text, #fff) !important;}'
		. '.cb-search-page__form button:hover,.cb-search-page__form button:focus-visible{background:var(--cb-search-results-submit-hover-bg, var(--cb-search-results-submit-bg, currentColor)) !important;}'
		// Results page — body text + muted helpers
		. '.cb-search-page__body,.cb-search-page__empty-line,.cb-search-page__hit-title{color:var(--cb-search-results-text, currentColor) !important;}'
		// NOTE: `.cb-search-page__hit-type` is intentionally NOT in this muted
		// group — the type pill now has its own admin-controlled text colour
		// (see the pill rules below) so it must not be forced to the muted
		// body colour here.
		. '.cb-search-page__count,.cb-search-page__hint,.cb-search-page__hit-excerpt,.cb-search-page__empty-hint{color:var(--cb-search-results-muted, var(--cb-search-results-text, currentColor)) !important;}';

	// ── Corner radius (admin-controlled). Modal panel scoped to ≥641px so the
	// mobile full-screen search panel stays square; results-page input box +
	// its submit button round to match.
	$rules .= '@media(min-width:641px){.rh-search-panel{border-radius:var(--cb-search-radius,16px) !important;}}'
		. '.cb-search-page__form{border-radius:var(--cb-search-radius,16px) !important;}'
		. '.cb-search-page__form button{border-radius:max(0px,calc(var(--cb-search-radius,16px) - 4px)) !important;}';

	// ── Result cards + type pills (admin-controlled). Shared across the header
	// dropdown (`.rh-search-result*`) and the /?s= results page
	// (`.cb-search-page__hit*`). Fallbacks reproduce the previously hardcoded
	// look: pill text = accent, pill bg = accent @10%, pill radius = 999px
	// (full pill), card radius = 8px (dropdown) / 12px (results page). The
	// admin's single card-radius now applies to both surfaces.
	$rules .= '.rh-search-result__type,.cb-search-page__hit-type{'
		.   'color:var(--cb-search-pill-text, var(--wp--preset--color--accent, currentColor)) !important;'
		.   'background:var(--cb-search-pill-bg, color-mix(in srgb, var(--wp--preset--color--accent, #f0a83c) 10%, transparent)) !important;'
		.   'border-radius:var(--cb-search-pill-radius, 999px) !important;'
		. '}'
		. '.rh-search-result,.cb-search-page__hit-link{'
		.   'border-radius:var(--cb-search-card-radius, 12px) !important;'
		. '}';

	$css = ':root{' . implode( ';', $decls ) . ';}' . $rules;
	// wp_strip_all_tags() so a value can never close the <style> element and
	// start an executable one. Values are already sanitized in cb_search_sanitize().
	printf( '<style id="cb-search-vars">%s</style>', wp_strip_all_tags( $css ) );
}
// Priority 100 — runs AFTER theme stylesheets so equal-specificity
// `!important` rules in this <style> tag win the cascade.
add_action( 'wp_head', 'cb_search_emit_css_vars', 100 );

/* ── Admin page template ────────────────────────────────────────────────────── */

function cb_search_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) return;
	?>
	<div class="wrap cb-search-settings-wrap">
		<h1><?php esc_html_e( 'Search Settings', 'styrk-blocks' ); ?></h1>
		<p class="description" style="max-width:720px;">
			<?php esc_html_e( 'Copy + colour controls for the header search dropdown and the standalone /?s= results page. Every color picker is locked to the active theme palette — add new colours in theme.json.', 'styrk-blocks' ); ?>
		</p>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'cb_search_group' );
			cb_search_render_collapsible_sections( 'cb-search-settings' );
			submit_button();
			?>
		</form>
	</div>
	<?php
}

/**
 * Tiny schematic SVG previews — one per settings section — so admins can
 * see *what* and *where* on the site each group of fields affects without
 * leaving the page. Deliberately abstract (grey = neutral chrome, WP-admin
 * blue = the region this section controls); colour sections also carry a
 * small swatch trio to signal "this changes colours." All markup is
 * hardcoded (no user input), so it is emitted verbatim.
 *
 * @return string Inline SVG, or '' when no preview is defined for the id.
 */
function cb_search_section_preview_svg( string $id ): string {
	$frame = '<rect x="1.5" y="1.5" width="129" height="93" rx="7" fill="#fff" stroke="#c3c4c7" stroke-width="1.5"/>';
	$open  = '<svg viewBox="0 0 132 96" role="img" focusable="false" aria-label="%s">' . $frame;

	switch ( $id ) {
		case 'cb_search_heading': // Navy hero band + headline text on the results page.
			return sprintf( $open, esc_attr__( 'Preview: results-page hero band with eyebrow and heading', 'styrk-blocks' ) )
				. '<rect x="10" y="10" width="112" height="40" rx="4" fill="#e7f0f8" stroke="#2271b1"/>'
				. '<rect x="20" y="18" width="26" height="4" rx="2" fill="#2271b1"/>'
				. '<rect x="20" y="27" width="72" height="7" rx="3.5" fill="#2271b1"/>'
				. '<rect x="20" y="40" width="50" height="3" rx="1.5" fill="#9cb8d4"/>'
				. '<rect x="20" y="62" width="92" height="4" rx="2" fill="#dcdcde"/>'
				. '<rect x="20" y="72" width="92" height="4" rx="2" fill="#dcdcde"/>'
				. '<rect x="20" y="82" width="60" height="4" rx="2" fill="#dcdcde"/>'
				. '</svg>';

		case 'cb_search_empty': // Magnifier + "no results" copy, no result rows.
			return sprintf( $open, esc_attr__( 'Preview: empty no-results state with headline and hint', 'styrk-blocks' ) )
				. '<circle cx="66" cy="32" r="10" fill="none" stroke="#c3c4c7" stroke-width="2.5"/>'
				. '<line x1="73" y1="39" x2="80" y2="46" stroke="#c3c4c7" stroke-width="2.5" stroke-linecap="round"/>'
				. '<rect x="30" y="60" width="72" height="6" rx="3" fill="#2271b1"/>'
				. '<rect x="38" y="73" width="56" height="4" rx="2" fill="#dcdcde"/>'
				. '<rect x="50" y="83" width="32" height="4" rx="2" fill="#9cb8d4"/>'
				. '</svg>';

		case 'cb_search_form': // Inline search-again field + submit button.
			return sprintf( $open, esc_attr__( 'Preview: inline search field with placeholder and button', 'styrk-blocks' ) )
				. '<rect x="14" y="39" width="76" height="18" rx="9" fill="#fff" stroke="#c3c4c7" stroke-width="1.5"/>'
				. '<rect x="24" y="46" width="40" height="4" rx="2" fill="#dcdcde"/>'
				. '<rect x="94" y="39" width="24" height="18" rx="6" fill="#2271b1"/>'
				. '<rect x="100" y="46" width="12" height="4" rx="2" fill="#fff"/>'
				. '</svg>';

		case 'cb_search_behaviour': // Result rows + paginated page numbers.
			return sprintf( $open, esc_attr__( 'Preview: result rows with pagination controls', 'styrk-blocks' ) )
				. '<rect x="16" y="16" width="100" height="5" rx="2.5" fill="#dcdcde"/>'
				. '<rect x="16" y="28" width="100" height="5" rx="2.5" fill="#dcdcde"/>'
				. '<rect x="16" y="40" width="100" height="5" rx="2.5" fill="#dcdcde"/>'
				. '<rect x="16" y="52" width="74" height="5" rx="2.5" fill="#dcdcde"/>'
				. '<rect x="40" y="72" width="14" height="14" rx="3" fill="#fff" stroke="#c3c4c7"/>'
				. '<rect x="59" y="72" width="14" height="14" rx="3" fill="#2271b1"/>'
				. '<rect x="78" y="72" width="14" height="14" rx="3" fill="#fff" stroke="#c3c4c7"/>'
				. '</svg>';

		case 'cb_search_overlay_colors': // Header search icon + the dropdown panel it opens.
			return sprintf( $open, esc_attr__( 'Preview: header search icon and the dropdown panel it opens', 'styrk-blocks' ) )
				. '<rect x="10" y="10" width="112" height="16" rx="3" fill="#f0f0f1"/>'
				. '<circle cx="106" cy="18" r="4" fill="none" stroke="#2271b1" stroke-width="1.8"/>'
				. '<line x1="109" y1="21" x2="112" y2="24" stroke="#2271b1" stroke-width="1.8" stroke-linecap="round"/>'
				. '<rect x="62" y="31" width="60" height="50" rx="4" fill="#e7f0f8" stroke="#2271b1"/>'
				. '<rect x="70" y="39" width="44" height="4" rx="2" fill="#9cb8d4"/>'
				. '<rect x="70" y="49" width="36" height="4" rx="2" fill="#9cb8d4"/>'
				. '<rect x="70" y="59" width="40" height="4" rx="2" fill="#9cb8d4"/>'
				. '<rect x="70" y="70" width="30" height="4" rx="2" fill="#2271b1"/>'
				. '<circle cx="20" cy="84" r="4" fill="#2271b1"/>'
				. '<circle cx="31" cy="84" r="4" fill="#9cb8d4"/>'
				. '<circle cx="42" cy="84" r="4" fill="#dcdcde"/>'
				. '</svg>';

		case 'cb_search_results_colors': // The full results page, tinted, with a swatch cue.
			return sprintf( $open, esc_attr__( 'Preview: full results page colours — heading, input and button', 'styrk-blocks' ) )
				. '<rect x="16" y="14" width="60" height="7" rx="3.5" fill="#2271b1"/>'
				. '<rect x="16" y="28" width="80" height="14" rx="7" fill="#fff" stroke="#c3c4c7"/>'
				. '<rect x="100" y="28" width="20" height="14" rx="5" fill="#2271b1"/>'
				. '<rect x="16" y="50" width="104" height="4" rx="2" fill="#dcdcde"/>'
				. '<rect x="16" y="60" width="104" height="4" rx="2" fill="#dcdcde"/>'
				. '<circle cx="20" cy="84" r="4" fill="#2271b1"/>'
				. '<circle cx="31" cy="84" r="4" fill="#9cb8d4"/>'
				. '<circle cx="42" cy="84" r="4" fill="#dcdcde"/>'
				. '</svg>';
	}

	return '';
}

/**
 * Drop-in replacement for `do_settings_sections()` that wraps each
 * registered section in a collapsible `<details>` element. Only the
 * first section is open by default — admins who don't need to tune
 * 20+ colour fields don't have to scroll past them. Each section opens
 * with a small schematic preview (see cb_search_section_preview_svg).
 */
function cb_search_render_collapsible_sections( string $page ): void {
	global $wp_settings_sections, $wp_settings_fields;
	if ( ! isset( $wp_settings_sections[ $page ] ) ) return;

	$first = true;
	foreach ( (array) $wp_settings_sections[ $page ] as $section ) {
		// Sections without color fields stay open; color sections collapse
		// by default. The first non-color section is always open.
		$id        = (string) ( $section['id'] ?? '' );
		$is_colour = ( $id === 'cb_search_overlay_colors' || $id === 'cb_search_results_colors' );
		$open_attr = ( ! $is_colour && $first ) ? ' open' : ( $is_colour ? '' : ' open' );
		$first     = false;

		// Capture the section's intro paragraph so it can sit beside the preview.
		$intro = '';
		if ( ! empty( $section['callback'] ) ) {
			ob_start();
			call_user_func( $section['callback'], $section );
			$intro = (string) ob_get_clean();
		}
		?>
		<details class="cb-search-section"<?php echo $open_attr; // phpcs:ignore ?>>
			<summary class="cb-search-section__summary">
				<span class="cb-search-section__title"><?php echo esc_html( (string) $section['title'] ); ?></span>
				<span class="cb-search-section__chevron" aria-hidden="true">▾</span>
			</summary>
			<div class="cb-search-section__body">
				<?php if ( $intro !== '' || $preview !== '' ) : ?>
					<div class="cb-search-section__intro">
						<div class="cb-search-section__intro-text"><?php echo $intro; // safe: callback output, no user input ?></div>
						<?php if ( $preview !== '' ) : ?>
							<figure class="cb-search-preview"><?php echo cb_search_section_preview_svg( $id ); ?></figure>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<?php
				if ( isset( $wp_settings_fields[ $page ][ $id ] ) ) {
					echo '<table class="form-table" role="presentation">';
					do_settings_fields( $page, $id );
					echo '</table>';
				}
				?>
			</div>
		</details>
		<?php
	}
}

/* ── Seed defaults on first load ────────────────────────────────────────────── */

function cb_search_seed_defaults(): void {
	if ( get_option( CB_SEARCH_OPTION ) ) return;
	update_option( CB_SEARCH_OPTION, cb_search_defaults() );
}
add_action( 'admin_init', 'cb_search_seed_defaults' );

/* ── One-shot migration: existing hex saves → palette slugs ─────────────────── */

/**
 * In v0.8.x the option store held hex strings (`#0F1B2D`). In v0.9.0 it
 * holds theme.json slugs (`primary`). This one-shot maps each saved hex to
 * the closest swatch in the active palette so admins don't lose their
 * configuration on upgrade. Runs once per site (flagged by
 * `cb_search_color_migration_v1`), and only when the palette is loadable
 * — if theme.json isn't ready yet (very early hook), it skips and retries
 * on the next admin_init.
 */
function cb_search_migrate_hex_to_slugs(): void {
	if ( get_option( 'cb_search_color_migration_v1' ) ) return;

	$saved = get_option( CB_SEARCH_OPTION );
	if ( ! is_array( $saved ) || empty( $saved ) ) {
		// Nothing to migrate — fresh install gets the slug defaults directly.
		update_option( 'cb_search_color_migration_v1', 1, false );
		return;
	}

	$palette = cb_get_theme_palette();
	if ( empty( $palette ) ) {
		// Theme.json not yet readable. Don't flag migrated — retry next request.
		return;
	}

	$defaults    = cb_search_defaults();
	$color_keys  = [
		'overlay_panel_bg', 'overlay_panel_text', 'overlay_panel_muted',
		'overlay_panel_placeholder', 'overlay_icon_color',
		'overlay_close_hover_bg', 'overlay_result_hover_bg',
		'overlay_all_results_color', 'overlay_all_results_hover_color',
		'overlay_all_results_hover_bg',
		'overlay_backdrop_color',
		'results_eyebrow_color', 'results_heading_color',
		'results_text', 'results_muted',
		'results_input_bg', 'results_input_text', 'results_input_border',
		'results_submit_bg', 'results_submit_text', 'results_submit_hover_bg',
		'results_link_hover',
		'pill_text', 'pill_bg',
	];
	$valid_slugs = array_column( $palette, 'slug' );

	foreach ( $color_keys as $k ) {
		if ( ! isset( $saved[ $k ] ) ) continue;
		$val = (string) $saved[ $k ];
		if ( in_array( $val, $valid_slugs, true ) ) continue; // already a slug
		if ( $val === '' || $val[0] !== '#' ) {
			// Junk value — reset to default slug.
			$saved[ $k ] = $defaults[ $k ];
			continue;
		}
		$nearest = cb_search_nearest_palette_slug( $val, $palette );
		$saved[ $k ] = $nearest ?: $defaults[ $k ];
	}

	update_option( CB_SEARCH_OPTION, $saved );
	update_option( 'cb_search_color_migration_v1', 1, false );
}
add_action( 'admin_init', 'cb_search_migrate_hex_to_slugs', 9 );

/**
 * Return the palette slug whose color is closest to the given hex via
 * Euclidean distance in RGB. Used by the v0.9.0 migration to map legacy
 * hex settings onto the active theme palette.
 */
function cb_search_nearest_palette_slug( string $hex, array $palette ): ?string {
	$target = cb_search_hex_to_rgb( $hex );
	if ( $target === null ) return null;

	$best_slug = null;
	$best_dist = PHP_FLOAT_MAX;
	foreach ( $palette as $entry ) {
		$rgb = cb_search_hex_to_rgb( (string) ( $entry['color'] ?? '' ) );
		if ( $rgb === null ) continue;
		$dr = $target[0] - $rgb[0];
		$dg = $target[1] - $rgb[1];
		$db = $target[2] - $rgb[2];
		$dist = $dr * $dr + $dg * $dg + $db * $db;
		if ( $dist < $best_dist ) {
			$best_dist = $dist;
			$best_slug = (string) ( $entry['slug'] ?? '' );
		}
	}
	return $best_slug ?: null;
}

function cb_search_hex_to_rgb( string $hex ): ?array {
	$h = ltrim( trim( $hex ), '#' );
	if ( strlen( $h ) === 3 ) {
		$h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
	}
	if ( strlen( $h ) !== 6 || ! ctype_xdigit( $h ) ) return null;
	return [
		hexdec( substr( $h, 0, 2 ) ),
		hexdec( substr( $h, 2, 2 ) ),
		hexdec( substr( $h, 4, 2 ) ),
	];
}
