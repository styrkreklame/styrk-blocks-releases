<?php
/**
 * Header colour logic — PHP port of src/blocks/react-header/colors.ts.
 *
 * The server-rendered header must paint exactly what the client header does,
 * so this mirrors the TypeScript line for line (including its fallbacks for
 * malformed and `var(...)` colours). Both are pinned to
 * tests/fixtures/header-colors.json; change them together.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'CB_HEADER_MOBILE_MENU_BG' ) ) {
	define( 'CB_HEADER_MOBILE_MENU_BG', 'var(--wp--preset--color--primary, #0a2020)' );
}

if ( ! function_exists( 'cb_header_parse_hex' ) ) {
	/**
	 * `#rrggbb` → [r, g, b], anything else → null (as parseHex in colors.ts).
	 *
	 * @param string $hex Colour.
	 * @return int[]|null
	 */
	function cb_header_parse_hex( string $hex ): ?array {
		if ( ! preg_match( '/^#([0-9a-f]{6})$/i', trim( $hex ), $m ) ) {
			return null;
		}
		$n = hexdec( $m[1] );
		return [ ( $n >> 16 ) & 0xff, ( $n >> 8 ) & 0xff, $n & 0xff ];
	}
}

if ( ! function_exists( 'cb_header_relative_luminance' ) ) {
	/**
	 * WCAG relative luminance; malformed input counts as dark (0).
	 *
	 * @param string $hex Colour.
	 * @return float
	 */
	function cb_header_relative_luminance( string $hex ): float {
		$rgb = cb_header_parse_hex( $hex );
		if ( null === $rgb ) {
			return 0.0;
		}
		[ $r, $g, $b ] = array_map(
			static function ( int $v ): float {
				$s = $v / 255;
				return $s <= 0.03928 ? $s / 12.92 : ( ( $s + 0.055 ) / 1.055 ) ** 2.4;
			},
			$rgb
		);
		return 0.2126 * $r + 0.7152 * $g + 0.0722 * $b;
	}
}

if ( ! function_exists( 'cb_header_mix_with_black' ) ) {
	/**
	 * Darken a hex colour by `$amount` (0–1); non-hex input is returned as-is.
	 *
	 * @param string $hex    Colour.
	 * @param float  $amount Share of black.
	 * @return string
	 */
	function cb_header_mix_with_black( string $hex, float $amount ): string {
		$rgb = cb_header_parse_hex( $hex );
		if ( null === $rgb ) {
			return $hex;
		}
		$f = 1 - $amount;
		return '#' . implode(
			'',
			array_map(
				static function ( int $v ) use ( $f ): string {
					// JS Math.round rounds .5 up; PHP round() matches for positives.
					return str_pad( dechex( max( 0, min( 255, (int) round( $v * $f ) ) ) ), 2, '0', STR_PAD_LEFT );
				},
				$rgb
			)
		);
	}
}

if ( ! function_exists( 'cb_header_panel_style' ) ) {
	/**
	 * Dropdown panel style (derivePanelStyle in colors.ts).
	 *
	 * @param string $header_bg  Header background colour setting.
	 * @param bool   $is_overlay Overlay (transparent-over-hero) mode.
	 * @return array<string, string> camelCase CSS properties, as the client uses.
	 */
	function cb_header_panel_style( string $header_bg, bool $is_overlay ): array {
		$base = [
			'border'       => '1px solid rgba(255,255,255,0.08)',
			'borderRadius' => '12px',
			'padding'      => '6px',
			'minWidth'     => '220px',
			'boxShadow'    => '0 16px 48px rgba(0,0,0,0.5), 0 0 0 0.5px rgba(255,255,255,0.04)',
		];
		if ( $is_overlay ) {
			return $base + [
				'background'           => 'rgba(10,15,30,0.92)',
				'backdropFilter'       => 'blur(20px) saturate(160%)',
				'WebkitBackdropFilter' => 'blur(20px) saturate(160%)',
			];
		}
		$dark = cb_header_relative_luminance( $header_bg ) < 0.5;
		return $base + [ 'background' => $dark ? cb_header_mix_with_black( $header_bg, 0.25 ) : '#0a2020' ];
	}
}

if ( ! function_exists( 'cb_header_colors' ) ) {
	/**
	 * Bar background and nav colours for one header state (deriveHeaderColors).
	 *
	 * @param array<string, mixed> $state bgMode, bgColor, textColor,
	 *                                    solidifyOnScroll, scrolled, menuOpen,
	 *                                    mobileMenuBg, mobileMenuText.
	 * @return array{headerBg: string, navColor: string, navColorFaded: string}
	 */
	function cb_header_colors( array $state ): array {
		$bg_mode       = (string) ( $state['bgMode'] ?? '' );
		$bg_color      = (string) ( $state['bgColor'] ?? '' );
		$text_color    = (string) ( $state['textColor'] ?? '' );
		$solidify      = ! empty( $state['solidifyOnScroll'] );
		$scrolled      = ! empty( $state['scrolled'] );
		$menu_open     = ! empty( $state['menuOpen'] );
		$mobile_bg     = (string) ( $state['mobileMenuBg'] ?? '' );
		$mobile_text   = (string) ( $state['mobileMenuText'] ?? '' );

		$show_solid = 'solid' === $bg_mode || ( $solidify && $scrolled );
		if ( $menu_open ) {
			$header_bg = '' !== $mobile_bg ? $mobile_bg : CB_HEADER_MOBILE_MENU_BG;
		} else {
			$header_bg = $show_solid ? $bg_color : 'transparent';
		}

		// White over the transparent front-page hero until scrolled; the
		// configured text colour is only contrast-checked against the solid bg.
		$over_hero = $solidify && ! $scrolled && ! $menu_open;

		if ( $menu_open ) {
			$nav       = '' !== $mobile_text ? $mobile_text : '#ffffff';
			$nav_faded = '' !== $mobile_text ? $mobile_text : '#ffffffe0';
		} elseif ( $over_hero ) {
			$nav       = '#ffffff';
			$nav_faded = '#ffffffe0';
		} else {
			$nav       = $text_color;
			$nav_faded = $text_color . 'e0'; // Same hex-alpha trick as the client, quirks included.
		}

		return [
			'headerBg'      => $header_bg,
			'navColor'      => $nav,
			'navColorFaded' => $nav_faded,
		];
	}
}
