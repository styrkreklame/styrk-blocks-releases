<?php
/**
 * Login privacy.
 *
 * A stock WordPress publishes every author's login name to anonymous
 * visitors: the REST users endpoint, `/?author=1` (which redirects to
 * `/author/<slug>/`), the oEmbed author, and — via SmartCrawl — the Person
 * schema printed on every page. Our sites log in with the account email, so
 * that hands an attacker half the credentials for brute force or credential
 * stuffing.
 *
 * The email may still be shown as a CONTACT address. This only stops
 * WordPress announcing an account's login. Logged-in users keep everything
 * (the editor's author picker reads the users endpoint).
 *
 * The decisions live in pure functions so they can be unit-tested without
 * WordPress; the hooks at the bottom feed them live state.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_privacy_rest_endpoints' ) ) {
	/**
	 * Drop the /wp/v2/users routes for anonymous requests.
	 *
	 * @param array $endpoints REST routes, keyed by pattern.
	 * @param bool  $logged_in Whether the request is authenticated.
	 * @return array
	 */
	function cb_privacy_rest_endpoints( array $endpoints, bool $logged_in ): array {
		if ( $logged_in ) {
			return $endpoints;
		}
		foreach ( array_keys( $endpoints ) as $route ) {
			if ( 0 === strpos( (string) $route, '/wp/v2/users' ) ) {
				unset( $endpoints[ $route ] );
			}
		}
		return $endpoints;
	}
}

if ( ! function_exists( 'cb_privacy_request_vars' ) ) {
	/**
	 * Turn author lookups into a 404 for anonymous visitors.
	 *
	 * Removing the vars here, before WP_Query runs, also stops
	 * redirect_canonical() from answering `/?author=1` with a Location header
	 * that spells out the login slug.
	 *
	 * @param array $vars      Parsed query vars.
	 * @param bool  $logged_in Whether the visitor is logged in.
	 * @return array
	 */
	function cb_privacy_request_vars( array $vars, bool $logged_in ): array {
		if ( $logged_in || ( ! isset( $vars['author'] ) && ! isset( $vars['author_name'] ) ) ) {
			return $vars;
		}
		unset( $vars['author'], $vars['author_name'] );
		$vars['error'] = '404';
		return $vars;
	}
}

if ( ! function_exists( 'cb_privacy_oembed' ) ) {
	/**
	 * Credit oEmbeds to the site instead of the account.
	 *
	 * @param array  $data      oEmbed response data.
	 * @param string $site_name Site title.
	 * @param string $home      Home URL.
	 * @return array
	 */
	function cb_privacy_oembed( array $data, string $site_name, string $home ): array {
		if ( isset( $data['author_name'] ) ) {
			$data['author_name'] = $site_name;
		}
		if ( isset( $data['author_url'] ) ) {
			$data['author_url'] = $home;
		}
		return $data;
	}
}

if ( ! function_exists( 'cb_privacy_scrub_schema' ) ) {
	/**
	 * Remove login names and author-archive URLs from schema data.
	 *
	 * Author URLs are rewritten to the home URL everywhere (they embed the
	 * login slug), which keeps `@id` references consistent. A Person whose
	 * name IS a login or email is renamed to the site; other fields — such as
	 * an Organization's public contact email — are left alone.
	 *
	 * @param mixed    $data        Schema data (array tree).
	 * @param string[] $author_urls Author archive URLs to replace.
	 * @param string[] $secrets     Login names / emails that must not be a name.
	 * @param string   $site_name   Replacement name.
	 * @param string   $home        Replacement URL.
	 * @return mixed
	 */
	function cb_privacy_scrub_schema( $data, array $author_urls, array $secrets, string $site_name, string $home ) {
		if ( is_string( $data ) ) {
			return $author_urls ? str_replace( $author_urls, $home, $data ) : $data;
		}
		if ( ! is_array( $data ) ) {
			return $data;
		}
		foreach ( $data as $key => $value ) {
			$data[ $key ] = cb_privacy_scrub_schema( $value, $author_urls, $secrets, $site_name, $home );
		}
		if ( ( $data['@type'] ?? '' ) === 'Person' && in_array( $data['name'] ?? null, $secrets, true ) ) {
			$data['name'] = $site_name;
		}
		return $data;
	}
}

if ( ! function_exists( 'cb_privacy_author_identities' ) ) {
	/**
	 * Author archive URLs and login identifiers of everyone who has published.
	 *
	 * @return array{0: string[], 1: string[]} [ author URLs, secrets ].
	 */
	function cb_privacy_author_identities(): array {
		static $cache = null;
		if ( null !== $cache ) {
			return $cache;
		}
		$urls    = [];
		$secrets = [];
		foreach ( get_users( [ 'has_published_posts' => true ] ) as $user ) {
			$urls[]    = get_author_posts_url( $user->ID, $user->user_nicename );
			$secrets[] = $user->user_login;
			$secrets[] = $user->user_email;
			$secrets[] = $user->user_nicename;
		}
		$cache = [ $urls, array_values( array_unique( array_filter( $secrets ) ) ) ];
		return $cache;
	}
}

add_filter(
	'rest_endpoints',
	static function ( $endpoints ) {
		return cb_privacy_rest_endpoints( (array) $endpoints, is_user_logged_in() );
	}
);

add_filter(
	'request',
	static function ( $vars ) {
		return is_admin() ? $vars : cb_privacy_request_vars( (array) $vars, is_user_logged_in() );
	}
);

add_filter(
	'oembed_response_data',
	static function ( $data ) {
		return cb_privacy_oembed( (array) $data, (string) get_bloginfo( 'name' ), home_url( '/' ) );
	}
);

// Core's users sitemap lists every author archive (and so every login slug).
add_filter(
	'wp_sitemaps_add_provider',
	static function ( $provider, $name ) {
		return 'users' === $name ? false : $provider;
	},
	10,
	2
);

// SmartCrawl prints a Person node for the post author on every page.
add_filter(
	'wds_schema_printer_schema_data',
	static function ( $data ) {
		[ $urls, $secrets ] = cb_privacy_author_identities();
		return cb_privacy_scrub_schema( $data, $urls, $secrets, (string) get_bloginfo( 'name' ), home_url( '/' ) );
	}
);
