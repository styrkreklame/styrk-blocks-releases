<?php
/**
 * Plugin Name: Styrk Blocks
 * Description: Styrk Reklame's block + admin-UX toolkit — hero, CTA, employee grid, testimonial, rich-text section, logo strip, stats row, feature cards, FAQ accordion, split section, and more.
 * Version:     0.10.76
 * Author:      Styrk Reklame AS
 * Requires at least: 6.4
 * Requires PHP: 8.3
 * Text Domain: styrk-blocks
 * Update URI:  https://github.com/styrkreklame/styrk-blocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard: protects against double-load scenarios (symlink + mu
// plugin, manual include, etc.) that would otherwise fatal on function
// redeclaration below.
if ( defined( 'CB_CUSTOM_BLOCKS_LOADED' ) ) return;
define( 'CB_CUSTOM_BLOCKS_LOADED', true );

/* ── Fix asset URLs when plugin is symlinked ──────────────────────────────── */
add_filter( 'plugins_url', function ( string $url, string $path, string $plugin ): string {
	static $real = null, $sym = null;
	if ( $real === null ) {
		$sym  = wp_normalize_path( dirname( __FILE__ ) );
		$real = wp_normalize_path( dirname( realpath( __FILE__ ) ) );
	}
	if ( $real !== $sym ) {
		$url = str_replace(
			wp_normalize_path( $real ),
			wp_normalize_path( $sym ),
			wp_normalize_path( $url )
		);
	}
	return $url;
}, 10, 3 );

/* ── Includes ─────────────────────────────────────────────────────────────── */
require_once __DIR__ . '/includes/a11y-color.php';
require_once __DIR__ . '/includes/nav-menu.php';
require_once __DIR__ . '/includes/eyebrow.php';
require_once __DIR__ . '/includes/video-helpers.php';
require_once __DIR__ . '/includes/updater.php';
require_once __DIR__ . '/includes/companion-theme.php';
require_once __DIR__ . '/includes/header-settings.php';
require_once __DIR__ . '/includes/footer-settings.php';
require_once __DIR__ . '/includes/footer-shortcodes.php';
require_once __DIR__ . '/includes/icons.php';
require_once __DIR__ . '/includes/webp-converter.php';
require_once __DIR__ . '/includes/search-settings.php';
require_once __DIR__ . '/includes/search-render.php';
require_once __DIR__ . '/includes/schema-person.php';

add_action( 'init', function () {
	/* Register shared block CSS so it loads on frontend AND inside the editor iframe. */
	$css_file = __DIR__ . '/build/style-index.css';
	if ( file_exists( $css_file ) ) {
		wp_register_style(
			'styrk-blocks-shared',
			plugins_url( 'build/style-index.css', __FILE__ ),
			[],
			(string) filemtime( $css_file )
		);
	}

	foreach ( glob( __DIR__ . '/build/blocks/*', GLOB_ONLYDIR ) as $block ) {
		register_block_type( $block );

		// Backward-compat: the plugin was previously named "Custom Blocks"
		// and blocks shipped under the `custom-blocks/` namespace. Posts
		// and template parts saved before the rename still reference those
		// old names. Register each block a SECOND time under its legacy
		// name so existing content keeps rendering without a DB migration.
		// New content saves under `styrk-blocks/` — no harm.
		$block_json = $block . '/block.json';
		if ( file_exists( $block_json ) ) {
			$data = json_decode( (string) file_get_contents( $block_json ), true );
			$new_name = is_array( $data ) ? ( $data['name'] ?? '' ) : '';
			if ( is_string( $new_name ) && strpos( $new_name, 'styrk-blocks/' ) === 0 ) {
				$legacy_name = 'custom-blocks/' . substr( $new_name, strlen( 'styrk-blocks/' ) );
				if ( ! \WP_Block_Type_Registry::get_instance()->is_registered( $legacy_name ) ) {
					register_block_type( $block, [ 'name' => $legacy_name ] );
				}
			}
		}
	}

	/*
	 * OPcache caches index.asset.php files, so register_block_type() may read
	 * stale version hashes after a webpack rebuild. Fix this by re-stamping every
	 * styrk-blocks script version using filemtime() — a plain stat() call that
	 * OPcache never touches.
	 */
	$wp_scripts = wp_scripts();
	foreach ( $wp_scripts->registered as $handle => $script ) {
		if ( ! str_starts_with( $handle, 'styrk-blocks-' ) ) {
			continue;
		}
		// Resolve the handle's src to an absolute path.
		$src = $script->src;
		// Strip query-string and WP site URL prefix to get a relative path.
		$src = strtok( $src, '?' );
		$abs = str_replace(
			content_url( 'plugins/styrk-blocks/' ),
			__DIR__ . '/',
			$src
		);
		if ( file_exists( $abs ) ) {
			$script->ver = (string) filemtime( $abs );
		}
	}
} );

/* Enqueue the shared CSS both on the frontend and inside the block editor canvas. */
add_action( 'enqueue_block_assets', function () {
	if ( wp_style_is( 'styrk-blocks-shared', 'registered' ) ) {
		wp_enqueue_style( 'styrk-blocks-shared' );
	}
} );

/* Load Fraunces (display serif used by page-header) inside the editor iframe
   so the editor preview matches the rendered frontend. On the frontend, the
   page-header block's render.php lazy-enqueues this stylesheet only on pages
   that actually render the block. */
/**
 * Brand image shown on an employee card when the employee has NO photo
 * (instead of the initials). Empty by default so the plugin stays
 * client-agnostic — a theme supplies the URL via the filter, e.g.:
 *   add_filter( 'styrk_blocks_employee_photo_fallback',
 *       fn() => get_theme_file_uri( 'assets/symbol-color.png' ) );
 */
if ( ! function_exists( 'cb_employee_photo_fallback_url' ) ) {
	function cb_employee_photo_fallback_url(): string {
		return (string) apply_filters( 'styrk_blocks_employee_photo_fallback', '' );
	}
}

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style(
		'styrk-blocks-fraunces',
		'https://fonts.bunny.net/css?family=fraunces:400,500&display=swap',
		[],
		null
	);

	// Expose the (theme-filtered) employee photo fallback to the editor so the
	// in-canvas card preview matches the front end when there's no photo.
	wp_register_script( 'styrk-blocks-editor-data', false, [], '0.10.2', false );
	wp_enqueue_script( 'styrk-blocks-editor-data' );
	wp_add_inline_script(
		'styrk-blocks-editor-data',
		'window.styrkBlocks = window.styrkBlocks || {};'
			. 'window.styrkBlocks.employeePhotoFallback = '
			. wp_json_encode( cb_employee_photo_fallback_url() ) . ';',
		'before'
	);

	// Single, narrow override: bump the "Type / to choose a block"
	// appender's text colour so it's readable on cream / off-white
	// editor canvases. ONLY this selector — no opacity manipulation,
	// no in-block placeholder selectors (those inherit currentColor
	// from their parent block's text colour, which is correct).
	wp_register_style( 'styrk-blocks-editor-appender-contrast', false, [], '0.10.2' );
	wp_enqueue_style( 'styrk-blocks-editor-appender-contrast' );
	wp_add_inline_style(
		'styrk-blocks-editor-appender-contrast',
		'.editor-styles-wrapper .block-editor-default-block-appender__content{color:rgba(15,27,45,0.55) !important;}'
	);

	/* Editor-side plugins (PluginDocumentSettingPanel, etc.) live under
	 * build/plugins/<name>/index.js, each with a webpack-generated
	 * index.asset.php declaring WP deps. Enqueue every one automatically —
	 * new editor plugins just need to drop a folder in src/plugins/ and
	 * webpack.config.js to register the entry, no PHP boilerplate. */
	$plugins_dir = __DIR__ . '/build/plugins';
	if ( ! is_dir( $plugins_dir ) ) return;
	foreach ( glob( $plugins_dir . '/*', GLOB_ONLYDIR ) as $plugin_dir ) {
		$slug     = basename( $plugin_dir );
		$js_file  = $plugin_dir . '/index.js';
		$asset_php= $plugin_dir . '/index.asset.php';
		if ( ! file_exists( $js_file ) || ! file_exists( $asset_php ) ) continue;

		$asset   = include $asset_php;
		$deps    = is_array( $asset['dependencies'] ?? null ) ? $asset['dependencies'] : [];
		$version = (string) ( $asset['version'] ?? filemtime( $js_file ) );

		wp_enqueue_script(
			'styrk-blocks-plugin-' . $slug,
			plugins_url( 'build/plugins/' . $slug . '/index.js', __FILE__ ),
			$deps,
			$version,
			true
		);
	}
} );

function custom_blocks_register_cpt(): void {
	register_post_type( 'employee', [
		'labels' => [
			'name'          => __( 'Employees',        'styrk-blocks' ),
			'singular_name' => __( 'Employee',         'styrk-blocks' ),
			'add_new_item'  => __( 'Add New Employee', 'styrk-blocks' ),
			'edit_item'     => __( 'Edit Employee',    'styrk-blocks' ),
		],
		'public'       => true,
		'show_in_rest' => true,
		'supports'     => [ 'title', 'thumbnail', 'custom-fields' ],
		'menu_icon'    => 'dashicons-id',
		'has_archive'  => true,
		'rewrite'      => [ 'slug' => 'team' ],
	] );

	// Norwegian labels (source strings) so the admin box reads "Avdelinger /
	// Legg til ny avdeling" on this nb_NO site instead of the bare English
	// "Departments / + Add category" core fallback — the generic wording made
	// the field easy to overlook, leaving employees un-departmented. Hierarchical
	// taxonomy → these drive the post-edit metabox + the term-management screen.
	register_taxonomy( 'employee_department', 'employee', [
		'labels'       => [
			'name'              => __( 'Avdelinger',           'styrk-blocks' ),
			'singular_name'     => __( 'Avdeling',             'styrk-blocks' ),
			'menu_name'         => __( 'Avdelinger',           'styrk-blocks' ),
			'all_items'         => __( 'Alle avdelinger',      'styrk-blocks' ),
			'search_items'      => __( 'Søk i avdelinger',     'styrk-blocks' ),
			'parent_item'       => __( 'Overordnet avdeling',  'styrk-blocks' ),
			'parent_item_colon' => __( 'Overordnet avdeling:', 'styrk-blocks' ),
			'edit_item'         => __( 'Rediger avdeling',     'styrk-blocks' ),
			'update_item'       => __( 'Oppdater avdeling',    'styrk-blocks' ),
			'add_new_item'      => __( 'Legg til ny avdeling',  'styrk-blocks' ),
			'new_item_name'     => __( 'Navn på ny avdeling',   'styrk-blocks' ),
			'not_found'         => __( 'Ingen avdelinger funnet', 'styrk-blocks' ),
			'back_to_items'     => __( '← Til avdelinger',     'styrk-blocks' ),
		],
		'public'            => true,
		'show_in_rest'      => true,
		'hierarchical'      => true,
		'show_admin_column' => true,
	] );

	// Employee role / credential tags (e.g. "Daglig leder", "Tømrer med
	// mesterbrev"). Tag-style (non-hierarchical) so the edit screen exposes
	// the autocomplete chip metabox; one employee can hold several roles
	// and each renders as its own pill on the card.
	register_taxonomy( 'employee_role', 'employee', [
		'labels'       => [
			'name'                       => __( 'Roles',                'styrk-blocks' ),
			'singular_name'              => __( 'Role',                 'styrk-blocks' ),
			'add_new_item'               => __( 'Add new role',         'styrk-blocks' ),
			'search_items'               => __( 'Search roles',         'styrk-blocks' ),
			'popular_items'              => __( 'Frequently used',      'styrk-blocks' ),
			'separate_items_with_commas' => __( 'Separate roles with commas', 'styrk-blocks' ),
			'add_or_remove_items'        => __( 'Add or remove roles',  'styrk-blocks' ),
			'choose_from_most_used'      => __( 'Choose from frequently used', 'styrk-blocks' ),
		],
		'public'       => true,
		'show_in_rest' => true,
		'hierarchical' => false,
		'show_admin_column' => true,
	] );
}
add_action( 'init', 'custom_blocks_register_cpt' );

function custom_blocks_register_meta(): void {
	$fields = [
		'_cb_occupation' => [ 'sanitize_callback' => 'sanitize_text_field' ],
		'_cb_email'      => [ 'sanitize_callback' => 'sanitize_email' ],
		'_cb_phone'      => [ 'sanitize_callback' => 'sanitize_text_field' ],
		'_cb_background' => [ 'sanitize_callback' => 'sanitize_textarea_field', 'type' => 'string' ],
		'_cb_linkedin'   => [ 'sanitize_callback' => 'esc_url_raw' ],
	];

	foreach ( $fields as $key => $extra ) {
		register_post_meta( 'employee', $key, array_merge( [
			'single'        => true,
			'type'          => 'string',
			'default'       => '',
			'show_in_rest'  => true,
			'auth_callback' => fn() => current_user_can( 'edit_posts' ),
		], $extra ) );
	}
}
add_action( 'init', 'custom_blocks_register_meta' );



function custom_blocks_categories( array $categories ): array {
	return array_merge(
		[ [ 'slug' => 'styrk-blocks', 'title' => __( 'Site Blocks', 'styrk-blocks' ) ] ],
		$categories
	);
}
add_filter( 'block_categories_all', 'custom_blocks_categories' );

/**
 * Apply each block's optional `anchorId` (set in the block's Advanced →
 * "HTML-anker" field) as the `id` on its rendered wrapper, so a menu or button
 * link to `#<id>` scrolls straight to that section.
 *
 * Centralised here rather than in every template: the styrk-blocks sections are
 * dynamic (`save() => null`), so core's built-in anchor support can't persist a
 * value, and the value lives in a custom `anchorId` attribute instead. The id is
 * injected into the first opening tag only when that tag doesn't already carry
 * one, so a block that sets its own id is left untouched.
 *
 * @param string $content Rendered block HTML.
 * @param array  $block   Parsed block (name + attrs).
 */
function cb_apply_block_anchor( string $content, array $block ): string {
	$name = $block['blockName'] ?? '';
	if ( '' === $name || 0 !== strpos( $name, 'styrk-blocks/' ) ) {
		return $content;
	}
	$id = preg_replace( '/[^A-Za-z0-9_-]/', '', (string) ( $block['attrs']['anchorId'] ?? '' ) );
	if ( '' === $id || '' === trim( $content ) ) {
		return $content;
	}
	// Inject into the first opening tag, but only if it has no id yet.
	if ( preg_match( '/^(\s*<[a-zA-Z][a-zA-Z0-9-]*)([^>]*?)(\s*\/?>)/', $content, $m ) ) {
		if ( false !== strpos( $m[2], ' id=' ) ) {
			return $content;
		}
		$replacement = $m[1] . $m[2] . ' id="' . esc_attr( $id ) . '"' . $m[3];
		return substr_replace( $content, $replacement, 0, strlen( $m[0] ) );
	}
	return $content;
}
add_filter( 'render_block', 'cb_apply_block_anchor', 10, 2 );


/* ── Project CPT ──────────────────────────────────────────────────────────────
 * Public CPT for project case-studies. Default URL slug is `referanser` for
 * historical reasons (the Skotnes client launched on that path), but the slug
 * is **filterable** via `styrk_blocks_project_rewrite_slug` so per-client
 * themes can rename it without forking the plugin. Styrk Reklame uses
 * `prosjekter`, for example.
 *
 * Whatever slug is used becomes both the rewrite base and the explicit
 * top-priority rewrite rule (so a static page with the same slug doesn't
 * eat the single-project URLs).
 * -------------------------------------------------------------------------- */
function cb_register_project_cpt(): void {
	/**
	 * Filter the URL slug used by the project CPT.
	 *
	 * Companion themes can override the default `referanser` to localise the
	 * permalink (e.g. `prosjekter`, `projects`, `cases`) without forking the
	 * plugin. Companion themes are also responsible for adding redirects
	 * from the old slug to the new one when changing this value.
	 *
	 * @param string $slug Default 'referanser'.
	 */
	$project_slug = (string) apply_filters( 'styrk_blocks_project_rewrite_slug', 'referanser' );
	if ( '' === $project_slug ) {
		$project_slug = 'referanser';
	}

	register_post_type( 'project', [
		'labels' => [
			'name'          => __( 'Projects',        'styrk-blocks' ),
			'singular_name' => __( 'Project',         'styrk-blocks' ),
			'add_new_item'  => __( 'Add New Project', 'styrk-blocks' ),
			'edit_item'     => __( 'Edit Project',    'styrk-blocks' ),
		],
		'public'       => true,
		'show_in_rest' => true,
		'supports'     => [ 'title', 'editor', 'excerpt', 'thumbnail', 'custom-fields' ],
		'menu_icon'    => 'dashicons-portfolio',
		// Archive disabled — the static listing page (which embeds the
		// project-grid block) acts as the archive view. Custom rewrite below
		// routes /{slug}/{post-slug}/ → single project.
		'has_archive'  => false,
		'rewrite'      => [ 'slug' => $project_slug, 'with_front' => false ],
		// Starter content for new project posts. Gives editors a scaffold
		// instead of an empty canvas — they replace placeholder text and
		// drag images into the gallery rather than starting from scratch.
		'template'     => [
			[ 'core/paragraph', [
				'placeholder' => __( 'Skriv en kort ingress (1–2 setninger) som beskriver prosjektet på et høyt nivå.', 'styrk-blocks' ),
			] ],
			[ 'core/heading', [
				'level'       => 2,
				'placeholder' => __( 'Hva vi leverte', 'styrk-blocks' ),
			] ],
			[ 'core/paragraph', [
				'placeholder' => __( 'Beskriv arbeidet — hva som ble bygget, hvordan, og spesielle løsninger. 2–4 avsnitt.', 'styrk-blocks' ),
			] ],
			[ 'core/heading', [
				'level'       => 2,
				'placeholder' => __( 'Galleri', 'styrk-blocks' ),
			] ],
			[ 'core/gallery', [
				'columns' => 3,
				'linkTo'  => 'media',
			] ],
		],
	] );

	// Top-priority rewrite so /{slug}/{post-slug}/ resolves to a single
	// project even when a static page exists at /{slug}/. WP's default rule
	// ordering would let the page hierarchy match first and 404 on any
	// non-existent child page. `$project_slug` is the filtered value (above).
	add_rewrite_rule(
		'^' . preg_quote( $project_slug, '#' ) . '/([^/]+)/?$',
		'index.php?project=$matches[1]',
		'top'
	);

	register_taxonomy( 'project_category', 'project', [
		'labels' => [
			'name'          => __( 'Project Categories', 'styrk-blocks' ),
			'singular_name' => __( 'Project Category',   'styrk-blocks' ),
		],
		'public'            => true,
		'show_in_rest'      => true,
		'show_admin_column' => true,
		'hierarchical'      => false,
	] );

	$string_fields = [
		'_cb_location' => [],
		'_cb_size'     => [],
		'_cb_client'   => [],
	];
	foreach ( $string_fields as $key => $extra ) {
		register_post_meta( 'project', $key, array_merge( [
			'single'            => true,
			'type'              => 'string',
			'default'           => '',
			'show_in_rest'      => true,
			'sanitize_callback' => 'sanitize_text_field',
			'auth_callback'     => fn() => current_user_can( 'edit_posts' ),
		], $extra ) );
	}

	register_post_meta( 'project', '_cb_year', [
		'single'            => true,
		'type'              => 'integer',
		'default'           => 0,
		'show_in_rest'      => true,
		'sanitize_callback' => 'absint',
		'auth_callback'     => fn() => current_user_can( 'edit_posts' ),
	] );

	// Gallery is an array of attachment IDs. show_in_rest needs a full
	// schema so REST passes arrays through; otherwise it silently flattens
	// to a single value or rejects the field on save.
	register_post_meta( 'project', '_cb_gallery_ids', [
		'single'            => true,
		'type'              => 'array',
		'default'           => [],
		'show_in_rest'      => [
			'schema' => [
				'type'  => 'array',
				'items' => [ 'type' => 'integer' ],
			],
		],
		'sanitize_callback' => function ( $value ) {
			if ( ! is_array( $value ) ) {
				return [];
			}
			return array_values( array_filter( array_map( 'absint', $value ) ) );
		},
		'auth_callback'     => fn() => current_user_can( 'edit_posts' ),
	] );
}
add_action( 'init', 'cb_register_project_cpt' );

/* One-shot seeder for placeholder project categories on a fresh install.
 * Seeds neutral example terms so the Projects taxonomy isn't empty out of
 * the box. Admins are expected to rename/replace these with their own
 * categories — that's why the names are deliberately generic.
 *
 * The version-suffixed option key (`cb_project_terms_v2`) means existing
 * sites that already ran the v1 seeder (e.g. with trade-specific Norwegian
 * defaults) keep their terms — we never overwrite a site that's past
 * first-run. Bumping to `_v3` would re-seed everyone again. */
function cb_seed_project_terms(): void {
	if ( get_option( 'cb_project_terms_v2' ) || get_option( 'cb_project_terms_v1' ) ) {
		return;
	}
	$terms = [
		__( 'Eksempel-kategori 1', 'styrk-blocks' ),
		__( 'Eksempel-kategori 2', 'styrk-blocks' ),
		__( 'Eksempel-kategori 3', 'styrk-blocks' ),
	];
	foreach ( $terms as $term ) {
		if ( ! term_exists( $term, 'project_category' ) ) {
			wp_insert_term( $term, 'project_category' );
		}
	}
	update_option( 'cb_project_terms_v2', 1, false );
}
add_action( 'init', 'cb_seed_project_terms', 11 );


/* ── Testimonial CPT ──────────────────────────────────────────────────────────
 * Customer testimonials. Not publicly browsable (no archive, no single page) —
 * data feeds the styrk-blocks/testimonials block only. Title = customer name,
 * editor content = the quote text.
 * -------------------------------------------------------------------------- */
function cb_register_testimonial_cpt(): void {
	register_post_type( 'testimonial', [
		'labels' => [
			'name'          => __( 'Testimonials',        'styrk-blocks' ),
			'singular_name' => __( 'Testimonial',         'styrk-blocks' ),
			'add_new_item'  => __( 'Add New Testimonial', 'styrk-blocks' ),
			'edit_item'     => __( 'Edit Testimonial',    'styrk-blocks' ),
		],
		'public'             => false,
		'show_ui'            => true,
		'show_in_menu'       => true,
		'show_in_rest'       => true,
		'publicly_queryable' => false,
		'has_archive'        => false,
		'rewrite'            => false,
		'supports'           => [ 'title', 'editor', 'custom-fields' ],
		'menu_icon'          => 'dashicons-format-quote',
	] );

	register_post_meta( 'testimonial', '_cb_role', [
		'single'            => true,
		'type'              => 'string',
		'default'           => '',
		'show_in_rest'      => true,
		'sanitize_callback' => 'sanitize_text_field',
		'auth_callback'     => fn() => current_user_can( 'edit_posts' ),
	] );

	register_post_meta( 'testimonial', '_cb_rating', [
		'single'            => true,
		'type'              => 'integer',
		'default'           => 0,
		'show_in_rest'      => true,
		'sanitize_callback' => fn( $v ) => max( 0, min( 5, (int) $v ) ),
		'auth_callback'     => fn() => current_user_can( 'edit_posts' ),
	] );

	register_post_meta( 'testimonial', '_cb_project_id', [
		'single'            => true,
		'type'              => 'integer',
		'default'           => 0,
		'show_in_rest'      => true,
		'sanitize_callback' => 'absint',
		'auth_callback'     => fn() => current_user_can( 'edit_posts' ),
	] );
}
add_action( 'init', 'cb_register_testimonial_cpt' );


/* ── Block: skotnes/project-grid ──────────────────────────────────────────────
 * Asymmetric portfolio grid with category filter on the Referanser page.
 * Reads from the `project` CPT and `project_category` taxonomy. The block
 * name uses the `skotnes/` namespace (kept verbatim from when it lived in
 * skotnes-theme/functions.php) so existing saved post content keeps
 * resolving — no content migration needed.
 *
 * Block name kept distinct from the new `styrk-blocks/featured-projects`:
 * - skotnes/project-grid     — full archive, category-filterable, public
 * - styrk-blocks/featured-projects — hand-picked subset, drag-sort, homepage
 * -------------------------------------------------------------------------- */
function cb_register_project_grid_block(): void {
	register_block_type( 'skotnes/project-grid', [
		'api_version'     => 3,
		'title'           => __( 'Project Grid (filterable)', 'styrk-blocks' ),
		'category'        => 'styrk-blocks',
		'icon'            => 'screenoptions',
		'description'     => __( 'Filterable archive of projects from the Project CPT. Use on the Referanser page.', 'styrk-blocks' ),
		'supports'        => [ 'align' => [ 'wide', 'full' ], 'html' => false ],
		'attributes'      => [
			'align' => [ 'type' => 'string', 'default' => 'full' ],
		],
		'render_callback' => 'cb_render_project_grid',
	] );
}
add_action( 'init', 'cb_register_project_grid_block' );

/* ── Shared section background-shape helper ───────────────────────────────────
 * Renders the optional faint background mark (e.g. the Hywer «dråpe») for any
 * section block. Source is an uploaded raster image; colour is baked into the
 * chosen asset. Placement maths mirror src/components/SectionBgShape.tsx so the
 * front end matches the editor preview. The caller's section wrapper must be
 * position:relative; overflow:hidden, and the section's inner content should sit
 * at z-index >= 1 so the mark stays behind it.
 * -------------------------------------------------------------------------- */
if ( ! function_exists( 'cb_render_bg_shape' ) ) {
	function cb_render_bg_shape( array $attributes ): string {
		$url = esc_url( (string) ( $attributes['bgShapeUrl'] ?? '' ) );
		if ( ! $url ) {
			return '';
		}
		$pos     = (string) ( $attributes['bgShapePosition'] ?? 'bottom-right' );
		$allowed = [ 'top-left', 'top-center', 'top-right', 'center-left', 'center', 'center-right', 'bottom-left', 'bottom-center', 'bottom-right' ];
		if ( ! in_array( $pos, $allowed, true ) ) {
			$pos = 'bottom-right';
		}
		$size    = max( 5, min( 100, (int) ( $attributes['bgShapeSize'] ?? 40 ) ) );
		$opacity = max( 0, min( 100, (int) ( $attributes['bgShapeOpacity'] ?? 8 ) ) ) / 100;
		$flip    = ! empty( $attributes['bgShapeFlip'] );

		list( $v, $h ) = array_pad( explode( '-', $pos ), 2, 'center' );
		$style  = 'position:absolute;pointer-events:none;z-index:0;height:auto;';
		$style .= 'width:' . $size . '%;opacity:' . $opacity . ';';
		$tx = '0';
		$ty = '0';
		if ( 'top' === $v ) {
			$style .= 'top:0;';
		} elseif ( 'bottom' === $v ) {
			$style .= 'bottom:0;';
		} else {
			$style .= 'top:50%;';
			$ty     = '-50%';
		}
		if ( 'left' === $h ) {
			$style .= 'left:0;';
		} elseif ( 'right' === $h ) {
			$style .= 'right:0;';
		} else {
			$style .= 'left:50%;';
			$tx     = '-50%';
		}
		$translate = ( '0' !== $tx || '0' !== $ty ) ? "translate($tx,$ty)" : '';
		$transform = trim( $translate . ( $flip ? ' scaleX(-1)' : '' ) );
		if ( $transform ) {
			$style .= 'transform:' . $transform . ';';
		}

		return '<img src="' . $url . '" alt="" aria-hidden="true" class="cb-bg-shape" style="' . esc_attr( $style ) . '" />';
	}
}

/* Render callback — queries published projects, derives filter pills from
 * actual taxonomy terms, and emits the same markup the inline filter JS
 * already targets (`.skotnes-projects__pill[data-filter]` vs
 * `.skotnes-project[data-cat]`). Card sizing is determined by index modulo
 * a static pattern so the asymmetric grid reads consistent regardless of
 * how many projects exist. */
function cb_render_project_grid( array $attributes ): string {
	$query = new WP_Query( [
		'post_type'      => 'project',
		'posts_per_page' => -1,
		'post_status'    => 'publish',
		'no_found_rows'  => true,
		'orderby'        => 'date',
		'order'          => 'DESC',
	] );

	// Drop empty categories so the filter pills only ever offer terms that
	// actually return projects — empty pills look broken to users.
	$category_terms = get_terms( [
		'taxonomy'   => 'project_category',
		'hide_empty' => true,
	] );
	$categories = [ __( 'Alle', 'styrk-blocks' ) ];
	if ( ! is_wp_error( $category_terms ) ) {
		foreach ( $category_terms as $term ) {
			$categories[] = $term->name;
		}
	}

	ob_start(); ?>
	<section class="skotnes-projects alignfull" data-skotnes-project-grid>
		<div class="skotnes-projects__inner">
			<nav class="skotnes-projects__filter" aria-label="<?php esc_attr_e( 'Filtrer prosjekter', 'styrk-blocks' ); ?>">
				<?php foreach ( $categories as $cat ) : ?>
					<button
						class="skotnes-projects__pill <?php echo $cat === __( 'Alle', 'styrk-blocks' ) ? 'is-active' : ''; ?>"
						data-filter="<?php echo esc_attr( $cat ); ?>"
						type="button"
					><?php echo esc_html( $cat ); ?></button>
				<?php endforeach; ?>
				<span class="skotnes-projects__count" data-skotnes-project-count><?php echo (int) $query->post_count; ?> <?php esc_html_e( 'prosjekter', 'styrk-blocks' ); ?></span>
			</nav>

			<div class="skotnes-projects__grid">
				<?php if ( ! $query->have_posts() ) : ?>
					<p class="skotnes-projects__empty"><?php esc_html_e( 'Ingen prosjekter publisert ennå.', 'styrk-blocks' ); ?></p>
				<?php endif; ?>
				<?php
				while ( $query->have_posts() ) :
					$query->the_post();
					$post_id   = (int) get_the_ID();
					$location  = (string) get_post_meta( $post_id, '_cb_location', true );
					$year      = (int)    get_post_meta( $post_id, '_cb_year',     true );
					$photo_url = get_the_post_thumbnail_url( $post_id, 'large' );
					$terms     = get_the_terms( $post_id, 'project_category' );
					$primary   = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
				?>
					<a class="skotnes-project"
					   href="<?php the_permalink(); ?>"
					   data-cat="<?php echo esc_attr( $primary ); ?>">
						<div class="skotnes-project__photo-wrap">
							<?php if ( $photo_url ) : ?>
								<img class="skotnes-project__photo"
									src="<?php echo esc_url( $photo_url ); ?>"
									alt="<?php echo esc_attr( get_the_title() ); ?>"
									loading="lazy" decoding="async" />
							<?php else : ?>
								<div class="skotnes-project__photo-fallback" aria-hidden="true">
									<?php echo esc_html( mb_substr( get_the_title(), 0, 1 ) ); ?>
								</div>
							<?php endif; ?>
							<?php if ( $primary ) : ?>
								<div class="skotnes-project__cat-badge"><?php echo esc_html( $primary ); ?></div>
							<?php endif; ?>
						</div>
						<div class="skotnes-project__body">
							<?php if ( $location || $year ) : ?>
								<div class="skotnes-project__meta">
									<?php
									echo esc_html( $location );
									if ( $location && $year ) {
										echo ' · ';
									}
									if ( $year ) {
										echo (int) $year;
									}
									?>
								</div>
							<?php endif; ?>
							<h3 class="skotnes-project__title"><?php the_title(); ?></h3>
							<span class="skotnes-project__cta">
								<?php esc_html_e( 'Se prosjektet', 'styrk-blocks' ); ?>
								<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
							</span>
						</div>
					</a>
				<?php endwhile; wp_reset_postdata(); ?>
			</div>
		</div>
		<script>
		(function() {
			var root = document.currentScript && document.currentScript.closest('[data-skotnes-project-grid]');
			if (!root) return;
			var pills = root.querySelectorAll('.skotnes-projects__pill');
			var items = root.querySelectorAll('.skotnes-project');
			var count = root.querySelector('[data-skotnes-project-count]');
			pills.forEach(function(pill) {
				pill.addEventListener('click', function() {
					var f = pill.getAttribute('data-filter');
					pills.forEach(function(p) { p.classList.toggle('is-active', p === pill); });
					var visible = 0;
					items.forEach(function(item) {
						var match = (f === '<?php echo esc_js( __( 'Alle', 'styrk-blocks' ) ); ?>' || item.getAttribute('data-cat') === f);
						item.style.display = match ? '' : 'none';
						if (match) visible++;
					});
					if (count) count.textContent = visible + (visible === 1 ? ' prosjekt' : ' prosjekter');
				});
			});
		})();
		</script>
	</section>
	<?php
	return (string) ob_get_clean();
}


/* ── [project_meta] shortcode ─────────────────────────────────────────────────
 * Renders the Project meta bar (location · year · size · client) for use
 * inside the single-project block template. Shortcode form lets the template
 * stay declarative while the markup lives in one place.
 * -------------------------------------------------------------------------- */
function cb_shortcode_project_meta(): string {
	$post_id = get_the_ID();
	if ( ! $post_id || get_post_type( $post_id ) !== 'project' ) {
		return '';
	}

	$location = (string) get_post_meta( $post_id, '_cb_location', true );
	$year     = (int)    get_post_meta( $post_id, '_cb_year',     true );
	$size     = (string) get_post_meta( $post_id, '_cb_size',     true );
	$client   = (string) get_post_meta( $post_id, '_cb_client',   true );

	$rows = [];

	$terms        = get_the_terms( $post_id, 'project_category' );
	$primary_term = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
	if ( $primary_term ) {
		$rows[] = [ __( 'Kategori', 'styrk-blocks' ), $primary_term ];
	}
	if ( $location ) {
		$rows[] = [ __( 'Sted',   'styrk-blocks' ), $location ];
	}
	if ( $year ) {
		$rows[] = [ __( 'År',     'styrk-blocks' ), (string) $year ];
	}
	if ( $size ) {
		$rows[] = [ __( 'Omfang', 'styrk-blocks' ), $size ];
	}
	if ( $client ) {
		$rows[] = [ __( 'Kunde',  'styrk-blocks' ), $client ];
	}

	if ( empty( $rows ) ) {
		return '';
	}

	// Build as a single-line string with no inner newlines so wpautop()
	// can't insert <p></p> between rows when this shortcode runs through
	// post-content auto-formatting.
	$parts = [];
	foreach ( $rows as $row ) {
		$parts[] = '<div class="cb-project-meta__row"><dt>' . esc_html( $row[0] ) . '</dt><dd>' . esc_html( $row[1] ) . '</dd></div>';
	}
	return '<dl class="cb-project-meta">' . implode( '', $parts ) . '</dl>';
}
add_shortcode( 'project_meta', 'cb_shortcode_project_meta' );


/**
 * [project_hero] — full-bleed hero for the single-project page. Renders the
 * featured image as background with a dark gradient overlay and the title +
 * primary category overlaid. Replaces the awkward stack of "tiny title hidden
 * behind sticky header → meta bar → photo" produced by stock post-title +
 * post-featured-image blocks.
 */
function cb_shortcode_project_hero(): string {
	$post_id = get_the_ID();
	if ( ! $post_id || get_post_type( $post_id ) !== 'project' ) {
		return '';
	}

	$photo_url    = get_the_post_thumbnail_url( $post_id, 'full' );
	$title        = get_the_title( $post_id );
	$terms        = get_the_terms( $post_id, 'project_category' );
	$primary_term = ( $terms && ! is_wp_error( $terms ) ) ? $terms[0]->name : '';
	$location     = (string) get_post_meta( $post_id, '_cb_location', true );
	$year         = (int)    get_post_meta( $post_id, '_cb_year',     true );

	$bg_style = $photo_url
		? 'background-image:url(' . esc_url( $photo_url ) . ');'
		: '';

	$eyebrow_bits = array_filter( [ $primary_term, $location, $year ?: null ] );
	$eyebrow      = implode( ' · ', array_map( 'strval', $eyebrow_bits ) );

	$out  = '<div class="cb-project-hero" style="' . esc_attr( $bg_style ) . '">';
	$out .= '<div class="cb-project-hero__overlay"></div>';
	$out .= '<div class="cb-project-hero__inner">';
	if ( $eyebrow !== '' ) {
		$out .= '<p class="cb-project-hero__eyebrow">' . esc_html( $eyebrow ) . '</p>';
	}
	$out .= '<h1 class="cb-project-hero__title">' . esc_html( $title ) . '</h1>';
	$out .= '</div></div>';
	return $out;
}
add_shortcode( 'project_hero', 'cb_shortcode_project_hero' );


/* ── Single-project block template ────────────────────────────────────────────
 * Plugin-provided default template for the `project` CPT, registered via
 * register_block_template() (WP 6.7+). The active block theme can override
 * this via Site Editor → Templates; until they do, this is what /referanser/
 * /{slug}/ renders.
 * -------------------------------------------------------------------------- */
function cb_register_single_project_template(): void {
	if ( ! function_exists( 'register_block_template' ) ) {
		return;
	}

	$content = <<<HTML
<!-- wp:template-part {"slug":"header","area":"header","tagName":"header"} /-->

<!-- wp:group {"tagName":"main","align":"full","layout":{"type":"default"}} -->
<main class="wp-block-group alignfull">

	<!-- wp:styrk-blocks/project-hero {"align":"full"} /-->

	<!-- wp:group {"align":"full","className":"cb-project-body","layout":{"type":"default"}} -->
	<div class="wp-block-group alignfull cb-project-body">
		<div class="cb-project-body__inner">
			<!-- wp:styrk-blocks/breadcrumbs /-->
			<!-- wp:styrk-blocks/project-meta /-->
			<!-- wp:post-content /-->

			<!-- wp:group {"className":"cb-post-nav","layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between"}} -->
			<div class="wp-block-group cb-post-nav">
				<!-- wp:post-navigation-link {"type":"previous","label":"Forrige prosjekt","showTitle":false,"arrow":"none","className":"cb-post-nav__link"} /-->
				<!-- wp:post-navigation-link {"label":"Neste prosjekt","showTitle":false,"arrow":"none","className":"cb-post-nav__link"} /-->
			</div>
			<!-- /wp:group -->
		</div>
	</div>
	<!-- /wp:group -->

</main>
<!-- /wp:group -->

<!-- wp:template-part {"slug":"footer","area":"footer","tagName":"footer"} /-->
HTML;

	register_block_template( 'styrk-blocks//single-project', [
		'title'       => __( 'Single Project', 'styrk-blocks' ),
		'description' => __( 'Default layout for a single project: title, meta, featured image, content, and customer testimonials. Override via Site Editor → Templates.', 'styrk-blocks' ),
		'content'     => $content,
		'post_types'  => [ 'project' ],
	] );
}
add_action( 'init', 'cb_register_single_project_template', 20 );


/* ── Media-uploader CDN guard ─────────────────────────────────────────────────
 * The WordPress media uploader (moxie / Plupload, wp-includes/js/plupload) is
 * brittle behind a CDN. When a CDN's JS layer reorders, defers, or injects
 * around these scripts (Cloudflare Rocket Loader, bot-challenge shims, etc.),
 * moxie's runtime init dereferences a null element and throws
 * "Cannot read properties of null (reading 'style')" — which blanks the whole
 * block editor the moment you try to upload an image (e.g. into the hero).
 *
 * `data-cfasync="false"` tells Cloudflare to leave a script untouched. Adding
 * it to the uploader's scripts keeps moxie/Plupload loading in the correct
 * order so the html5 runtime initialises instead of falling through to the
 * crashing html4 shim. Admin-only and a no-op on hosts without such a CDN, so
 * it is safe everywhere.
 * -------------------------------------------------------------------------- */
function cb_protect_uploader_scripts( string $tag, string $handle ): string {
	static $protected = [
		'moxiejs',
		'plupload',
		'plupload-handlers',
		'wp-plupload',
		'media-views',
		'media-editor',
	];
	if ( in_array( $handle, $protected, true ) && false === strpos( $tag, 'data-cfasync' ) ) {
		$tag = str_replace( '<script ', '<script data-cfasync="false" ', $tag );
	}
	return $tag;
}
add_filter( 'script_loader_tag', 'cb_protect_uploader_scripts', 10, 2 );


/* ── Block pattern category ──────────────────────────────────────────────────
 * Groups all patterns under one labelled tab in the block inserter.
 * -------------------------------------------------------------------------- */
function custom_blocks_register_pattern_category(): void {
	register_block_pattern_category(
		'styrk-blocks',
		[ 'label' => __( 'Styrk Blocks', 'styrk-blocks' ) ]
	);
}
add_action( 'init', 'custom_blocks_register_pattern_category' );

/* ── Block patterns ──────────────────────────────────────────────────────────
 * Pre-built section templates. Each pattern injects one or more blocks with
 * sensible defaults so the user just swaps text/media rather than configuring
 * every setting from scratch.
 * -------------------------------------------------------------------------- */
function custom_blocks_register_patterns(): void {

	// ── Hero ─────────────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/hero-dark', [
		'title'       => __( 'Dark Hero', 'styrk-blocks' ),
		'description' => __( 'Full-screen dark hero with headline, sub-text and a CTA button.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/hero {"align":"full","heading":"Din overskrift her","subtext":"Kort, beskrivende ingress som forteller hva bedriften tilbyr og til hvem.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt","overlayOpacity":40} /-->',
	] );

	// ── Rich text section ────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/rich-text-left', [
		'title'       => __( 'Text Section', 'styrk-blocks' ),
		'description' => __( 'Left-aligned eyebrow, heading, body text and optional CTA link.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/rich-text-section {"align":"full","eyebrow":"Eyebrow","heading":"Seksjonens overskrift","body":"<p>Erstatt denne teksten med en kort beskrivelse av seksjonen. To eller tre setninger fungerer best.</p>","ctaLabel":"Les mer","ctaUrl":"#"} /-->',
	] );

	// ── Split section — image left ────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/split-image-left', [
		'title'       => __( 'Split — Image Left', 'styrk-blocks' ),
		'description' => __( 'Two-column layout: image on the left, heading + body + CTA on the right.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/split-section {"align":"full","eyebrow":"Eyebrow","heading":"Overskrift for to-kolonne-seksjon","body":"Plass til en kort beskrivende tekst som passer ved siden av et bilde eller en video.","ctaLabel":"Lenketekst","ctaUrl":"#","imageRight":false} /-->',
	] );

	// ── Split section — image right ───────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/split-image-right', [
		'title'       => __( 'Split — Image Right', 'styrk-blocks' ),
		'description' => __( 'Two-column layout: heading + body + CTA on the left, image on the right.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/split-section {"align":"full","eyebrow":"Eyebrow","heading":"Overskrift for to-kolonne-seksjon","body":"Plass til en kort beskrivende tekst som passer ved siden av et bilde eller en video.","ctaLabel":"Lenketekst","ctaUrl":"#","imageRight":true} /-->',
	] );

	// ── Feature cards ────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/feature-cards', [
		'title'       => __( 'Feature Cards (3 col)', 'styrk-blocks' ),
		'description' => __( 'Three icon cards — great for services, benefits or key points.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/feature-cards {"align":"full","eyebrow":"Eyebrow","heading":"Seksjonsoverskrift","columns":3,"items":[{"icon":"","heading":"Korttittel 1","body":"Beskrivende tekst for det første kortet."},{"icon":"","heading":"Korttittel 2","body":"Beskrivende tekst for det andre kortet."},{"icon":"","heading":"Korttittel 3","body":"Beskrivende tekst for det tredje kortet."}]} /-->',
	] );

	// ── Media grid — portrait ─────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/media-grid-portrait', [
		'title'       => __( 'Media Grid — Portrait', 'styrk-blocks' ),
		'description' => __( '4 portrait-format image or video slots in a row. Great for portfolios.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/media-grid {"align":"full","aspectRatio":"portrait","columns":4,"gap":"sm","radius":8,"sectionPad":true} /-->',
	] );

	// ── Stats row ────────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/stats-row', [
		'title'       => __( 'Stats Row', 'styrk-blocks' ),
		'description' => __( 'Three key numbers side by side — great for social proof.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/stats-row {"align":"full"} /-->',
	] );

	// ── Testimonial ──────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/testimonial', [
		'title'       => __( 'Testimonial', 'styrk-blocks' ),
		'description' => __( 'A single large quote with attribution — great for social proof.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/testimonial {"align":"full","quote":"Et kort, troverdig sitat fra en kunde går her. To eller tre setninger fungerer best.","authorName":"Kundens navn","authorRole":"Stilling, Bedrift"} /-->',
	] );

	// ── CTA section ──────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/cta-dark', [
		'title'       => __( 'CTA — Dark Banner', 'styrk-blocks' ),
		'description' => __( 'Full-width call-to-action banner with headline and button.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/cta-section {"align":"full","heading":"Klar for å komme i gang?","subtext":"Kort sluttoppfordring som leder leseren videre.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt"} /-->',
	] );

	// ── FAQ accordion ────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/faq', [
		'title'       => __( 'FAQ Accordion', 'styrk-blocks' ),
		'description' => __( 'Expandable questions and answers — great for common objections.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/faq-accordion {"align":"full","eyebrow":"Spørsmål og svar","heading":"Ofte stilte spørsmål"} /-->',
	] );

	// ── Logo strip ───────────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/logo-strip', [
		'title'       => __( 'Partner Logo Strip', 'styrk-blocks' ),
		'description' => __( 'Horizontal scrolling ticker of partner or client logos.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/logo-strip {"align":"full","eyebrow":"Samarbeidspartnere"} /-->',
	] );

	// ── Full landing page ─────────────────────────────────────────────────────
	register_block_pattern( 'styrk-blocks/landing-page', [
		'title'       => __( 'Complete Landing Page', 'styrk-blocks' ),
		'description' => __( 'Hero → Features → Split → Stats → Testimonial → CTA. A full page in one click.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     =>
			'<!-- wp:styrk-blocks/hero {"align":"full","heading":"Din overskrift her","subtext":"Kort, beskrivende ingress som forteller hva bedriften tilbyr og til hvem.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt","overlayOpacity":40} /-->'
			. "\n" .
			'<!-- wp:styrk-blocks/feature-cards {"align":"full","eyebrow":"Eyebrow","heading":"Seksjonsoverskrift","columns":3,"items":[{"icon":"","heading":"Korttittel 1","body":"Beskrivende tekst for det første kortet."},{"icon":"","heading":"Korttittel 2","body":"Beskrivende tekst for det andre kortet."},{"icon":"","heading":"Korttittel 3","body":"Beskrivende tekst for det tredje kortet."}]} /-->'
			. "\n" .
			'<!-- wp:styrk-blocks/split-section {"align":"full","eyebrow":"Eyebrow","heading":"Overskrift for to-kolonne-seksjon","body":"Plass til en kort beskrivende tekst som passer ved siden av et bilde eller en video.","ctaLabel":"Les mer","ctaUrl":"#","imageRight":false} /-->'
			. "\n" .
			'<!-- wp:styrk-blocks/stats-row {"align":"full","items":[{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"},{"value":"00","label":"Beskrivelse","prefix":"","suffix":""},{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"}]} /-->'
			. "\n" .
			'<!-- wp:styrk-blocks/testimonial {"align":"full","quote":"Et kort, troverdig sitat fra en kunde går her. To eller tre setninger fungerer best.","authorName":"Kundens navn","authorRole":"Stilling, Bedrift"} /-->'
			. "\n" .
			'<!-- wp:styrk-blocks/cta-section {"align":"full","heading":"Klar for å komme i gang?","subtext":"Kort sluttoppfordring som leder leseren videre.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt"} /-->',
	] );

	// ── Page Header (inner page default) ──────────────────────────────────────
	register_block_pattern( 'styrk-blocks/page-header-default', [
		'title'       => __( 'Page Header — Inner Page', 'styrk-blocks' ),
		'description' => __( 'Editorial header for inner pages: serif title on light surface with auto breadcrumb, teal hairline and optional subtitle. Insert at the top of non-frontpage content, replacing any existing hero block.', 'styrk-blocks' ),
		'categories'  => [ 'styrk-blocks' ],
		'content'     => '<!-- wp:styrk-blocks/page-header {"align":"full","subtitle":"Kort ingress som rammer inn hva denne siden handler om.","useTitleFromPost":true} /-->',
	] );
}
add_action( 'init', 'custom_blocks_register_patterns' );

function custom_blocks_add_meta_box(): void {
	add_meta_box(
		'cb_employee_details',
		__( 'Employee Details', 'styrk-blocks' ),
		'custom_blocks_meta_box_html',
		'employee',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'custom_blocks_add_meta_box' );

function custom_blocks_meta_box_html( WP_Post $post ): void {
	wp_nonce_field( 'cb_employee_save', 'cb_employee_nonce' );

	// Read-only mirror of the assigned employee_role terms — the SOURCE of
	// truth is the sidebar Roles metabox; this block just renders the
	// resulting pills inline so the admin sees the same chips that will
	// ship on the public card. Refreshes on save/reload.
	$role_terms = get_the_terms( $post->ID, 'employee_role' );
	$role_terms = ( $role_terms && ! is_wp_error( $role_terms ) ) ? $role_terms : [];
	?>
	<style>
		#cb_employee_details .cb-field { display:flex; flex-direction:column; gap:4px; margin-bottom:16px; }
		#cb_employee_details .cb-field:last-child { margin-bottom:0; }
		#cb_employee_details label { font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:.04em; color:#1e1e1e; }
		#cb_employee_details input[type=text],
		#cb_employee_details input[type=email],
		#cb_employee_details input[type=tel],
		#cb_employee_details input[type=url],
		#cb_employee_details textarea { width:100%; padding:8px 10px; border:1px solid #c3c4c7; border-radius:4px; font-size:14px; line-height:1.5; box-shadow:inset 0 1px 2px rgba(0,0,0,.07); }
		#cb_employee_details input:focus,
		#cb_employee_details textarea:focus { border-color:#2271b1; box-shadow:0 0 0 1px #2271b1; outline:none; }
		#cb_employee_details textarea { resize:vertical; min-height:90px; }
		#cb_employee_details .cb-roles-preview {
			display:flex; flex-wrap:wrap; gap:6px;
			padding:6px 0; min-height:32px;
		}
		#cb_employee_details .cb-roles-preview__pill {
			display:inline-flex; align-items:center;
			padding:4px 10px; border-radius:4px;
			border-left:2px solid #1E5BD8;
			background:rgba(30,91,216,.08);
			color:#1E5BD8;
			font-size:11px; font-weight:600;
			letter-spacing:.04em; text-transform:uppercase;
			line-height:1.2; white-space:nowrap;
		}
		#cb_employee_details .cb-roles-preview__hint {
			color:#777; font-size:12px; font-style:italic;
		}
	</style>

	<div class="cb-field">
		<label><?php esc_html_e( 'Roles', 'styrk-blocks' ); ?></label>
		<div class="cb-roles-preview">
			<?php if ( $role_terms ) : ?>
				<?php foreach ( $role_terms as $term ) : ?>
					<span class="cb-roles-preview__pill"><?php echo esc_html( $term->name ); ?></span>
				<?php endforeach; ?>
			<?php else : ?>
				<span class="cb-roles-preview__hint">
					<?php esc_html_e( 'Add roles in the Roles panel →', 'styrk-blocks' ); ?>
				</span>
			<?php endif; ?>
		</div>
	</div>
	<?php

	$fields = [
		'_cb_email' => [
			'label'       => __( 'Email', 'styrk-blocks' ),
			'type'        => 'email',
			'placeholder' => 'name@example.com',
		],
		'_cb_phone' => [
			'label'       => __( 'Phone', 'styrk-blocks' ),
			'type'        => 'tel',
			'placeholder' => '+47 900 00 000',
		],
		'_cb_linkedin' => [
			'label'       => __( 'LinkedIn URL', 'styrk-blocks' ),
			'type'        => 'url',
			'placeholder' => 'https://linkedin.com/in/…',
		],
	];

	foreach ( $fields as $key => $field ) :
		$value = get_post_meta( $post->ID, $key, true );
	?>
		<div class="cb-field">
			<label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
			<input
				type="<?php echo esc_attr( $field['type'] ); ?>"
				id="<?php echo esc_attr( $key ); ?>"
				name="<?php echo esc_attr( $key ); ?>"
				value="<?php echo esc_attr( $value ); ?>"
				placeholder="<?php echo esc_attr( $field['placeholder'] ); ?>"
			/>
		</div>
	<?php endforeach;

	$background = get_post_meta( $post->ID, '_cb_background', true );
	?>
	<div class="cb-field">
		<label for="_cb_background"><?php esc_html_e( 'Background', 'styrk-blocks' ); ?></label>
		<textarea
			id="_cb_background"
			name="_cb_background"
			placeholder="<?php esc_attr_e( 'Short professional bio shown on the team page.', 'styrk-blocks' ); ?>"
		><?php echo esc_textarea( $background ); ?></textarea>
	</div>
	<?php
}

function custom_blocks_save_meta( int $post_id ): void {
	if (
		! isset( $_POST['cb_employee_nonce'] ) ||
		! wp_verify_nonce( sanitize_key( $_POST['cb_employee_nonce'] ), 'cb_employee_save' ) ||
		( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ||
		! current_user_can( 'edit_post', $post_id )
	) {
		return;
	}

	$text_fields = [ '_cb_occupation', '_cb_phone' ];
	foreach ( $text_fields as $key ) {
		if ( isset( $_POST[ $key ] ) ) {
			update_post_meta( $post_id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
		}
	}

	if ( isset( $_POST['_cb_email'] ) ) {
		update_post_meta( $post_id, '_cb_email', sanitize_email( wp_unslash( $_POST['_cb_email'] ) ) );
	}
	if ( isset( $_POST['_cb_linkedin'] ) ) {
		update_post_meta( $post_id, '_cb_linkedin', esc_url_raw( wp_unslash( $_POST['_cb_linkedin'] ) ) );
	}
	if ( isset( $_POST['_cb_background'] ) ) {
		update_post_meta( $post_id, '_cb_background', sanitize_textarea_field( wp_unslash( $_POST['_cb_background'] ) ) );
	}
}
add_action( 'save_post_employee', 'custom_blocks_save_meta' );

add_action( 'wp_loaded', function () {
	if ( get_option( 'viken_pages_v8' ) ) return;

	$services_content = '<!-- wp:styrk-blocks/hero {"align":"full","heading":"Tjenester","subtext":"Kort, beskrivende ingress om hvilke tjenester bedriften tilbyr.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt","overlayOpacity":50} /-->

<!-- wp:styrk-blocks/rich-text-section {"align":"full","eyebrow":"Eyebrow","heading":"Seksjonens overskrift","body":"<p>Erstatt denne teksten med en kort beskrivelse av hva bedriften tilbyr. Hold det enkelt – to eller tre setninger fungerer ofte best.</p>","centered":true} /-->

<!-- wp:styrk-blocks/feature-cards {"align":"full","eyebrow":"Eyebrow","heading":"Seksjonsoverskrift","centered":true,"columns":3,"items":[{"icon":"","heading":"Tjeneste 1","body":"Beskrivende tekst for den første tjenesten."},{"icon":"","heading":"Tjeneste 2","body":"Beskrivende tekst for den andre tjenesten."},{"icon":"","heading":"Tjeneste 3","body":"Beskrivende tekst for den tredje tjenesten."},{"icon":"","heading":"Tjeneste 4","body":"Beskrivende tekst for den fjerde tjenesten."},{"icon":"","heading":"Tjeneste 5","body":"Beskrivende tekst for den femte tjenesten."},{"icon":"","heading":"Tjeneste 6","body":"Beskrivende tekst for den sjette tjenesten."}]} /-->

<!-- wp:styrk-blocks/stats-row {"align":"full","eyebrow":"Eyebrow","heading":"Tall som teller","centered":true,"items":[{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"},{"value":"00","label":"Beskrivelse","prefix":"","suffix":""},{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"},{"value":"00","label":"Beskrivelse","prefix":"","suffix":"%"}]} /-->

<!-- wp:styrk-blocks/testimonial {"align":"full","quote":"Et kort, troverdig sitat fra en kunde går her. To eller tre setninger fungerer best.","authorName":"Kundens navn","authorRole":"Stilling, Bedrift"} /-->

<!-- wp:styrk-blocks/cta-section {"align":"full","heading":"Klar for å komme i gang?","body":"Kort sluttoppfordring som leder leseren videre.","primaryLabel":"Ta kontakt","primaryUrl":"/kontakt","accentBg":true} /-->';

	$contact_content = '<!-- wp:styrk-blocks/hero {"align":"full","heading":"Kontakt","subtext":"Kort ingress som forteller hvordan kunder kan ta kontakt.","ctaLabel":"","ctaUrl":"","overlayOpacity":55} /-->

<!-- wp:styrk-blocks/rich-text-section {"align":"full","eyebrow":"Eyebrow","heading":"Vi hører gjerne fra deg","body":"Erstatt denne teksten med en kort kontaktinvitasjon. To eller tre setninger fungerer best.","centered":true} /-->

<!-- wp:styrk-blocks/contact-section {"align":"full"} /-->

<!-- wp:styrk-blocks/faq-accordion {"align":"full","eyebrow":"Spørsmål og svar","heading":"Ofte stilte spørsmål","items":[{"question":"Spørsmål 1?","answer":"Plass til et tydelig, kort svar på spørsmålet over."},{"question":"Spørsmål 2?","answer":"Plass til et tydelig, kort svar på spørsmålet over."},{"question":"Spørsmål 3?","answer":"Plass til et tydelig, kort svar på spørsmålet over."},{"question":"Spørsmål 4?","answer":"Plass til et tydelig, kort svar på spørsmålet over."}]} /-->

<!-- wp:styrk-blocks/cta-section {"align":"full","heading":"Ring oss direkte","body":"+47 00 00 00 00 eller send e-post til post@bedriftsnavn.no","primaryLabel":"Send e-post","primaryUrl":"mailto:post@bedriftsnavn.no","accentBg":false} /-->';

	$find_services = get_posts( [ 'post_type' => 'page', 'name' => 'services', 'numberposts' => 1, 'post_status' => 'any' ] );
	$find_contact  = get_posts( [ 'post_type' => 'page', 'name' => 'contact',  'numberposts' => 1, 'post_status' => 'any' ] );

	$services_data = [
		'post_title'   => 'Tjenester',
		'post_name'    => 'services',
		'post_content' => $services_content,
		'post_status'  => 'publish',
		'post_type'    => 'page',
		'post_author'  => 1,
	];
	$contact_data = [
		'post_title'   => 'Kontakt',
		'post_name'    => 'contact',
		'post_content' => $contact_content,
		'post_status'  => 'publish',
		'post_type'    => 'page',
		'post_author'  => 1,
	];

	if ( ! empty( $find_services ) ) {
		$services_data['ID'] = $find_services[0]->ID;
		$services_id = wp_update_post( $services_data );
	} else {
		$services_id = wp_insert_post( $services_data );
	}

	if ( ! empty( $find_contact ) ) {
		$contact_data['ID'] = $find_contact[0]->ID;
		$contact_id = wp_update_post( $contact_data );
	} else {
		$contact_id = wp_insert_post( $contact_data );
	}

	if ( $services_id && $contact_id && ! is_wp_error( $services_id ) && ! is_wp_error( $contact_id ) ) {
		update_option( 'viken_pages_v8', true );
	}
} );

/* ── Homepage content updater ────────────────────────────────────────────────
 * Sets/updates the static front page with neutral placeholder content
 * the first time the plugin runs. Existing installs (where the option
 * key is already set) are skipped — the seeder never overwrites real
 * content once a site has gone past first-run.
 *
 * TODO: the option key `viken_homepage_v3` is a legacy name from when this
 * seeder was first introduced on the Viken project. Renaming to something
 * neutral (e.g. `cb_homepage_seed_v1`) requires a one-shot migration that
 * copies the old flag to the new key so existing seeded sites don't
 * re-seed and wipe real homepage content. Defer until next major bump.
 * -------------------------------------------------------------------------- */
add_action( 'wp_loaded', function () {
	if ( get_option( 'viken_homepage_v3' ) ) return;

	$homepage_content = '<!-- wp:styrk-blocks/hero {"align":"full","heading":"Din overskrift her","subtext":"Kort, beskrivende ingress som forteller hva bedriften tilbyr og til hvem.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt","overlayOpacity":40} /-->

<!-- wp:styrk-blocks/rich-text-section {"align":"full","eyebrow":"Om oss","heading":"Seksjonens overskrift","body":"<p>Erstatt denne teksten med en kort presentasjon av bedriften. To korte avsnitt på to–tre setninger fungerer ofte best.</p><p>Snakk om hvem dere er, hva dere brenner for, og hvordan dere skiller dere fra konkurrentene.</p>","ctaLabel":"Les mer","ctaUrl":"/om-oss"} /-->

<!-- wp:styrk-blocks/feature-cards {"align":"full","eyebrow":"Eyebrow","heading":"Hva vi tilbyr","centered":true,"columns":3,"items":[{"icon":"","heading":"Tjeneste 1","body":"Kort, beskrivende tekst for det første tilbudet."},{"icon":"","heading":"Tjeneste 2","body":"Kort, beskrivende tekst for det andre tilbudet."},{"icon":"","heading":"Tjeneste 3","body":"Kort, beskrivende tekst for det tredje tilbudet."},{"icon":"","heading":"Tjeneste 4","body":"Kort, beskrivende tekst for det fjerde tilbudet."},{"icon":"","heading":"Tjeneste 5","body":"Kort, beskrivende tekst for det femte tilbudet."},{"icon":"","heading":"Tjeneste 6","body":"Kort, beskrivende tekst for det sjette tilbudet."}]} /-->

<!-- wp:styrk-blocks/stats-row {"align":"full","eyebrow":"Eyebrow","heading":"Tall som teller","centered":true,"items":[{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"},{"value":"00","label":"Beskrivelse","prefix":"","suffix":""},{"value":"00","label":"Beskrivelse","prefix":"","suffix":"+"},{"value":"00","label":"Beskrivelse","prefix":"","suffix":"%"}]} /-->

<!-- wp:styrk-blocks/split-section {"align":"full","eyebrow":"Eyebrow","heading":"Overskrift for to-kolonne-seksjon","body":"Plass til en kort beskrivende tekst som passer ved siden av et bilde eller en video.","ctaLabel":"Lenketekst","ctaUrl":"#","imageRight":true} /-->

<!-- wp:styrk-blocks/cta-section {"align":"full","heading":"Klar for å komme i gang?","subtext":"Kort sluttoppfordring som leder leseren videre.","ctaLabel":"Ta kontakt","ctaUrl":"/kontakt"} /-->';

	// Find or create the front page
	$front_page_id = (int) get_option( 'page_on_front' );
	if ( ! $front_page_id ) {
		$find_home = get_posts( [ 'post_type' => 'page', 'name' => 'home', 'numberposts' => 1, 'post_status' => 'any' ] );
		if ( ! empty( $find_home ) ) {
			$front_page_id = $find_home[0]->ID;
		}
	}
	if ( ! $front_page_id ) {
		$find_front = get_posts( [ 'post_type' => 'page', 'name' => 'front-page', 'numberposts' => 1, 'post_status' => 'any' ] );
		if ( ! empty( $find_front ) ) {
			$front_page_id = $find_front[0]->ID;
		}
	}

	if ( $front_page_id ) {
		wp_update_post( [
			'ID'           => $front_page_id,
			'post_content' => $homepage_content,
			'post_status'  => 'publish',
		] );
	} else {
		$front_page_id = wp_insert_post( [
			'post_title'   => 'Hjem',
			'post_name'    => 'home',
			'post_content' => $homepage_content,
			'post_status'  => 'publish',
			'post_type'    => 'page',
			'post_author'  => 1,
		] );
	}

	if ( $front_page_id && ! is_wp_error( $front_page_id ) ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id );
		update_option( 'viken_homepage_v3', true );
	}
} );

/*
 * ── Header template-part updater ────────────────────────────────────────────
 * Replaces whatever is in the DB header template-part with the react-header
 * block so ALL pages use the React header consistently.
 * The react-header render.php reads the logo from WP Customizer (custom-logo)
 * so no hardcoded logo path is needed here.
 * Bump the option key (viken_header_v2) to force a re-run after changes.
 */
add_action( 'wp_loaded', function () {
	if ( get_option( 'viken_header_v2' ) ) return;

	// Header block with no hardcoded logo — render.php resolves it from Customizer
	$react_header_content =
		'<!-- wp:styrk-blocks/react-header {"align":"full"} -->' . "\n"
		. '<div class="wp-block-styrk-blocks-react-header react-header-mount-point alignfull"></div>' . "\n"
		. '<!-- /wp:styrk-blocks/react-header -->';

	$parts = get_posts( [
		'post_type'      => 'wp_template_part',
		'posts_per_page' => -1,
		'post_status'    => 'publish',
	] );

	$updated = false;
	foreach ( $parts as $part ) {
		if ( strpos( $part->post_name, 'header' ) !== false ) {
			wp_update_post( [
				'ID'           => $part->ID,
				'post_content' => $react_header_content,
			] );
			$updated = true;
		}
	}

	if ( $updated ) {
		update_option( 'viken_header_v2', true );
	}
} );

/*
 * ── Footer template-part updater ─────────────────────────────────────────────
 * Uses wp:site-logo and wp:site-title core blocks so the footer reads from
 * Appearance → Customize → Site Identity (no hardcoded logo/name).
 * Bump version key (viken_footer_v4) to force a re-run after changes.
 */
/* ── Social Link CPT ─────────────────────────────────────────────────────────
 * Manageable social media links for the footer.
 * Admin can add/remove platforms (Facebook, Instagram, LinkedIn, etc.)
 * with a URL and icon selection. Rendered dynamically in the footer.
 * -------------------------------------------------------------------------- */
function custom_blocks_register_social_link_cpt(): void {
	register_post_type( 'social_link', [
		'labels' => [
			'name'          => __( 'Social Links',       'styrk-blocks' ),
			'singular_name' => __( 'Social Link',        'styrk-blocks' ),
			'add_new_item'  => __( 'Add New Social Link','styrk-blocks' ),
			'edit_item'     => __( 'Edit Social Link',   'styrk-blocks' ),
			'menu_name'     => __( 'Social Links',       'styrk-blocks' ),
		],
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => true,
		'show_in_rest' => true,
		'supports'     => [ 'title' ],
		'menu_icon'    => 'dashicons-share',
		'rewrite'      => false,
	] );

	register_post_meta( 'social_link', '_cb_social_url', [
		'single'        => true,
		'type'          => 'string',
		'default'       => '',
		'show_in_rest'  => true,
		'sanitize_callback' => 'esc_url_raw',
		'auth_callback' => fn() => current_user_can( 'edit_posts' ),
	] );

	register_post_meta( 'social_link', '_cb_social_platform', [
		'single'        => true,
		'type'          => 'string',
		'default'       => 'website',
		'show_in_rest'  => true,
		'sanitize_callback' => 'sanitize_text_field',
		'auth_callback' => fn() => current_user_can( 'edit_posts' ),
	] );
}
add_action( 'init', 'custom_blocks_register_social_link_cpt' );

/* Social Link meta box */
function custom_blocks_social_link_meta_box(): void {
	add_meta_box(
		'cb_social_link_details',
		__( 'Social Link Details', 'styrk-blocks' ),
		'custom_blocks_social_link_meta_box_html',
		'social_link',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'custom_blocks_social_link_meta_box' );

function custom_blocks_social_link_meta_box_html( WP_Post $post ): void {
	wp_nonce_field( 'cb_social_link_save', 'cb_social_link_nonce' );
	$url      = get_post_meta( $post->ID, '_cb_social_url', true );
	$platform = get_post_meta( $post->ID, '_cb_social_platform', true ) ?: 'website';
	$platforms = [ 'facebook', 'instagram', 'linkedin', 'twitter', 'youtube', 'tiktok', 'website' ];
	?>
	<style>
		#cb_social_link_details .cb-field { display:flex; flex-direction:column; gap:4px; margin-bottom:16px; }
		#cb_social_link_details label { font-weight:600; font-size:12px; text-transform:uppercase; letter-spacing:.04em; }
		#cb_social_link_details input, #cb_social_link_details select { width:100%; padding:8px 10px; border:1px solid #c3c4c7; border-radius:4px; font-size:14px; }
	</style>
	<div class="cb-field">
		<label for="_cb_social_platform"><?php esc_html_e( 'Platform', 'styrk-blocks' ); ?></label>
		<select id="_cb_social_platform" name="_cb_social_platform">
			<?php foreach ( $platforms as $p ) : ?>
				<option value="<?php echo esc_attr( $p ); ?>" <?php selected( $platform, $p ); ?>><?php echo esc_html( ucfirst( $p ) ); ?></option>
			<?php endforeach; ?>
		</select>
	</div>
	<div class="cb-field">
		<label for="_cb_social_url"><?php esc_html_e( 'URL', 'styrk-blocks' ); ?></label>
		<input type="url" id="_cb_social_url" name="_cb_social_url" value="<?php echo esc_attr( $url ); ?>" placeholder="https://..." />
	</div>
	<?php
}

function custom_blocks_save_social_link_meta( int $post_id ): void {
	if (
		! isset( $_POST['cb_social_link_nonce'] ) ||
		! wp_verify_nonce( sanitize_key( $_POST['cb_social_link_nonce'] ), 'cb_social_link_save' ) ||
		( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) ||
		! current_user_can( 'edit_post', $post_id )
	) {
		return;
	}
	if ( isset( $_POST['_cb_social_url'] ) ) {
		update_post_meta( $post_id, '_cb_social_url', esc_url_raw( wp_unslash( $_POST['_cb_social_url'] ) ) );
	}
	if ( isset( $_POST['_cb_social_platform'] ) ) {
		update_post_meta( $post_id, '_cb_social_platform', sanitize_text_field( wp_unslash( $_POST['_cb_social_platform'] ) ) );
	}
}
add_action( 'save_post_social_link', 'custom_blocks_save_social_link_meta' );

/* ── Render social links in footer (PHP helper) ─────────────────────────────
 * Called from the footer template part via a shortcode [social_links].
 * -------------------------------------------------------------------------- */
function custom_blocks_social_links_shortcode(): string {
	$links = get_posts( [
		'post_type'      => 'social_link',
		'posts_per_page' => 20,
		'post_status'    => 'publish',
		'orderby'        => 'menu_order',
		'order'          => 'ASC',
	] );

	if ( empty( $links ) ) return '';

	$svg_icons = [
		'facebook'  => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>',
		'instagram' => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z"/></svg>',
		'linkedin'  => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>',
		'twitter'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
		'youtube'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814z"/><polygon fill="#fff" points="9.545,15.568 15.818,12 9.545,8.432"/></svg>',
		'tiktok'    => '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/></svg>',
		'website'   => '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>',
	];

	$html = '<div class="site-footer__social">';
	foreach ( $links as $link ) {
		$url      = get_post_meta( $link->ID, '_cb_social_url', true );
		$platform = get_post_meta( $link->ID, '_cb_social_platform', true ) ?: 'website';
		if ( ! $url ) continue;
		$icon  = $svg_icons[ $platform ] ?? $svg_icons['website'];
		$label = esc_attr( $link->post_title );
		$html .= '<a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . $label . '" class="site-footer__social-link">' . $icon . '</a>';
	}
	$html .= '</div>';
	return $html;
}
add_shortcode( 'social_links', 'custom_blocks_social_links_shortcode' );

/* ── Seed default social link entries ────────────────────────────────────────
 * Creates blank-URL placeholder entries so admins see the platforms they can
 * fill in. URLs default to '#' — admin must supply real URLs via the CPT
 * editor before the [social_links] shortcode renders the icons.
 * -------------------------------------------------------------------------- */
add_action( 'wp_loaded', function () {
	if ( get_option( 'viken_social_links_v1' ) ) return;

	$defaults = [
		[ 'title' => 'Facebook',  'platform' => 'facebook',  'url' => '' ],
		[ 'title' => 'Instagram', 'platform' => 'instagram', 'url' => '' ],
		[ 'title' => 'LinkedIn',  'platform' => 'linkedin',  'url' => '' ],
	];

	foreach ( $defaults as $i => $social ) {
		$id = wp_insert_post( [
			'post_title'  => $social['title'],
			'post_type'   => 'social_link',
			'post_status' => 'publish',
			'menu_order'  => $i,
		] );
		if ( $id && ! is_wp_error( $id ) ) {
			update_post_meta( $id, '_cb_social_platform', $social['platform'] );
			update_post_meta( $id, '_cb_social_url',      $social['url'] );
		}
	}

	update_option( 'viken_social_links_v1', true );
} );

/*
 * ── Footer template-part updater ─────────────────────────────────────────────
 * Uses wp:site-logo and wp:site-title core blocks so the footer reads from
 * Appearance → Customize → Site Identity (no hardcoded logo/name).
 * Includes social links via [social_links] shortcode (reads from CPT).
 * Bump version key to force a re-run after changes.
 */
add_action( 'wp_loaded', function () {
	if ( get_option( 'viken_footer_v9' ) ) return;

	$footer_content = '<!-- wp:group {"align":"full","className":"site-footer","layout":{"type":"default"}} -->
<div class="wp-block-group alignfull site-footer">

	<!-- wp:group {"className":"site-footer__inner","layout":{"type":"default"}} -->
	<div class="wp-block-group site-footer__inner">

		<!-- wp:shortcode -->[footer_logo]<!-- /wp:shortcode -->

		<!-- wp:columns {"className":"site-footer__cols"} -->
		<div class="wp-block-columns site-footer__cols">

			<!-- wp:column -->
			<div class="wp-block-column">
				<!-- wp:site-title {"className":"site-footer__col-heading","isLink":false} /-->
				<!-- wp:shortcode -->[footer_description]<!-- /wp:shortcode -->
			</div>
			<!-- /wp:column -->

			<!-- wp:column -->
			<div class="wp-block-column">
				<!-- wp:paragraph {"className":"site-footer__col-heading"} -->
				<p class="site-footer__col-heading">Kontakt</p>
				<!-- /wp:paragraph -->
				<!-- wp:shortcode -->[footer_contact]<!-- /wp:shortcode -->
			</div>
			<!-- /wp:column -->

			<!-- wp:column -->
			<div class="wp-block-column">
				<!-- wp:shortcode -->[footer_social_heading]<!-- /wp:shortcode -->
				<!-- wp:shortcode -->[social_links]<!-- /wp:shortcode -->
			</div>
			<!-- /wp:column -->

		</div>
		<!-- /wp:columns -->

	</div>
	<!-- /wp:group -->

	<!-- wp:group {"className":"site-footer__bar","layout":{"type":"default"}} -->
	<div class="wp-block-group site-footer__bar">
		<!-- wp:shortcode -->[footer_copyright]<!-- /wp:shortcode -->
	</div>
	<!-- /wp:group -->

</div>
<!-- /wp:group -->';

	$parts = get_posts( [
		'post_type'      => 'wp_template_part',
		'posts_per_page' => -1,
		'post_status'    => [ 'publish', 'auto-draft', 'draft' ],
	] );

	foreach ( $parts as $part ) {
		$name  = strtolower( $part->post_name  ?? '' );
		$title = strtolower( $part->post_title ?? '' );
		if ( strpos( $name, 'footer' ) !== false || strpos( $title, 'footer' ) !== false ) {
			wp_update_post( [
				'ID'           => $part->ID,
				'post_content' => $footer_content,
				'post_status'  => 'publish',
			] );
		}
	}

	update_option( 'viken_footer_v9', true );
} );