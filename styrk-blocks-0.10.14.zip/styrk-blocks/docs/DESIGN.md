# Styrk Blocks — Design System

> Audience: developers + designers working on styrk-blocks and its
> consuming client sites. Codifies the **actual** design language of
> the current Viken Regnskap build. Re-theming a different client
> means editing the palette in `theme.json` and the RGB companion
> vars in `src/style.css` — the rest of this document is structural
> and stays stable.

---

## 1. Principles

Six rules that govern every design decision in this plugin:

1. **Attributes control state.** No component keeps local design state
   outside of `attributes` / `theme.json`. Editing an attribute must
   visibly change the output on the next render.
2. **Inline editing via RichText.** Every heading, eyebrow, body text
   is a `<RichText>` with allowed formats declared explicitly. No
   TextControls in sidebars for copy.
3. **Cascade wins over scoped CSS.** Theme tokens (`--wp--preset--…`)
   → brand tokens (`--cb-…`) → Tailwind utilities → component
   classes. Fight `!important` with *more specific* selectors, not
   more `!important`.
4. **Accessibility is not optional.** WCAG 2.1 AA is a ship-blocker.
   Focus-visible outlines, 4.5:1 contrast on text, keyboard nav on
   every interactive element.
5. **Performance is a design constraint.** LCP ≤ 2.5 s, INP ≤ 200 ms,
   CLS ≤ 0.1. Any design decision that regresses those numbers gets
   reworked before merge.
6. **Intentionality over intensity.** A restrained design executed
   precisely beats a maximalist design executed sloppily. This brand
   is **refined / institutional / trust-first** — it's an accounting
   firm, not a nightclub.

---

## 2. Brand tokens

### 2.1 Palette (`theme.json` → `settings.color.palette`)

| Slug        | Hex       | CSS variable                      | Role                                  |
|-------------|-----------|-----------------------------------|---------------------------------------|
| `primary`   | `#00486A` | `--wp--preset--color--primary`    | Body text, dark sections, navy brand  |
| `secondary` | `#0084AF` | `--wp--preset--color--secondary`  | Subheadings, secondary links          |
| `accent`    | `#F5833C` | `--wp--preset--color--accent`     | CTA buttons, highlights, selection    |
| `surface`   | `#f0f7fa` | `--wp--preset--color--surface`    | Light section backgrounds             |
| `muted`     | `#d6eef5` | `--wp--preset--color--muted`      | Dividers, subtle fills                |
| `white`     | `#ffffff` | `--wp--preset--color--white`      | Default background                    |

**Custom colours are disabled** in `theme.json` — editors cannot pick
off-palette colours. This is intentional.

### 2.2 Accent tints (pre-computed, `src/style.css`)

Use for hover fills, backgrounds, subtle highlights — never mix with
`rgba()` by hand.

| Token             | Value                                  |
|-------------------|----------------------------------------|
| `--cb-accent-10`  | `rgba(var(--cb-accent-rgb), 0.10)`     |
| `--cb-accent-15`  | `rgba(…, 0.15)`                        |
| `--cb-accent-20`  | `rgba(…, 0.20)`                        |
| `--cb-accent-25`  | `rgba(…, 0.25)`                        |
| `--cb-accent-28`  | `rgba(…, 0.28)` — CTA shadow           |
| `--cb-accent-38`  | `rgba(…, 0.38)` — focus-visible rings  |

### 2.3 Dark-section tokens

Applied automatically when a section has `--cb-dark-bg` set (hero,
footer, CTA, video block):

```css
--cb-dark-bg:     var(--cb-primary);
--cb-dark-text:   #ffffff;
--cb-dark-sub:    rgba(255,255,255,0.65);
--cb-dark-border: rgba(255,255,255,0.08);
```

### 2.4 Shadows

Four-step elevation scale — nothing else ships.

| Token             | Value                                                                   | Use                                     |
|-------------------|-------------------------------------------------------------------------|-----------------------------------------|
| `--cb-shadow-sm`  | `0 1px 3px rgba(0,0,0,.06), 0 1px 2px rgba(0,0,0,.04)`                  | Cards at rest                           |
| `--cb-shadow-md`  | `0 8px 32px rgba(0,0,0,.1), 0 2px 8px rgba(0,0,0,.06)`                  | Modals, floating menus, card hover      |
| `--cb-shadow-lg`  | `0 24px 64px -12px rgba(0,0,0,.22), 0 0 0 1px rgba(0,0,0,.04)`          | Dropdowns, popovers                     |
| `--cb-shadow-xl`  | `0 32px 72px -12px rgba(0,0,0,.28), 0 0 0 1px rgba(0,0,0,.04)`          | Feature cards, reveal moments           |

### 2.5 Selection colour

Orange (accent) on white — maximum contrast, reinforces brand.

```css
::selection { background: var(--cb-selection-bg); color: #fff; }
```

---

## 3. Typography

### 3.1 Family

**Inter variable** (100–900 weight axis), loaded from Bunny Fonts
(privacy-respecting CDN, no Google tracking).

```json
"fontFamily": "'Inter', system-ui, -apple-system, BlinkMacSystemFont,
               'Segoe UI', sans-serif"
```

> **Trade-off acknowledged.** Inter is explicitly called out as a
> "generic AI-looking font" in the Claude frontend-design skill.
> It was chosen here for a *deliberate* institutional reason: Viken
> Regnskap is an accounting firm, and the brand voice is "measured,
> trustworthy, Scandinavian modern." Inter's quiet neutrality serves
> that better than a characterful display face would. If this design
> system is forked for a brand that wants *distinctive*, swap the
> Inter face at the `theme.json` `fontFamily` level and keep every
> other token.

### 3.2 Size scale

Two coexisting scales — use the right one for context:

**theme.json fixed sizes** (for Gutenberg font-size presets):

| Slug   | Size  | Use                            |
|--------|-------|--------------------------------|
| `xs`   | 13 px | Captions, micro-copy           |
| `sm`   | 15 px | Eyebrow labels, metadata       |
| `base` | 18 px | Default body                   |
| `lg`   | 20 px | Lead paragraphs                |
| `xl`   | 24 px | Card headings, callouts        |
| `2xl`  | 32 px | Small section headings         |
| `3xl`  | 40 px | Medium headings                |
| `4xl`  | 56 px | Large display                  |

**Fluid scale** (Tailwind extension, `clamp()` — for hero + section
headings that must respond to viewport):

| Token              | Clamp                                     | Line-height | Letter-spacing |
|--------------------|-------------------------------------------|-------------|----------------|
| `text-hero`        | `clamp(1.75rem, 6.5vw, 5.5rem)`           | 1.05        | -0.01em        |
| `text-hero-sub`    | `clamp(1.15rem, 1vw + 1rem, 1.45rem)`     | 1.625       | —              |
| `text-section-heading` | `clamp(2rem, 3vw + 0.5rem, 3.25rem)`  | 1.15        | -0.015em       |
| `text-quote`       | `clamp(1.1rem, 1.5vw + 0.5rem, 1.375rem)` | 1.625       | —              |

### 3.3 Body font size — responsive root

Base `font-size` on `.wp-site-blocks` scales with viewport:

| Viewport       | Root size |
|----------------|-----------|
| `< 769px`      | 18 px     |
| `≥ 769px`      | 19 px     |
| `≥ 1025px`     | 20 px     |

Body line-height: **1.75** (generous — reading comfort for longer
accounting/legal copy).

### 3.4 Weights

- Body: 400
- Emphasis / links: 500–600
- Headings (h1–h3): 700
- Eyebrow / small caps: 600 uppercase

---

## 4. Spacing, containers, radii

### 4.1 Section spacing (vertical rhythm)

| Token          | Clamp                       | Use                         |
|----------------|-----------------------------|-----------------------------|
| `py-section`   | `clamp(4rem, 8vw, 6rem)`    | Default section padding-y   |
| `py-section-sm`| `clamp(2.5rem, 5vw, 4rem)`  | Compact sections            |

### 4.2 Container widths (max-w)

| Token         | Width   | Use                                          |
|---------------|---------|----------------------------------------------|
| `max-w-prose` | 720 px  | Reading copy (blog posts, legal text)        |
| `max-w-site-md` | 1200 px | Default content cap (matches `contentSize`) |
| `max-w-site`  | 1440 px | Wide content (matches `wideSize`)            |
| `max-w-screen-rts` | 1024 px | Rich-text-section inner                 |

### 4.3 Horizontal padding

- Section edges: `px-6` (24 px) on mobile, scales implicitly with
  container max-widths

### 4.4 Radius scale

Uses Tailwind utilities directly — no custom scale:

| Class        | Value  | Use                              |
|--------------|--------|----------------------------------|
| `rounded-md` | 6 px   | Inputs, small chips              |
| `rounded-lg` | 8 px   | **Default button radius**        |
| `rounded-xl` | 12 px  | Icon tiles, avatars              |
| `rounded-2xl`| 16 px  | **Default card radius**          |
| `rounded-3xl`| 24 px  | Large feature cards, hero panels |
| `rounded-full` | 9999 px | Pills, round avatars           |

Button radius is tokenised: `var(--cb-btn-radius, 8px)` — change in
`:root` to rescale all buttons.

---

## 5. Component library

### 5.1 Buttons

Two variants — **always use these classes**, not raw Tailwind:

**Primary (`cb-cta-btn`)**
- Solid accent background (`var(--cb-accent)`) on light sections
- White text
- Radius: `var(--cb-btn-radius, 8px)`
- Shadow: `0 2px 12px var(--cb-accent-28)`
- Hover: underline on text-decoration (enforced with `!important` —
  see v1.1.7 for the rationale)

**Secondary (`cb-cta-btn-secondary`)**
- Transparent background
- `border-primary` → primary colour border + text
- `border-white/40` → white 40% border for dark sections
- Hover: solid fill (primary or white) + inverted text colour

### 5.2 Cards

**Feature / testimonial / employee cards**

```html
<li class="bg-white rounded-2xl shadow-sm border border-neutral-100 p-8
           flex flex-col gap-4">
  …
</li>
```

- Background: `bg-white`
- Radius: `rounded-2xl`
- Shadow: `shadow-sm` at rest, `shadow-md` on hover (transition 0.2s)
- Border: `border border-neutral-100` (subtle definition)
- Padding: `p-8` (32 px) on desktop
- Gap between children: `gap-4` (16 px)

**Drag-reorderable card** — add `cb-drag-card` + `data-drag-index` +
the drag handle `[data-drag-handle]` pattern (see
[useDragSort](../src/components/useDragSort.ts)).

### 5.3 Icon tiles

Circular / rounded icon containers for feature lists:

```html
<span class="cb-feature-icon w-12 h-12 flex items-center justify-center
             rounded-xl shrink-0">
  <IconRenderer icon="…" />
</span>
```

- Size: `w-12 h-12` (48 × 48)
- Radius: `rounded-xl` (12 px)
- `shrink-0` — never squeezed by flex siblings

### 5.4 Section header

All section-level blocks use the shared `<SectionHeader>` component
for eyebrow + heading + subtext. Each field is inline-editable via
RichText. Alignment (left/center/right) is per-field, stored in
attributes.

---

## 6. Layout patterns

### 6.1 Standard section skeleton

```tsx
<section className="py-section px-6" ...blockProps>
  <div className="max-w-site mx-auto">
    <SectionHeader … />
    {/* content */}
  </div>
</section>
```

`py-section px-6` → `max-w-site mx-auto` inner. Use `max-w-site-md`
for content-cap sections and `max-w-prose` for long-form copy.

### 6.2 Grid defaults

Responsive card grid:

```html
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
```

- `gap-8` = 32 px between cards
- Breakpoint order: mobile single-column → 2-up at ≥ 640 px → 3-up at
  ≥ 1024 px
- `columns` attribute (1 / 2 / 3) is author-controlled — honour it

### 6.3 Split section

Two-column layout with optional image/copy swap. Padding + gap follow
the section defaults. Equal-height columns via flex.

---

## 7. Block registry — current catalogue

| Block                 | Purpose                               | Status       |
|-----------------------|---------------------------------------|--------------|
| `hero`                | Above-the-fold hero with CTA          | Stable       |
| `feature-cards`       | 2–6 reorderable feature cards         | Stable (v1.1.9) |
| `stats-row`           | 3–4 metric pill row                   | Stable       |
| `split-section`       | 2-column image + text                 | Stable       |
| `testimonial`         | Quote card + attribution              | Stable       |
| `employee-grid`       | Team grid with modal bios             | Stable       |
| `employee-card`       | Single-employee inner block           | Inner only   |
| `call-card`           | Contact / phone CTA card              | Stable       |
| `cta-section`         | Full-width accent CTA band            | Stable       |
| `contact-section`     | Inline contact form                   | Stable       |
| `faq-accordion`       | Q&A accordion                         | Stable       |
| `logo-strip`          | Client logos row                      | Stable       |
| `media-grid`          | Image / video grid with lightbox      | Stable       |
| `rich-text-section`   | Long-form prose container             | Stable       |
| `react-header`        | Site header (menu, logo)              | Stable       |
| `video-section`       | Dark section with video hero          | Stable       |

Before creating a new block, check whether an existing block + options
can cover the use case.

---

## 8. Decision tree — new component vs extend existing

```
New visual need
    │
    ├─ Same purpose as existing block, different data shape?
    │   → Extend the existing block with new attributes
    │
    ├─ Same purpose, different styling?
    │   → Add a style variant (attribute enum), not a new block
    │
    ├─ New purpose, composition of existing bits?
    │   → Build a new block that reuses existing components
    │     (SectionHeader, IconRenderer, RichText, CtaButton)
    │
    └─ Genuinely new primitive UI pattern?
        → New component in src/components/ + new block that uses it
          + docs/DESIGN.md entry
```

---

## 9. What NOT to do

- ❌ **Inline hex colours.** Use palette slugs (`bg-accent`,
  `text-primary`) or CSS variables. Makes re-theming fail.
- ❌ **Custom font sizes outside the scale.** If the scale lacks a
  size you need, add it to `theme.json` + Tailwind config — don't
  one-off in markup.
- ❌ **Box-shadow other than the four tokens.** Stick to sm/md/lg/xl.
- ❌ **New card radii that aren't `rounded-lg` / `rounded-2xl` /
  `rounded-3xl`.** Visual consistency matters more than pixel-perfect
  designer whim.
- ❌ **Animations on every element.** Motion is a high-impact tool —
  one orchestrated reveal > scattered micro-interactions.
- ❌ **Text in images.** Real HTML text only. Needed for a11y and i18n.
- ❌ **Colour as the only signifier.** Error states: colour + icon +
  text. Focus: colour + outline (focus-visible).
- ❌ **Hover-only affordances.** Mobile has no hover. Touch = tap
  target; desktop = tap target + hover affordance (additive).

---

## 10. Re-theming checklist (new client)

When forking this plugin's design for a new client:

1. **Palette** — edit `theme.json` → `settings.color.palette` (6 slugs)
2. **Accent RGB channels** — update `--cb-accent-r/g/b` +
   `--cb-primary-r/g/b` in `src/style.css` (used by `rgba()` tints)
3. **Font family** — swap the `fontFamily` URL in `theme.json` if the
   brand wants a non-Inter face
4. **Rebuild CSS** — `pnpm build`
5. **Visual QA** — walk every block in the editor + frontend at
   mobile / tablet / desktop breakpoints
6. **Content QA** — every default string in block attributes should
   be neutral / industry-appropriate (no "We craft bold digital
   experiences" on an accountant's site)

Every block adapts automatically. No per-block CSS edits needed.

---

*Document version: 1.0 — lives in `docs/DESIGN.md` on `main`.
Updates go through the same PR flow described in `docs/WORKFLOW.md`.*
