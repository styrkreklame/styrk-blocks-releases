# Styrk Blocks — Development & Release Workflow

> Audience: Styrk Reklame developers + management. This document describes
> the end-to-end flow from writing code → merging → shipping an update to
> client sites. Follow it exactly. Deviations break the review trail or
> the auto-update pipeline.

---

## 1. Architecture at a glance

```
┌────────────┐   git push   ┌──────────────────────────┐   gh release   ┌────────────────────┐
│ Developer  │ ───────────> │  GitHub                  │ ─────────────> │  GitHub Releases   │
│  laptop    │              │  styrkreklame/styrk-blocks│                │  (zip + tag)       │
└────────────┘              └──────────────────────────┘                └─────────┬──────────┘
                                                                                  │ polled every ~12 h
                                                                                  │ by the plugin on each site
                                                                                  ▼
                                                                         ┌────────────────────┐
                                                                         │  Client WordPress  │
                                                                         │  (staging + prod)  │
                                                                         │  "Update available"│
                                                                         └────────────────────┘
```

Three independent pieces:

1. **Source of truth:** `main` branch on `github.com/styrkreklame/styrk-blocks`
2. **Delivery mechanism:** GitHub Releases — each release carries a tagged
   version and an attached `.zip` asset
3. **Client-side puller:** the plugin's built-in update checker
   ([yahnis-elsts/plugin-update-checker][puc]) polls the repo and surfaces
   an "Update" button in WP Admin on every client site

[puc]: https://github.com/YahnisElsts/plugin-update-checker

---

## 2. Developer workflow — every change

**Rule: nothing goes to `main` without a Pull Request.** This is
enforced by convention (`~/.claude/CLAUDE.md`) because the org is on the
free GitHub plan and server-side branch protection requires a paid plan
(Team, ~$4/seat/month).

### 2.1 Create a branch

| Prefix   | When to use                            |
|----------|----------------------------------------|
| `feat/`  | New user-facing feature or capability  |
| `fix/`   | Bug fix, regression, hotfix            |
| `chore/` | Maintenance, docs, tooling, refactor   |
| `docs/`  | Documentation-only                     |

```bash
git checkout main
git pull origin main
git checkout -b feat/<short-descriptor>     # e.g. feat/employee-grid-drag-reorder
```

### 2.2 Work on the change

- Edit **source only** (`src/…`). Never hand-edit `build/…` — it's
  regenerated.
- Follow the rules in `~/.claude/CLAUDE.md` (strict TypeScript, PHP
  idempotency, edit/save parity, WCAG AA, Core Web Vitals).
- Keep the scope tight — one PR = one concern.

### 2.3 Bump the version (only when shipping)

If this PR is going to be released:

1. Edit `styrk-blocks.php` → `* Version: X.Y.Z` (semver: patch for
   bugfix, minor for feature, major for breaking)
2. Add the **[X.Y.Z] section to `CHANGELOG.md`** (above `[Unreleased]`).
   This is non-negotiable — the release script reads this section as
   the GitHub release notes.

### 2.4 Build + commit

```bash
pnpm install          # first time or lockfile changed
pnpm build            # regenerates build/
git add -A
git commit -m "vX.Y.Z — <concise title>"   # match existing style
```

### 2.5 Push + open a PR

```bash
git push -u origin <branch>
gh pr create --fill    # or open manually on github.com
```

### 2.6 QA before merging

Before clicking "Squash and merge", verify:

- [ ] `pnpm build` succeeds without errors
- [ ] `npx tsc --noEmit` introduces **no new type errors** (compare against
  main — some pre-existing errors may be ignored)
- [ ] Block renders correctly in the **Gutenberg editor**
- [ ] Block renders correctly on the **frontend** (edit/save parity)
- [ ] No console errors, no layout shifts, no fatal PHP
- [ ] Responsive: mobile, tablet, desktop — no overflow, no broken grid
- [ ] Accessibility: keyboard navigation works, focus states visible, alt
  text present, colour contrast AA
- [ ] Reload the site to catch double-load / redeclaration fatals

### 2.7 Merge

Squash-merge on GitHub. Delete the branch.

```bash
gh pr merge <n> --squash --delete-branch
```

---

## 3. Release workflow — shipping to client sites

A merged PR on `main` is **not** a deployed update. Client sites only see
new code when a **GitHub Release** exists with an attached zip matching
the current version.

### 3.1 One-shot command (recommended)

Prerequisite: the PR you just merged must have bumped the version AND
added the matching `CHANGELOG.md` entry.

```bash
cd <repo>
git checkout main
git pull origin main
pnpm run release:publish
```

This script does, in order:

1. Reads the version from `styrk-blocks.php`
2. Sanity checks: working tree clean, on `main`
3. Runs `pnpm run release` → builds `release/styrk-blocks-X.Y.Z.zip`
4. Extracts `[X.Y.Z]` from `CHANGELOG.md` as release notes
5. Creates and pushes the `vX.Y.Z` git tag
6. Calls `gh release create vX.Y.Z <zip> --title ... --notes-file ...`

Result: release is live on
`github.com/styrkreklame/styrk-blocks/releases/tag/vX.Y.Z`.

### 3.2 Manual fallback

If the automated script fails:

```bash
pnpm build
pnpm run release            # produces release/styrk-blocks-X.Y.Z.zip
git tag vX.Y.Z
git push origin vX.Y.Z
gh release create vX.Y.Z release/styrk-blocks-X.Y.Z.zip \
  --title "vX.Y.Z — <title>" \
  --notes "<paste release notes here>"
```

### 3.3 When does staging/prod update?

Each site's built-in update checker polls GitHub every ~12 hours. To
force an immediate check:

- **WP Admin → Plugins page** → click "Check again" in any banner, or
- **WP Admin → Dashboard → Updates** → "Check again", or
- Run `wp transient delete update_plugins` via WP-CLI / Rocket.net terminal

---

## 4. GitHub authentication — token rotation

The plugin's updater needs a **fine-grained Personal Access Token (PAT)**
because the repo is private. The token lives in each client site's
`wp-config.php`.

### 4.1 When to rotate

- The token-holder leaves the org / account is deleted
- Token is about to expire
- Token is suspected compromised

### 4.2 Create a new token

1. Log into GitHub as an **org admin** for `styrkreklame`
2. Visit
   [github.com/settings/personal-access-tokens/new](https://github.com/settings/personal-access-tokens/new)
3. Fill:
   - **Token name:** `styrk-blocks updater (<site>)`
   - **Resource owner:** `styrkreklame` *(not your personal account)*
   - **Expiration:** 1 year
   - **Repository access:** "Only select repositories" → `styrk-blocks`
   - **Permissions → Repository → Contents:** Read-only
   - **Permissions → Repository → Metadata:** Read-only (auto)
4. Generate → copy the `github_pat_…` value (shown once only)

### 4.3 Install on each client site

Edit `wp-config.php` on the site (via Rocket.net file manager, SFTP, or
SSH). Above the line `/* That's all, stop editing! */` add:

```php
define( 'CB_UPDATE_AUTH_TOKEN', 'github_pat_XXXXXXXXXXXXXXXXXXXXXXXX' );
```

Save. The updater picks up the new token on next poll.

### 4.4 Optional overrides

| Constant                 | Default                    | When to override                        |
|--------------------------|----------------------------|-----------------------------------------|
| `CB_UPDATE_REPO`         | `styrkreklame/styrk-blocks`| Fork / white-label a client copy        |
| `CB_UPDATE_AUTH_TOKEN`   | `''`                       | **Always set on client sites**          |
| `CB_UPDATE_BRANCH`       | `main`                     | Pin a site to a pre-release branch      |

---

## 5. New-developer onboarding

```bash
# 1. GitHub CLI + auth (personal account, not a shared one)
brew install gh
gh auth login                         # HTTPS + web browser flow

# 2. Clone
gh repo clone styrkreklame/styrk-blocks

# 3. Install deps
cd styrk-blocks
pnpm install

# 4. Configure git identity (use your GitHub noreply email to stay private)
git config user.name "<your GitHub username>"
git config user.email "<id>+<username>@users.noreply.github.com"

# 5. Verify you can push (should be HTTPS remote)
git remote -v
# → origin  https://github.com/styrkreklame/styrk-blocks.git (fetch/push)
```

**Do not use SSH keys for auth.** HTTPS + `gh auth login` is the
modern default — OAuth tokens, auto-refresh, fine-grained scopes, works
through corporate firewalls.

---

## 6. Operational contacts

| Role                              | Who                                          |
|-----------------------------------|----------------------------------------------|
| GitHub org owner (primary)        | `web@styrkreklame.no`                        |
| GitHub org owner (developer)      | `ALorentzen`                                 |
| Repo                              | github.com/styrkreklame/styrk-blocks         |
| Release channel                   | github.com/styrkreklame/styrk-blocks/releases|
| Engineering rules (global)        | `~/.claude/CLAUDE.md`                        |

---

## 7. Emergency runbook

### "WP Admin shows `Could not determine if updates are available`"

- Cause: `CB_UPDATE_AUTH_TOKEN` in `wp-config.php` is invalid or expired.
- Fix: rotate the token (section 4).

### "PR merged but staging doesn't show the update"

- Cause: no GitHub Release was cut — merging to `main` alone is not
  enough.
- Fix: `pnpm run release:publish` (section 3).

### "Release script complains about dirty working tree / missing CHANGELOG"

- Cause: either uncommitted changes or the `[X.Y.Z]` section is missing.
- Fix: commit or stash pending work; add the CHANGELOG entry; rerun.

### "`pnpm install` fails on a new machine"

- Cause: Node / pnpm version mismatch.
- Fix: install with `corepack enable && corepack prepare pnpm@latest --activate`.

---

## 8. What not to do

- ❌ **Commit directly to `main`.** Always via PR.
- ❌ **Edit `build/…` by hand.** It's a build artifact.
- ❌ **Publish a release without bumping `styrk-blocks.php` + updating
  `CHANGELOG.md`.** The updater deduplicates on version and the release
  script reads the changelog for notes.
- ❌ **Use a personal GitHub email for commits.** Use the
  `…@users.noreply.github.com` form so private email doesn't leak.
- ❌ **Share a single PAT between sites.** Give each site its own
  fine-grained PAT so revocation is scoped.
- ❌ **Skip QA because "it's a small change."** Small changes have
  caused every post-incident review.

---

*Document version: 1.0 — maintained in `docs/WORKFLOW.md` on `main`.
Updates to this doc go through the same PR workflow they describe.*
