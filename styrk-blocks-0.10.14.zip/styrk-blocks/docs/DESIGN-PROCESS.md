# Styrk Blocks — Design Discovery Protocol

> When a client brief arrives ("we're a tow-truck company," "we're a
> Michelin-star restaurant," "we're a biotech lab"), this is the
> process the plugin maintainer (human or AI-assisted) follows before
> writing code. The goal is to **not ship the same template twice.**
> The plugin's structural components stay identical; the visual
> language — typography, palette, layout rhythm, component detail —
> gets redesigned to fit the brand.

---

## 1. When this protocol fires

Run the full protocol whenever **any** of these are true:

- Starting a **new client project** (new site from the plugin)
- **Re-skinning** an existing site (brand refresh, M&A, new owner)
- The existing design is being called "generic" / "template-y" /
  "AI-looking" and you need to level it up
- Launching a new **sub-brand** or product line under an existing site

Do **not** run it for: content updates, bug fixes, new blocks,
performance work, accessibility fixes. Those follow the normal
workflow in `WORKFLOW.md`.

---

## 2. The ten dimensions of a modernization

Every run of this protocol evaluates and touches all ten. Skipping
any of them is how a re-skin ends up half-done.

| # | Dimension                    | What gets considered                                                                 |
|---|------------------------------|--------------------------------------------------------------------------------------|
| 1 | **Template / layout**        | Section skeletons, grid patterns, asymmetry, rhythm, hero treatment, page structure  |
| 2 | **Component design**         | Cards, buttons, inputs, nav, icons, dividers, form fields — their shape and posture  |
| 3 | **Typography**               | Display + body pairing, scale, weights, tracking, line-height, paragraph rhythm      |
| 4 | **Colour**                   | Palette, tints, contrast, dark- vs light-section usage, accent discipline            |
| 5 | **Spacing & proportions**    | Section padding, gap scale, content ratios, negative space, vertical rhythm          |
| 6 | **Sizes**                    | Type scale, touch-target sizes, media sizing, container max-widths                   |
| 7 | **Responsiveness**           | Desktop / tablet / mobile — each checked **independently**, not just "it reflows"    |
| 8 | **Editor UX (Gutenberg)**    | InspectorControls panels, toolbar, inline affordances, copy clarity, control grouping|
| 9 | **Backwards compatibility**  | Existing saved content renders without loss; edit/save parity; sensible defaults     |
| 10| **Research-driven**          | WebSearch the vertical + competitors + current-year trend scan BEFORE proposing      |

**Guardrail:** we only touch what we control — the plugin's blocks,
the companion theme, and `theme.json`. Never modify WordPress core,
Gutenberg core, or third-party plugins. If a desired move requires
that, the answer is "not in this protocol."

---

## 3. The protocol — six steps

Each step has a clear input, action, and output. Don't skip steps.
Don't start coding before step 5.

### Step 1 — Brief intake

**Input:** a few sentences from the user / stakeholder.

**Action:** capture five attributes, ask follow-up questions only for
missing ones:

| Attribute       | Example                                                   |
|-----------------|-----------------------------------------------------------|
| **Industry**    | Accounting, tow-trucking, pediatric dentistry, aerospace  |
| **Audience**    | SMB owners, stranded drivers, parents, engineers          |
| **Brand voice** | Measured / rugged / playful / luxurious / clinical / raw  |
| **Competitors** | 2–3 sites they benchmark against (or want to avoid)       |
| **Constraints** | Legal palette, required content, pre-existing logo, etc.  |

**Output:** a one-paragraph brief the rest of the protocol hangs off.

---

### Step 2 — Vertical research (web)

**Input:** the brief from step 1.

**Action:** use `WebSearch` / `WebFetch` to look at **real sites in
the vertical**. Aim for 4–6 references:

- 2–3 **best-in-class** (Awwwards / SiteInspire / Land-book winners
  in that industry — use `site:awwwards.com`, `site:siteinspire.com`,
  etc. in the query)
- 1–2 **direct competitors** of the client
- 1 **cross-industry inspiration** that captures the right *tone*
  (e.g. a brutal industrial machinery site might borrow moves from a
  streetwear brand if both want "rugged, confident")

For each reference, note **across all 10 dimensions**:

- **Template / layout** — asymmetry, overlap, grid-breaking, fixed vs fluid
- **Component design** — card shape, button treatment, input style, icon use
- **Typography** — display + body pairing, weights, tracking
- **Colour** — dominant / accent / neutral discipline; skip "safe" palettes
- **Spacing & proportions** — rhythm, density, negative-space strategy
- **Sizes** — type scale, media sizing, touch targets
- **Responsive** — mobile-first adaptations, tablet handling, desktop moves
- **Distinctive details** — cursors, hover, motion, textures, borders, drop caps
- **What specifically to steal vs avoid**

**Output:** a short "references" table pasted into the proposal.

---

### Step 3 — Current-trend scan

**Input:** the brief + vertical references.

**Action:** scan design publications for what's **currently working
in the year of the brief** (not 3-year-old Pinterest boards):

- [awwwards.com](https://www.awwwards.com) — filter by industry
- [siteinspire.com](https://www.siteinspire.com) — industry filter
- [land-book.com](https://land-book.com) — curated, fresh
- [godly.website](https://godly.website) — avant-garde
- [typewolf.com](https://www.typewolf.com) — type-in-use
- [fonts.google.com](https://fonts.google.com) — variable fonts
  recently added
- [fonts.bunny.net](https://fonts.bunny.net) — what's actually
  loadable (privacy-respecting CDN the plugin already uses)

Look for: recurring typographic pairings, palette shifts (what's
*leaving* the zeitgeist, not just what's entering), new layout
idioms, motion patterns.

**Output:** 3–5 "moves" the proposal will commit to.

---

### Step 4 — Proposal + approval gate

**Input:** brief + references + trend scan.

**Action:** write a proposal with commitments for **each of the 10
dimensions** — not just type + colour. Every section is required:

1. **Typography** — exact display + body fonts + weights + source
   (Bunny Fonts URL, Google Fonts, self-hosted woff2), scale overrides
   if any, line-height and tracking rationale
2. **Colour** — 6 slots matching `theme.json`'s schema
   (primary / secondary / accent / surface / muted / white) with
   rationale tying each choice to the brand voice; tint usage rules
3. **Template / layout** — asymmetry rules, section rhythm, hero
   posture, grid patterns, overlap/bleed behaviour
4. **Component design** — card style, button system (primary /
   secondary / ghost), input style, icon treatment, divider approach
5. **Spacing & proportions** — section padding scale, gap values,
   content-to-whitespace ratio, density posture
6. **Sizes** — type scale adjustments, touch-target minimums,
   container max-widths, media sizing rules
7. **Responsive strategy** — what changes at each breakpoint
   (mobile / tablet / desktop); which signature moves stay vs
   degrade; mobile-first posture
8. **Editor UX** — how the InspectorControls panels group and name
   settings; which options get the toolbar vs sidebar; inline
   affordances in the block canvas; copy clarity
9. **Backwards compatibility** — list of attributes kept / added /
   deprecated (never removed outright); migration notes for any
   semantic change; default values for new attributes
10. **Signature moves** — 3–5 specific named patterns that make the
    site *distinctive* (e.g. "diagonal accent rule bleeding between
    sections," "numbered section indicators in condensed mono," "hero
    drop-shadow only, everything else flat")
11. **Anti-list** — what we are explicitly NOT doing (guards against
    drift to template defaults)
12. **References** — the 4–6 sites pulled in step 2, with a one-line
    note on what each contributes to the proposal

**Stop. Present to user. Wait for approval.** Do not touch code yet.

**Output:** signed-off proposal in a PR comment or doc draft.

---

### Step 5 — Implementation

**Input:** approved proposal.

**Action:** a single feature branch (e.g.
`chore/re-skin-<client-slug>`) containing, in this order:

### 5a. Tokens — global re-skin

1. **`theme.json`** — palette (6 slugs), font family URL, font-size
   scale adjustments, spacing overrides
2. **`src/style.css`** — `--cb-accent-rgb` + `--cb-primary-rgb`
   channels, new custom properties for signature moves, texture
   overlays, selection colour, base font-size scaling
3. **`tailwind.config.js`** — new font-family tokens
   (`font-display`, `font-serif`), fluid size clamps, any added
   spacing / max-width tokens, new rounded-scale entries if needed

### 5b. Components — shared primitives

4. **Signature-move CSS** — diagonal rules, grain overlays, custom
   cursors, orchestrated keyframes, accent lead-ins, numbered section
   indicators. Add as reusable classes (`.cb-deco-*`, `.cb-grain`,
   etc.), not one-off styles.
5. **Shared components** (`src/components/`) that need visual refresh:
   `SectionHeader`, `CtaButtonShell`, `IconRenderer`. Update their
   JSX + styling; NEVER break their public API or existing props.

### 5c. Blocks — per-block pass

6. For **each of the 16 blocks** in `src/blocks/*`, do a focused pass
   covering all 10 dimensions:
   - **Frontend `save.tsx`** — new layout / spacing / component look
   - **Editor `edit.tsx`** — ensure edit/save parity; update
     InspectorControls grouping + labels for editor UX; preserve all
     existing attributes (backwards compat)
   - **`block.json`** — add new attributes with defaults; never
     remove or rename existing ones
   - **Block-specific CSS** — only if it can't live in shared classes

### 5d. Responsive passes

7. For each block, verify at **three breakpoints**:
   - **Mobile (≤ 640 px)** — signature moves adapted or gracefully
     dropped; touch targets ≥ 44 × 44 px
   - **Tablet (641–1024 px)** — intermediate density; grid
     transitions correct
   - **Desktop (≥ 1025 px)** — full signature-move expression

### 5e. Editor UX pass

8. Open each block in the Gutenberg editor and verify:
   - Inline editing works on every RichText
   - InspectorControls panels are logically grouped and named
   - No duplicated settings (same thing in toolbar AND sidebar)
   - Toggle / select labels are written for editors, not developers
   - Block's default state (no content) renders clearly and shows
     editable placeholders

### 5f. Sync docs

9. **Refresh `docs/DESIGN.md`** to document the new tokens,
   components, and patterns. This stays in sync with the
   implementation and is the single source of truth for the next
   developer.

Run `pnpm build` and visually walk every block in the editor + on
the frontend at all three breakpoints.

**Output:** a PR on the plugin repo per the normal `WORKFLOW.md`.

---

### Step 6 — Visual QA

**Input:** built + running site (staging).

**Action:** check each block against the checklist below. Any fail
sends you back to step 5 — no "merge now, fix later."

### Frontend (public site)

- [ ] **Distinctiveness.** Would a designer unfamiliar with the site
  guess this was AI-generated? If yes, it's not there yet.
- [ ] **Brand fit.** Does the voice match the brief? (A tow-truck
  site shouldn't feel like a spa.)
- [ ] **Template / layout.** Section rhythm and hero posture match
  the proposal.
- [ ] **Component design.** Cards, buttons, inputs, nav look
  consistent and on-brand.
- [ ] **Typography.** Display + body pairing renders; weights and
  tracking match spec.
- [ ] **Colour.** Palette discipline holds; no off-palette drift.
- [ ] **Spacing & proportions.** Section rhythm correct; no cramped
  or unintentionally loose areas.
- [ ] **Sizes.** Type scale visible; touch targets ≥ 44 × 44 px;
  media sized correctly.
- [ ] **Responsive: mobile (≤ 640 px).** Signature moves adapted
  gracefully; no overflow; no broken grid; navigation usable.
- [ ] **Responsive: tablet (641–1024 px).** Intermediate density
  correct; grid transitions intentional.
- [ ] **Responsive: desktop (≥ 1025 px).** Full signature-move
  expression; no wasted whitespace at wide viewports.

### Editor (Gutenberg)

- [ ] **Inline editing.** Every RichText accepts cursor + keystrokes
  on first click.
- [ ] **Edit/save parity.** Editor preview matches frontend render.
- [ ] **InspectorControls.** Panels grouped logically; labels clear;
  no duplicated settings across toolbar + sidebar.
- [ ] **Defaults.** A freshly-inserted block renders clearly with
  placeholder content; nothing blank or broken.
- [ ] **Toolbar.** Only the actions an editor *actually uses* are in
  the toolbar; developer-flavoured settings stay in the sidebar.

### Data integrity

- [ ] **Backwards compatibility.** Open 3+ existing posts/pages that
  used this block **before** the re-skin. They render correctly with
  no lost content.
- [ ] **Attribute stability.** No attribute was renamed or removed;
  new attributes have sensible defaults that don't break old output.

### Non-functional

- [ ] **Accessibility (WCAG 2.1 AA).** Contrast, focus states,
  keyboard nav, screen-reader labels all intact. Decorative moves
  do not degrade any of the above.
- [ ] **Performance.** LCP ≤ 2.5 s, INP ≤ 200 ms, CLS ≤ 0.1.
  Custom fonts preloaded; background textures lightweight (SVG /
  small PNG, not 2 MB JPG); animations GPU-friendly.

**Output:** release per `WORKFLOW.md` (`pnpm run release:publish`).

---

## 4. Anti-patterns

### Visual (frontend)

| Anti-pattern                                  | Replace with                                     |
|-----------------------------------------------|--------------------------------------------------|
| Inter everywhere                              | A distinctive display face + Inter for body      |
| Safely-centered sections only                 | Asymmetric headers, occasional grid-breaking     |
| Shadow-sm + border-neutral + rounded-2xl cards| Differentiated card system per brand             |
| Purple gradient on white                      | Brand-specific palette commitment                |
| Evenly-distributed palette                    | Dominant + sharp accent + restrained neutrals    |
| Scattered generic micro-animations            | One orchestrated hero reveal + subtle on-scroll  |
| Pure `#ffffff` background                     | Warm off-white / subtle tint that fits the brand |
| Identical across clients                      | **Every client gets its own skin.**              |

### Editor UX (Gutenberg)

| Anti-pattern                                  | Replace with                                     |
|-----------------------------------------------|--------------------------------------------------|
| Same setting in toolbar AND sidebar           | One home for each setting; toolbar = frequent    |
| Developer-flavoured labels ("Eyebrow Alignment Horizontal") | Editor-flavoured labels ("Align small label")    |
| Flat list of 20 controls in one panel         | Grouped panels: "Content," "Appearance," "Layout"|
| TextControl in sidebar for copy               | Inline RichText in the block canvas              |
| Empty default state (nothing rendered)        | Placeholder content that teaches the block's use |

### Data / backwards compatibility

| Anti-pattern                                  | Replace with                                     |
|-----------------------------------------------|--------------------------------------------------|
| Renaming an attribute                         | Add new attribute + deprecate old + migrate on load |
| Removing an attribute                         | Keep it in schema; stop rendering it             |
| Changing an attribute's type                  | New attribute with new type; old stays for compat|
| New attribute without a default               | Always set a sensible default so old blocks upgrade |

---

## 5. Integration with the rest of the workflow

```
BRIEF INTAKE  →  RESEARCH  →  TREND SCAN  →  PROPOSAL (APPROVAL GATE)
                                                        │
                                                        ▼
                               WORKFLOW.md (branch → PR → QA → merge)
                                                        │
                                                        ▼
                                          RELEASE (pnpm run release:publish)
                                                        │
                                                        ▼
                                              VISUAL QA on staging
```

Steps 1–4 of this protocol happen **before** the PR workflow in
`WORKFLOW.md` opens. Step 5 feeds into that workflow. Step 6 happens
after the release is cut.

---

## 6. Research library — recommended sources

Sources to check every time; don't reuse the same inspiration well:

**Awards / curation**
- awwwards.com — industry filter + "site of the day"
- siteinspire.com — tight curation, industry filter
- land-book.com — landing pages specifically
- godly.website — experimental / avant-garde
- minimal.gallery — refined minimalism
- httpster.net — eclectic, fresh

**Type**
- typewolf.com — "this week in type"
- fonts.google.com — variable fonts
- fonts.bunny.net — privacy-friendly CDN (already used by plugin)
- pangrampangram.com, displaay.net, grilli.type — independent foundries (paid, but inspiration is free)

**Branding + identity**
- underconsideration.com/brandnew — brand refresh case studies
- brandingletters.com — monthly digest

**Patterns**
- refactoringui.com — Tailwind-era UI patterns (already in the team's DNA)
- mobbin.com — real app UI patterns
- pttrns.com — mobile-first

---

## 7. Rules

- **Never skip step 4 (approval gate).** The research is for *the
  user to react to*, not a fait accompli. Surprising the user with a
  committed re-skin defeats the purpose.
- **Never copy pixel-for-pixel.** References are directional, not
  templates. If someone asks, "where did this come from?" the answer
  should be "the brief + these 5 references + a synthesis," not "we
  cloned site X."
- **Never reach for the same go-to choices.** If the last three
  projects all used Space Grotesk as display, that's a signal to pick
  anything else.
- **Update this doc when the process evolves.** Ran a better
  reference search this time? Found a new trend publication? Add it.
- **The result is the proof.** If after steps 1–6 the site still
  looks AI-generated, step 3 (trend scan) was too shallow. Go back.

---

*Document version: 1.0 — lives in `docs/DESIGN-PROCESS.md`. Updates
go through the same PR flow described in `docs/WORKFLOW.md`.*
