# Styrk Blocks — working instructions for Claude Code

## Design system

The folder [design-system/](design-system/) is the visual source of
truth for this plugin.

**Before making UI changes, read:**

- [design-system/README.md](design-system/README.md) — brand
  fundamentals, tokens, iconography
- [design-system/SKILL.md](design-system/SKILL.md) — content rules +
  hard rules for production code
- [design-system/colors_and_type.css](design-system/colors_and_type.css) —
  canonical tokens (colors, type, spacing, shadows, radii)
- [design-system/assets/icons.js](design-system/assets/icons.js) — the
  27 Feather-style stroke icons. **Never invent new icon SVGs.**
- [design-system/ui_kits/website/](design-system/ui_kits/website/) —
  hi-fi component specs (the 17 blocks as they should render, as JSX)
- [design-system/preview/](design-system/preview/) — per-token
  specimens (buttons, eyebrows, colors, type, etc.)

When building or editing a block, **mirror the matching preview /
ui_kit component in look and behavior.**

---

## Official palette (from the brand book)

All four hex values are fixed by the designer. **Do not invent new
brand colors** — use tints 100 / 80 / 50 only.

| Role           | Hex       | CMYK              | RGB             |
|----------------|-----------|-------------------|-----------------|
| Logofarge      | `#00486A` | 100, 40, 15, 50   | 0, 72, 106      |
| Støttefarge 1  | `#0084AF` | 100, 6, 7, 25     | 0, 132, 175     |
| Støttefarge 2  | `#5DB6CF` | 60, 10, 14, 0     | 93, 182, 207    |
| Støttefarge 3  | `#F5833C` | 0, 60, 85, 0      | 245, 131, 60    |

Tint tokens already in `colors_and_type.css`:
`--primary-80 / -50`, `--secondary-80 / -50`, `--light-teal-80 / -50`,
`--accent-80 / -50`.

---

## Typography

Two families only — **Fraunces** (display serif) and **Inter** (sans).
Fonts are self-hosted in `design-system/fonts/` (latin subsets, Bunny
CDN origin). **Do not substitute.**

---

## Contrast

Every fg/bg combination must pass WCAG AA. Specifically:

- **Never white text on `--accent` (#F5833C)** — fails AA (~2.8:1). Use
  navy text on orange, or **soft peach (`#FCE6D3`) with navy text**.
- **Primary CTA** = navy `#00486A` with white text (AAA).
- **Accent CTA** = soft peach fill with navy text.
- Orange is a **decorative accent color** (icons, underlines, dots), not
  a body-text color.

---

## Hard rules for production code (`src/`)

- **Dynamic blocks only.** Never add `save.tsx`.
- **Additive schema changes.** Never rename / remove block attributes.
- **Escape everything in `template.php`:** `esc_html`, `esc_attr`,
  `esc_url`, `wp_kses_post`. Inline styles go through `esc_attr`.
- **Theme colors** reference `theme.json` via
  `var(--wp--preset--color--<slug>, #hex-fallback)` — always include
  the fallback.
- **Build output (`build/`) is committed to Git.** Run `pnpm build`
  before release.
- **Edit `src/`, never `build/`.**

---

## Content rules

- **Norwegian bokmål** everywhere in rendered copy. Sentence case (no
  title casing).
- Use **"du"**, never "De". Decimal comma, space thousand-separator.
- **No emoji. No hand-drawn SVG. No illustrations** — use the
  StyrkIcons catalog.

---

## Motion

- **0.15 s / 0.25 s / 0.4 s** transitions with
  `cubic-bezier(0.4, 0, 0.2, 1)`.
- **Always wrap animation in `@media (prefers-reduced-motion: reduce)`
  killswitches.**
- Button hover = subtle lift + shadow increase, **never darker fill**.

---

## Not shipped

`design-system/` is listed in `.distignore` and **must stay there** —
it's dev-time reference, never goes in the release zip.
