<?php
/**
 * WebP Auto-Converter — automatically creates .webp copies of uploaded images.
 *
 * When a JPEG or PNG is uploaded through the Media Library, this module:
 *  1. Creates a .webp copy of the original full-size image
 *  2. Creates .webp copies of every generated thumbnail
 *  3. Optionally serves .webp via <picture> element (filter-based)
 *
 * Requirements: GD with WebP support or Imagick with WEBP delegate.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard — see header-settings.php for the rationale.
if ( defined( 'CB_WEBP_CONVERTER_LOADED' ) ) return;
define( 'CB_WEBP_CONVERTER_LOADED', true );

/* ── Quality constant ──────────────────────────────────────────────────────── */
if ( ! defined( 'CB_WEBP_QUALITY' ) ) {
	define( 'CB_WEBP_QUALITY', 82 );
}

/* ── Check server support ──────────────────────────────────────────────────── */

/**
 * Can this server convert images to WebP?
 */
function cb_webp_supported(): bool {
	static $supported = null;
	if ( $supported !== null ) {
		return $supported;
	}

	// Check Imagick first (usually better quality)
	if ( extension_loaded( 'imagick' ) ) {
		$formats = \Imagick::queryFormats( 'WEBP' );
		if ( ! empty( $formats ) ) {
			$supported = true;
			return true;
		}
	}

	// Fall back to GD
	if ( function_exists( 'imagewebp' ) && ( defined( 'IMG_WEBP' ) && ( imagetypes() & IMG_WEBP ) ) ) {
		$supported = true;
		return true;
	}

	$supported = false;
	return false;
}

/* ── Core conversion function ──────────────────────────────────────────────── */

/**
 * Convert a single image file to WebP.
 *
 * @param string $file Absolute path to the source image (JPEG or PNG).
 * @return string|false Path to the created .webp file, or false on failure.
 */
function cb_convert_to_webp( string $file ): string|false {
	if ( ! file_exists( $file ) || ! cb_webp_supported() ) {
		return false;
	}

	$mime = wp_check_filetype( $file )['type'] ?? '';
	if ( ! in_array( $mime, [ 'image/jpeg', 'image/png' ], true ) ) {
		return false;
	}

	$webp_path = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $file );
	if ( ! $webp_path || $webp_path === $file ) {
		return false;
	}

	// Skip if .webp already exists and is newer than source
	if ( file_exists( $webp_path ) && filemtime( $webp_path ) >= filemtime( $file ) ) {
		return $webp_path;
	}

	$editor = wp_get_image_editor( $file );
	if ( is_wp_error( $editor ) ) {
		return false;
	}

	$result = $editor->save( $webp_path, 'image/webp' );
	if ( is_wp_error( $result ) || empty( $result['path'] ) ) {
		return false;
	}

	return $result['path'];
}

/* ── Hook into upload pipeline ─────────────────────────────────────────────── */

/**
 * After WP generates all thumbnail sizes for an upload, create .webp copies
 * of each size AND the original full-size image.
 *
 * Hooked to `wp_generate_attachment_metadata` (priority 10).
 */
function cb_webp_on_upload( array $metadata, int $attachment_id ): array {
	if ( ! cb_webp_supported() ) {
		return $metadata;
	}

	$file = get_attached_file( $attachment_id );
	if ( ! $file || ! file_exists( $file ) ) {
		return $metadata;
	}

	$mime = get_post_mime_type( $attachment_id );
	if ( ! in_array( $mime, [ 'image/jpeg', 'image/png' ], true ) ) {
		return $metadata;
	}

	// Convert original full-size
	cb_convert_to_webp( $file );

	// Convert every generated thumbnail
	if ( ! empty( $metadata['sizes'] ) ) {
		$upload_dir = dirname( $file );
		foreach ( $metadata['sizes'] as $size_data ) {
			if ( ! empty( $size_data['file'] ) ) {
				$thumb_path = $upload_dir . '/' . $size_data['file'];
				cb_convert_to_webp( $thumb_path );
			}
		}
	}

	return $metadata;
}
add_filter( 'wp_generate_attachment_metadata', 'cb_webp_on_upload', 10, 2 );

/* ── Clean up .webp files when attachment is deleted ───────────────────────── */

/**
 * Remove .webp copies when the original attachment is deleted.
 */
function cb_webp_on_delete( int $attachment_id ): void {
	$file = get_attached_file( $attachment_id );
	if ( ! $file ) {
		return;
	}

	$mime = get_post_mime_type( $attachment_id );
	if ( ! in_array( $mime, [ 'image/jpeg', 'image/png' ], true ) ) {
		return;
	}

	// Delete full-size .webp
	$webp_path = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $file );
	if ( $webp_path && file_exists( $webp_path ) ) {
		wp_delete_file( $webp_path );
	}

	// Delete thumbnail .webp files
	$metadata = wp_get_attachment_metadata( $attachment_id );
	if ( ! empty( $metadata['sizes'] ) ) {
		$upload_dir = dirname( $file );
		foreach ( $metadata['sizes'] as $size_data ) {
			if ( ! empty( $size_data['file'] ) ) {
				$thumb_webp = preg_replace( '/\.(jpe?g|png)$/i', '.webp', $upload_dir . '/' . $size_data['file'] );
				if ( $thumb_webp && file_exists( $thumb_webp ) ) {
					wp_delete_file( $thumb_webp );
				}
			}
		}
	}
}
add_action( 'delete_attachment', 'cb_webp_on_delete' );

/* ── Allow .webp uploads ──────────────────────────────────────────────────── */

/**
 * Ensure .webp is in the allowed mime types for uploads.
 */
function cb_webp_mime_types( array $mimes ): array {
	$mimes['webp'] = 'image/webp';
	return $mimes;
}
add_filter( 'upload_mimes', 'cb_webp_mime_types' );

/* ── Admin notice if server lacks WebP support ─────────────────────────────── */

function cb_webp_admin_notice(): void {
	if ( cb_webp_supported() ) {
		return;
	}

	$screen = get_current_screen();
	if ( ! $screen || ! in_array( $screen->id, [ 'upload', 'plugins', 'options-general' ], true ) ) {
		return;
	}

	printf(
		'<div class="notice notice-warning"><p>%s</p></div>',
		esc_html__( 'WebP auto-conversion is disabled — your server lacks GD WebP or Imagick WEBP support. Contact your hosting provider to enable it.', 'styrk-blocks' )
	);
}
add_action( 'admin_notices', 'cb_webp_admin_notice' );
