<?php
/**
 * Self-hosted update channel for Styrk Blocks.
 *
 * Uses yahnis-elsts/plugin-update-checker in JSON-metadata mode. A
 * single public URL (the manifest) describes the current version and
 * where to download the zip. No GitHub tokens, no API auth — any site
 * that can reach the manifest URL can check for and install updates.
 *
 * Flow:
 *   Maintainer runs `pnpm run release:publish` → builds zip, writes
 *   manifest.json, uploads both to the public host.
 *   Client site's PUC pings the manifest ~every 12h, compares version,
 *   shows the standard WP "Update Now" badge if newer. User clicks,
 *   WP downloads the zip from `download_url` and installs in place.
 *
 * Per-site override (rarely needed — only for testing, staging, or a
 * customer with a mirrored host):
 *
 *     define( 'CB_UPDATE_MANIFEST_URL', 'https://your.host/path/manifest.json' );
 *
 * Set CB_UPDATE_MANIFEST_URL to '' to disable update checks entirely.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_UPDATER_LOADED' ) ) return;
define( 'CB_UPDATER_LOADED', true );

/**
 * Public URL of the JSON manifest describing available releases.
 * Must be reachable without auth from every site running this plugin.
 */
if ( ! defined( 'CB_UPDATE_MANIFEST_URL' ) ) {
	define( 'CB_UPDATE_MANIFEST_URL', 'https://raw.githubusercontent.com/styrkreklame/styrk-blocks-releases/main/manifest.json' );
}

add_action( 'plugins_loaded', function () {
	if ( CB_UPDATE_MANIFEST_URL === '' ) return;

	$vendor_path = dirname( __DIR__ ) . '/vendor/yahnis-elsts/plugin-update-checker/plugin-update-checker.php';
	$manual_path = dirname( __DIR__ ) . '/lib/plugin-update-checker/plugin-update-checker.php';

	if ( file_exists( $vendor_path ) ) {
		require_once $vendor_path;
	} elseif ( file_exists( $manual_path ) ) {
		require_once $manual_path;
	} else {
		// Library not bundled — plugin still works, just no auto-update.
		return;
	}

	if ( ! class_exists( '\\YahnisElsts\\PluginUpdateChecker\\v5\\PucFactory' ) ) {
		return;
	}

	$factory = '\\YahnisElsts\\PluginUpdateChecker\\v5\\PucFactory';
	$factory::buildUpdateChecker(
		CB_UPDATE_MANIFEST_URL,
		dirname( __DIR__ ) . '/styrk-blocks.php',
		'styrk-blocks'
	);
} );
