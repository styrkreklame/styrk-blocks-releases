<?php
/**
 * Eyebrow style helper.
 *
 * Every section block renders a small pill-style "eyebrow" above its heading
 * (TJENESTER / REFERANSER / ANBEFALINGER …). The inline-style assembly used
 * to be reimplemented in ~8 template.php files with slight variations — fix
 * to one, drift in the rest. This helper centralises it.
 *
 * Returns a CSS style string ready to drop into a style="" attribute. Reads
 * these keys from $attributes:
 *   eyebrowAlign       — left|center|right (optional; omit to skip align-self)
 *   eyebrowBgColor     — hex / colour
 *   eyebrowTextColor   — hex / colour
 *   eyebrowRadius      — int (px); defaults to 50
 *
 * When a bg colour is set, the helper snaps the text colour through
 * cb_best_contrast_text() to keep WCAG AA, mirroring what feature-cards /
 * rich-text-section already do inline today.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_render_eyebrow_style' ) ) {
	function cb_render_eyebrow_style( array $attributes ): string {
		$style = '';

		$align = $attributes['eyebrowAlign'] ?? null;
		if ( is_string( $align ) && $align !== '' ) {
			$self = $align === 'right'
				? 'flex-end'
				: ( $align === 'center' ? 'center' : 'flex-start' );
			$style .= 'align-self:' . $self . ';';
		}

		$bg     = (string) ( $attributes['eyebrowBgColor']   ?? '' );
		$text   = (string) ( $attributes['eyebrowTextColor'] ?? '' );
		$radius = (int)    ( $attributes['eyebrowRadius']    ?? 50 );

		if ( $bg !== '' ) {
			$text_safe = function_exists( 'cb_best_contrast_text' )
				? cb_best_contrast_text( $bg, $text, 4.5 )
				: ( $text !== '' ? $text : '#0a2020' );
			$style .= 'background:' . esc_attr( $bg ) . ';';
			$style .= 'padding:8px 20px;';
			$style .= 'border-radius:' . max( 0, min( 999, $radius ) ) . 'px;';
			$style .= 'color:' . esc_attr( $text_safe ) . ';';
		} elseif ( $text !== '' ) {
			$style .= 'color:' . esc_attr( $text ) . ';';
		}

		return $style;
	}
}
