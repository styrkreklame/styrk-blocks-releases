<?php
/**
 * Video MIME helpers.
 *
 * Block templates declare a <source type="…"> for embedded videos. If the
 * declared MIME doesn't match the file, browsers that honour the MIME skip
 * the source — autoplay then fails silently and the poster is shown as a
 * fallback. Derive the MIME from the file extension instead of hardcoding it.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_video_mime_for' ) ) {
	/**
	 * Best-effort MIME type for a video URL. Falls back to video/mp4 when
	 * the extension is unrecognised, since mp4 is the universal baseline.
	 *
	 * @param string $url
	 * @return string
	 */
	function cb_video_mime_for( string $url ): string {
		$ext = strtolower( (string) pathinfo( wp_parse_url( $url, PHP_URL_PATH ) ?: $url, PATHINFO_EXTENSION ) );
		switch ( $ext ) {
			case 'webm':
				return 'video/webm';
			case 'ogv':
			case 'ogg':
				return 'video/ogg';
			case 'mov':
				return 'video/quicktime';
			case 'mp4':
			case 'm4v':
			default:
				return 'video/mp4';
		}
	}
}
