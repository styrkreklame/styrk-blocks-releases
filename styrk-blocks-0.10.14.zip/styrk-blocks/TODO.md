# Backlog — Styrk Blocks

Notes for things flagged but deferred. Not promises, just a list so we don't forget.

---

## Sitemap — replace WP-core default

**Flagged:** 2026-04-28 — staging shows `wp-sitemap.xml` with only the
4 default sub-sitemaps (posts, pages, categories, users). It's
WordPress core's built-in sitemap (since 5.5), which is intentionally
bare-bones.

### Gaps vs. what a real B2B site wants

- **No image entries** — image sitemap helps Google Images.
- **No `priority` / `changefreq` signals** — core only ships `lastmod`.
- **`users-1.xml` is publicly listed** — privacy + low SEO value;
  most sites suppress it.
- **Custom post types** (`employee`, `social_link`) need their
  `show_in_rest` / sitemap inclusion verified — they may or may not
  surface in the core sitemap depending on registration.
- **No exclusion control** — admins can't easily de-list the 404
  stub, archive pages, or specific posts.
- **No news / video / hreflang** support.

### Recommended fix when picked up

Drop in one of:
- **Rank Math** — leanest, modern, free tier covers everything we need.
- **Yoast SEO** — most familiar to clients; heavier but well-documented.
- **SEOPress** — middle ground.

Any of the three will:
- Add image sitemap entries
- Add `lastmod` / priority / changefreq tuning
- Auto-include CPTs (employee, social_link) with per-type toggles
- Exclude users sitemap by default
- Provide admin UI for indexability per post / taxonomy
- Replace `wp-sitemap.xml` route with their own (e.g.
  `sitemap_index.xml`)

### Notes

- Pick **one** and stick with it — the three SEO plugins step on each
  other if installed simultaneously.
- After install, submit the new sitemap URL to Google Search Console
  + Bing Webmaster Tools.
- Verify our react-header / page-auto-hero pages all surface — the
  sitemap is built from public-queryable post types, not from
  navigation.

---

## Posts — design system + landing/archive page

**Flagged:** 2026-04-28 — site has no post (blog) design or post
archive landing page. Core `post` post type is registered but using
WP defaults. Once we want to publish articles for SEO + thought
leadership (Norwegian regnskap firms typically do — "Siste fra
bloggen", tax-update posts, year-end-close guides), we need:

### Single-post template

- New theme template `templates/single.html` (currently inherits
  `index.html` or default).
- Header band: matches the page-auto-hero pattern (or page-header
  block) — top-level ancestor eyebrow ("ARTIKKEL" or category label),
  big serif h1 (post title), date + author meta below in muted body
  weight.
- Featured image as hero bg with overlay (same handshake as
  page-auto-hero).
- Reading column (720px contentSize) for the body — already aligned
  with the rest of the site by the column-alignment work in PR #36.
- Author byline + reading-time + published date metadata strip.
- Tag/category pills below the body.
- Related-posts section at the bottom (3 cards, same category,
  excluding current post).
- "Tilbake til oversikt" link to the archive page.

### Archive / landing page (`/blogg/` or `/aktuelt/`)

- New page (or `archive-post.html` template) with:
  - Header band (page-auto-hero with "AKTUELT" eyebrow + e.g. "Siste
    fra Viken")
  - Filter row: category pills, optionally search.
  - Grid of post cards: 3-up desktop, 2-up tablet, 1-up mobile.
  - Each card: featured image (16:9), category eyebrow, title (2-line
    clamp), excerpt (3-line clamp), date.
  - Pagination at the bottom — match site button style.
- Decide on slug + permalink structure: `/aktuelt/<slug>/` is more
  Norwegian than `/blog/`. Update WP permalink settings if needed.

### Block(s) we'd need to build

- **Post card** — possibly reusable inside Article Grid block + as a
  related-posts component.
- **Article Grid** — query loop over posts with the filtering UI;
  could extend `feature-cards` or be its own block.
- (Optional) **Author byline** — small avatar + name + role + link to
  author archive. Pulls from user meta.

### Conventions to honour

- Eyebrow on single-post header should derive from the post's
  primary category (parallel to how page-auto-hero derives from the
  top-level page ancestor).
- Reading-column width = 720px (matches contentSize, see column
  alignment work in PR #36).
- Featured-image fallback: if no featured image, use a brand-tinted
  navy gradient panel — same `--cb-hero-bg` fallback as
  page-auto-hero.
- Typography: Fraunces for h1/h2, Inter for body (already established).
- Default image ratio for cards: 16:9 (consistent with hero feel).

### Decision points before starting

- Slug: `/aktuelt/`, `/blogg/`, `/artikler/`, or `/innsikt/`?
- Categories: do we map them to existing service columns
  (Bokføring / Lønn / Rådgivning) or invent new editorial categories
  (Aktuelt / Veiledere / Bransje)?
- Pagination style: traditional numbered, or load-more button?
- Author display: are author bios visible? If so, single-author or
  multi-author setup?

These should be answered before any code lands.
