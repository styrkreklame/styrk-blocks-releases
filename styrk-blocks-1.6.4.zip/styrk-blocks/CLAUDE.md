# Styrk Blocks — project instructions for Claude

This plugin ships with a complete, canonical design system at
[design-system/](design-system/). It is the single source of truth for
every visual, typographic, and copy decision inside this plugin and
its companion theme (`styrk-theme/`).

---

## Before any design, UI, copy, block, or theme work

**Read these first:**

1. [design-system/README.md](design-system/README.md) — content
   fundamentals, visual foundations (palette, type, spacing, motion,
   hover/focus, borders, shadows, radii, imagery), iconography, and
   production conventions.
2. [design-system/SKILL.md](design-system/SKILL.md) — the working rules
   and hard production constraints.
3. [design-system/colors_and_type.css](design-system/colors_and_type.css) —
   every design token as a CSS custom property.

**Do not invent tokens.** Pull from the token file. If a value is
missing, flag it and ask — do not make up hex values, spacing, or
font sizes on the fly.

---

## Non-negotiable rules from the design system

These are distilled from `SKILL.md` and `README.md`; the full
rationale lives there.

### Visual

- **Palette.** Only `--primary #00486A`, `--secondary #0084AF`,
  `--accent #F5833C`, `--surface #f0f7fa`, `--muted`, `--light-teal`,
  and their `-r/-g/-b` channels. Everything derives from these. No
  off-palette colours. Override these to re-skin for a new client.
- **Type.** Fraunces (variable serif, `opsz 144`, `SOFT 30`) for
  display headings only. Inter (variable) for body, nav, forms,
  eyebrows, captions, buttons. No third family.
- **Spacing.** Section padding `clamp(4rem, 8vw, 6rem)`. Content
  width cap 1200px (1440px for wide), prose cap 720px (≈64ch).
- **No gradients on backgrounds.** Sections alternate white ↔
  `--surface` ↔ `--primary` (dark). The only gradient is stat numbers
  (`primary → secondary`, clipped to text). The only tinted bg is the
  feature-icon tile.
- **Motion.** 0.15s / 0.25s / 0.4s, `cubic-bezier(0.4, 0, 0.2, 1)`.
  Always wrap in `@media (prefers-reduced-motion: reduce)`.
- **Iconography.** Feather-style stroke icons, 24×24, `currentColor`,
  `stroke-width=1.5`, from the 27-slug catalog in `IconPicker.tsx` /
  `IconRenderer.tsx` / `cb_render_icon()`. No emoji in UI. No
  illustrations. No hand-drawn SVG.

### Copy

- **Norwegian bokmål** on all client-facing surfaces. UI labels in
  code stay English; rendered copy is always Norwegian.
- **Sentence case everywhere** (including headings). Exception:
  eyebrows in ALL CAPS with `letter-spacing: 0.14em`.
- **"Du"-form**, never "De".
- **Norwegian numerics.** Decimal comma, space thousand-separator,
  24-hour clock, lowercase weekdays.
- **No marketing slop.** No "velkommen til vår hjemmeside", no
  lorem, no "revolutionizing/empowering/seamless".

### Accessibility

- **WCAG AA** minimum for any user-picked bg+text pair. In PHP,
  that's `cb_best_contrast_text( $bg, $preferred, 4.5 )` from
  `includes/a11y-color.php`. In prototype HTML, pick directly from
  the palette.
- Focus rings: 2px `--accent` with 3px offset.

### Production code rules

- **Dynamic blocks only.** Never add `save.tsx` to an existing block.
- **Additive schema.** Never rename or remove block attributes; add
  new ones and deprecate old where needed.
- **Escape everything in PHP.** `esc_html`, `esc_attr`, `esc_url`,
  `wp_kses_post`. Inline styles go through `esc_attr`.
- **Theme colours** come from `theme.json` via
  `var(--wp--preset--color--<slug>, #hex-fallback)` — always
  include the fallback.
- **Build output is committed.** Edit `src/`, never `build/`. Run
  `pnpm build` before release.

---

## When in doubt

Ask. Don't guess tokens, don't substitute fonts, don't add a new
component pattern without checking `ui_kits/website/` to see if
something equivalent already exists.

For a walkthrough of how to re-skin this system for a new client,
see `design-system/README.md → Working with this brand` and
`SKILL.md → If the user invokes this skill without other guidance`.
