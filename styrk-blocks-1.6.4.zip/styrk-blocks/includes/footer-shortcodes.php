<?php
/**
 * Footer shortcodes — dynamic footer content from Settings → Footer / Header.
 *
 * [footer_logo]         → White logo for the footer
 * [footer_description]  → Company description
 * [footer_contact]      → Address, email, phones
 * [footer_copyright]    → Copyright line
 *
 * Social links are handled by [social_links] in styrk-blocks.php.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard — see header-settings.php for the rationale.
if ( defined( 'CB_FOOTER_SHORTCODES_LOADED' ) ) return;
define( 'CB_FOOTER_SHORTCODES_LOADED', true );

/**
 * [footer_logo] — outputs the white footer logo.
 *
 * Priority: Header Settings → logo_white_id → custom_logo → theme asset fallback.
 */
function cb_footer_logo_shortcode(): string {
	$header   = function_exists( 'cb_get_header_settings' ) ? cb_get_header_settings() : [];
	$site_name = get_bloginfo( 'name' );

	/* 1. White logo from Header Settings */
	$white_id = (int) ( $header['logo_white_id'] ?? 0 );
	if ( $white_id ) {
		$url = wp_get_attachment_image_url( $white_id, 'full' );
		if ( $url ) {
			return sprintf(
				'<a href="%s" class="site-footer__logo-link" aria-label="%s"><img src="%s" alt="%s" class="site-footer__logo-img" width="240" loading="lazy" /></a>',
				esc_url( home_url( '/' ) ),
				esc_attr( $site_name ),
				esc_url( $url ),
				esc_attr( $site_name )
			);
		}
	}

	/* 2. Main logo from Header Settings (with CSS invert) */
	$main_id = (int) ( $header['logo_id'] ?? 0 );
	if ( ! $main_id ) {
		$main_id = (int) get_theme_mod( 'custom_logo', 0 );
	}
	if ( $main_id ) {
		$url = wp_get_attachment_image_url( $main_id, 'full' );
		if ( $url ) {
			return sprintf(
				'<a href="%s" class="site-footer__logo-link" aria-label="%s"><img src="%s" alt="%s" class="site-footer__logo-img site-footer__logo-img--invert" width="240" loading="lazy" /></a>',
				esc_url( home_url( '/' ) ),
				esc_attr( $site_name ),
				esc_url( $url ),
				esc_attr( $site_name )
			);
		}
	}

	/* 3. Theme asset fallback — logo-hvit.svg */
	$fallback = get_theme_file_uri( 'assets/logo-hvit.svg' );
	return sprintf(
		'<a href="%s" class="site-footer__logo-link" aria-label="%s"><img src="%s" alt="%s" class="site-footer__logo-img" width="240" loading="lazy" /></a>',
		esc_url( home_url( '/' ) ),
		esc_attr( $site_name ),
		esc_url( $fallback ),
		esc_attr( $site_name )
	);
}
add_shortcode( 'footer_logo', 'cb_footer_logo_shortcode' );

/**
 * [footer_description] — outputs the company description.
 */
function cb_footer_description_shortcode(): string {
	$settings = cb_get_footer_settings();
	$desc     = $settings['description'] ?? '';

	if ( ! $desc ) {
		return '';
	}

	return '<p>' . esc_html( $desc ) . '</p>';
}
add_shortcode( 'footer_description', 'cb_footer_description_shortcode' );

/**
 * [footer_contact] — outputs address, email, and phone numbers.
 */
function cb_footer_contact_shortcode(): string {
	$s    = cb_get_footer_settings();
	$html = '';

	if ( ! empty( $s['address'] ) ) {
		$lines   = array_map( 'esc_html', explode( "\n", $s['address'] ) );
		$address = implode( '<br/>', $lines );
		$html   .= '<address class="site-footer__address">' . $address . '</address>';
	}

	$contact_lines = [];
	if ( ! empty( $s['email'] ) ) {
		$contact_lines[] = '<a href="mailto:' . esc_attr( $s['email'] ) . '">'
			. esc_html( $s['email'] ) . '</a>';
	}
	if ( ! empty( $s['phone_1'] ) ) {
		$tel = preg_replace( '/\s+/', '', $s['phone_1'] );
		$contact_lines[] = '<a href="tel:+47' . esc_attr( $tel ) . '">'
			. esc_html( $s['phone_1'] ) . '</a>';
	}
	if ( ! empty( $s['phone_2'] ) ) {
		$tel = preg_replace( '/\s+/', '', $s['phone_2'] );
		$contact_lines[] = '<a href="tel:+47' . esc_attr( $tel ) . '">'
			. esc_html( $s['phone_2'] ) . '</a>';
	}

	if ( $contact_lines ) {
		$html .= '<p class="site-footer__contact-info">'
			. implode( '<br/>', $contact_lines ) . '</p>';
	}

	return $html;
}
add_shortcode( 'footer_contact', 'cb_footer_contact_shortcode' );

/**
 * [footer_social_heading] — outputs the "Følg oss" heading (editable from Settings).
 *
 * Emits an <h2> so the column heading is part of the page heading outline —
 * lets screen-reader users navigate to the footer columns via heading nav.
 */
function cb_footer_social_heading_shortcode(): string {
	$settings = cb_get_footer_settings();
	$heading  = $settings['social_heading'] ?? 'Følg oss';

	if ( ! $heading ) {
		return '';
	}

	return '<h2 class="wp-block-heading site-footer__col-heading">' . esc_html( $heading ) . '</h2>';
}
add_shortcode( 'footer_social_heading', 'cb_footer_social_heading_shortcode' );

/**
 * [footer_copyright] — outputs the copyright text.
 */
function cb_footer_copyright_shortcode(): string {
	$settings  = cb_get_footer_settings();
	$copyright = $settings['copyright'] ?? '';

	if ( ! $copyright ) {
		return '';
	}

	return '<p>' . esc_html( $copyright ) . '</p>';
}
add_shortcode( 'footer_copyright', 'cb_footer_copyright_shortcode' );

/**
 * [footer_site_name] — outputs the site name as an <h2> footer-column heading.
 *
 * Matches the Kontakt / Følg oss heading levels so the footer has a
 * consistent <h2>-per-column heading outline.
 */
function cb_footer_site_name_shortcode(): string {
	return '<h2 class="wp-block-heading site-footer__col-heading">' . esc_html( get_bloginfo( 'name' ) ) . '</h2>';
}
add_shortcode( 'footer_site_name', 'cb_footer_site_name_shortcode' );

/**
 * [footer_credits] — outputs the credits line.
 * Editable from Settings → Footer → Bottom Bar → Credits.
 */
function cb_footer_credits_shortcode(): string {
	$settings = cb_get_footer_settings();
	$credits  = $settings['credits'] ?? '';
	if ( ! $credits ) return '';
	return '<p class="site-footer__credits">' . esc_html( $credits ) . '</p>';
}
add_shortcode( 'footer_credits', 'cb_footer_credits_shortcode' );

/**
 * [footer_legal] — outputs the inline legal-links nav (privacy, terms, etc).
 *
 * Reads the raw Settings → Footer → Legal Links textarea (one "Label|URL"
 * per line). Returns an empty string when no links are configured — the
 * bottom bar just collapses to copyright + credits on sites that don't
 * need a legal-nav row.
 *
 * URL handling:
 * - Relative URLs ("/personvern") are preserved as-is.
 * - Absolute URLs (https://…) are validated via esc_url so javascript:
 *   or data: schemes can't slip through.
 *
 * a11y: wraps the links in <nav aria-label="Juridisk"> so the links
 * register as a landmark for screen-reader users, distinct from the main
 * footer content.
 */
function cb_footer_legal_shortcode(): string {
	$settings = cb_get_footer_settings();
	$raw      = (string) ( $settings['legal_links'] ?? '' );
	if ( $raw === '' ) return '';

	$links = [];
	foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
		$line = trim( $line );
		if ( $line === '' ) continue;
		// Split on the first pipe only — labels may contain pipes, URLs
		// normally do not.
		$parts = explode( '|', $line, 2 );
		if ( count( $parts ) !== 2 ) continue;

		$label = trim( $parts[0] );
		$url   = trim( $parts[1] );
		if ( $label === '' || $url === '' ) continue;

		$links[] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $url ),
			esc_html( $label )
		);
	}

	if ( ! $links ) return '';

	return '<nav class="site-footer__legal" aria-label="' . esc_attr__( 'Juridisk', 'styrk-blocks' ) . '">'
		. implode( '', $links )
		. '</nav>';
}
add_shortcode( 'footer_legal', 'cb_footer_legal_shortcode' );
