<?php
/**
 * Footer Settings — admin page and helpers.
 *
 * Registers an options page under Settings → Footer where site admins
 * can manage company description, address, phone, email, copyright,
 * and the "follow us" column heading. Social links themselves are
 * managed via the social_link CPT (see styrk-blocks.php).
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard — see header-settings.php for the rationale.
if ( defined( 'CB_FOOTER_SETTINGS_LOADED' ) ) return;
define( 'CB_FOOTER_SETTINGS_LOADED', true );

/* ── Option key (all stored under one serialized option) ────────────────────── */
define( 'CB_FOOTER_OPTION', 'cb_footer_settings' );

/**
 * Default values for every footer field.
 */
function cb_footer_defaults(): array {
	$site_name = get_bloginfo( 'name' ) ?: 'Bedriftsnavn';
	return [
		'description'    => 'Kort beskrivelse av bedriften – én eller to setninger som forklarer hva dere gjør.',
		'address'        => "Gateadresse 1\n0000 Sted, Norge",
		'email'          => 'post@bedriftsnavn.no',
		'phone_1'        => '+47 00 00 00 00',
		'phone_2'        => '',
		'copyright'      => '© ' . gmdate( 'Y' ) . ' ' . $site_name . '. Alle rettigheter forbeholdt.',
		'social_heading' => 'Følg oss',
		'credits'        => 'Utvikling og design av Styrk Reklame AS',
		// One link per line, Label|URL format. Empty by default — legal
		// links only appear in the bottom bar when this field is filled.
		'legal_links'    => '',
	];
}

/**
 * Return merged (saved + defaults) footer settings.
 */
function cb_get_footer_settings(): array {
	$saved = get_option( CB_FOOTER_OPTION, [] );
	return wp_parse_args( $saved, cb_footer_defaults() );
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_footer_settings_menu(): void {
	add_options_page(
		__( 'Footer Settings', 'styrk-blocks' ),
		__( 'Footer', 'styrk-blocks' ),
		'manage_options',
		'cb-footer-settings',
		'cb_footer_settings_page'
	);
}
add_action( 'admin_menu', 'cb_footer_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

function cb_footer_settings_init(): void {
	register_setting( 'cb_footer_group', CB_FOOTER_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_footer_sanitize',
		'default'           => cb_footer_defaults(),
	] );

	/* ── Section: Company info ──────────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_company',
		__( 'Company Information', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Text shown in the first footer column, below the company name.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_description',
		__( 'Company Description', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_company',
		[ 'key' => 'description', 'type' => 'textarea' ]
	);

	/* ── Section: Contact details ───────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_contact',
		__( 'Contact Details', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Shown in the "Kontakt" footer column.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	$contact_fields = [
		'address' => [ 'label' => __( 'Address', 'styrk-blocks' ),  'type' => 'textarea' ],
		'email'   => [ 'label' => __( 'Email', 'styrk-blocks' ),    'type' => 'email' ],
		'phone_1' => [ 'label' => __( 'Phone 1', 'styrk-blocks' ),  'type' => 'tel' ],
		'phone_2' => [ 'label' => __( 'Phone 2', 'styrk-blocks' ),  'type' => 'tel' ],
	];

	foreach ( $contact_fields as $key => $field ) {
		add_settings_field(
			"cb_footer_{$key}",
			$field['label'],
			'cb_footer_render_field',
			'cb-footer-settings',
			'cb_footer_contact',
			[ 'key' => $key, 'type' => $field['type'] ]
		);
	}

	/* ── Section: Social / Følg oss ─────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_social',
		__( 'Social Media Column', 'styrk-blocks' ),
		'cb_footer_social_section_description',
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_social_heading',
		__( 'Column Heading', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_social',
		[ 'key' => 'social_heading', 'type' => 'text' ]
	);

	/* ── Section: Copyright ─────────────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_bottom',
		__( 'Bottom Bar', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'The small text shown at the very bottom of the footer.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_copyright',
		__( 'Copyright Text', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_bottom',
		[ 'key' => 'copyright', 'type' => 'text' ]
	);

	add_settings_field(
		'cb_footer_credits',
		__( 'Credits', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_bottom',
		[ 'key' => 'credits', 'type' => 'text' ]
	);

	add_settings_field(
		'cb_footer_legal_links',
		__( 'Legal Links', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_bottom',
		[
			'key'         => 'legal_links',
			'type'        => 'textarea',
			'description' => __(
				'One link per line, in the format "Label|URL". E.g.:<br><code>Personvern|/personvern</code><br><code>Informasjonskapsler|/informasjonskapsler</code><br>Leave empty to hide the legal-nav row.',
				'styrk-blocks'
			),
		]
	);
}
add_action( 'admin_init', 'cb_footer_settings_init' );

/**
 * Social section description — includes a link to manage social links.
 */
function cb_footer_social_section_description(): void {
	$social_url = admin_url( 'edit.php?post_type=social_link' );
	$add_url    = admin_url( 'post-new.php?post_type=social_link' );
	printf(
		'<p>%s</p><p><a href="%s" class="button">%s</a> &nbsp; <a href="%s" class="button button-primary">%s</a></p>',
		esc_html__( 'The social media icons are managed as individual posts. Use the links below to add or edit them.', 'styrk-blocks' ),
		esc_url( $social_url ),
		esc_html__( 'Manage Social Links', 'styrk-blocks' ),
		esc_url( $add_url ),
		esc_html__( '+ Add Social Link', 'styrk-blocks' )
	);
}

/* ── Field renderer ─────────────────────────────────────────────────────────── */

function cb_footer_render_field( array $args ): void {
	$settings    = cb_get_footer_settings();
	$key         = $args['key'];
	$type        = $args['type'];
	$description = $args['description'] ?? '';
	$value       = $settings[ $key ] ?? '';
	$name        = CB_FOOTER_OPTION . "[{$key}]";
	$id          = "cb_footer_{$key}";

	if ( $type === 'textarea' ) {
		printf(
			'<textarea id="%s" name="%s" rows="4" class="large-text" aria-label="%s">%s</textarea>',
			esc_attr( $id ),
			esc_attr( $name ),
			esc_attr( $key ),
			esc_textarea( $value )
		);
	} else {
		printf(
			'<input type="%s" id="%s" name="%s" value="%s" class="regular-text" aria-label="%s"/>',
			esc_attr( $type ),
			esc_attr( $id ),
			esc_attr( $name ),
			esc_attr( $value ),
			esc_attr( $key )
		);
	}

	if ( $description ) {
		// wp_kses_post allows the <br> + <code> tags used in the inline
		// help text without opening up arbitrary markup.
		printf( '<p class="description">%s</p>', wp_kses_post( $description ) );
	}
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

function cb_footer_sanitize( $input ): array {
	$defaults  = cb_footer_defaults();
	$sanitized = [];

	foreach ( $defaults as $key => $default ) {
		if ( ! isset( $input[ $key ] ) ) {
			$sanitized[ $key ] = $default;
			continue;
		}
		$sanitized[ $key ] = match ( $key ) {
			'email'   => sanitize_email( $input[ $key ] ),
			'address',
			'description',
			'legal_links' => sanitize_textarea_field( $input[ $key ] ),
			default       => sanitize_text_field( $input[ $key ] ),
		};
	}

	return $sanitized;
}

/* ── Page template ──────────────────────────────────────────────────────────── */

function cb_footer_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Footer Settings', 'styrk-blocks' ); ?></h1>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'cb_footer_group' );
			do_settings_sections( 'cb-footer-settings' );
			submit_button();
			?>
		</form>
	</div>
	<?php
}

/* ── Seed defaults on first activation ──────────────────────────────────────── */

function cb_footer_seed_defaults(): void {
	if ( get_option( CB_FOOTER_OPTION ) ) {
		return;
	}
	update_option( CB_FOOTER_OPTION, cb_footer_defaults() );
}
add_action( 'admin_init', 'cb_footer_seed_defaults' );
