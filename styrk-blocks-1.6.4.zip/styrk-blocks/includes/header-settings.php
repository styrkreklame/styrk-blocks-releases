<?php
/**
 * Header Settings — admin page for logo + header appearance.
 *
 * Settings → Header lets admins manage:
 *  - Logo uploads (main header logo + white footer variant)
 *  - Header background mode (transparent overlay or solid color)
 *  - Header background color (when solid)
 *  - Header text / nav link color
 *
 * On save, the main logo also updates the `custom_logo` theme mod
 * so wp:site-logo blocks work out of the box.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// File-level idempotency guard: if this file somehow gets included twice
// (symlink setups, mu-plugins double-load, etc.) the `function` declarations
// below would fatal with "Cannot redeclare". Bail early on the second include.
if ( defined( 'CB_HEADER_SETTINGS_LOADED' ) ) return;
define( 'CB_HEADER_SETTINGS_LOADED', true );

/* ── Option key ─────────────────────────────────────────────────────────────── */
define( 'CB_HEADER_OPTION', 'cb_header_settings' );

/**
 * Default values for header settings.
 */
function cb_header_defaults(): array {
	return [
		'logo_id'        => 0,              // attachment ID — main/color logo
		'logo_white_id'  => 0,              // attachment ID — white (footer) logo
		'bg_mode'        => 'transparent',  // 'transparent' | 'solid'
		'bg_color'       => '#00486A',      // solid background color
		'text_color'     => '#ffffff',      // header text / nav link color
	];
}

/**
 * Return merged (saved + defaults) header settings.
 */
function cb_get_header_settings(): array {
	$saved = get_option( CB_HEADER_OPTION, [] );
	return wp_parse_args( $saved, cb_header_defaults() );
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_header_settings_menu(): void {
	add_options_page(
		__( 'Header Settings', 'styrk-blocks' ),
		__( 'Header', 'styrk-blocks' ),
		'manage_options',
		'cb-header-settings',
		'cb_header_settings_page'
	);
}
add_action( 'admin_menu', 'cb_header_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

function cb_header_settings_init(): void {
	register_setting( 'cb_header_group', CB_HEADER_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_header_sanitize',
		'default'           => cb_header_defaults(),
	] );

	/* ── Section: Logos ──────────────────────────────────────────────────────── */
	add_settings_section(
		'cb_header_logos',
		__( 'Logos', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Upload your site logos. The main logo appears in the header; the white variant is used in the footer. SVG or PNG recommended.', 'styrk-blocks' )
		),
		'cb-header-settings'
	);

	add_settings_field(
		'cb_header_logo',
		__( 'Main Logo (header)', 'styrk-blocks' ),
		'cb_header_render_media_field',
		'cb-header-settings',
		'cb_header_logos',
		[ 'key' => 'logo_id', 'description' => __( 'Displayed in the site header. Use a white/light version if your header background is dark.', 'styrk-blocks' ) ]
	);

	add_settings_field(
		'cb_header_logo_white',
		__( 'White Logo (footer)', 'styrk-blocks' ),
		'cb_header_render_media_field',
		'cb-header-settings',
		'cb_header_logos',
		[ 'key' => 'logo_white_id', 'description' => __( 'White variant for the dark footer. Falls back to the theme asset if not set.', 'styrk-blocks' ) ]
	);

	/* ── Section: Appearance ─────────────────────────────────────────────────── */
	add_settings_section(
		'cb_header_appearance',
		__( 'Header Appearance', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Control how the header looks across the site. These settings apply globally.', 'styrk-blocks' )
		),
		'cb-header-settings'
	);

	add_settings_field(
		'cb_header_bg_mode',
		__( 'Background Mode', 'styrk-blocks' ),
		'cb_header_render_bg_mode_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_bg_color',
		__( 'Background Color', 'styrk-blocks' ),
		'cb_header_render_color_field',
		'cb-header-settings',
		'cb_header_appearance',
		[
			'key'         => 'bg_color',
			'description' => __( 'Used when Background Mode is set to "Solid color".', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_text_color',
		__( 'Text / Nav Color', 'styrk-blocks' ),
		'cb_header_render_color_field',
		'cb-header-settings',
		'cb_header_appearance',
		[
			'key'         => 'text_color',
			'description' => __( 'Color for the site name, navigation links, and hamburger icon.', 'styrk-blocks' ),
		]
	);
}
add_action( 'admin_init', 'cb_header_settings_init' );

/* ── Field renderers ────────────────────────────────────────────────────────── */

/**
 * Media uploader field (for logos).
 */
function cb_header_render_media_field( array $args ): void {
	$settings      = cb_get_header_settings();
	$key           = $args['key'];
	$attachment_id = (int) ( $settings[ $key ] ?? 0 );
	$name          = CB_HEADER_OPTION . "[{$key}]";
	$field_id      = "cb_header_{$key}";
	$preview_url   = $attachment_id ? wp_get_attachment_image_url( $attachment_id, 'medium' ) : '';
	$description   = $args['description'] ?? '';
	$bg            = $key === 'logo_white_id' ? '#00486A' : '#f0f0f1';

	?>
	<div class="cb-media-field" id="<?php echo esc_attr( $field_id ); ?>_wrapper">
		<div class="cb-media-preview" style="margin-bottom:10px;padding:16px;background:<?php echo esc_attr( $bg ); ?>;border-radius:8px;display:<?php echo $preview_url ? 'block' : 'none'; ?>;max-width:320px;">
			<img id="<?php echo esc_attr( $field_id ); ?>_preview" src="<?php echo esc_url( $preview_url ); ?>" alt="" style="max-width:100%;max-height:120px;width:auto;height:auto;display:block;" />
		</div>
		<input type="hidden" id="<?php echo esc_attr( $field_id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $attachment_id ); ?>" />
		<button type="button" class="button cb-upload-btn" data-target="<?php echo esc_attr( $field_id ); ?>" data-preview-bg="<?php echo esc_attr( $bg ); ?>">
			<?php echo $preview_url ? esc_html__( 'Change Logo', 'styrk-blocks' ) : esc_html__( 'Upload Logo', 'styrk-blocks' ); ?>
		</button>
		<?php if ( $preview_url ) : ?>
			<button type="button" class="button cb-remove-btn" data-target="<?php echo esc_attr( $field_id ); ?>" style="margin-left:8px;color:#b32d2e;">
				<?php esc_html_e( 'Remove', 'styrk-blocks' ); ?>
			</button>
		<?php endif; ?>
		<?php if ( $description ) : ?>
			<p class="description" style="margin-top:8px;"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Background mode radio buttons.
 */
function cb_header_render_bg_mode_field(): void {
	$settings = cb_get_header_settings();
	$current  = $settings['bg_mode'] ?? 'transparent';
	$name     = CB_HEADER_OPTION . '[bg_mode]';

	$options = [
		'transparent' => __( 'Transparent (overlays hero/content)', 'styrk-blocks' ),
		'solid'       => __( 'Solid color', 'styrk-blocks' ),
	];

	echo '<fieldset>';
	foreach ( $options as $value => $label ) {
		printf(
			'<label style="display:block;margin-bottom:8px;"><input type="radio" name="%s" value="%s" %s /> %s</label>',
			esc_attr( $name ),
			esc_attr( $value ),
			checked( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</fieldset>';
	echo '<p class="description">' . esc_html__( 'Transparent works best when the first block is a hero with a dark background image.', 'styrk-blocks' ) . '</p>';
}

/**
 * Color picker field.
 */
function cb_header_render_color_field( array $args ): void {
	$settings    = cb_get_header_settings();
	$key         = $args['key'];
	$value       = $settings[ $key ] ?? '';
	$name        = CB_HEADER_OPTION . "[{$key}]";
	$field_id    = "cb_header_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<input type="color" id="%s" name="%s" value="%s" style="width:60px;height:40px;padding:2px;border:1px solid #c3c4c7;border-radius:4px;cursor:pointer;" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_attr( $value )
	);
	printf(
		'<input type="text" id="%s_hex" value="%s" style="margin-left:8px;width:90px;font-family:monospace;" readonly />',
		esc_attr( $field_id ),
		esc_attr( $value )
	);

	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

function cb_header_sanitize( $input ): array {
	$defaults  = cb_header_defaults();
	$sanitized = [];

	/* Logos — integer IDs */
	$sanitized['logo_id']       = isset( $input['logo_id'] )       ? absint( $input['logo_id'] )       : $defaults['logo_id'];
	$sanitized['logo_white_id'] = isset( $input['logo_white_id'] ) ? absint( $input['logo_white_id'] ) : $defaults['logo_white_id'];

	/* Background mode — whitelist */
	$sanitized['bg_mode'] = isset( $input['bg_mode'] ) && in_array( $input['bg_mode'], [ 'transparent', 'solid' ], true )
		? $input['bg_mode']
		: $defaults['bg_mode'];

	/* Colors — must be valid hex */
	foreach ( [ 'bg_color', 'text_color' ] as $color_key ) {
		if ( isset( $input[ $color_key ] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $input[ $color_key ] ) ) {
			$sanitized[ $color_key ] = $input[ $color_key ];
		} else {
			$sanitized[ $color_key ] = $defaults[ $color_key ];
		}
	}

	/* Sync main logo to the custom_logo theme mod so wp:site-logo works */
	if ( ! empty( $sanitized['logo_id'] ) ) {
		set_theme_mod( 'custom_logo', $sanitized['logo_id'] );
	}

	return $sanitized;
}

/* ── Admin page template ────────────────────────────────────────────────────── */

function cb_header_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	wp_enqueue_media();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Header Settings', 'styrk-blocks' ); ?></h1>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'cb_header_group' );
			do_settings_sections( 'cb-header-settings' );
			submit_button();
			?>
		</form>
	</div>

	<script>
	(function($){
		'use strict';

		/* ── Media upload ───────────────────────────────────────────────────── */
		$(document).on('click', '.cb-upload-btn', function(e) {
			e.preventDefault();
			var btn      = $(this);
			var targetId = btn.data('target');
			var bgColor  = btn.data('preview-bg') || '#f0f0f1';
			var frame    = wp.media({
				title:    '<?php echo esc_js( __( 'Select Logo', 'styrk-blocks' ) ); ?>',
				button:   { text: '<?php echo esc_js( __( 'Use as Logo', 'styrk-blocks' ) ); ?>' },
				multiple: false,
				library:  { type: ['image', 'image/svg+xml'] }
			});

			frame.on('select', function() {
				var attachment = frame.state().get('selection').first().toJSON();
				var previewUrl = attachment.sizes && attachment.sizes.medium
					? attachment.sizes.medium.url
					: attachment.url;

				$('#' + targetId).val(attachment.id);
				$('#' + targetId + '_preview').attr('src', previewUrl);
				$('#' + targetId + '_wrapper .cb-media-preview')
					.css({ display: 'block', background: bgColor }).show();
				btn.text('<?php echo esc_js( __( 'Change Logo', 'styrk-blocks' ) ); ?>');

				if ( ! btn.siblings('.cb-remove-btn').length ) {
					$('<button type="button" class="button cb-remove-btn" data-target="' + targetId + '" style="margin-left:8px;color:#b32d2e;"><?php echo esc_js( __( 'Remove', 'styrk-blocks' ) ); ?></button>')
						.insertAfter(btn);
				}
			});
			frame.open();
		});

		$(document).on('click', '.cb-remove-btn', function(e) {
			e.preventDefault();
			var targetId = $(this).data('target');
			$('#' + targetId).val('0');
			$('#' + targetId + '_preview').attr('src', '');
			$('#' + targetId + '_wrapper .cb-media-preview').hide();
			$(this).siblings('.cb-upload-btn').text('<?php echo esc_js( __( 'Upload Logo', 'styrk-blocks' ) ); ?>');
			$(this).remove();
		});

		/* ── Sync color picker → hex text ───────────────────────────────────── */
		$('input[type="color"]').on('input change', function() {
			$('#' + this.id + '_hex').val(this.value);
		});
	})(jQuery);
	</script>
	<?php
}

/* ── Seed defaults on first load ────────────────────────────────────────────── */

function cb_header_seed_defaults(): void {
	if ( get_option( CB_HEADER_OPTION ) ) {
		return;
	}
	update_option( CB_HEADER_OPTION, cb_header_defaults() );
}
add_action( 'admin_init', 'cb_header_seed_defaults' );

/* ── Output header CSS vars to <head> ───────────────────────────────────────── */

function cb_header_output_css_vars(): void {
	$s = cb_get_header_settings();

	$bg_mode    = $s['bg_mode'] ?? 'transparent';
	$bg_color   = $s['bg_color'] ?? '#00486A';
	$text_color = $s['text_color'] ?? '#ffffff';

	$bg_value = $bg_mode === 'solid' ? $bg_color : 'transparent';

	printf(
		'<style id="cb-header-vars">:root{--cb-header-bg:%s;--cb-header-text:%s;--cb-header-bg-mode:%s;}</style>' . "\n",
		esc_attr( $bg_value ),
		esc_attr( $text_color ),
		esc_attr( $bg_mode )
	);
}
add_action( 'wp_head', 'cb_header_output_css_vars', 1 );
