<?php
/**
 * Search Settings — admin page for the search results hero + copy.
 *
 * Settings → Search lets admins manage the editable Norwegian copy
 * surfaced by `[styrk_search_results]` (see search-render.php):
 *  - Eyebrow text above the heading
 *  - Heading templates (with-query / no-query)
 *  - Empty-state copy
 *  - Form placeholder + button label
 *  - Number of results per page
 *
 * Deliberately content-only — no color or typography pickers. The
 * hero's visual style (navy bg, Fraunces display, orange accent)
 * comes from the design system tokens in theme.json + style.css and
 * applies globally. Per-instance styling controls would encourage
 * brand drift; copy-only keeps the page brand-locked.
 *
 * Mirrors the structure of header-settings.php / footer-settings.php
 * so the three "global" settings pages (Header, Footer, Search) stay
 * consistent under WP's Settings menu.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_SEARCH_SETTINGS_LOADED' ) ) return;
define( 'CB_SEARCH_SETTINGS_LOADED', true );

/* ── Option key ─────────────────────────────────────────────────────────────── */
define( 'CB_SEARCH_OPTION', 'cb_search_settings' );

/**
 * Default values for search settings. The {query} token in heading
 * and empty-line templates is replaced at render time with the
 * user's actual search term (already escaped).
 */
function cb_search_defaults(): array {
	return [
		'eyebrow_text'        => 'SØKERESULTATER',
		'heading_with_query'  => 'Søkeresultater for «{query}»',
		'heading_no_query'    => 'Søk på siden',
		'hint_no_query'       => 'Skriv et søkeord over for å finne sider, ansatte eller innlegg.',
		'empty_line'          => 'Ingen treff for «{query}».',
		'empty_hint'          => 'Sjekk stavemåten eller prøv et annet søkeord.',
		'empty_back_label'    => 'gå tilbake til forsiden',
		'form_placeholder'    => 'Søk på siden…',
		'form_button'         => 'Søk',
		'posts_per_page'      => 20,

	] + cb_search_default_color_slugs();
}

/**
 * Default theme-palette slugs for every search color setting. These are
 * filterable so child themes can ship sensible defaults that fit their
 * page background (e.g. Skotnes has a dark page body, so it filters in
 * 'surface' for text colors instead of the light-bg-default 'primary').
 *
 *   add_filter( 'styrk_blocks_search_default_colors', function( $defaults ) {
 *       $defaults['results_text']    = 'surface';
 *       $defaults['results_heading_color'] = 'surface';
 *       return $defaults;
 *   } );
 *
 * Plugin-side defaults assume a LIGHT page bg + a 4-slug palette
 * (primary, accent, surface, white) — the lowest common denominator
 * across our themes. Anything else is the child theme's job.
 */
function cb_search_default_color_slugs(): array {
	$defaults = [
		// Overlay (header dropdown — light card on translucent dark backdrop).
		'overlay_panel_bg'              => 'surface',
		'overlay_panel_text'            => 'primary',
		'overlay_panel_muted'           => 'primary',
		'overlay_panel_placeholder'     => 'primary',
		'overlay_icon_color'            => 'primary',
		'overlay_close_hover_bg'        => 'surface',
		'overlay_result_hover_bg'       => 'surface',
		'overlay_all_results_color'        => 'primary',
		'overlay_all_results_hover_color'  => 'primary',
		'overlay_all_results_hover_bg'     => 'surface',
		'overlay_backdrop_color'        => 'primary',
		'overlay_backdrop_opacity'      => 55,

		// Standalone results page (/?s=…) — assumes light page bg.
		'results_eyebrow_color'      => 'primary',
		'results_heading_color'      => 'primary',
		'results_text'               => 'primary',
		'results_muted'              => 'primary',
		'results_input_bg'           => 'surface',
		'results_input_text'         => 'primary',
		'results_input_border'       => 'primary',
		'results_link_hover'         => 'accent',
		'results_submit_bg'          => 'accent',
		'results_submit_text'        => 'white',
		'results_submit_hover_bg'    => 'primary',
	];
	return (array) apply_filters( 'styrk_blocks_search_default_colors', $defaults );
}

/**
 * Read the active theme's color palette from theme.json. Returns an array of
 * `[ slug, name, color ]` entries. This is the SINGLE source of truth for
 * what colors admins can pick in Settings → Search — there is no free-form
 * hex input, the picker is locked to brand swatches. To change what colors
 * appear, edit theme.json's `settings.color.palette`.
 */
function cb_get_theme_palette(): array {
	$palette = wp_get_global_settings( [ 'color', 'palette' ] );
	if ( isset( $palette['theme'] ) && is_array( $palette['theme'] ) ) {
		return $palette['theme'];
	}
	if ( isset( $palette['default'] ) && is_array( $palette['default'] ) ) {
		return $palette['default'];
	}
	if ( is_array( $palette ) && isset( $palette[0]['slug'] ) ) {
		return $palette;
	}
	return [];
}

/**
 * Resolve a saved color value (slug or legacy hex) to a CSS string suitable
 * for emitting into a custom property. Slugs become `var(--wp--preset--color--SLUG, HEX)`
 * with a hex fallback so the value remains valid even if the slug is later
 * removed from theme.json. Legacy hex values are passed through unchanged so
 * sites that haven't yet run the migration keep rendering.
 */
function cb_search_resolve_color_to_css( string $value, array $palette ): string {
	if ( $value === '' ) return 'transparent';
	if ( $value[0] === '#' ) return $value; // legacy hex
	$hex = '';
	foreach ( $palette as $entry ) {
		if ( ( $entry['slug'] ?? '' ) === $value ) {
			$hex = (string) ( $entry['color'] ?? '' );
			break;
		}
	}
	if ( $hex === '' ) return 'currentColor'; // unknown slug — safe inert fallback
	return "var(--wp--preset--color--{$value}, {$hex})";
}

/**
 * Resolve a saved color value to its raw hex (for server-side rgba composition,
 * e.g. the backdrop opacity slider). Returns empty string if unresolvable.
 */
function cb_search_resolve_color_to_hex( string $value, array $palette ): string {
	if ( $value === '' ) return '';
	if ( $value[0] === '#' ) return $value;
	foreach ( $palette as $entry ) {
		if ( ( $entry['slug'] ?? '' ) === $value ) {
			return (string) ( $entry['color'] ?? '' );
		}
	}
	return '';
}

/**
 * Return merged (saved + defaults) search settings.
 */
function cb_get_search_settings(): array {
	$saved = get_option( CB_SEARCH_OPTION, [] );
	return wp_parse_args( $saved, cb_search_defaults() );
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_search_settings_menu(): void {
	add_options_page(
		__( 'Search Settings', 'styrk-blocks' ),
		__( 'Search', 'styrk-blocks' ),
		'manage_options',
		'cb-search-settings',
		'cb_search_settings_page'
	);
}
add_action( 'admin_menu', 'cb_search_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

function cb_search_settings_init(): void {
	register_setting( 'cb_search_group', CB_SEARCH_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_search_sanitize',
		'default'           => cb_search_defaults(),
	] );

	/* ── Section: Heading & eyebrow ──────────────────────────────────────────── */
	add_settings_section(
		'cb_search_heading',
		__( 'Heading & eyebrow', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Copy shown in the navy hero band at the top of the search results page. Use {query} as a placeholder for the user\'s search term — it is replaced safely at render time.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_eyebrow_text', __( 'Eyebrow text', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'eyebrow_text', 'description' => __( 'Small all-caps label above the heading.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_heading_with_query', __( 'Heading (with query)', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'heading_with_query', 'description' => __( 'Shown when the visitor has a search term. Use {query} for the term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_heading_no_query', __( 'Heading (no query)', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'heading_no_query', 'description' => __( 'Shown when the visitor lands on /?s= with no term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_hint_no_query', __( 'Hint (no query)', 'styrk-blocks' ), 'cb_search_render_textarea_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'hint_no_query', 'description' => __( 'Helper paragraph below the heading when no term is entered yet.', 'styrk-blocks' ) ] );

	/* ── Section: Empty state ────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_empty',
		__( 'No-results state', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Copy shown when the search returns zero results. Keep it warm — visitors are mid-task.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_empty_line', __( 'Headline', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_line', 'description' => __( 'Use {query} for the searched term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_empty_hint', __( 'Hint', 'styrk-blocks' ), 'cb_search_render_textarea_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_hint', 'description' => __( 'Suggestion paragraph (without the home link — that is rendered separately).', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_empty_back_label', __( 'Back-to-home link label', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_back_label', 'description' => __( 'Visible label of the inline link back to the home page.', 'styrk-blocks' ) ] );

	/* ── Section: Search form ────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_form',
		__( 'Search form', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Strings shown inside the inline search-again form in the hero.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_form_placeholder', __( 'Input placeholder', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_form',
		[ 'key' => 'form_placeholder' ] );

	add_settings_field( 'cb_search_form_button', __( 'Button label', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_form',
		[ 'key' => 'form_button' ] );

	/* ── Section: Behaviour ──────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_behaviour',
		__( 'Behaviour', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Pagination size and other non-content options.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_posts_per_page', __( 'Results per page', 'styrk-blocks' ), 'cb_search_render_number_field', 'cb-search-settings', 'cb_search_behaviour',
		[ 'key' => 'posts_per_page', 'min' => 1, 'max' => 100, 'description' => __( 'How many hits to show per results page (1–100).', 'styrk-blocks' ) ] );

	/* ── Section: Overlay colors ───────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_overlay_colors',
		__( 'Overlay colors (header search dropdown)', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Colors used inside the search dropdown that opens when a visitor clicks the header search icon. Pick from the theme palette (defined in theme.json).', 'styrk-blocks' )
		),
		'cb-search-settings'
	);
	add_settings_field( 'cb_search_overlay_panel_bg', __( 'Panel background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_panel_bg', 'description' => __( 'Background of the white search card.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_panel_text', __( 'Panel text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_panel_text', 'description' => __( 'Text color for the input, status line and result titles inside the panel.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_panel_muted', __( 'Panel muted text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_panel_muted', 'description' => __( 'Secondary text inside the panel — type label, excerpts.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_panel_placeholder', __( 'Input placeholder', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_panel_placeholder', 'description' => __( 'Color of the placeholder text inside the search input.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_icon_color', __( 'Icon color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_icon_color', 'description' => __( 'Color of the magnifying-glass icon (left of the input) and the close button icon (right of the input).', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_close_hover_bg', __( 'Close button hover background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_close_hover_bg', 'description' => __( 'Tint shown behind the close button on hover/focus.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_result_hover_bg', __( 'Result row hover background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_result_hover_bg', 'description' => __( 'Background tint shown when a result row is hovered or keyboard-focused (arrow keys).', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_all_results_color', __( '"See all results" link color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_all_results_color', 'description' => __( 'Color of the "See all results for X →" link at the bottom of the dropdown.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_all_results_hover_color', __( '"See all results" hover text color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_all_results_hover_color', 'description' => __( 'Text color of the "See all results" link on hover/focus. Pick a slug that contrasts the hover background.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_all_results_hover_bg', __( '"See all results" hover background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_all_results_hover_bg', 'description' => __( 'Background tint behind the "See all results" link on hover/focus.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_backdrop_color', __( 'Backdrop color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_backdrop_color', 'description' => __( 'Color of the translucent layer behind the panel.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_backdrop_opacity', __( 'Backdrop opacity', 'styrk-blocks' ), 'cb_search_render_opacity_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_backdrop_opacity', 'description' => __( '0 = fully transparent, 100 = solid. The panel sits on top of this.', 'styrk-blocks' ) ] );

	/* ── Section: Results-page colors ──────────────────────────────────────────── */
	add_settings_section(
		'cb_search_results_colors',
		__( 'Results page colors', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Colors on the standalone search results page (/?s=…). Pick swatches that contrast the page background — choose lighter slugs (Surface / White) if the page body is dark.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);
	add_settings_field( 'cb_search_results_eyebrow_color', __( 'Eyebrow color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_eyebrow_color', 'description' => __( 'The small label above the heading ("SØKERESULTATER").', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_heading_color', __( 'Heading color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_heading_color', 'description' => __( 'The big H1 ("Søkeresultater for X"). Make sure it contrasts the page background.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_text', __( 'Body text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_text', 'description' => __( 'Hit titles + excerpts + empty-state copy.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_muted', __( 'Muted text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_muted', 'description' => __( 'Type chip, counts and helper copy.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_input_bg', __( 'Search input background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_input_bg' ] );
	add_settings_field( 'cb_search_results_input_text', __( 'Search input text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_input_text', 'description' => __( 'Text typed into the search field on the results page.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_input_border', __( 'Search input border', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_input_border' ] );
	add_settings_field( 'cb_search_results_submit_bg', __( 'Submit button background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_submit_bg' ] );
	add_settings_field( 'cb_search_results_submit_text', __( 'Submit button text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_submit_text' ] );
	add_settings_field( 'cb_search_results_submit_hover_bg', __( 'Submit button hover background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_submit_hover_bg', 'description' => __( 'Submit button background on hover/focus.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_link_hover', __( 'Hit title hover color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_link_hover' ] );
}
add_action( 'admin_init', 'cb_search_settings_init' );

/* ── Field renderers ────────────────────────────────────────────────────────── */

function cb_search_render_text_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<input type="text" id="%s" name="%s" value="%s" class="regular-text" style="max-width:520px;" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_attr( $value )
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

function cb_search_render_textarea_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<textarea id="%s" name="%s" rows="3" class="large-text" style="max-width:520px;">%s</textarea>',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_textarea( $value )
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/**
 * Render a theme-palette-only color picker. Admin sees brand swatches and
 * picks one — there is no rainbow wheel, no hex input, no "Default" escape
 * hatch. The choice is locked to slugs declared in theme.json. This is the
 * point: it must be impossible to introduce a non-brand color through this
 * UI, so the design system can't drift via the settings page.
 *
 * Selected state is driven by CSS (`:checked + .cb-swatch__chip`) so the
 * ring updates live as the admin clicks — not via a PHP-baked inline style
 * that only reflects the value at page load.
 */
function cb_search_render_color_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = (string) $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';
	$palette     = cb_get_theme_palette();

	if ( empty( $palette ) ) {
		printf(
			'<p class="description" style="color:#b32d2e;">%s</p>',
			esc_html__( 'No theme palette found. Add colors to theme.json → settings.color.palette to enable this picker.', 'styrk-blocks' )
		);
		// Fall back to a hidden input so the option isn't lost on save.
		printf( '<input type="hidden" name="%s" value="%s" />', esc_attr( $name ), esc_attr( $value ) );
		return;
	}

	echo '<fieldset class="cb-swatch-group">';
	foreach ( $palette as $entry ) {
		$slug    = (string) ( $entry['slug'] ?? '' );
		$name_l  = (string) ( $entry['name'] ?? $slug );
		$color   = (string) ( $entry['color'] ?? '#000' );
		if ( $slug === '' ) continue;
		$checked = $value === $slug ? 'checked' : '';
		$radio_id = $field_id . '-' . preg_replace( '/[^a-z0-9_-]/i', '', $slug );
		printf(
			'<label class="cb-swatch" for="%s" title="%s">'
			. '<input type="radio" id="%s" name="%s" value="%s" %s class="cb-swatch__input" />'
			. '<span class="cb-swatch__chip-wrap"><span aria-hidden="true" class="cb-swatch__chip" style="background:%s"></span></span>'
			. '<span class="cb-swatch__name">%s</span>'
			. '</label>',
			esc_attr( $radio_id ),
			esc_attr( $name_l ),
			esc_attr( $radio_id ),
			esc_attr( $name ),
			esc_attr( $slug ),
			$checked,
			esc_attr( $color ),
			esc_html( $name_l )
		);
	}
	echo '</fieldset>';

	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/**
 * Enqueue the admin CSS for the swatch picker. Only loads on the search
 * settings screen — no need to ship it everywhere in wp-admin.
 */
function cb_search_enqueue_admin_assets( $hook ): void {
	if ( $hook !== 'settings_page_cb-search-settings' ) return;
	wp_register_style( 'cb-search-admin', false, [], '0.9.1' );
	wp_enqueue_style( 'cb-search-admin' );
	wp_add_inline_style( 'cb-search-admin', <<<'CSS'
.cb-swatch-group {
	display: flex;
	flex-wrap: wrap;
	gap: 24px;
	margin: 0;
	padding: 0;
	border: 0;
}
/* Fixed width per swatch — keeps the row's geometry STABLE no matter
   which one is selected, no matter the name length, no matter the font
   weight. Hover/click never reflows the row.
   `!important` is required because wp-admin's forms.css ships:
       .form-table td fieldset label { margin: 0.35em 0 0.5em !important;
                                       display: inline-block; }
   which silently breaks flex layout. We need to win that fight. */
.form-table td fieldset .cb-swatch,
.cb-swatch {
	position: relative !important;
	display: inline-flex !important;
	flex-direction: column !important;
	align-items: center !important;
	gap: 16px !important;
	cursor: pointer;
	width: 96px;
	flex: 0 0 96px;
	margin: 0 !important;
	padding: 0;
	font-size: 12px;
	line-height: 1.3;
	text-align: center;
}
/* Hide the native radio off-screen but keep it focusable + form-submitable. */
.cb-swatch__input {
	position: absolute;
	width: 1px;
	height: 1px;
	margin: -1px;
	padding: 0;
	overflow: hidden;
	clip: rect(0, 0, 0, 0);
	border: 0;
	white-space: nowrap;
}
/* Chip sits in a 44×44 reserved cell so the hover scale + selected-ring
   never push outside their own slot, no neighbour movement. */
.cb-swatch__chip-wrap {
	width: 44px;
	height: 44px;
	display: flex;
	align-items: center;
	justify-content: center;
}
.cb-swatch__chip {
	display: block;
	width: 40px;
	height: 40px;
	border-radius: 8px;
	box-shadow: 0 0 0 1px rgba(0, 0, 0, 0.15);
	transition: box-shadow 0.12s ease, transform 0.12s ease;
}
.cb-swatch:hover .cb-swatch__chip {
	transform: scale(1.06);
	box-shadow: 0 0 0 2px rgba(34, 113, 177, 0.45);
}
.cb-swatch__input:checked ~ .cb-swatch__chip-wrap .cb-swatch__chip {
	box-shadow: 0 0 0 2px #2271b1, 0 0 0 4px #fff;
}
.cb-swatch__input:focus-visible ~ .cb-swatch__chip-wrap .cb-swatch__chip {
	box-shadow: 0 0 0 2px #2271b1, 0 0 0 4px #fff;
}
.cb-swatch__name {
	color: #50575e;
	width: 100%;
	word-break: break-word;
}
/* Selected = colour change only. NOT font-weight — bold widens letters
   which used to shift the rest of the row whenever the selection moved.
   The chip's ring already carries the "selected" signal loud and clear. */
.cb-swatch__input:checked ~ .cb-swatch__name {
	color: #2271b1;
}
CSS
	);
}
add_action( 'admin_enqueue_scripts', 'cb_search_enqueue_admin_assets' );

function cb_search_render_opacity_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (int) ( $settings[ $key ] ?? 0 );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<input type="range" id="%1$s" name="%2$s" value="%3$d" min="0" max="100" step="1" oninput="document.getElementById(\'%1$s-val\').textContent=this.value+\'%%\'" style="vertical-align:middle;width:240px;" />'
		. ' <output id="%1$s-val" style="margin-left:8px;font-variant-numeric:tabular-nums;">%3$d%%</output>',
		esc_attr( $field_id ),
		esc_attr( $name ),
		$value
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

function cb_search_render_number_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (int) ( $settings[ $key ] ?? 0 );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';
	$min         = (int) ( $args['min'] ?? 1 );
	$max         = (int) ( $args['max'] ?? 100 );

	printf(
		'<input type="number" id="%s" name="%s" value="%d" min="%d" max="%d" step="1" style="width:90px;" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		$value,
		$min,
		$max
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

function cb_search_sanitize( $input ): array {
	$defaults  = cb_search_defaults();
	$sanitized = [];

	$text_keys = [
		'eyebrow_text', 'heading_with_query', 'heading_no_query',
		'empty_line', 'empty_back_label', 'form_placeholder', 'form_button',
	];
	foreach ( $text_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) $input[ $k ] : '';
		$clean = sanitize_text_field( wp_unslash( $raw ) );
		$sanitized[ $k ] = $clean !== '' ? $clean : $defaults[ $k ];
	}

	$textarea_keys = [ 'hint_no_query', 'empty_hint' ];
	foreach ( $textarea_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) $input[ $k ] : '';
		$clean = sanitize_textarea_field( wp_unslash( $raw ) );
		$sanitized[ $k ] = $clean !== '' ? $clean : $defaults[ $k ];
	}

	$ppp = isset( $input['posts_per_page'] ) ? (int) $input['posts_per_page'] : $defaults['posts_per_page'];
	$sanitized['posts_per_page'] = max( 1, min( 100, $ppp ) );

	/* Color keys — slug-only. Each value must match a slug declared in the
	   active theme's theme.json palette. Anything else (legacy hex, junk,
	   slug for a color that's been removed from theme.json) falls back to
	   the default slug. This is the design-system lockdown. */
	$color_keys = [
		'overlay_panel_bg', 'overlay_panel_text', 'overlay_panel_muted',
		'overlay_panel_placeholder', 'overlay_icon_color',
		'overlay_close_hover_bg', 'overlay_result_hover_bg',
		'overlay_all_results_color', 'overlay_all_results_hover_color',
		'overlay_all_results_hover_bg',
		'overlay_backdrop_color',
		'results_eyebrow_color', 'results_heading_color',
		'results_text', 'results_muted',
		'results_input_bg', 'results_input_text', 'results_input_border',
		'results_submit_bg', 'results_submit_text', 'results_submit_hover_bg',
		'results_link_hover',
	];
	$palette        = cb_get_theme_palette();
	$valid_slugs    = array_column( $palette, 'slug' );
	foreach ( $color_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) wp_unslash( $input[ $k ] ) : '';
		$raw = trim( $raw );
		if ( in_array( $raw, $valid_slugs, true ) ) {
			$sanitized[ $k ] = $raw;
		} else {
			$sanitized[ $k ] = $defaults[ $k ];
		}
	}

	$op_raw = isset( $input['overlay_backdrop_opacity'] ) ? (int) $input['overlay_backdrop_opacity'] : $defaults['overlay_backdrop_opacity'];
	$sanitized['overlay_backdrop_opacity'] = max( 0, min( 100, $op_raw ) );

	return $sanitized;
}

/* ── Frontend CSS injector ──────────────────────────────────────────────────── */

/**
 * Emit a <style> block in <head> that publishes the configured colors as
 * CSS custom properties on :root. The theme's stylesheet reads these vars
 * (--cb-search-panel-bg, --cb-search-panel-text, etc.) so the admin's
 * picks become the live values without touching the stylesheet.
 */
function cb_search_emit_css_vars(): void {
	$s       = cb_get_search_settings();
	$palette = cb_get_theme_palette();

	// Compose the translucent backdrop from the slug's hex + 0–100 opacity.
	// Slug → hex lookup happens server-side so the rgba() string is fully
	// resolved (CSS can't natively turn `var(...)` into an rgba channel).
	$backdrop_hex = cb_search_resolve_color_to_hex( (string) $s['overlay_backdrop_color'], $palette );
	$bd           = ltrim( $backdrop_hex, '#' );
	if ( strlen( $bd ) === 3 ) {
		$bd = $bd[0] . $bd[0] . $bd[1] . $bd[1] . $bd[2] . $bd[2];
	}
	$r = strlen( $bd ) === 6 ? hexdec( substr( $bd, 0, 2 ) ) : 0;
	$g = strlen( $bd ) === 6 ? hexdec( substr( $bd, 2, 2 ) ) : 0;
	$b = strlen( $bd ) === 6 ? hexdec( substr( $bd, 4, 2 ) ) : 0;
	$a = number_format( ( (int) $s['overlay_backdrop_opacity'] ) / 100, 2, '.', '' );
	$backdrop_rgba = "rgba({$r},{$g},{$b},{$a})";

	// Map each setting key to its CSS-var name. Each value becomes
	// `var(--wp--preset--color--SLUG, HEX)` so the active theme.json palette
	// drives the live color, with a hex fallback for cache-misses.
	// Keys in $tint_pct emit at low alpha via color-mix() — hover tints need
	// to be translucent or they're indistinguishable from the panel they
	// sit on (e.g. surface hover on a surface panel = invisible).
	$mapping = [
		'overlay_panel_bg'              => '--cb-search-panel-bg',
		'overlay_panel_text'            => '--cb-search-panel-text',
		'overlay_panel_muted'           => '--cb-search-panel-muted',
		'overlay_panel_placeholder'     => '--cb-search-panel-placeholder',
		'overlay_icon_color'            => '--cb-search-icon-color',
		'overlay_close_hover_bg'        => '--cb-search-close-hover-bg',
		'overlay_result_hover_bg'       => '--cb-search-result-hover-bg',
		'overlay_all_results_color'        => '--cb-search-all-results-color',
		'overlay_all_results_hover_color'  => '--cb-search-all-results-hover-color',
		'overlay_all_results_hover_bg'     => '--cb-search-all-results-hover-bg',
		'results_eyebrow_color'         => '--cb-search-results-eyebrow',
		'results_heading_color'         => '--cb-search-results-heading',
		'results_text'                  => '--cb-search-results-text',
		'results_muted'                 => '--cb-search-results-muted',
		'results_input_bg'              => '--cb-search-results-input-bg',
		'results_input_text'            => '--cb-search-results-input-text',
		'results_input_border'          => '--cb-search-results-input-border',
		'results_submit_bg'             => '--cb-search-results-submit-bg',
		'results_submit_text'           => '--cb-search-results-submit-text',
		'results_submit_hover_bg'       => '--cb-search-results-submit-hover-bg',
		'results_link_hover'            => '--cb-search-results-link-hover',
	];
	$tint_pct = [
		'overlay_close_hover_bg'       => 8,
		'overlay_result_hover_bg'      => 8,
		'overlay_all_results_hover_bg' => 8,
	];

	$decls = [];
	foreach ( $mapping as $key => $var ) {
		$resolved = cb_search_resolve_color_to_css( (string) $s[ $key ], $palette );
		if ( isset( $tint_pct[ $key ] ) && $resolved !== 'transparent' && $resolved !== 'currentColor' ) {
			$pct      = (int) $tint_pct[ $key ];
			$resolved = "color-mix(in srgb, {$resolved} {$pct}%, transparent)";
		}
		$decls[] = $var . ':' . $resolved;
	}
	$decls[] = '--cb-search-backdrop-bg:' . $backdrop_rgba;

	// Baseline rules that read the vars emitted above. Shipped here in the
	// plugin (not the theme) so the search UI respects admin choices on
	// EVERY site, even when the active theme has stale CSS or a broad
	// `.cb-site-header a:hover { color: #fff !important; ... }` rule that
	// would otherwise repaint overlay anchors white on hover.
	//
	// !important + plain class specificity wins over equal-specificity
	// theme `!important` rules by declaration order — this <style> tag is
	// emitted at wp_head priority 100, after theme stylesheets.
	$rules = (
		// Standalone results page
		'.cb-search-page__eyebrow{color:var(--cb-search-results-eyebrow, var(--cb-search-results-muted, currentColor)) !important;}'
		. '.cb-search-page__heading{color:var(--cb-search-results-heading, var(--cb-search-results-text, currentColor)) !important;}'

		// Header dropdown — admin controls drive every interactive state.
		// `text-decoration: none` everywhere defeats the broad
		// `header a:hover { text-decoration: underline !important; }`
		// patterns common in themes.
		. '.rh-search-all{'
		.   'color:var(--cb-search-all-results-color, currentColor) !important;'
		.   'text-decoration:none !important;'
		. '}'
		. '.rh-search-all:hover,.rh-search-all:focus-visible{'
		.   'color:var(--cb-search-all-results-hover-color, var(--cb-search-all-results-color, currentColor)) !important;'
		.   'background:var(--cb-search-all-results-hover-bg, transparent) !important;'
		.   'text-decoration:none !important;'
		. '}'
		. '.rh-search-result,.rh-search-result:hover,.rh-search-result:focus-visible{'
		.   'text-decoration:none !important;'
		. '}'
		. '.rh-search-result.is-active,.rh-search-result:hover{'
		.   'background:var(--cb-search-result-hover-bg, transparent) !important;'
		. '}'
	);

	// ── Single-project page visibility floor ────────────────────────────────
	// The "Beskrivelse" eyebrow and the meta-strip values are rendered by
	// theme-side `the_content` filters that ship no colour API. On themes
	// where a broad cream/`color:inherit` rule turns these invisible on a
	// light body bg, force the brand palette via !important. NOT
	// admin-customizable yet — the block-conversion refactor planned for
	// the next release exposes per-element controls. Until then, these
	// rules guarantee these elements have legible contrast out of the box.
	$rules .= '.cb-project-body__eyebrow{'
		. 'color:var(--wp--preset--color--accent, currentColor) !important;'
		. '}'
		. '.cb-project-meta-strip dt{'
		. 'color:var(--wp--preset--color--accent, currentColor) !important;'
		. '}'
		. '.cb-project-meta-strip dd{'
		. 'color:var(--wp--preset--color--primary, currentColor) !important;'
		. '}';

	$css = ':root{' . implode( ';', $decls ) . ';}' . $rules;
	printf( '<style id="cb-search-vars">%s</style>', $css ); // values sanitized in cb_search_sanitize
}
// Priority 100 — runs AFTER theme stylesheets so equal-specificity
// `!important` rules in this <style> tag win the cascade.
add_action( 'wp_head', 'cb_search_emit_css_vars', 100 );

/* ── Admin page template ────────────────────────────────────────────────────── */

function cb_search_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) return;
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Search Settings', 'styrk-blocks' ); ?></h1>
		<p class="description" style="max-width:720px;">
			<?php esc_html_e( 'These strings appear on the /?s= search results page. Visual styling (navy hero, Fraunces display heading, orange button) comes from the design system and is intentionally not editable here — keep brand consistency.', 'styrk-blocks' ); ?>
		</p>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'cb_search_group' );
			do_settings_sections( 'cb-search-settings' );
			submit_button();
			?>
		</form>
	</div>
	<?php
}

/* ── Seed defaults on first load ────────────────────────────────────────────── */

function cb_search_seed_defaults(): void {
	if ( get_option( CB_SEARCH_OPTION ) ) return;
	update_option( CB_SEARCH_OPTION, cb_search_defaults() );
}
add_action( 'admin_init', 'cb_search_seed_defaults' );

/* ── One-shot migration: existing hex saves → palette slugs ─────────────────── */

/**
 * In v0.8.x the option store held hex strings (`#0F1B2D`). In v0.9.0 it
 * holds theme.json slugs (`primary`). This one-shot maps each saved hex to
 * the closest swatch in the active palette so admins don't lose their
 * configuration on upgrade. Runs once per site (flagged by
 * `cb_search_color_migration_v1`), and only when the palette is loadable
 * — if theme.json isn't ready yet (very early hook), it skips and retries
 * on the next admin_init.
 */
function cb_search_migrate_hex_to_slugs(): void {
	if ( get_option( 'cb_search_color_migration_v1' ) ) return;

	$saved = get_option( CB_SEARCH_OPTION );
	if ( ! is_array( $saved ) || empty( $saved ) ) {
		// Nothing to migrate — fresh install gets the slug defaults directly.
		update_option( 'cb_search_color_migration_v1', 1, false );
		return;
	}

	$palette = cb_get_theme_palette();
	if ( empty( $palette ) ) {
		// Theme.json not yet readable. Don't flag migrated — retry next request.
		return;
	}

	$defaults    = cb_search_defaults();
	$color_keys  = [
		'overlay_panel_bg', 'overlay_panel_text', 'overlay_panel_muted',
		'overlay_panel_placeholder', 'overlay_icon_color',
		'overlay_close_hover_bg', 'overlay_result_hover_bg',
		'overlay_all_results_color', 'overlay_all_results_hover_color',
		'overlay_all_results_hover_bg',
		'overlay_backdrop_color',
		'results_eyebrow_color', 'results_heading_color',
		'results_text', 'results_muted',
		'results_input_bg', 'results_input_text', 'results_input_border',
		'results_submit_bg', 'results_submit_text', 'results_submit_hover_bg',
		'results_link_hover',
	];
	$valid_slugs = array_column( $palette, 'slug' );

	foreach ( $color_keys as $k ) {
		if ( ! isset( $saved[ $k ] ) ) continue;
		$val = (string) $saved[ $k ];
		if ( in_array( $val, $valid_slugs, true ) ) continue; // already a slug
		if ( $val === '' || $val[0] !== '#' ) {
			// Junk value — reset to default slug.
			$saved[ $k ] = $defaults[ $k ];
			continue;
		}
		$nearest = cb_search_nearest_palette_slug( $val, $palette );
		$saved[ $k ] = $nearest ?: $defaults[ $k ];
	}

	update_option( CB_SEARCH_OPTION, $saved );
	update_option( 'cb_search_color_migration_v1', 1, false );
}
add_action( 'admin_init', 'cb_search_migrate_hex_to_slugs', 9 );

/**
 * Return the palette slug whose color is closest to the given hex via
 * Euclidean distance in RGB. Used by the v0.9.0 migration to map legacy
 * hex settings onto the active theme palette.
 */
function cb_search_nearest_palette_slug( string $hex, array $palette ): ?string {
	$target = cb_search_hex_to_rgb( $hex );
	if ( $target === null ) return null;

	$best_slug = null;
	$best_dist = PHP_FLOAT_MAX;
	foreach ( $palette as $entry ) {
		$rgb = cb_search_hex_to_rgb( (string) ( $entry['color'] ?? '' ) );
		if ( $rgb === null ) continue;
		$dr = $target[0] - $rgb[0];
		$dg = $target[1] - $rgb[1];
		$db = $target[2] - $rgb[2];
		$dist = $dr * $dr + $dg * $dg + $db * $db;
		if ( $dist < $best_dist ) {
			$best_dist = $dist;
			$best_slug = (string) ( $entry['slug'] ?? '' );
		}
	}
	return $best_slug ?: null;
}

function cb_search_hex_to_rgb( string $hex ): ?array {
	$h = ltrim( trim( $hex ), '#' );
	if ( strlen( $h ) === 3 ) {
		$h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
	}
	if ( strlen( $h ) !== 6 || ! ctype_xdigit( $h ) ) return null;
	return [
		hexdec( substr( $h, 0, 2 ) ),
		hexdec( substr( $h, 2, 2 ) ),
		hexdec( substr( $h, 4, 2 ) ),
	];
}
