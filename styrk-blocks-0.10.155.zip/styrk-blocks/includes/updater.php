<?php
/**
 * Self-hosted update channel for Styrk Blocks.
 *
 * Uses yahnis-elsts/plugin-update-checker in JSON-metadata mode. A
 * single public URL (the manifest) describes the current version and
 * where to download the zip. No GitHub tokens, no API auth — any site
 * that can reach the manifest URL can check for and install updates.
 *
 * Flow:
 *   Maintainer runs `pnpm run release:publish` → builds zip, writes
 *   manifest.json, uploads both to the public host.
 *   Client site's PUC pings the manifest ~every 12h, compares version,
 *   shows the standard WP "Update Now" badge if newer. User clicks,
 *   WP downloads the zip from `download_url` and installs in place.
 *
 * Per-site override (rarely needed — only for testing, staging, or a
 * customer with a mirrored host):
 *
 *     define( 'CB_UPDATE_MANIFEST_URL', 'https://your.host/path/manifest.json' );
 *
 * Set CB_UPDATE_MANIFEST_URL to '' to disable update checks entirely.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_UPDATER_LOADED' ) ) return;
define( 'CB_UPDATER_LOADED', true );

/**
 * Public URL of the JSON manifest describing available releases.
 * Must be reachable without auth from every site running this plugin.
 */
if ( ! defined( 'CB_UPDATE_MANIFEST_URL' ) ) {
	define( 'CB_UPDATE_MANIFEST_URL', 'https://raw.githubusercontent.com/styrkreklame/styrk-blocks-releases/main/manifest.json' );
}

/**
 * Ed25519 public key (raw 32 bytes, base64) for release signature verification.
 *
 * WHY THIS EXISTS
 * ---------------
 * The manifest and the zip both live in a PUBLIC repo that the release workflow
 * pushes to with a PAT. Anyone who obtains write access to that repo can replace
 * the zip — and WordPress on every client site will install it automatically,
 * as root-equivalent PHP, within ~12 hours. That is remote code execution across
 * the entire customer base from a single leaked token.
 *
 * A checksum in the manifest does NOT fix that: the attacker who replaces the
 * zip also replaces the checksum next to it. Only a signature made with a key
 * that is NOT in the releases repo does, which is what this verifies. The
 * matching private key lives solely in the styrk-blocks repo secret
 * STYRK_RELEASE_SIGNING_KEY.
 *
 * ROTATION: generate a new keypair, put the new public key here, ship that
 * release SIGNED WITH THE OLD KEY (so existing sites accept the update that
 * teaches them the new key), then swap the CI secret.
 */
if ( ! defined( 'CB_RELEASE_PUBLIC_KEY' ) ) {
	define( 'CB_RELEASE_PUBLIC_KEY', 'ca08+pOezSmyNFaX9lZC7yKdQsPb+gjVWZEC0xkrIJs=' );
}

if ( ! function_exists( 'cb_verify_release_signature' ) ) {
	/**
	 * Verify the Ed25519 signature of our own update package before WordPress
	 * unpacks it.
	 *
	 * Hooked to `upgrader_pre_download`, which is the last point where the
	 * package is still an opaque URL we control the fetching of. Returning a
	 * WP_Error here aborts the install cleanly, leaving the running plugin
	 * untouched; anything later (`upgrader_source_selection`) already has the
	 * archive expanded on disk.
	 *
	 * FAILS CLOSED. Every uncertain path — manifest unreachable, signature
	 * absent, sodium missing — refuses the install. A blocked auto-update is a
	 * visible inconvenience the admin can resolve by updating manually; an
	 * unverified auto-update is silent RCE. Only the "not our package" path
	 * hands control back untouched, so this never interferes with updates to
	 * WordPress core, themes, or anyone else's plugins.
	 *
	 * @param bool|WP_Error $reply      Short-circuit value from earlier filters.
	 * @param string        $package    Package URL being downloaded.
	 * @param \WP_Upgrader  $upgrader   Upgrader instance (unused).
	 * @param array         $hook_extra Context describing what is being updated.
	 * @return bool|string|WP_Error Local temp file path on success.
	 */
	function cb_verify_release_signature( $reply, $package, $upgrader = null, $hook_extra = array() ) {
		// Someone earlier already resolved (or rejected) this download.
		if ( false !== $reply ) {
			return $reply;
		}
		if ( ! is_string( $package ) || '' === $package ) {
			return $reply;
		}
		if ( '' === CB_UPDATE_MANIFEST_URL ) {
			return $reply;
		}

		// ── Is this ours? ────────────────────────────────────────────────────
		// Match on the plugin being updated when WP tells us, and fall back to
		// the package URL for flows that pass no hook_extra. Both are checked
		// because neither alone is reliable across bulk/single/auto updates.
		// Derived, not hardcoded: client installs occasionally sit in a renamed
		// directory, and a mismatch here would silently skip verification.
		$self       = plugin_basename( dirname( __DIR__ ) . '/styrk-blocks.php' );
		$is_ours    = false;
		$plugin_ctx = isset( $hook_extra['plugin'] ) ? (string) $hook_extra['plugin'] : '';
		if ( '' !== $plugin_ctx ) {
			$is_ours = ( $plugin_ctx === $self );
		} else {
			$manifest_base = trailingslashit( dirname( CB_UPDATE_MANIFEST_URL ) );
			$is_ours       = ( 0 === strpos( $package, $manifest_base ) );
		}
		if ( ! $is_ours ) {
			return $reply;
		}

		$fail = static function ( $message ) {
			return new \WP_Error(
				'cb_release_verification_failed',
				sprintf(
					/* translators: %s: reason the release could not be verified. */
					__( 'Styrk Blocks update blocked: %s Install was stopped and the current version is untouched. If this persists, download the plugin from the release channel and install it manually.', 'styrk-blocks' ),
					$message
				)
			);
		};

		if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
			return $fail( __( 'this server has no libsodium, so the release signature cannot be checked.', 'styrk-blocks' ) );
		}

		$public_key = base64_decode( CB_RELEASE_PUBLIC_KEY, true );
		if ( false === $public_key || 32 !== strlen( $public_key ) ) {
			return $fail( __( 'the bundled release public key is malformed.', 'styrk-blocks' ) );
		}

		// ── Signature comes from the manifest, fetched fresh ─────────────────
		// Deliberately re-fetched rather than read from PUC's cached transient:
		// the transient is writable by anything running on the site, so trusting
		// it would let a local foothold nominate its own signature.
		$response = wp_remote_get( CB_UPDATE_MANIFEST_URL, array( 'timeout' => 20 ) );
		if ( is_wp_error( $response ) ) {
			return $fail( $response->get_error_message() );
		}
		if ( 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			return $fail( __( 'the release manifest could not be fetched.', 'styrk-blocks' ) );
		}

		$manifest = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $manifest ) ) {
			return $fail( __( 'the release manifest is not valid JSON.', 'styrk-blocks' ) );
		}

		$alg = isset( $manifest['signature_alg'] ) ? (string) $manifest['signature_alg'] : '';
		if ( 'ed25519' !== $alg ) {
			return $fail( __( 'the release is signed with an unsupported algorithm.', 'styrk-blocks' ) );
		}

		$signature = isset( $manifest['signature'] ) ? base64_decode( (string) $manifest['signature'], true ) : false;
		if ( false === $signature || 64 !== strlen( $signature ) ) {
			return $fail( __( 'the release is unsigned or its signature is malformed.', 'styrk-blocks' ) );
		}

		// The manifest must be describing the very file WP is about to fetch.
		// Without this, a stale or swapped download_url could be paired with a
		// valid signature for a different build.
		$expected_url = isset( $manifest['download_url'] ) ? (string) $manifest['download_url'] : '';
		if ( '' === $expected_url || untrailingslashit( $expected_url ) !== untrailingslashit( $package ) ) {
			return $fail( __( 'the download URL does not match the signed release.', 'styrk-blocks' ) );
		}

		// ── Fetch, then verify the bytes ─────────────────────────────────────
		if ( ! function_exists( 'download_url' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}
		$tmp = download_url( $package );
		if ( is_wp_error( $tmp ) ) {
			return $tmp;
		}

		$bytes = file_get_contents( $tmp ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- local temp file, not a remote fetch.
		if ( false === $bytes ) {
			wp_delete_file( $tmp );
			return $fail( __( 'the downloaded package could not be read.', 'styrk-blocks' ) );
		}

		if ( ! sodium_crypto_sign_verify_detached( $signature, $bytes, $public_key ) ) {
			// Delete before returning: leaving a rejected archive in the temp
			// dir invites a later step from picking it up.
			wp_delete_file( $tmp );
			return $fail( __( 'the package signature is INVALID — the download does not match what Styrk Reklame published.', 'styrk-blocks' ) );
		}

		// Verified. Hand WP the local path it would otherwise have fetched.
		return $tmp;
	}
}

// Registered unconditionally — NOT inside the plugins_loaded guard below.
// That guard disables update *checks* on local/symlinked installs, but if an
// install is ever attempted here anyway it must still be verified.
add_filter( 'upgrader_pre_download', 'cb_verify_release_signature', 10, 4 );

add_action( 'plugins_loaded', function () {
	if ( CB_UPDATE_MANIFEST_URL === '' ) return;

	// ── Dev safety net ──────────────────────────────────────────────────────
	// NEVER run the updater from a symlinked install or a local environment.
	// On a dev box the plugin is symlinked to the working source; WordPress'
	// updater follows the symlink on "Update" and recursively DELETES the
	// source (incl. .git and any sibling theme). Production installs are real
	// directories, so they are unaffected. This makes the "oops I clicked
	// Update on local" footgun impossible on every site, with no per-site
	// config and nothing to remember.
	$self_dir = WP_PLUGIN_DIR . '/' . basename( dirname( __DIR__ ) );
	$is_symlinked = is_link( $self_dir ) || is_link( dirname( __DIR__ ) );
	$is_local_env = function_exists( 'wp_get_environment_type' )
		&& in_array( wp_get_environment_type(), [ 'local', 'development' ], true );
	if ( $is_symlinked || $is_local_env ) {
		return;
	}

	$vendor_path = dirname( __DIR__ ) . '/vendor/yahnis-elsts/plugin-update-checker/plugin-update-checker.php';
	$manual_path = dirname( __DIR__ ) . '/lib/plugin-update-checker/plugin-update-checker.php';

	if ( file_exists( $vendor_path ) ) {
		require_once $vendor_path;
	} elseif ( file_exists( $manual_path ) ) {
		require_once $manual_path;
	} else {
		// Library not bundled — plugin still works, just no auto-update.
		return;
	}

	if ( ! class_exists( '\\YahnisElsts\\PluginUpdateChecker\\v5\\PucFactory' ) ) {
		return;
	}

	$factory = '\\YahnisElsts\\PluginUpdateChecker\\v5\\PucFactory';
	$factory::buildUpdateChecker(
		CB_UPDATE_MANIFEST_URL,
		dirname( __DIR__ ) . '/styrk-blocks.php',
		'styrk-blocks'
	);
} );
