<?php
/**
 * Skip link: move keyboard focus into the content, on every site.
 *
 * WordPress's block-theme skip link ("Hopp til innhold") only jumps to the
 * #wp--skip-link--target hash. Safari scrolls there but leaves focus at the
 * top, so the next Tab goes back into the header; and browsers only activate
 * links on Enter, so Space just scrolled the page. Focusing the target
 * directly fixes both (click, Enter and Space) and keeps the URL clean.
 *
 * Fixed once in a single client theme first; it belongs here so every site
 * running Styrk Blocks gets it.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'cb_skip_link_focus_script' ) ) {
	function cb_skip_link_focus_script(): void {
		if ( is_admin() ) {
			return;
		}
		echo "<script>(function(){function go(e){var a=e.target&&e.target.closest&&e.target.closest('#wp-skip-link');if(!a)return;var t=document.getElementById((a.getAttribute('href')||'').slice(1));if(!t)return;e.preventDefault();t.setAttribute('tabindex','-1');t.focus({preventScroll:true});t.scrollIntoView();}document.addEventListener('click',go);document.addEventListener('keydown',function(e){if(e.key===' '||e.key==='Spacebar')go(e);});})();</script>\n";
	}
	add_action( 'wp_footer', 'cb_skip_link_focus_script' );
}

if ( ! function_exists( 'cb_skip_link_target_style' ) ) {
	/* The target takes focus only so the next Tab starts inside the content;
	   it is not a control, so no ring around the whole page. */
	function cb_skip_link_target_style(): void {
		if ( is_admin() ) {
			return;
		}
		echo "<style id=\"cb-skip-link-target\">#wp--skip-link--target[tabindex=\"-1\"]:focus,main[tabindex=\"-1\"]:focus{outline:none!important;box-shadow:none!important;}</style>\n";
	}
	add_action( 'wp_head', 'cb_skip_link_target_style', 100 );
}
