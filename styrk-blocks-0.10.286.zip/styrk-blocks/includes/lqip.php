<?php
/**
 * Blur-up image placeholders (LQIP).
 *
 * WordPress renders pages on the server, but images arrive after first paint,
 * so every image slot sat empty until its bytes landed. Each attachment now
 * gets a ~16px JPEG copy of itself (a few hundred bytes), stored in post meta
 * and inlined as the <img>'s own CSS background. The browser upscales it into
 * a soft blur the moment the HTML paints; the real image then paints over it.
 * No wrapper markup, no layout change.
 *
 * An image shown with `object-fit: contain` (or scale-down / none) does not
 * fill its box, so the blur would stay visible around it for good. Each
 * placeholder is marked `data-lqip`, and a tiny inline script in <head>
 * drops the placeholder from such images once they have loaded and decoded.
 * Images that fill their box keep it: there it is fully covered anyway, and
 * removing it could flash an empty frame.
 *
 * Transparent images (logos, icons) get no placeholder: the blur would show
 * through their transparent areas forever.
 *
 * Placeholders are generated on upload and, for older media, lazily on first
 * render (capped per request) or in bulk with `wp styrk lqip`.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'CB_LQIP_META' ) ) {
	define( 'CB_LQIP_META', '_cb_lqip' );
}

if ( ! function_exists( 'cb_lqip_from_file' ) ) {
	/**
	 * Build a placeholder data URI from an image file.
	 *
	 * @param string $path Absolute path to an image.
	 * @return string `data:image/jpeg;base64,…`, or '' when the image is
	 *                unreadable or has transparency.
	 */
	function cb_lqip_from_file( string $path ): string {
		if ( ! function_exists( 'imagecreatefromstring' ) || ! is_readable( $path ) ) {
			return '';
		}
		$bytes = (string) file_get_contents( $path );
		$src   = '' === $bytes ? false : @imagecreatefromstring( $bytes ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged -- non-images return false; the warning is noise.
		if ( ! $src ) {
			return '';
		}

		$w = imagesx( $src );
		$h = imagesy( $src );
		$tw = 16;
		$th = max( 1, (int) round( $h * $tw / max( 1, $w ) ) );

		$tiny = imagecreatetruecolor( $tw, $th );
		imagealphablending( $tiny, false );
		imagesavealpha( $tiny, true );
		imagecopyresampled( $tiny, $src, 0, 0, 0, 0, $tw, $th, $w, $h );

		// Any transparent pixel → no placeholder.
		for ( $y = 0; $y < $th; $y++ ) {
			for ( $x = 0; $x < $tw; $x++ ) {
				if ( ( ( imagecolorat( $tiny, $x, $y ) >> 24 ) & 0x7F ) > 0 ) {
					return '';
				}
			}
		}

		ob_start();
		imagejpeg( $tiny, null, 50 );
		return 'data:image/jpeg;base64,' . base64_encode( (string) ob_get_clean() );
	}
}

if ( ! function_exists( 'cb_lqip_normalize_src' ) ) {
	/**
	 * Map a (possibly resized) upload URL back to its full-size URL.
	 *
	 * @param string $src Image URL as rendered.
	 * @return string
	 */
	function cb_lqip_normalize_src( string $src ): string {
		$src = (string) preg_replace( '/[?#].*$/', '', $src );
		return (string) preg_replace( '/-\d+x\d+(\.[a-z0-9]+)$/i', '$1', $src );
	}
}

if ( ! function_exists( 'cb_lqip_src_candidates' ) ) {
	/**
	 * Full-size URLs an image may be stored under. Uploads over the big-image
	 * threshold are stored as "<name>-scaled.<ext>".
	 *
	 * @param string $full Normalised full-size URL.
	 * @return string[]
	 */
	function cb_lqip_src_candidates( string $full ): array {
		if ( preg_match( '/-scaled\.[a-z0-9]+$/i', $full ) ) {
			return [ $full ];
		}
		return [ $full, (string) preg_replace( '/(\.[a-z0-9]+)$/i', '-scaled$1', $full ) ];
	}
}

if ( ! function_exists( 'cb_lqip_merge_style' ) ) {
	/**
	 * Append the placeholder background to an inline style.
	 *
	 * @param string|null $style Existing style attribute value, or null.
	 * @param string      $uri   Placeholder data URI.
	 * @return string|null New style, or null when the author already set a
	 *                     background (leave it alone).
	 */
	function cb_lqip_merge_style( ?string $style, string $uri ): ?string {
		if ( null !== $style && preg_match( '/background(-image)?\s*:/i', $style ) ) {
			return null;
		}
		$bg = 'background-image:url(' . $uri . ');background-size:cover;background-position:center';
		$style = null === $style ? '' : rtrim( trim( $style ), ';' );
		return '' === $style ? $bg : $style . ';' . $bg;
	}
}

if ( ! function_exists( 'cb_lqip_apply_to_html' ) ) {
	/**
	 * Add each <img>'s placeholder as its inline background.
	 *
	 * @param string   $html    Rendered markup.
	 * @param callable $resolve fn( ?int $attachment_id, string $full_size_src ): string data URI or ''.
	 * @return string
	 */
	function cb_lqip_apply_to_html( string $html, callable $resolve ): string {
		if ( false === stripos( $html, '<img' ) ) {
			return $html;
		}
		return (string) preg_replace_callback(
			'/<img\b[^>]*>/i',
			static function ( array $m ) use ( $resolve ): string {
				$tag = $m[0];
				$attr = static function ( string $name ) use ( $tag ): ?string {
					return preg_match( '/\s' . $name . '\s*=\s*(["\'])(.*?)\1/is', $tag, $a ) ? $a[2] : null;
				};

				$style = $attr( 'style' );
				if ( null !== $style && null === cb_lqip_merge_style( $style, 'data:' ) ) {
					return $tag; // The author set a background; keep it.
				}

				$id = null;
				if ( preg_match( '/\bwp-image-(\d+)\b/', (string) $attr( 'class' ), $c ) ) {
					$id = (int) $c[1];
				} elseif ( ctype_digit( (string) $attr( 'data-id' ) ) ) {
					$id = (int) $attr( 'data-id' );
				}

				$uri = (string) $resolve( $id, cb_lqip_normalize_src( (string) $attr( 'src' ) ) );
				if ( '' === $uri || 0 !== strpos( $uri, 'data:image/' ) ) {
					return $tag;
				}

				$merged = (string) cb_lqip_merge_style( $style, $uri );
				$tag    = (string) preg_replace( '/^<img\b/i', '<img data-lqip', $tag );
				if ( null === $style ) {
					return (string) preg_replace( '/^<img\b/i', '<img style="' . $merged . '"', $tag );
				}
				return (string) preg_replace(
					'/(\sstyle\s*=\s*)(["\'])(.*?)\2/is',
					'$1$2' . str_replace( '$', '\$', $merged ) . '$2',
					$tag,
					1
				);
			},
			$html
		);
	}
}

if ( ! function_exists( 'cb_lqip_for_attachment' ) ) {
	/**
	 * Placeholder for an attachment, generating (and caching) it if missing.
	 *
	 * @param int        $id       Attachment ID.
	 * @param bool       $generate Generate when missing.
	 * @param array|null $meta     Attachment metadata, when not saved yet (upload).
	 * @return string Data URI or ''.
	 */
	function cb_lqip_for_attachment( int $id, bool $generate = true, ?array $meta = null ): string {
		$stored = get_post_meta( $id, CB_LQIP_META, true );
		if ( 'none' === $stored ) {
			return '';
		}
		if ( is_string( $stored ) && 0 === strpos( $stored, 'data:image/' ) ) {
			return $stored;
		}
		if ( ! $generate || ! wp_attachment_is_image( $id ) ) {
			return '';
		}
		// The smallest generated size is plenty to sample 16px from, and far
		// cheaper to decode than a multi-megapixel original.
		$file = get_attached_file( $id );
		$meta = $meta ?? wp_get_attachment_metadata( $id );
		// Medium keeps the aspect ratio (thumbnail is a square crop).
		if ( $file && ! empty( $meta['sizes']['medium']['file'] ) ) {
			$medium = path_join( dirname( $file ), $meta['sizes']['medium']['file'] );
			if ( is_readable( $medium ) ) {
				$file = $medium;
			}
		}
		$uri = $file ? cb_lqip_from_file( $file ) : '';
		update_post_meta( $id, CB_LQIP_META, '' === $uri ? 'none' : $uri );
		return $uri;
	}
}

if ( ! function_exists( 'cb_lqip_resolve' ) ) {
	/**
	 * Resolver used on the front end: by ID, else by URL; lazy generation is
	 * capped per request so a page full of old media cannot stall a render.
	 *
	 * @param int|null $id  Attachment ID from the markup, if any.
	 * @param string   $src Full-size URL.
	 * @return string
	 */
	function cb_lqip_resolve( ?int $id, string $src ): string {
		static $by_src   = [];
		static $budget   = 12;

		if ( null === $id && '' !== $src ) {
			if ( ! array_key_exists( $src, $by_src ) ) {
				$by_src[ $src ] = 0;
				foreach ( cb_lqip_src_candidates( $src ) as $candidate ) {
					$by_src[ $src ] = (int) attachment_url_to_postid( $candidate );
					if ( $by_src[ $src ] ) {
						break;
					}
				}
			}
			$id = $by_src[ $src ] ?: null;
		}
		if ( null === $id ) {
			return '';
		}
		$uri = cb_lqip_for_attachment( $id, false );
		if ( '' === $uri && $budget > 0 && '' === (string) get_post_meta( $id, CB_LQIP_META, true ) ) {
			$budget--;
			$uri = cb_lqip_for_attachment( $id, true );
		}
		return $uri;
	}
}

if ( ! function_exists( 'cb_lqip_clear_script' ) ) {
	/**
	 * Inline script that removes the placeholder from loaded images that do
	 * not fill their box (object-fit contain / scale-down / none), where the
	 * blur would otherwise stay visible around the photo. A capturing `load`
	 * listener on document sees every <img> load, including lazy ones.
	 *
	 * @return string JavaScript source.
	 */
	function cb_lqip_clear_script(): string {
		return "document.addEventListener('load',function(e){var i=e.target,f;"
			. "if(!i||i.tagName!=='IMG'||!i.hasAttribute('data-lqip'))return;"
			. "f=getComputedStyle(i).objectFit;if(f==='fill'||f==='cover')return;"
			. "(i.decode?i.decode():Promise.resolve()).catch(function(){}).then(function(){"
			. "i.style.removeProperty('background-image');i.removeAttribute('data-lqip');});},true);";
	}
}

// In <head>, before any <img> in the body can fire its load event.
add_action(
	'wp_head',
	static function () {
		if ( is_admin() ) {
			return;
		}
		wp_print_inline_script_tag( cb_lqip_clear_script() );
	},
	1
);

add_filter(
	'render_block',
	static function ( $html, $block ) {
		if ( is_admin() || ! is_string( $html ) ) {
			return $html;
		}
		$name = (string) ( $block['blockName'] ?? '' );
		if ( 0 !== strpos( $name, 'styrk-blocks/' ) && ! in_array( $name, [ 'core/image', 'core/gallery', 'core/media-text', 'core/post-featured-image' ], true ) ) {
			return $html;
		}
		return cb_lqip_apply_to_html( $html, 'cb_lqip_resolve' );
	},
	20,
	2
);

// Images rendered through wp_get_attachment_image() (templates, theme,
// featured images) carry their ID, so no URL lookup is needed.
add_filter(
	'wp_get_attachment_image_attributes',
	static function ( $attr, $attachment ) {
		if ( is_admin() || ! is_array( $attr ) || ! isset( $attachment->ID ) ) {
			return $attr;
		}
		$uri = cb_lqip_resolve( (int) $attachment->ID, '' );
		if ( '' !== $uri ) {
			$style = cb_lqip_merge_style( $attr['style'] ?? null, $uri );
			if ( null !== $style ) {
				$attr['style']     = $style;
				$attr['data-lqip'] = '';
			}
		}
		return $attr;
	},
	20,
	2
);

// New uploads (and regenerated thumbnails) get their placeholder as soon as
// their sizes exist. The metadata is not saved yet here, so pass it along.
add_filter(
	'wp_generate_attachment_metadata',
	static function ( $metadata, $attachment_id ) {
		delete_post_meta( (int) $attachment_id, CB_LQIP_META );
		cb_lqip_for_attachment( (int) $attachment_id, true, is_array( $metadata ) ? $metadata : null );
		return $metadata;
	},
	20,
	2
);

if ( defined( 'WP_CLI' ) && WP_CLI && class_exists( 'WP_CLI' ) ) {
	/**
	 * Generate blur-up placeholders for existing images.
	 *
	 * ## OPTIONS
	 *
	 * [--force]
	 * : Regenerate placeholders that already exist.
	 */
	WP_CLI::add_command(
		'styrk lqip',
		static function ( $args, $assoc ) {
			$ids   = get_posts( [ 'post_type' => 'attachment', 'post_mime_type' => 'image', 'post_status' => 'inherit', 'fields' => 'ids', 'posts_per_page' => -1 ] );
			$made  = 0;
			$none  = 0;
			foreach ( $ids as $id ) {
				if ( ! empty( $assoc['force'] ) ) {
					delete_post_meta( $id, CB_LQIP_META );
				}
				'' === cb_lqip_for_attachment( (int) $id, true ) ? $none++ : $made++;
			}
			WP_CLI::success( sprintf( '%d placeholders, %d images skipped (transparent or unreadable).', $made, $none ) );
		}
	);
}
