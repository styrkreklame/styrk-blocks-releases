<?php
/**
 * Search colours: find text / surface pairs that cannot be read.
 *
 * Settings → Search lets an admin choose a palette colour for a text and,
 * separately, for the surface it sits on. Nothing stopped a cream label on
 * an amber button. cb_search_contrast_conflicts() lists every such pair
 * (WCAG AA, 4.5:1) together with a readable replacement; the settings page
 * shows the list, and the front end renders the replacement.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_search_contrast_pairs' ) ) {
	/**
	 * Text setting → the surface setting it is drawn on, with a label.
	 *
	 * @return array<int,array{0:string,1:string,2:string}>
	 */
	function cb_search_contrast_pairs(): array {
		return [
			[ 'results_input_text', 'results_input_bg', __( 'Results page: text in the search field', 'styrk-blocks' ) ],
			[ 'results_submit_text', 'results_submit_bg', __( 'Results page: text on the "Search" button', 'styrk-blocks' ) ],
			[ 'overlay_panel_text', 'overlay_panel_bg', __( 'Search panel: text', 'styrk-blocks' ) ],
			[ 'overlay_all_results_color', 'overlay_panel_bg', __( 'Search panel: the "See all results" link', 'styrk-blocks' ) ],
			// The results page header band is always the primary colour (not a
			// setting), so '@hero' stands for it. Without these pairs a primary
			// heading sat invisibly on the primary band.
			[ 'results_eyebrow', '@hero', __( 'Results page: the eyebrow above the heading', 'styrk-blocks' ) ],
			[ 'results_heading', '@hero', __( 'Results page: the heading', 'styrk-blocks' ) ],
		];
	}
}

if ( ! function_exists( 'cb_search_contrast_conflicts' ) ) {
	/**
	 * Pairs under 4.5:1.
	 *
	 * @param array    $settings Resolved search settings (colour slugs or hex).
	 * @param callable $to_hex   fn( string $value ): string — hex, or '' if unknown.
	 * @return array<int,array{key:string,bg_key:string,label:string,fg:string,bg:string,ratio:float,safe:string}>
	 */
	function cb_search_contrast_conflicts( array $settings, callable $to_hex ): array {
		$out = [];
		foreach ( cb_search_contrast_pairs() as [ $fg_key, $bg_key, $label ] ) {
			$fg = (string) $to_hex( (string) ( $settings[ $fg_key ] ?? '' ) );
			$bg = (string) $to_hex( '@hero' === $bg_key ? 'primary' : (string) ( $settings[ $bg_key ] ?? '' ) );
			// An unknown colour is not guessed at.
			if ( ! preg_match( '/^#[0-9a-f]{3,8}$/i', $fg ) || ! preg_match( '/^#[0-9a-f]{3,8}$/i', $bg ) ) {
				continue;
			}
			$ratio = (float) cb_contrast_ratio( $bg, $fg );
			if ( $ratio >= 4.5 ) {
				continue;
			}
			$out[] = [
				'key'    => $fg_key,
				'bg_key' => $bg_key,
				'label'  => $label,
				'fg'     => $fg,
				'bg'     => $bg,
				'ratio'  => round( $ratio, 2 ),
				'safe'   => (string) cb_best_contrast_text( $bg, '', 4.5 ),
			];
		}
		return $out;
	}
}
