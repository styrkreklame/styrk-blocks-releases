<?php
/**
 * WCAG-aware color helpers.
 *
 * Used by block templates to guarantee that text placed on a user-picked
 * background colour still meets WCAG AA contrast (4.5:1 for normal text,
 * 3:1 for large text). Keeps the user's background, adjusts the text.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_hex_to_rgb' ) ) {
	function cb_hex_to_rgb( $hex ) {
		$hex = ltrim( (string) $hex, '#' );
		if ( strlen( $hex ) === 3 ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( strlen( $hex ) !== 6 || ! ctype_xdigit( $hex ) ) {
			return null;
		}
		return [
			hexdec( substr( $hex, 0, 2 ) ),
			hexdec( substr( $hex, 2, 2 ) ),
			hexdec( substr( $hex, 4, 2 ) ),
		];
	}
}

if ( ! function_exists( 'cb_relative_luminance' ) ) {
	function cb_relative_luminance( $hex ) {
		$rgb = cb_hex_to_rgb( $hex );
		if ( ! $rgb ) return null;
		$lin = array_map( function ( $c ) {
			$s = $c / 255;
			return $s <= 0.03928 ? $s / 12.92 : pow( ( $s + 0.055 ) / 1.055, 2.4 );
		}, $rgb );
		return 0.2126 * $lin[0] + 0.7152 * $lin[1] + 0.0722 * $lin[2];
	}
}

if ( ! function_exists( 'cb_contrast_ratio' ) ) {
	function cb_contrast_ratio( $a, $b ) {
		$la = cb_relative_luminance( $a );
		$lb = cb_relative_luminance( $b );
		if ( $la === null || $lb === null ) return 0.0;
		$lighter = max( $la, $lb );
		$darker  = min( $la, $lb );
		return ( $lighter + 0.05 ) / ( $darker + 0.05 );
	}
}

if ( ! function_exists( 'cb_best_contrast_text' ) ) {
	/**
	 * Pick a WCAG-passing text color for a given background.
	 *
	 * - If $preferred is passed AND meets $min_ratio against $bg → keep it.
	 * - Otherwise pick whichever of #ffffff / #111111 gives the higher ratio.
	 *
	 * @param string $bg         Background colour (hex).
	 * @param string $preferred  User-picked text colour (hex). May be empty.
	 * @param float  $min_ratio  Minimum required contrast. 4.5 = AA normal text,
	 *                           3.0 = AA large text / UI components.
	 * @return string            Hex color with leading #.
	 */
	function cb_best_contrast_text( $bg, $preferred = '', $min_ratio = 4.5 ) {
		if ( $preferred && cb_contrast_ratio( $bg, $preferred ) >= $min_ratio ) {
			return $preferred;
		}
		$white_ratio = cb_contrast_ratio( $bg, '#ffffff' );
		$black_ratio = cb_contrast_ratio( $bg, '#111111' );
		return $white_ratio >= $black_ratio ? '#ffffff' : '#111111';
	}
}
