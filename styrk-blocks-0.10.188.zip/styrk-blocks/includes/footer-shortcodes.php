<?php
/**
 * Footer shortcodes — dynamic footer content from Settings → Footer / Header.
 *
 * [footer_logo]         → White logo for the footer
 * [footer_description]  → Company description
 * [footer_contact]      → Address, email, phones, org number. `parts="address"`
 *                         / `parts="contact,org"` splits the column for themes
 *                         that label the two stacks separately.
 * [footer_address_heading] → Optional "Adresse" heading for that split
 * [footer_copyright]    → Copyright line
 *
 * Social links are handled by [social_links] in styrk-blocks.php.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard — see header-settings.php for the rationale.
if ( defined( 'CB_FOOTER_SHORTCODES_LOADED' ) ) return;
define( 'CB_FOOTER_SHORTCODES_LOADED', true );

/**
 * [footer_logo] — outputs the white footer logo.
 *
 * Priority: Header Settings → logo_white_id → custom_logo → theme asset fallback.
 */
function cb_footer_logo_shortcode(): string {
	$footer    = function_exists( 'cb_get_footer_settings' ) ? cb_get_footer_settings() : [];
	$header    = function_exists( 'cb_get_header_settings' ) ? cb_get_header_settings() : [];
	$site_name = get_bloginfo( 'name' );

	/* 1. White logo from FOOTER Settings (new home since v1.6.5). Falls back
	 *    to the legacy Header-Settings key for client sites that have set it
	 *    there and haven't been through the migration yet — cb_footer_migrate
	 *    _white_logo_from_header moves existing values on admin_init, but
	 *    reading both here makes the render robust regardless. */
	$white_id = (int) ( $footer['logo_white_id'] ?? 0 );
	if ( ! $white_id ) {
		$white_id = (int) ( $header['logo_white_id'] ?? 0 );
	}
	// Small helper — every branch below returns the same <a>/<img> shape,
	// wrapped in a <div> so WP's wpautop doesn't enclose the inline <a>
	// in a <p> (which was collapsing to height:0 when the inner SVG had
	// no intrinsic dimensions). The CSS on .site-footer__logo-img also
	// pins an explicit 200×64 footprint with object-fit:contain so the
	// logo renders correctly regardless of the asset's intrinsic size.
	$render_logo = function ( string $url, string $alt, bool $invert = false ) use ( $site_name ): string {
		$img_class = 'site-footer__logo-img' . ( $invert ? ' site-footer__logo-img--invert' : '' );
		return sprintf(
			'<div class="site-footer__logo"><a href="%s" class="site-footer__logo-link" aria-label="%s"><img src="%s" alt="%s" class="%s" width="200" height="64" loading="lazy" /></a></div>',
			esc_url( home_url( '/' ) ),
			esc_attr( $alt ),
			esc_url( $url ),
			esc_attr( $alt ),
			esc_attr( $img_class )
		);
	};

	if ( $white_id ) {
		$url = wp_get_attachment_image_url( $white_id, 'full' );
		if ( $url ) {
			return $render_logo( $url, $site_name );
		}
	}

	/* 2. Main logo from Header Settings (with CSS invert) */
	$main_id = (int) ( $header['logo_id'] ?? 0 );
	if ( ! $main_id ) {
		$main_id = (int) get_theme_mod( 'custom_logo', 0 );
	}
	if ( $main_id ) {
		$url = wp_get_attachment_image_url( $main_id, 'full' );
		if ( $url ) {
			return $render_logo( $url, $site_name, /* invert = */ true );
		}
	}

	/* 3. Theme asset fallback — logo-hvit.svg */
	$fallback = get_theme_file_uri( 'assets/logo-hvit.svg' );
	return $render_logo( $fallback, $site_name );
}
add_shortcode( 'footer_logo', 'cb_footer_logo_shortcode' );

/**
 * [footer_description] — outputs the company description.
 */
function cb_footer_description_shortcode(): string {
	$settings = cb_get_footer_settings();
	$desc     = $settings['description'] ?? '';

	if ( ! $desc ) {
		return '';
	}

	return '<p>' . esc_html( $desc ) . '</p>';
}
add_shortcode( 'footer_description', 'cb_footer_description_shortcode' );

/**
 * Format a 9-digit Norwegian org number as "NNN NNN NNN". Accepts any
 * mix of digits + separators; strips non-digits first. Returns an empty
 * string for anything that doesn't parse to 9 digits so the footer
 * shortcode doesn't render a malformed label.
 */
function cb_format_org_number( string $raw ): string {
	$digits = preg_replace( '/\D+/', '', $raw );
	if ( strlen( (string) $digits ) !== 9 ) return '';
	return trim( chunk_split( (string) $digits, 3, ' ' ) );
}

/**
 * Which settings feed each part of the contact column.
 *
 * One map, used by [footer_contact] to decide what to render and by the
 * heading shortcodes to decide whether there is anything to head. Without
 * it a heading could survive its own content: a footer that renders only
 * the address part would still print "Kontakt" because a phone number was
 * set somewhere the theme never outputs.
 */
const CB_FOOTER_CONTACT_PARTS = [
	'address' => [ 'address' ],
	'contact' => [ 'email', 'phone_1', 'phone_2' ],
	'org'     => [ 'org_number' ],
];

/**
 * Normalise a `parts="…"` attribute into a list of valid part names.
 *
 * Unset / empty / unrecognised → every part, which is what every call site
 * predating the attribute means. So `[footer_contact]` keeps rendering the
 * whole column exactly as before.
 *
 * @param array<string,mixed>|string $atts Shortcode attributes.
 * @return string[]
 */
function cb_footer_contact_parts( $atts ): array {
	$all = array_keys( CB_FOOTER_CONTACT_PARTS );
	$raw = is_array( $atts ) ? (string) ( $atts['parts'] ?? '' ) : '';
	if ( '' === trim( $raw ) ) {
		return $all;
	}
	$requested = array_filter( array_map( 'trim', explode( ',', strtolower( $raw ) ) ), 'strlen' );
	$valid     = array_values( array_intersect( $all, $requested ) );
	return $valid ?: $all;
}

/**
 * True when at least one setting behind the given parts holds a value.
 *
 * @param array<string,mixed> $settings Footer settings.
 * @param string[]            $parts    Part names.
 */
function cb_footer_contact_has_content( array $settings, array $parts ): bool {
	foreach ( $parts as $part ) {
		foreach ( CB_FOOTER_CONTACT_PARTS[ $part ] ?? [] as $field ) {
			if ( '' !== trim( (string) ( $settings[ $field ] ?? '' ) ) ) {
				return true;
			}
		}
	}
	return false;
}

/**
 * Build a `tel:` href from an admin-entered phone number.
 *
 * The country code used to be pasted in unconditionally: `'tel:+47' . $digits`.
 * That is correct for "57 73 52 00" and broken for "+47 57 73 52 00" — which
 * is how most of these fields are actually filled in — producing
 * `tel:+47+4757735200`, a URI no dialler can parse. Same for a number written
 * in the 00-prefixed international form.
 *
 * Rules: keep an explicit country code, normalise `00` to `+`, and only assume
 * Norway for a bare national number.
 */
function cb_footer_tel_href( string $raw ): string {
	// Everything a human might type as a separator, gone. Keep a leading '+'.
	$compact = preg_replace( '/[^\d+]/', '', $raw ) ?? '';
	$compact = '+' === substr( $compact, 0, 1 )
		? '+' . preg_replace( '/\D/', '', $compact )
		: preg_replace( '/\D/', '', $compact );

	if ( '' === $compact || '+' === $compact ) {
		return '';
	}
	if ( '+' === $compact[0] ) {
		return 'tel:' . $compact;
	}
	if ( str_starts_with( $compact, '00' ) ) {
		return 'tel:+' . substr( $compact, 2 );
	}
	return 'tel:+47' . $compact;
}

/**
 * [footer_contact] — outputs address, email, phone numbers, and org number.
 *
 * Order: address → email → phones → org nr. Org nr sits last in its own
 * visually muted line because it's regulatory context, not a contact
 * action — users scan phone/email first.
 *
 * `parts` (optional) limits the output to some of those, comma separated:
 * `address`, `contact` (email + phones), `org`. Themes whose footer labels
 * the address and the contact details separately place two calls —
 * `[footer_contact parts="address"]` and `[footer_contact parts="contact,org"]` —
 * each under its own heading, instead of hard-coding the values into the
 * template to get the layout. Omitting the attribute renders everything,
 * so existing templates are untouched.
 *
 * @param array<string,mixed>|string $atts Shortcode attributes.
 */
function cb_footer_contact_shortcode( $atts = [] ): string {
	$s     = cb_get_footer_settings();
	$parts = cb_footer_contact_parts( $atts );
	$html  = '';

	if ( in_array( 'address', $parts, true ) && ! empty( $s['address'] ) ) {
		// Trim each line and drop empty ones so accidental double-newlines in
		// the Settings textarea don't render as a visible gap between lines.
		$lines   = array_filter( array_map( 'trim', explode( "\n", $s['address'] ) ), 'strlen' );
		$lines   = array_map( 'esc_html', $lines );
		$address = implode( '<br/>', $lines );
		$html   .= '<address class="site-footer__address">' . $address . '</address>';
	}

	$contact_lines = [];
	if ( in_array( 'contact', $parts, true ) ) {
		if ( ! empty( $s['email'] ) ) {
			$contact_lines[] = '<a href="mailto:' . esc_attr( $s['email'] ) . '">'
				. esc_html( $s['email'] ) . '</a>';
		}
		foreach ( [ 'phone_1', 'phone_2' ] as $phone_key ) {
			if ( empty( $s[ $phone_key ] ) ) {
				continue;
			}
			$href = cb_footer_tel_href( (string) $s[ $phone_key ] );
			// A "number" with no digits in it gets rendered as plain text
			// rather than as a link to nowhere.
			$contact_lines[] = '' === $href
				? esc_html( $s[ $phone_key ] )
				: '<a href="' . esc_attr( $href ) . '">' . esc_html( $s[ $phone_key ] ) . '</a>';
		}
	}

	if ( $contact_lines ) {
		$html .= '<p class="site-footer__contact-info">'
			. implode( '<br/>', $contact_lines ) . '</p>';
	}

	$org_formatted = in_array( 'org', $parts, true )
		? cb_format_org_number( (string) ( $s['org_number'] ?? '' ) )
		: '';
	if ( $org_formatted !== '' ) {
		$html .= sprintf(
			'<p class="site-footer__org-number">%s <span>%s</span></p>',
			esc_html__( 'Org.nr.', 'styrk-blocks' ),
			esc_html( $org_formatted )
		);
	}

	return $html;
}
add_shortcode( 'footer_contact', 'cb_footer_contact_shortcode' );

/**
 * [footer_org_number] — standalone shortcode for the org number, for sites
 * that want to place it outside the Kontakt column (e.g. inline with the
 * copyright line). Silently renders nothing when the field is unset or
 * malformed.
 */
function cb_footer_org_number_shortcode(): string {
	$s             = cb_get_footer_settings();
	$org_formatted = cb_format_org_number( (string) ( $s['org_number'] ?? '' ) );
	if ( $org_formatted === '' ) return '';
	return sprintf(
		'<span class="site-footer__org-number-inline">%s %s</span>',
		esc_html__( 'Org.nr.', 'styrk-blocks' ),
		esc_html( $org_formatted )
	);
}
add_shortcode( 'footer_org_number', 'cb_footer_org_number_shortcode' );

/**
 * [footer_social_heading] — outputs the "Følg oss" heading (editable from Settings).
 *
 * Emits an <h2> so the column heading is part of the page heading outline —
 * lets screen-reader users navigate to the footer columns via heading nav.
 */
function cb_footer_social_heading_shortcode(): string {
	$settings = cb_get_footer_settings();
	// No default label: if the admin hasn't set a social heading, render
	// nothing (an unset column heading should not appear).
	$heading  = trim( (string) ( $settings['social_heading'] ?? '' ) );

	if ( '' === $heading ) {
		return '';
	}

	// A heading over an empty column is worse than no heading: it promises
	// content that isn't there. [social_links] already returns '' when no
	// links exist, so reuse it as the emptiness test rather than duplicating
	// the query.
	if ( '' === trim( (string) do_shortcode( '[social_links]' ) ) ) {
		return '';
	}

	return '<h2 class="wp-block-heading site-footer__col-heading">' . esc_html( $heading ) . '</h2>';
}
add_shortcode( 'footer_social_heading', 'cb_footer_social_heading_shortcode' );

/**
 * [footer_contact_heading] — the "Kontakt" column heading.
 *
 * Was hardcoded in the theme template, so it rendered even when every
 * contact field was empty. Now it is a setting, and it disappears when the
 * column below it has nothing to show.
 */
function cb_footer_contact_heading_shortcode( $atts = [] ): string {
	$settings = cb_get_footer_settings();
	$heading  = trim( (string) ( $settings['contact_heading'] ?? '' ) );

	if ( '' === $heading ) {
		return '';
	}

	// Head only what is actually rendered below. `parts` mirrors the
	// attribute on [footer_contact]: a theme that puts the address under its
	// own "Adresse" heading passes parts="contact,org" here, so "Kontakt"
	// disappears when there is no email or phone — even though the address
	// (rendered elsewhere) is set.
	if ( ! cb_footer_contact_has_content( $settings, cb_footer_contact_parts( $atts ) ) ) {
		return '';
	}

	return '<h2 class="wp-block-heading site-footer__col-heading">' . esc_html( $heading ) . '</h2>';
}
add_shortcode( 'footer_contact_heading', 'cb_footer_contact_heading_shortcode' );

/**
 * [footer_address_heading] — the optional separate "Adresse" heading.
 *
 * For footers that label the address and the contact details as two stacks
 * inside one column. Renders nothing unless BOTH the heading (Settings →
 * Footer → Contact Details → Address Heading) and the address itself are
 * set, so the default single-heading layout is unaffected and an empty
 * address never gets a label.
 */
function cb_footer_address_heading_shortcode(): string {
	$settings = cb_get_footer_settings();
	$heading  = trim( (string) ( $settings['address_heading'] ?? '' ) );

	if ( '' === $heading || '' === trim( (string) ( $settings['address'] ?? '' ) ) ) {
		return '';
	}

	return '<h2 class="wp-block-heading site-footer__col-heading">' . esc_html( $heading ) . '</h2>';
}
add_shortcode( 'footer_address_heading', 'cb_footer_address_heading_shortcode' );

/**
 * [footer_copyright] — outputs the copyright text.
 */
function cb_footer_copyright_shortcode(): string {
	$settings  = cb_get_footer_settings();
	$copyright = $settings['copyright'] ?? '';

	if ( ! $copyright ) {
		return '';
	}

	return '<p>' . wp_kses( $copyright, cb_footer_allowed_inline_html() ) . '</p>';
}
add_shortcode( 'footer_copyright', 'cb_footer_copyright_shortcode' );

/**
 * [footer_site_name] — outputs the configured footer company-name as an <h2>
 * column heading. Comes only from the Settings → Footer field (no site-name fallback).
 *
 * Matches the Kontakt / Følg oss heading levels so the footer has a
 * consistent <h2>-per-column heading outline.
 */
function cb_footer_site_name_shortcode(): string {
	$settings = cb_get_footer_settings();
	// Heading is explicit: it comes ONLY from the Settings → Footer
	// "Company name" field. Empty = no heading rendered. No silent
	// fallback to the global site title — that pulled the site name
	// into the footer whether or not the admin wanted it there.
	$heading = trim( (string) ( $settings['site_name_heading'] ?? '' ) );
	if ( '' === $heading ) {
		return '';
	}
	return '<h2 class="wp-block-heading site-footer__col-heading">' . esc_html( $heading ) . '</h2>';
}
add_shortcode( 'footer_site_name', 'cb_footer_site_name_shortcode' );

/**
 * [footer_credits] — outputs the credits line.
 * Editable from Settings → Footer → Bottom Bar → Credits.
 */
function cb_footer_credits_shortcode(): string {
	$settings = cb_get_footer_settings();
	$credits  = $settings['credits'] ?? '';
	if ( ! $credits ) return '';

	// Prefix with the credits mark when set. Two sources, in order:
	//  1. Settings → Footer → Credits Icon (admin-uploaded attachment)
	//  2. Bundled styrk-reklame-ikon.webp when the credits text mentions
	//     "Styrk Reklame" (back-compat for sites built before the field
	//     existed).
	// The mark is a CSS-mask span so it inherits the footer's
	// currentColor (white on the dark bar) regardless of the source
	// asset being black on white.
	$mark         = '';
	$icon_id      = (int) ( $settings['credits_icon_id'] ?? 0 );
	$icon_url     = $icon_id ? wp_get_attachment_image_url( $icon_id, 'medium' ) : '';
	if ( ! $icon_url && false !== stripos( $credits, 'styrk reklame' ) ) {
		// The ICON, not the wordmark. The wordmark repeated the agency name it
		// sits beside and, being a fixed-ratio image next to type, could not
		// share a baseline with it — the credit read as broken on every site.
		$icon_url = plugins_url( 'assets/styrk-reklame-ikon.webp', dirname( __FILE__, 2 ) . '/styrk-blocks.php' );
	}
	if ( $icon_url ) {
		$mark = sprintf(
			'<span class="site-footer__credits-logo" aria-hidden="true" style="--styrk-mark-img:url(%s);"></span>',
			esc_url( $icon_url )
		);
	}

	// Inline the mark just before the agency name when the credits text
	// mentions "Styrk Reklame" — that puts the icon right next to the
	// brand it represents instead of decorating the whole sentence. For
	// any other credits string the mark falls through to the start.
	$position = (string) ( $settings['credits_logo_position'] ?? 'inline' );
	$escaped  = wp_kses( $credits, cb_footer_allowed_inline_html() );

	// Optional link on the agency name. Wraps the NAME (and its mark) rather
	// than the whole sentence: "Utvikling og design av" is not the thing being
	// linked to, and a link that swallows the sentence reads as a mistake.
	//
	// Skipped when the credits text already contains an <a>, so a site that
	// hand-wrote its own link in the field does not end up with nested anchors.
	$credits_url = (string) ( $settings['credits_url'] ?? '' );
	$link_open   = '';
	$link_close  = '';
	if ( $credits_url !== '' && false === stripos( $escaped, '<a ' ) ) {
		$rel  = '';
		$host = wp_parse_url( $credits_url, PHP_URL_HOST );
		if ( $host && $host !== wp_parse_url( home_url(), PHP_URL_HOST ) ) {
			$rel = ' target="_blank" rel="noopener"';
		}
		$link_open  = '<a class="site-footer__credits-link" href="' . esc_url( $credits_url ) . '"' . $rel . '>';
		$link_close = '</a>';
	}

	// Link the agency name wherever it appears, for the branches that do not
	// splice a mark next to it. Falls back to linking the whole line only when
	// no name is found — better a working link than a setting that silently
	// does nothing on a site whose credit text we cannot parse.
	$link_name = static function ( string $html ) use ( $link_open, $link_close ): string {
		if ( $link_open === '' ) {
			return $html;
		}
		if ( preg_match( '/Styrk Reklame(?:\s+AS)?/i', $html ) ) {
			return preg_replace(
				'/(Styrk Reklame(?:\s+AS)?)/i',
				$link_open . '$1' . $link_close,
				$html,
				1
			);
		}
		return $link_open . $html . $link_close;
	};

	if ( $mark === '' ) {
		return '<p class="site-footer__credits">' . $link_name( $escaped ) . '</p>';
	}

	if ( $position === 'start' ) {
		return '<p class="site-footer__credits site-footer__credits--logo-start">' . $mark . $link_name( $escaped ) . '</p>';
	}
	if ( $position === 'end' ) {
		return '<p class="site-footer__credits site-footer__credits--logo-end">' . $link_name( $escaped ) . $mark . '</p>';
	}

	// inline (default) — splice the mark in next to "Styrk Reklame" so the
	// icon visually labels the agency name rather than the whole sentence.
	if ( false !== stripos( $credits, 'Styrk Reklame' ) ) {
		$inlined = preg_replace(
			'/(Styrk Reklame(?:\s+AS)?)/i',
			$link_open . '<span class="site-footer__credits-mark-group">' . $mark . '$1</span>' . $link_close,
			$escaped,
			1
		);
		return '<p class="site-footer__credits">' . $inlined . '</p>';
	}

	return '<p class="site-footer__credits">' . $mark . $link_name( $escaped ) . '</p>';
}
add_shortcode( 'footer_credits', 'cb_footer_credits_shortcode' );

/**
 * [footer_legal] — outputs the inline legal-links nav (privacy, terms, etc).
 *
 * Reads the raw Settings → Footer → Legal Links textarea (one "Label|URL"
 * per line). Returns an empty string when no links are configured — the
 * bottom bar just collapses to copyright + credits on sites that don't
 * need a legal-nav row.
 *
 * URL handling:
 * - Relative URLs ("/personvern") are preserved as-is.
 * - Absolute URLs (https://…) are validated via esc_url so javascript:
 *   or data: schemes can't slip through.
 *
 * a11y: wraps the links in <nav aria-label="Juridisk"> so the links
 * register as a landmark for screen-reader users, distinct from the main
 * footer content.
 */
function cb_footer_legal_shortcode(): string {
	$settings = cb_get_footer_settings();

	// cb_footer_legal_rows() is the SAME function the settings screen renders
	// from — reading the legal_{1..4}_* slots, and falling back to the legacy
	// "Label|URL" string for sites that have not been re-saved yet. One source
	// of truth, so the admin screen cannot show one thing and the footer render
	// another.
	$rows = cb_footer_legal_rows( $settings );
	if ( ! $rows ) {
		return '';
	}

	$links = [];
	foreach ( $rows as $row ) {
		$link = cb_footer_legal_resolve( $row );
		if ( null === $link ) {
			continue;
		}
		[ $label, $href ] = $link;

		$links[] = sprintf(
			'<a href="%s">%s</a>',
			esc_url( $href ),
			esc_html( $label )
		);
	}

	if ( ! $links ) return '';

	return '<nav class="site-footer__legal" aria-label="' . esc_attr__( 'Juridisk', 'styrk-blocks' ) . '">'
		. implode( '', $links )
		. '</nav>';
}
add_shortcode( 'footer_legal', 'cb_footer_legal_shortcode' );

/**
 * [footer_certs] — renders 1–3 certification badges next to the footer
 * logo. Reads from the cert_{1,2,3}_id options set under Settings →
 * Footer → Certification Badges. Empty slots are skipped so a site
 * with one cert doesn't get two empty placeholders.
 */
function cb_footer_certs_shortcode(): string {
	$s     = cb_get_footer_settings();
	$items = [];

	for ( $i = 1; $i <= 3; $i++ ) {
		$id    = (int)    ( $s[ "cert_{$i}_id" ]    ?? 0 );
		$label = (string) ( $s[ "cert_{$i}_label" ] ?? '' );
		if ( ! $id ) {
			continue;
		}
		$img = wp_get_attachment_image( $id, 'large', false, [
			'class'    => 'site-footer__cert-img',
			'alt'      => $label !== '' ? $label : '',
			'loading'  => 'lazy',
			'decoding' => 'async',
		] );
		if ( ! $img ) {
			continue;
		}
		// Optional link to the issuing body. Rendered as an <a> in place of the
		// <span> so the badge stays one list item either way. Only genuinely
		// external hosts get target/rel — a site-relative link should not open
		// a new tab, and rel="noopener" on an internal link is noise.
		// The link is NESTED inside the listitem, never merged into it:
		// role="listitem" on an <a> replaces the implicit link role, so screen
		// readers stop announcing it as a link at all.
		//
		// Only genuinely external hosts get target/rel — a site-relative link
		// should not open a new tab, and rel="noopener" on an internal link is
		// noise.
		$url = (string) ( $s[ "cert_{$i}_url" ] ?? '' );
		$inner = $img;
		if ( $url !== '' ) {
			$rel  = '';
			$host = wp_parse_url( $url, PHP_URL_HOST );
			if ( $host && $host !== wp_parse_url( home_url(), PHP_URL_HOST ) ) {
				$rel = ' target="_blank" rel="noopener noreferrer"';
			}
			$inner = sprintf(
				'<a class="site-footer__cert-link" href="%s"%s>%s</a>',
				esc_url( $url ),
				$rel,
				$img
			);
		}
		$items[] = sprintf(
			'<span class="site-footer__cert" role="listitem"%s>%s</span>',
			$label !== '' ? ' title="' . esc_attr( $label ) . '"' : '',
			$inner
		);
	}

	if ( empty( $items ) ) {
		return '';
	}

	// Height is published as a custom property rather than baked into each
	// <img>, so one value drives the whole row and the CSS keeps ownership of
	// the aspect handling.
	$height = max( 40, min( 160, (int) ( $s['cert_height'] ?? 96 ) ) );

	return '<div class="site-footer__certs" role="list" aria-label="' .
		esc_attr__( 'Sertifiseringer', 'styrk-blocks' ) .
		'" style="--cb-cert-h:' . $height . 'px">' . implode( '', $items ) . '</div>';
}
add_shortcode( 'footer_certs', 'cb_footer_certs_shortcode' );

/**
 * [footer_newsletter] — optional newsletter-signup column.
 *
 * Renders the heading + consent text + a trailing privacy link + the email
 * signup form, all configured under Settings → Footer → Newsletter. Returns
 * an empty string when "Show newsletter signup" is unticked, so the footer
 * column stays invisible by default (same opt-in pattern as [footer_certs]).
 *
 * The form is a static placeholder (no submit handler yet — pending a
 * Forminator/Mailchimp integration); it posts nowhere and just renders the
 * email field + arrow button.
 */
function cb_footer_newsletter_shortcode(): string {
	$s = cb_get_footer_settings();

	if ( empty( $s['newsletter_enabled'] ) ) {
		return '';
	}

	$html = '';

	$heading = trim( (string) ( $s['newsletter_heading'] ?? '' ) );
	if ( $heading !== '' ) {
		$html .= '<h2 class="wp-block-heading">' . esc_html( $heading ) . '</h2>';
	}

	$body  = trim( (string) ( $s['newsletter_body'] ?? '' ) );
	$label = trim( (string) ( $s['newsletter_privacy_label'] ?? '' ) );
	$url   = trim( (string) ( $s['newsletter_privacy_url'] ?? '' ) );
	if ( $body !== '' || ( $label !== '' && $url !== '' ) ) {
		$para = esc_html( $body );
		if ( $label !== '' && $url !== '' ) {
			$link = '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
			// Append the link (with a leading space when there's body text)
			// and close the sentence with a period.
			$para = $para !== '' ? $para . ' ' . $link . '.' : $link . '.';
		}
		$html .= '<p>' . $para . '</p>';
	}

	// Email signup form (static placeholder). Moved here from the Hywer
	// theme so the newsletter column is self-contained in the plugin and
	// reusable across sites.
	$html .= '<div class="news-field">'
		. '<input type="email" name="email"'
		. ' placeholder="' . esc_attr__( 'Din e-postadresse', 'styrk-blocks' ) . '"'
		. ' aria-label="' . esc_attr__( 'Din e-postadresse', 'styrk-blocks' ) . '">'
		. '<button type="submit" class="arrow-circle"'
		. ' aria-label="' . esc_attr__( 'Meld på nyhetsbrev', 'styrk-blocks' ) . '">'
		. '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor"'
		. ' stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"'
		. ' width="14" height="14" aria-hidden="true">'
		. '<path d="M5 12h14M13 6l6 6-6 6"/></svg>'
		. '</button>'
		. '</div>';

	return $html;
}
add_shortcode( 'footer_newsletter', 'cb_footer_newsletter_shortcode' );
