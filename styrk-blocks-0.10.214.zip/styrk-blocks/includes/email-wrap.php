<?php
/**
 * Email addresses that wrap where a reader expects them to.
 *
 * In a narrow card — a four-up team grid on a laptop — a long address is wider
 * than its column, and the only break opportunity CSS finds is mid-word, so
 * "christian@styrkreklame.no" wrapped as "christian@styrkreklame" / ".no".
 * Giving the browser one break opportunity right after the @ means the address
 * splits at the part everyone reads as a seam: name on one line, domain on the
 * next.
 *
 * <wbr> is a hint, not a forced break: on a wide card the address stays on one
 * line exactly as before.
 *
 * @package styrk-blocks
 */

namespace Styrk\Blocks;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Escaped email text with a break opportunity after the "@".
 *
 * Output is already escaped and contains one <wbr> — echo it directly, do not
 * pass it through esc_html() again.
 *
 * @param string $email Raw email address.
 * @return string Escaped HTML.
 */
function email_wrappable( string $email ): string {
	$at = strpos( $email, '@' );
	if ( false === $at ) {
		return esc_html( $email );
	}

	return esc_html( substr( $email, 0, $at + 1 ) )
		. '<wbr>'
		. esc_html( substr( $email, $at + 1 ) );
}
