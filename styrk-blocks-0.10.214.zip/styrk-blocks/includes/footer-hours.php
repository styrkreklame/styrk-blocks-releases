<?php
/**
 * Opening hours as DATA, not as a sentence.
 *
 * The hours used to be one free-text box: "Mandag – Fredag: 08.00 – 16.00" on
 * one line, "Lørdag – Søndag: Stengt" on the next. That renders fine and is
 * unreadable to everything else — Google, an assistant answering "når har de
 * åpent?", or a future opening-hours widget all get a string that would have
 * to be parsed back into days and times, in Norwegian, with whatever dash and
 * time format the admin happened to use.
 *
 * So each weekday is stored as three values: open/closed, from, to. The footer
 * renders them into the same lines as before by collapsing consecutive days
 * that share their hours ("Mandag–fredag: 08.00–16.00"), and
 * openingHoursSpecification is emitted straight from the same numbers.
 *
 * The old free-text value is kept and still rendered on any site that has not
 * filled the per-day fields, so nothing goes blank on update.
 *
 * @package styrk-blocks
 */

namespace Styrk\Blocks\Footer;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Weekdays in week order: option-key suffix => [ Norwegian label, schema.org day ].
 *
 * @return array<string, array{0:string,1:string}>
 */
function hour_days(): array {
	return [
		'mon' => [ __( 'Mandag', 'styrk-blocks' ), 'Monday' ],
		'tue' => [ __( 'Tirsdag', 'styrk-blocks' ), 'Tuesday' ],
		'wed' => [ __( 'Onsdag', 'styrk-blocks' ), 'Wednesday' ],
		'thu' => [ __( 'Torsdag', 'styrk-blocks' ), 'Thursday' ],
		'fri' => [ __( 'Fredag', 'styrk-blocks' ), 'Friday' ],
		'sat' => [ __( 'Lørdag', 'styrk-blocks' ), 'Saturday' ],
		'sun' => [ __( 'Søndag', 'styrk-blocks' ), 'Sunday' ],
	];
}

/**
 * Normalise a typed time to 24h "HH:MM", or '' when it is not a time.
 *
 * Accepts what admins actually type: "8", "8.00", "08:00", "0800".
 *
 * @param string $raw Raw field value.
 * @return string
 */
function normalise_time( string $raw ): string {
	$raw = trim( $raw );
	if ( '' === $raw ) {
		return '';
	}
	if ( preg_match( '/^(\d{1,2})[.:]?(\d{2})?$/', $raw, $m ) ) {
		$h = (int) $m[1];
		$i = isset( $m[2] ) ? (int) $m[2] : 0;
		if ( $h > 23 || $i > 59 ) {
			return '';
		}
		return sprintf( '%02d:%02d', $h, $i );
	}
	return '';
}

/**
 * The week as stored: one entry per day, in week order.
 *
 * @param array $settings Footer settings.
 * @return array<int, array{key:string,label:string,schema:string,open:bool,from:string,to:string}>
 */
function hour_week( array $settings ): array {
	$week = [];
	foreach ( hour_days() as $key => list( $label, $schema_day ) ) {
		$week[] = [
			'key'    => $key,
			'label'  => $label,
			'schema' => $schema_day,
			'open'   => ! empty( $settings[ "hours_{$key}_open" ] ),
			'from'   => normalise_time( (string) ( $settings[ "hours_{$key}_from" ] ?? '' ) ),
			'to'     => normalise_time( (string) ( $settings[ "hours_{$key}_to" ] ?? '' ) ),
		];
	}
	return $week;
}

/**
 * Has anyone actually filled the per-day fields?
 *
 * Decides whether to use them or fall back to the legacy free-text box.
 *
 * @param array $settings Footer settings.
 * @return bool
 */
function hours_are_set( array $settings ): bool {
	foreach ( hour_week( $settings ) as $day ) {
		if ( $day['open'] && '' !== $day['from'] && '' !== $day['to'] ) {
			return true;
		}
	}
	return false;
}

/**
 * The week as display lines, consecutive days with equal hours collapsed.
 *
 * "Mandag–fredag: 08.00–16.00" / "Lørdag–søndag: Stengt" — the same shape the
 * free-text box was used to write by hand.
 *
 * @param array $settings Footer settings.
 * @return string[]
 */
function hour_lines( array $settings ): array {
	$week   = hour_week( $settings );
	$lines  = [];
	$run    = [];

	$flush = static function () use ( &$run, &$lines ) {
		if ( ! $run ) {
			return;
		}
		$first = $run[0];
		$last  = $run[ count( $run ) - 1 ];
		$days  = count( $run ) === 1
			? $first['label']
			// En dash between day names, as Norwegian typography wants.
			: $first['label'] . '–' . mb_strtolower( $last['label'] );
		$when  = $first['open']
			? str_replace( ':', '.', $first['from'] ) . '–' . str_replace( ':', '.', $first['to'] )
			: __( 'Stengt', 'styrk-blocks' );
		$lines[] = $days . ': ' . $when;
		$run     = [];
	};

	foreach ( $week as $day ) {
		$same = $run
			&& $run[0]['open'] === $day['open']
			&& $run[0]['from'] === $day['from']
			&& $run[0]['to'] === $day['to'];
		if ( ! $same ) {
			$flush();
		}
		$run[] = $day;
	}
	$flush();

	return $lines;
}

/**
 * schema.org openingHoursSpecification for the week.
 *
 * Closed days are emitted too (opens = closes = "00:00"), because "closed on
 * Sunday" is an answer, and leaving the day out only says "unknown".
 *
 * @param array $settings Footer settings.
 * @return array<int, array<string, mixed>>
 */
function hours_schema( array $settings ): array {
	if ( ! hours_are_set( $settings ) ) {
		return [];
	}

	$spec = [];
	foreach ( hour_week( $settings ) as $day ) {
		if ( $day['open'] && '' !== $day['from'] && '' !== $day['to'] ) {
			$spec[] = [
				'@type'     => 'OpeningHoursSpecification',
				'dayOfWeek' => 'https://schema.org/' . $day['schema'],
				'opens'     => $day['from'],
				'closes'    => $day['to'],
			];
			continue;
		}
		$spec[] = [
			'@type'     => 'OpeningHoursSpecification',
			'dayOfWeek' => 'https://schema.org/' . $day['schema'],
			'opens'     => '00:00',
			'closes'    => '00:00',
		];
	}
	return $spec;
}

/**
 * LocalBusiness JSON-LD built from the footer's own contact details.
 *
 * The site already carries an Organization node (SmartCrawl's, or a theme's),
 * but nothing machine-readable said where the company is, when it is open or
 * how to phone it — the footer had all three as plain text. This adds one
 * node, linked to the site by @id, so a search engine or an assistant asked
 * "når har de åpent?" has an actual answer.
 *
 * Emitted only when there is something to say: no hours and no address means
 * no node, rather than an empty shell claiming to describe a business.
 */
add_action( 'wp_head', __NAMESPACE__ . '\\print_local_business_schema', 20 );
function print_local_business_schema(): void {
	if ( ! function_exists( 'cb_get_footer_settings' ) || is_admin() ) {
		return;
	}

	$s       = cb_get_footer_settings();
	$address = trim( (string) ( $s['address'] ?? '' ) );
	$hours   = hours_schema( $s );

	if ( ! $hours && '' === $address ) {
		return;
	}

	$node = [
		'@context' => 'https://schema.org',
		'@type'    => 'LocalBusiness',
		'@id'      => home_url( '/#local-business' ),
		'name'     => get_bloginfo( 'name' ),
		'url'      => home_url( '/' ),
	];

	if ( '' !== $address ) {
		// One line per row in the footer field; schema wants a street line and
		// (where the last line looks like "7500 Stjørdal") a postcode + city.
		// Split on newlines AND commas: "Krogstads veg 11, 7500 Stjørdal" is
		// one line to the admin but a street and a postcode to schema.org.
		$lines  = array_values( array_filter( array_map( 'trim', preg_split( '/\r\n|\r|\n|,/', $address ) ), 'strlen' ) );
		$postal = [ '@type' => 'PostalAddress', 'addressCountry' => 'NO' ];
		$last   = end( $lines );
		if ( $last && preg_match( '/^(\d{4})\s+(.+)$/u', $last, $m ) ) {
			$postal['postalCode']      = $m[1];
			$postal['addressLocality'] = $m[2];
			array_pop( $lines );
		}
		if ( $lines ) {
			$postal['streetAddress'] = implode( ', ', $lines );
		}
		$node['address'] = $postal;
	}

	$phone = trim( (string) ( $s['phone_1'] ?? '' ) );
	if ( '' !== $phone ) {
		$node['telephone'] = $phone;
	}

	$email = trim( (string) ( $s['email'] ?? '' ) );
	if ( '' !== $email ) {
		$node['email'] = $email;
	}

	$org = preg_replace( '/\D+/', '', (string) ( $s['org_number'] ?? '' ) );
	if ( 9 === strlen( (string) $org ) ) {
		// Norwegian organisasjonsnummer — vatID is what consumers look for.
		$node['vatID'] = 'NO' . $org;
	}

	if ( $hours ) {
		$node['openingHoursSpecification'] = $hours;
	}

	printf(
		"<script type=\"application/ld+json\">%s</script>\n",
		wp_json_encode( $node, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
	);
}
