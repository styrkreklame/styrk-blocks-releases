# In-canvas editor panel — visual and structural redesign

Date: 2026-08-31
Status: approved (design), not implemented
Canvas: https://claude.ai/code/artifact/93282b64-6cac-45b2-ba8b-7e44ea1829ab

## Problem

The pinned in-canvas band (`SectionControls` + `ControlGroup`) accepts any
control in any group row. On a block with many options — employee-grid is the
worst case — one row mixes colour chips, a switch, and slider+number pairs that
each carry their own caps heading. Three labelling systems, no shared rhythm,
groups wrapping unpredictably. Editors read it as chaotic even though every
individual control works.

The dark band itself (`rgba(17,27,45,0.94)`) is off-palette and outweighs the
block being edited.

## Non-goals

- No attribute renames, removals or defaults changes. Live sites on this plugin
  must keep rendering identically. This is editor presentation only.
- No move to the WordPress sidebar. Controls stay where the block is.
- No block-by-block redesign of what options exist.

## Direction: "Papir"

The band becomes a light warm tray instead of a dark modal.

| Token | Value |
|---|---|
| Band background | `#EFECE5` |
| Band bottom border | `1px solid #DDD8CE` |
| Band shadow | `0 1px 0 rgba(0,72,106,0.04)` |
| Row separator | `1px solid rgba(0,72,106,0.10)` |
| Group label | 10px/700, `0.07em`, uppercase, `rgba(0,72,106,0.65)` |
| Control surface | `#FFFFFF`, border `#D9D4C9`, radius 4px, no shadow |
| Control text | `#1E2733`, 12px, sentence case |
| Inline label | 12px `#5B6470` |
| Segmented track | `#E5E1D7`, selected `#FFFFFF` with `#00486A` text |
| Switch on | `#0084AF` |

Control height stays 32px and radius stays 4px — unchanged from today, so
existing chips need no re-measuring.

## Structure

One group per ROW, not per free-flowing cluster:

    [ GROUP LABEL 104px ] [ control  control  control … ]

- Rows are ordered outside-in, matching what the editor sees on screen:
  Seksjon → Innhold → (block-specific groups, outermost first) → Modal.
- Row label column is fixed at 104px so every row's controls start on one
  vertical line.
- Controls inside a row are `display: flex; gap: 8px; flex-wrap: wrap`.
- Every control carries its label to its LEFT on the same line. No caps
  headings above controls, no unit suffix in the label.
- Rarely-used controls per row collapse behind a "Mer" disclosure at the end of
  the row. What counts as rare is decided per block during migration; nothing is
  deleted, only folded.

## The four control archetypes

Everything in the band is exactly one of these. New controls that fit none of
them are a design question, not a new widget.

1. **Farge** — colour swatch dot (14px) + sentence-case label, opens the
   existing `ColorPalette` popover. Diagonal-stripe dot = no value set
   (inherits the section). Replaces today's `InlineColorChip` chrome.
2. **Valg** — segmented control, 2–4 always-visible options. More than four
   options is a `Velg` (select) instead.
3. **Bryter** — switch (34×18px track) + label describing what happens when ON.
4. **Mengde** — one number. `[−] [ 16 px ] [+]`, 104px wide, unit inside the
   field, drag on the value to scrub. Replaces every slider + number field +
   "(PX)" caption trio in the plugin.

A fifth, `Velg` (native select in the same chrome), exists for lists — it is not
an archetype so much as the overflow of `Valg`.

## Components

New, in `src/components/`:

- `PanelRow.tsx` — the label column + controls row. Replaces `ControlGroup` as
  the thing blocks compose. `ControlGroup` stays as a thin alias so unmigrated
  blocks keep rendering.
- `ControlLabel.tsx` — the shared left-hand inline label.
- `Amount.tsx` — the Mengde stepper (value, min, max, step, unit, onChange).
- `Choice.tsx` — the Valg segmented control.
- `Switch.tsx` — the Bryter.

Changed:

- `InlineColorChip.tsx` — sentence-case label, empty-state dot; same props.
- `SectionControls.tsx` — Papir band tokens, rows instead of a wrapping flex of
  groups.
- `StandardSectionControls.tsx` — "Seksjon" becomes the first row.
- `src/style.css` — band + chip styles updated in place; the existing
  `.cb-feature-card__swatch` / `.cb-hero__bg-group` rules stay valid for
  unmigrated blocks until they are migrated.

## Migration

Block by block, employee-grid first (the worst offender and the canvas
reference). A block is migrated when its `edit.tsx` composes `PanelRow` and uses
only the four archetypes. Unmigrated blocks keep the old `ControlGroup` and
render in the new band colours — the two coexist, so no big-bang release.

## Verification per migrated block

1. `pnpm build`, then open the block in the editor on the local site.
2. Every control still writes the same attribute (spot-check colours, radii,
   toggles by reloading the page and reading the rendered front end).
3. Open an EXISTING page using that block and confirm the front end is
   byte-identical before/after (no attribute changes, so any diff is a bug).
4. Contrast check on the band: labels and control text against `#EFECE5` must
   pass WCAG AA.
5. Band at a narrow editor width (sidebar open, 1280px screen) must wrap into
   rows without clipping.
