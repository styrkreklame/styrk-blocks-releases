<?php
/**
 * Chat feedback — 👍/👎 under each answer. 👍 is only counted; 👎 keeps the
 * question and answer (no IP, nothing about the visitor) for 90 days so the
 * site owner can see what the bot gets wrong (Settings → Chat).
 *
 * The answer comes back from the browser, so every answer carries a signed
 * `ref`: only text this server actually answered can be stored.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_CHAT_FEEDBACK_LOADED' ) ) return;
define( 'CB_CHAT_FEEDBACK_LOADED', true );

define( 'CB_CHAT_FEEDBACK_DB_VERSION', '1' );
define( 'CB_CHAT_FEEDBACK_KEEP_DAYS', 90 );
define( 'CB_CHAT_FEEDBACK_PER_DAY', 30 );

/** Signature over the exact question and answer the server gave. */
function cb_chat_feedback_ref( string $question, string $answer, string $secret ): string {
	return hash_hmac( 'sha256', $question . "\n" . $answer, $secret . '|feedback' );
}

function cb_chat_feedback_valid( string $question, string $answer, string $ref, string $secret ): bool {
	return '' !== $ref && hash_equals( cb_chat_feedback_ref( $question, $answer, $secret ), $ref );
}

/**
 * Add one vote to the month's tally, keeping the last 12 months.
 *
 * @param array<string, array{up:int,down:int}> $counts
 * @return array<string, array{up:int,down:int}>
 */
function cb_chat_feedback_tally( array $counts, string $month, string $vote ): array {
	$row            = ( $counts[ $month ] ?? [] ) + [ 'up' => 0, 'down' => 0 ];
	$row[ $vote ]   = (int) $row[ $vote ] + 1;
	$counts[ $month ] = $row;
	krsort( $counts );
	return array_slice( $counts, 0, 12, true );
}

/* ── WordPress glue ─────────────────────────────────────────────────────────── */

function cb_chat_feedback_table(): string {
	global $wpdb;
	return $wpdb->prefix . 'styrk_chat_feedback';
}

function cb_chat_feedback_install(): void {
	global $wpdb;
	if ( get_option( 'cb_chat_feedback_db_version' ) === CB_CHAT_FEEDBACK_DB_VERSION ) return;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$table   = cb_chat_feedback_table();
	$charset = $wpdb->get_charset_collate();
	dbDelta(
		"CREATE TABLE $table (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			created DATETIME NOT NULL,
			question TEXT NOT NULL,
			answer TEXT NOT NULL,
			PRIMARY KEY  (id),
			KEY created (created)
		) $charset;"
	);
	update_option( 'cb_chat_feedback_db_version', CB_CHAT_FEEDBACK_DB_VERSION );
}
add_action( 'init', 'cb_chat_feedback_install', 5 );

add_action( 'rest_api_init', static function (): void {
	register_rest_route( 'styrk/v1', '/chat-feedback', [
		'methods'             => 'POST',
		'permission_callback' => static function ( WP_REST_Request $r ): bool {
			return cb_chat_visible_to_current_user()
				&& false !== wp_verify_nonce( (string) $r->get_header( 'X-WP-Nonce' ), 'wp_rest' );
		},
		'args'                => [
			'vote'     => [ 'type' => 'string', 'required' => true, 'enum' => [ 'up', 'down' ] ],
			'question' => [ 'type' => 'string', 'required' => true ],
			'answer'   => [ 'type' => 'string', 'required' => true ],
			'ref'      => [ 'type' => 'string', 'required' => true ],
		],
		'callback'            => 'cb_chat_handle_feedback',
	] );
} );

/** The question exactly as the chat endpoint signed it (sanitised, length-capped). */
function cb_chat_feedback_normalise_question( string $question ): string {
	return mb_substr( sanitize_textarea_field( $question ), 0, CB_CHAT_MAX_MESSAGE );
}

/** @return WP_REST_Response|WP_Error */
function cb_chat_handle_feedback( WP_REST_Request $r ) {
	global $wpdb;
	// The ref was signed over the question as cb_chat_handle() sanitised and
	// trimmed it, so verify against the same normalised form, not the raw input.
	$q    = cb_chat_feedback_normalise_question( (string) $r->get_param( 'question' ) );
	$a    = (string) $r->get_param( 'answer' );
	$ref  = (string) $r->get_param( 'ref' );
	$vote = (string) $r->get_param( 'vote' );
	if ( ! cb_chat_feedback_valid( $q, $a, $ref, cb_chat_pass_secret() ) ) {
		return new WP_Error( 'styrk_chat_feedback', 'unknown answer', [ 'status' => 400 ] );
	}

	// One vote per answer, and a daily cap per visitor (IP kept only as a hash).
	$ip   = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : '';
	$seen = 'cb_chat_fb_' . md5( $ref );
	$day  = 'cb_chat_fb_d_' . md5( $ip ) . '_' . gmdate( 'Ymd' );
	if ( get_transient( $seen ) || (int) get_transient( $day ) >= CB_CHAT_FEEDBACK_PER_DAY ) {
		return rest_ensure_response( [ 'ok' => true ] );
	}
	set_transient( $seen, 1, DAY_IN_SECONDS );
	set_transient( $day, (int) get_transient( $day ) + 1, DAY_IN_SECONDS );

	update_option(
		'cb_chat_feedback_counts',
		cb_chat_feedback_tally( (array) get_option( 'cb_chat_feedback_counts', [] ), gmdate( 'Y-m' ), $vote ),
		false
	);

	if ( 'down' === $vote ) {
		$table = cb_chat_feedback_table();
		$wpdb->insert(
			$table,
			[
				'created'  => current_time( 'mysql', true ),
				'question' => mb_substr( $q, 0, CB_CHAT_MAX_MESSAGE ),
				'answer'   => mb_substr( $a, 0, 4000 ),
			],
			[ '%s', '%s', '%s' ]
		);
		$wpdb->query( $wpdb->prepare( "DELETE FROM $table WHERE created < %s", gmdate( 'Y-m-d H:i:s', time() - CB_CHAT_FEEDBACK_KEEP_DAYS * DAY_IN_SECONDS ) ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name from $wpdb->prefix.
	}
	return rest_ensure_response( [ 'ok' => true ] );
}

define( 'CB_CHAT_FEEDBACK_PER_PAGE', 20 );

/** Number of list pages; at least 1. */
function cb_chat_feedback_pages( int $total, int $per_page = CB_CHAT_FEEDBACK_PER_PAGE ): int {
	return max( 1, (int) ceil( $total / max( 1, $per_page ) ) );
}

function cb_chat_feedback_count(): int {
	global $wpdb;
	return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . cb_chat_feedback_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name from $wpdb->prefix.
}

/** @return array<int, array{id:string,created:string,question:string,answer:string}> Newest first. */
function cb_chat_feedback_page( int $page, int $per_page = CB_CHAT_FEEDBACK_PER_PAGE ): array {
	global $wpdb;
	$table = cb_chat_feedback_table();
	return (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, created, question, answer FROM $table ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, ( max( 1, $page ) - 1 ) * $per_page ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name from $wpdb->prefix.
}

/** @return array{up:int,down:int} This month's votes. */
function cb_chat_feedback_month(): array {
	$counts = (array) get_option( 'cb_chat_feedback_counts', [] );
	return ( $counts[ gmdate( 'Y-m' ) ] ?? [] ) + [ 'up' => 0, 'down' => 0 ];
}

function cb_chat_handle_feedback_clear(): void {
	if ( ! current_user_can( 'styrk_use_chat' ) ) {
		wp_die( esc_html__( 'Ingen tilgang.', 'styrk-blocks' ), 403 );
	}
	check_admin_referer( 'cb_chat_feedback_clear' );
	global $wpdb;
	$wpdb->query( 'TRUNCATE TABLE ' . cb_chat_feedback_table() ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- table name from $wpdb->prefix.
	wp_safe_redirect( admin_url( 'options-general.php?page=cb-chat-settings&cleared=1' ) );
	exit;
}
add_action( 'admin_post_cb_chat_feedback_clear', 'cb_chat_handle_feedback_clear' );

/** One row, from the list's «Slett» button. */
function cb_chat_handle_feedback_delete(): void {
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified right below, per row.
	if ( ! current_user_can( 'styrk_use_chat' ) ) {
		wp_die( esc_html__( 'Ingen tilgang.', 'styrk-blocks' ), 403 );
	}
	check_admin_referer( 'cb_chat_feedback_delete_' . $id );
	global $wpdb;
	$wpdb->delete( cb_chat_feedback_table(), [ 'id' => $id ], [ '%d' ] );
	$page = isset( $_POST['fbpage'] ) ? absint( $_POST['fbpage'] ) : 1;
	wp_safe_redirect( admin_url( 'options-general.php?page=cb-chat-settings&deleted=1&fbpage=' . max( 1, $page ) . '#tilbakemeldinger' ) );
	exit;
}
add_action( 'admin_post_cb_chat_feedback_delete', 'cb_chat_handle_feedback_delete' );

/** Settings → Chat: this month's ratings and the «not helpful» answers, 20 per page. */
/**
 * Print the feedback list.
 *
 * @param bool $heading Print the heading (false when the caller labels the section).
 */
function cb_chat_feedback_render( bool $heading = true ): void {
	$m     = cb_chat_feedback_month();
	$total = cb_chat_feedback_count();
	$pages = cb_chat_feedback_pages( $total );
	$page  = min( $pages, max( 1, isset( $_GET['fbpage'] ) ? absint( $_GET['fbpage'] ) : 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only paging.
	$rows  = cb_chat_feedback_page( $page );
	$nav   = paginate_links( [
		'base'      => add_query_arg( 'fbpage', '%#%' ) . '#tilbakemeldinger',
		'format'    => '',
		'current'   => $page,
		'total'     => $pages,
		'prev_text' => '<span aria-hidden="true">‹</span><span class="screen-reader-text">' . esc_html__( 'Forrige side', 'styrk-blocks' ) . '</span>',
		'next_text' => '<span aria-hidden="true">›</span><span class="screen-reader-text">' . esc_html__( 'Neste side', 'styrk-blocks' ) . '</span>',
	] );
	// WordPress list-table look: page links as buttons, easier to hit.
	// The current page is filled in so it reads as «you are here».
	$nav = $nav ? (string) preg_replace(
		[ '/class="([^"]*page-numbers[^"]*)"/', '/class="button ([^"]*\bcurrent\b[^"]*)"/' ],
		[ 'class="button $1"', 'class="button button-primary $1"' ],
		$nav
	) : '';
	?>
	<?php if ( $heading ) : ?>
	<h2 id="tilbakemeldinger"><?php esc_html_e( 'Tilbakemeldinger', 'styrk-blocks' ); ?></h2>
	<?php endif; ?>
	<p>
		<?php
		printf(
			/* translators: 1: answers rated helpful this month, 2: answers rated not helpful */
			esc_html__( 'Denne måneden har besøkende merket %1$d svar som nyttige og %2$d som ikke nyttige. Svar merket «ikke nyttig» vises under og lagres i 90 dager, uten opplysninger om den besøkende.', 'styrk-blocks' ),
			(int) $m['up'],
			(int) $m['down']
		);
		?>
	</p>
	<?php if ( $rows ) : ?>
		<div class="tablenav top">
			<div class="tablenav-pages">
				<span class="displaying-num">
					<?php
					/* translators: %d: number of saved answers */
					echo esc_html( sprintf( _n( '%d svar', '%d svar', $total, 'styrk-blocks' ), $total ) );
					?>
				</span>
				<?php if ( $nav ) : ?>
					<span class="pagination-links"><?php echo wp_kses_post( $nav ); ?></span>
				<?php endif; ?>
			</div>
		</div>
		<table class="widefat striped">
			<thead><tr>
				<th style="width:9em"><?php esc_html_e( 'Dato', 'styrk-blocks' ); ?></th>
				<th style="width:25%"><?php esc_html_e( 'Spørsmål', 'styrk-blocks' ); ?></th>
				<th><?php esc_html_e( 'Svar', 'styrk-blocks' ); ?></th>
				<th style="width:6em"><span class="screen-reader-text"><?php esc_html_e( 'Handlinger', 'styrk-blocks' ); ?></span></th>
			</tr></thead>
			<tbody>
			<?php foreach ( $rows as $row ) : ?>
				<tr>
					<td><?php echo esc_html( get_date_from_gmt( (string) $row['created'], 'j.n.Y H:i' ) ); ?></td>
					<td><?php echo esc_html( (string) $row['question'] ); ?></td>
					<td><?php echo nl2br( esc_html( (string) $row['answer'] ) ); ?></td>
					<td>
						<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
							<input type="hidden" name="action" value="cb_chat_feedback_delete">
							<input type="hidden" name="id" value="<?php echo (int) $row['id']; ?>">
							<input type="hidden" name="fbpage" value="<?php echo (int) $page; ?>">
							<?php wp_nonce_field( 'cb_chat_feedback_delete_' . (int) $row['id'] ); ?>
							<button type="submit" class="button-link button-link-delete" aria-label="<?php echo esc_attr( sprintf( /* translators: %s: the question */ __( 'Slett tilbakemeldingen «%s»', 'styrk-blocks' ), (string) $row['question'] ) ); ?>"><?php esc_html_e( 'Slett', 'styrk-blocks' ); ?></button>
						</form>
					</td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php if ( $nav ) : ?>
			<div class="tablenav bottom"><div class="tablenav-pages"><span class="pagination-links"><?php echo wp_kses_post( $nav ); ?></span></div></div>
		<?php endif; ?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
			<input type="hidden" name="action" value="cb_chat_feedback_clear">
			<?php
			wp_nonce_field( 'cb_chat_feedback_clear' );
			submit_button( __( 'Slett alle tilbakemeldinger', 'styrk-blocks' ), 'secondary' );
			?>
		</form>
	<?php endif;
}
