<?php
/**
 * «Avanserte innstillinger» — who sees the advanced panel in the blocks (#471).
 *
 * Every block keeps its basic controls in its option band and puts the rest in
 * one collapsed «Avanserte innstillinger» panel (src/components/AdvancedSettings.tsx).
 * This file adds ONE optional site setting on Settings → Writing: hide that
 * panel for editors who are not allowed to change the design (users without
 * the `edit_theme_options` capability).
 *
 * Default OFF: everybody sees the panel, exactly as before the setting existed.
 * Hiding the panel only hides controls; it never changes a saved block.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_ADVANCED_SETTINGS_LOADED' ) ) {
	return;
}
define( 'CB_ADVANCED_SETTINGS_LOADED', true );

define( 'CB_HIDE_ADVANCED_OPTION', 'cb_hide_advanced_settings' );

/**
 * Whether the current user may see «Avanserte innstillinger» in the blocks.
 *
 * True unless the site setting is on AND the user lacks the design capability.
 * The capability can be changed with the `cb_advanced_settings_capability`
 * filter, and the final answer with `cb_show_advanced_settings`.
 */
if ( ! function_exists( 'cb_user_sees_advanced_settings' ) ) {
	function cb_user_sees_advanced_settings(): bool {
		$hide = (bool) get_option( CB_HIDE_ADVANCED_OPTION, false );
		$cap  = (string) apply_filters( 'cb_advanced_settings_capability', 'edit_theme_options' );
		$show = ! $hide || current_user_can( $cap );

		return (bool) apply_filters( 'cb_show_advanced_settings', $show );
	}
}

/* ── Register the setting + field on Settings → Writing ───────────────────── */
add_action( 'admin_init', function (): void {
	register_setting( 'writing', CB_HIDE_ADVANCED_OPTION, [
		'type'              => 'boolean',
		'sanitize_callback' => 'rest_sanitize_boolean',
		'default'           => false,
	] );

	add_settings_field(
		'cb_hide_advanced_settings_field',
		__( 'Advanced settings in blocks', 'styrk-blocks' ),
		'cb_hide_advanced_settings_render_field',
		'writing',
		'default'
	);
} );

/**
 * Checkbox renderer for the setting.
 */
if ( ! function_exists( 'cb_hide_advanced_settings_render_field' ) ) {
	function cb_hide_advanced_settings_render_field(): void {
		$hide = (bool) get_option( CB_HIDE_ADVANCED_OPTION, false );
		?>
		<label for="cb_hide_advanced_settings">
			<input type="checkbox" id="cb_hide_advanced_settings" name="<?php echo esc_attr( CB_HIDE_ADVANCED_OPTION ); ?>" value="1" <?php checked( $hide ); ?> />
			<?php esc_html_e( 'Hide «Advanced settings» for editors who may not change the design', 'styrk-blocks' ); ?>
		</label>
		<p class="description">
			<?php esc_html_e( 'Editors still change text, images, layout and colours. Administrators always see everything. Existing pages do not change.', 'styrk-blocks' ); ?>
		</p>
		<?php
	}
}

/* ── Tell the block editor ────────────────────────────────────────────────── */
add_action( 'enqueue_block_editor_assets', function (): void {
	if ( ! wp_script_is( 'styrk-blocks-controls', 'registered' ) ) {
		return;
	}
	wp_add_inline_script(
		'styrk-blocks-controls',
		'window.styrkBlocksEditor = Object.assign( window.styrkBlocksEditor || {}, '
			. wp_json_encode( [ 'showAdvancedSettings' => cb_user_sees_advanced_settings() ] )
			. ' );',
		'before'
	);
} );
