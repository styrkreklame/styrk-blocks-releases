<?php
/**
 * Post cards — the card grid's source logic and card markup, shared.
 *
 * Featured Projects was the only block that rendered these cards, so the
 * query (newest / picked / manual order) and the card markup lived inside its
 * template. The Showcase block shows the same cards in its second row, for
 * any post type. Both now call these two functions, so a fix to the card or
 * to the ordering lands in both blocks at once.
 *
 * @package styrk-blocks
 */

defined( 'ABSPATH' ) || exit;

if ( ! function_exists( 'cb_post_card_taxonomy' ) ) {
	/**
	 * The taxonomy whose terms a card shows as its labels.
	 *
	 * @param string $post_type Post type slug.
	 * @return string Taxonomy slug, or '' when the type has no label taxonomy.
	 */
	function cb_post_card_taxonomy( string $post_type ): string {
		$map = [
			'project' => 'project_category',
			'post'    => 'category',
			'product' => 'product_cat',
		];
		return $map[ $post_type ] ?? '';
	}
}

if ( ! function_exists( 'cb_post_cards_posts' ) ) {
	/**
	 * The posts a card grid shows, in display order.
	 *
	 * - Picked: exactly the picked ids, in the picked order. Count and
	 *   category do not apply — the selection is the source of truth.
	 * - Manual order: decides SEQUENCE, not membership. Everything the
	 *   filters allow is fetched, ids in the saved order go first, anything
	 *   else follows newest first, then the list is cut to `per_page`. (It
	 *   used to set post__in, which pinned the grid to the projects that
	 *   existed when the order was dragged.)
	 * - Otherwise: the newest `per_page`, optionally in one category.
	 *
	 * @param array $args {
	 *     @type string $post_type    Post type. Default 'project'.
	 *     @type int    $per_page     How many to show. Default 6.
	 *     @type int[]  $picked_ids   Picked ids; used when non-empty.
	 *     @type int    $category     Term id in the type's label taxonomy.
	 *     @type int[]  $manual_order Saved drag order.
	 * }
	 * @return WP_Post[] Posts to render.
	 */
	function cb_post_cards_posts( array $args ): array {
		$post_type    = (string) ( $args['post_type'] ?? 'project' );
		$per_page     = (int) ( $args['per_page'] ?? 6 );
		$picked_ids   = array_values( array_filter( array_map( 'intval', (array) ( $args['picked_ids'] ?? [] ) ) ) );
		$category     = (int) ( $args['category'] ?? 0 );
		$manual_order = $picked_ids ? [] : array_filter( array_map( 'intval', (array) ( $args['manual_order'] ?? [] ) ) );
		$taxonomy     = cb_post_card_taxonomy( $post_type );

		$query_args = [
			'post_type'      => $post_type,
			'posts_per_page' => $per_page,
			'post_status'    => 'publish',
			'no_found_rows'  => true,
			'orderby'        => 'date',
			'order'          => 'DESC',
		];

		if ( ! empty( $manual_order ) ) {
			$query_args['posts_per_page'] = -1;
		}

		if ( $picked_ids ) {
			$query_args['post__in']       = $picked_ids;
			$query_args['orderby']        = 'post__in';
			$query_args['order']          = 'ASC';
			$query_args['posts_per_page'] = -1;
		} elseif ( $category && '' !== $taxonomy ) {
			$query_args['tax_query'] = [ [
				'taxonomy' => $taxonomy,
				'field'    => 'term_id',
				'terms'    => $category,
			] ];
		}

		$query = new WP_Query( $query_args );
		$posts = (array) $query->posts;

		if ( ! empty( $manual_order ) ) {
			// Ids in the saved order first; the rest keep their date position
			// behind them, so a newly published post shows up instead of
			// staying invisible until someone re-drags the list.
			$rank = array_flip( $manual_order );
			usort( $posts, static function ( $a, $b ) use ( $rank ) {
				$ra = $rank[ $a->ID ] ?? PHP_INT_MAX;
				$rb = $rank[ $b->ID ] ?? PHP_INT_MAX;
				if ( $ra !== $rb ) {
					return $ra <=> $rb;
				}
				return strcmp( $b->post_date, $a->post_date );
			} );
			if ( $per_page > 0 ) {
				$posts = array_slice( $posts, 0, $per_page );
			}
		}

		return $posts;
	}
}

if ( ! function_exists( 'cb_the_post_card' ) ) {
	/**
	 * Print one card: photo (or the placeholder image, or a monogram), label
	 * pills, title and the location · year line. The whole card is the link.
	 *
	 * Every value is escaped here, at output.
	 *
	 * @param WP_Post|object $post Post to render (needs ->ID).
	 * @param array          $opts {
	 *     @type string $card_style       Inline style for the card (radius, colours).
	 *     @type string $body_style       Inline style for the text area.
	 *     @type string $title_style      Inline style for the title.
	 *     @type string $meta_style       Inline style for the meta line.
	 *     @type string $pill_style       Inline style for each label pill (radius, fill).
	 *     @type string $pill_bg          Pill fill (hex); empty = theme accent.
	 *     @type string $pill_text        Author-picked pill text (hex). Kept
	 *                                    only when it reaches 4.5:1 on the fill.
	 *     @type string $class            Extra classes on the card.
	 *     @type bool   $aria_label       Give the link «See project: <title>» as its name.
	 * }
	 */
	function cb_the_post_card( $post, array $opts = [] ): void {
		$post_id    = (int) $post->ID;
		$title      = (string) get_the_title( $post_id );
		$location   = (string) get_post_meta( $post_id, '_cb_location', true );
		$year       = (int) get_post_meta( $post_id, '_cb_year', true );
		$photo_id   = (int) get_post_thumbnail_id( $post_id );
		$taxonomy   = cb_post_card_taxonomy( (string) ( $post->post_type ?? 'project' ) );
		$terms      = '' !== $taxonomy ? get_the_terms( $post_id, $taxonomy ) : [];
		$term_names = ( $terms && ! is_wp_error( $terms ) ) ? array_values( wp_list_pluck( $terms, 'name' ) ) : [];
		$pill_style = (string) ( $opts['pill_style'] ?? '' );
		// Pill text by contrast (#491): white fails on a light accent, so
		// pick white or the dark ink, whichever reaches 4.5:1 on the fill.
		// Mirrored in the editor by pillTextColor() (src/components/roleColors.ts).
		$pill_text = (string) ( $opts['pill_text'] ?? '' );
		if ( function_exists( 'cb_pill_text_color' ) && function_exists( 'cb_theme_color' ) ) {
			$pill_fill = (string) ( $opts['pill_bg'] ?? '' );
			$pill_text = cb_pill_text_color(
				'' !== $pill_fill ? $pill_fill : cb_theme_color( 'accent', '#f0a83c' ),
				$pill_text,
				cb_theme_color( 'primary', '#0a2020' )
			);
		}
		// White is the stylesheet default; only print a colour that differs,
		// or one the author picked, so passing cards keep their markup.
		if ( '' !== $pill_text && ( '' !== (string) ( $opts['pill_text'] ?? '' ) || '#ffffff' !== strtolower( $pill_text ) ) ) {
			$pill_style .= 'color:' . $pill_text . ';';
		}
		$class      = trim( 'cb-project-card bg-white shadow-sm border border-muted overflow-hidden flex flex-col no-underline ' . ( $opts['class'] ?? '' ) );
		$image_args = [
			'class'    => 'absolute inset-0 w-full h-full object-cover',
			'loading'  => 'lazy',
			'decoding' => 'async',
			'alt'      => '',
		];
		/* translators: %s: project title */
		$aria = empty( $opts['aria_label'] ) ? '' : sprintf( __( 'See project: %s', 'styrk-blocks' ), $title );
		?>
		<a href="<?php echo esc_url( (string) get_permalink( $post_id ) ); ?>"
			<?php if ( '' !== $aria ) : ?>
				aria-label="<?php echo esc_attr( $aria ); ?>"
			<?php endif; ?>
			class="<?php echo esc_attr( $class ); ?>"
			style="<?php echo esc_attr( (string) ( $opts['card_style'] ?? '' ) ); ?>">
			<?php if ( $photo_id ) : ?>
				<div class="cb-project-photo relative overflow-hidden aspect-[4/3] w-full">
					<?php echo wp_get_attachment_image( $photo_id, 'large', false, $image_args ); ?>
					<?php cb_the_post_card_badges( $term_names, $pill_style ); ?>
				</div>
			<?php else : ?>
				<?php
				// No featured image: the global card placeholder image
				// (Settings → General), else the first-letter monogram.
				// Contained, not cropped, so the brand mark reads.
				$placeholder_id = function_exists( 'cb_get_card_placeholder_id' ) ? cb_get_card_placeholder_id() : 0;
				?>
				<?php if ( $placeholder_id ) : ?>
					<div class="cb-project-photo cb-project-photo--placeholder relative overflow-hidden flex items-center justify-center bg-surface aspect-[4/3] w-full p-8">
						<?php
						echo wp_get_attachment_image( $placeholder_id, 'medium', false, [
							'class'    => 'max-w-[60%] max-h-[60%] w-auto h-auto object-contain opacity-70',
							'loading'  => 'lazy',
							'decoding' => 'async',
							'alt'      => '',
						] );
						?>
						<?php cb_the_post_card_badges( $term_names, $pill_style ); ?>
					</div>
				<?php else : ?>
					<div class="flex items-center justify-center bg-surface text-accent font-bold aspect-[4/3] w-full">
						<span class="text-3xl"><?php echo esc_html( mb_substr( wp_strip_all_tags( $title ), 0, 1 ) ); ?></span>
					</div>
				<?php endif; ?>
			<?php endif; ?>
			<div class="p-6 flex flex-col gap-2 flex-1" style="<?php echo esc_attr( (string) ( $opts['body_style'] ?? '' ) ); ?>">
				<h3 class="text-xl font-semibold text-primary m-0 leading-tight" style="<?php echo esc_attr( (string) ( $opts['title_style'] ?? '' ) ); ?>">
					<?php echo wp_kses_post( $title ); ?>
				</h3>
				<?php if ( $location || $year ) : ?>
					<p class="cb-project-card__meta text-sm text-secondary m-0" style="<?php echo esc_attr( (string) ( $opts['meta_style'] ?? '' ) ); ?>">
						<?php echo esc_html( $location . ( $location && $year ? ' · ' : '' ) . ( $year ? (string) $year : '' ) ); ?>
					</p>
				<?php endif; ?>
			</div>
		</a>
		<?php
	}
}

if ( ! function_exists( 'cb_the_post_card_badges' ) ) {
	/**
	 * One pill per label term, not a comma-joined string.
	 *
	 * @param string[] $names      Term names.
	 * @param string   $pill_style Inline style for each pill.
	 */
	function cb_the_post_card_badges( array $names, string $pill_style ): void {
		if ( ! $names ) {
			return;
		}
		?>
		<div class="cb-project-card__badges">
			<?php foreach ( $names as $name ) : ?>
				<span class="cb-project-card__badge"<?php echo $pill_style ? ' style="' . esc_attr( $pill_style ) . '"' : ''; ?>><?php echo esc_html( (string) $name ); ?></span>
			<?php endforeach; ?>
		</div>
		<?php
	}
}
