<?php
/**
 * Process block: layout, CTA placement and number-style decisions.
 *
 * Kept out of template.php so they can be tested without rendering a page.
 * Every option is opt-in: with none of them set the helpers return nothing,
 * so the markup of a block saved before they existed does not change.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'cb_process_layout' ) ) {
	/**
	 * 'list' (the vertical stack, default) or 'grid' (steps side by side).
	 *
	 * @param array $attributes Block attributes.
	 * @return string 'list' | 'grid'
	 */
	function cb_process_layout( array $attributes ): string {
		return 'grid' === ( $attributes['layout'] ?? 'list' ) ? 'grid' : 'list';
	}
}

if ( ! function_exists( 'cb_process_cta_placement' ) ) {
	/**
	 * Where the button goes: under the steps (default) or in the header row,
	 * opposite the heading.
	 *
	 * @param array $attributes Block attributes.
	 * @return string 'below' | 'header'
	 */
	function cb_process_cta_placement( array $attributes ): string {
		return 'header' === ( $attributes['ctaPlacement'] ?? 'below' ) ? 'header' : 'below';
	}
}

if ( ! function_exists( 'cb_process_wrapper_classes' ) ) {
	/**
	 * Extra classes for the section, only for the options that were chosen.
	 *
	 * A grid carries its column count (the step count, at most four) so the
	 * stylesheet can give three steps three columns instead of leaving a gap.
	 *
	 * @param array $attributes Block attributes.
	 * @param int   $count      Steps being rendered.
	 * @return string[] Empty for a block that asked for none of the options.
	 */
	function cb_process_wrapper_classes( array $attributes, int $count ): array {
		$classes = [];
		if ( 'grid' === cb_process_layout( $attributes ) ) {
			$classes[] = 'cb-process--grid';
			$classes[] = 'cb-process--cols-' . max( 1, min( 4, $count ) );
		}
		if ( 'header' === cb_process_cta_placement( $attributes ) ) {
			$classes[] = 'cb-process--cta-header';
		}
		if ( 'outline' === ( $attributes['numberStyle'] ?? '' ) ) {
			$classes[] = 'cb-process--num-outline';
		}
		return $classes;
	}
}

if ( ! function_exists( 'cb_process_visible_count' ) ) {
	/**
	 * How many steps the template will print (a step with no title and no body
	 * is skipped), used for the grid's column count.
	 *
	 * @param array $steps Saved steps.
	 * @return int
	 */
	function cb_process_visible_count( array $steps ): int {
		$n = 0;
		foreach ( $steps as $step ) {
			if ( ! is_array( $step ) ) {
				continue;
			}
			$has_text = '' !== (string) ( $step['title'] ?? '' ) || '' !== (string) ( $step['body'] ?? '' );
			$non_empty = static fn ( $task ): bool => '' !== (string) $task;
			$has_cols  = array() !== array_filter( (array) ( $step['clientTasks'] ?? [] ), $non_empty )
				|| array() !== array_filter( (array) ( $step['firmTasks'] ?? [] ), $non_empty );
			if ( $has_text || $has_cols ) {
				++$n;
			}
		}
		return $n;
	}
}
