<?php
/**
 * Site-wide default corner radius.
 *
 * Corner radius used to be set per block, so a site easily ended up with
 * several radii. A site can now set ONE radius in its theme.json:
 *
 *   "settings": { "custom": { "styrkBlocks": { "radius": "6px" } } }
 *
 * WordPress turns that into the CSS variable --wp--custom--styrk-blocks--radius.
 * Every card, image and button radius that the author has NOT changed follows
 * it. A radius the author picked in the editor still wins.
 *
 * Backwards compatible by construction: when the site sets nothing, the
 * variable is undefined and the var() fallback is the exact pixel value the
 * block rendered before, so existing sites see no change.
 *
 * "Not changed" means "equal to the block.json default". The block editor
 * never saves an attribute whose value equals its default, so the two are
 * the same thing, and the editor preview (src/components/radius.ts, the TS
 * twin of this file) can apply the very same rule.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! defined( 'CB_SITE_RADIUS_VAR' ) ) {
	define( 'CB_SITE_RADIUS_VAR', '--wp--custom--styrk-blocks--radius' );
}

if ( ! function_exists( 'cb_radius_css' ) ) {
	/**
	 * CSS value for a corner radius.
	 *
	 * @param int|float|string $value   The block's (clamped) radius in px.
	 * @param int              $default The block.json default for that attribute.
	 * @return string `Npx`, or `var(<site radius>,Npx)` when $value is the default.
	 */
	function cb_radius_css( $value, int $default ): string {
		$value = (int) $value;
		if ( $value === $default ) {
			return 'var(' . CB_SITE_RADIUS_VAR . ',' . $default . 'px)';
		}
		return $value . 'px';
	}
}
