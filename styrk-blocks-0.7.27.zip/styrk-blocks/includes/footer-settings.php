<?php
/**
 * Footer Settings — admin page and helpers.
 *
 * Registers an options page under Settings → Footer where site admins
 * can manage company description, address, phone, email, copyright,
 * and the "follow us" column heading. Social links themselves are
 * managed via the social_link CPT (see styrk-blocks.php).
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// Idempotency guard — see header-settings.php for the rationale.
if ( defined( 'CB_FOOTER_SETTINGS_LOADED' ) ) return;
define( 'CB_FOOTER_SETTINGS_LOADED', true );

/* ── Option key (all stored under one serialized option) ────────────────────── */
define( 'CB_FOOTER_OPTION', 'cb_footer_settings' );

/**
 * Default values for every footer field.
 */
function cb_footer_defaults(): array {
	$site_name = get_bloginfo( 'name' ) ?: 'Bedriftsnavn';
	return [
		// Attachment ID of the white/light logo variant used in the dark
		// footer. Zero = no custom logo uploaded; the shortcode falls back
		// to the main header logo (CSS-inverted) or the theme asset.
		// (This used to live under cb_header_settings as logo_white_id —
		// moved to footer settings in v1.6.5 to group with other footer
		// fields. A one-shot migration copies the old value across.)
		'logo_white_id'  => 0,
		'description'    => 'Kort beskrivelse av bedriften – én eller to setninger som forklarer hva dere gjør.',
		'address'        => "Gateadresse 1\n0000 Sted, Norge",
		'email'          => 'post@bedriftsnavn.no',
		'phone_1'        => '+47 00 00 00 00',
		'phone_2'        => '',
		// Norwegian organisasjonsnummer (9 digits). Empty by default — the
		// shortcode output is silently skipped when unset, so sites outside
		// NO or without a registered entity don't get a broken "Org.nr."
		// label. Formatted for display as "NNN NNN NNN" regardless of how
		// the admin enters it.
		'org_number'     => '',
		'copyright'      => '© ' . gmdate( 'Y' ) . ' ' . $site_name . '. Alle rettigheter forbeholdt.',
		'social_heading' => 'Følg oss',
		'credits'        => 'Utvikling og design av Styrk Reklame AS',
		// One link per line, Label|URL format. Empty by default — legal
		// links only appear in the bottom bar when this field is filled.
		'legal_links'    => '',
		// Certification badges shown in the footer top row (paired with
		// the logo). Up to three. Each is an attachment ID — empty/0
		// means no badge, and the [footer_certs] shortcode renders only
		// the slots that are set, so a site with one cert doesn't get
		// two empty placeholders. Optional one-line text under each
		// badge for screen readers + a tooltip.
		'cert_1_id'      => 0,
		'cert_1_label'   => '',
		'cert_2_id'      => 0,
		'cert_2_label'   => '',
		'cert_3_id'      => 0,
		'cert_3_label'   => '',
	];
}

/**
 * Return merged (saved + defaults) footer settings.
 */
function cb_get_footer_settings(): array {
	$saved = get_option( CB_FOOTER_OPTION, [] );
	return wp_parse_args( $saved, cb_footer_defaults() );
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_footer_settings_menu(): void {
	add_options_page(
		__( 'Footer Settings', 'styrk-blocks' ),
		__( 'Footer', 'styrk-blocks' ),
		'manage_options',
		'cb-footer-settings',
		'cb_footer_settings_page'
	);
}
add_action( 'admin_menu', 'cb_footer_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

function cb_footer_settings_init(): void {
	register_setting( 'cb_footer_group', CB_FOOTER_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_footer_sanitize',
		'default'           => cb_footer_defaults(),
	] );

	/* ── Section: Logo ────────────────────────────────────────────────────────
	 * Footer-specific logo (white variant on the dark bar). Previously lived
	 * under Settings → Header, which was confusing UX — the logo shown in
	 * the footer should be edited from the footer settings page. */
	add_settings_section(
		'cb_footer_logo',
		__( 'Logo', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'White-variant logo used in the dark footer bar. Falls back to the main header logo (auto-inverted) or the theme asset if not set.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_logo_white',
		__( 'White Logo (footer)', 'styrk-blocks' ),
		'cb_footer_render_media_field',
		'cb-footer-settings',
		'cb_footer_logo',
		[
			'key'         => 'logo_white_id',
			'description' => __( 'SVG or PNG recommended. Should be a white/light logo on transparent background — it sits on the navy footer bar.', 'styrk-blocks' ),
		]
	);

	/* ── Section: Certification badges ────────────────────────────────────────
	 * Up to three small marks shown next to the footer logo (Mester, Lærling,
	 * Sentral Godkjenning, Miljøfyrtårn, etc.). Slots are independent — set
	 * one, two, or three; empty slots are skipped at render time. */
	add_settings_section(
		'cb_footer_certs',
		__( 'Certification Badges', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__(
				'Up to three certification logos shown on the footer top row beside the company logo. SVG or transparent PNG strongly recommended — they sit on the dark footer bar and look best as monochrome marks. Empty slots are hidden automatically.',
				'styrk-blocks'
			)
		),
		'cb-footer-settings'
	);

	for ( $i = 1; $i <= 3; $i++ ) {
		add_settings_field(
			"cb_footer_cert_{$i}",
			sprintf( __( 'Badge %d', 'styrk-blocks' ), $i ),
			'cb_footer_render_media_field',
			'cb-footer-settings',
			'cb_footer_certs',
			[
				'key'         => "cert_{$i}_id",
				'description' => __( 'Recommended: a transparent SVG or PNG of a single mark. White or light strokes on transparent background work best on the dark footer.', 'styrk-blocks' ),
			]
		);
		add_settings_field(
			"cb_footer_cert_{$i}_label",
			sprintf( __( 'Badge %d alt text', 'styrk-blocks' ), $i ),
			'cb_footer_render_field',
			'cb-footer-settings',
			'cb_footer_certs',
			[
				'key'         => "cert_{$i}_label",
				'type'        => 'text',
				'description' => __( 'Short description for screen readers, shown as a tooltip on hover (e.g. "Mesterbedrift", "Godkjent for ansvarsrett").', 'styrk-blocks' ),
			]
		);
	}

	/* ── Section: Company info ──────────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_company',
		__( 'Company Information', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Text shown in the first footer column, below the company name.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_description',
		__( 'Company Description', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_company',
		[ 'key' => 'description', 'type' => 'textarea' ]
	);

	/* ── Section: Contact details ───────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_contact',
		__( 'Contact Details', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Shown in the "Kontakt" footer column.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	$contact_fields = [
		'address'    => [ 'label' => __( 'Address', 'styrk-blocks' ),  'type' => 'textarea' ],
		'email'      => [ 'label' => __( 'Email', 'styrk-blocks' ),    'type' => 'email' ],
		'phone_1'    => [ 'label' => __( 'Phone 1', 'styrk-blocks' ),  'type' => 'tel' ],
		'phone_2'    => [ 'label' => __( 'Phone 2', 'styrk-blocks' ),  'type' => 'tel' ],
		'org_number' => [
			'label'       => __( 'Organisasjonsnummer', 'styrk-blocks' ),
			'type'        => 'text',
			'description' => __( '9-digit Norwegian org number (e.g. 987 654 321). Leave empty if not applicable. Displays as "Org.nr. NNN NNN NNN" in the contact column.', 'styrk-blocks' ),
		],
	];

	foreach ( $contact_fields as $key => $field ) {
		add_settings_field(
			"cb_footer_{$key}",
			$field['label'],
			'cb_footer_render_field',
			'cb-footer-settings',
			'cb_footer_contact',
			[ 'key' => $key, 'type' => $field['type'] ]
		);
	}

	/* ── Section: Social / Følg oss ─────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_social',
		__( 'Social Media Column', 'styrk-blocks' ),
		'cb_footer_social_section_description',
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_social_heading',
		__( 'Column Heading', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_social',
		[ 'key' => 'social_heading', 'type' => 'text' ]
	);

	/* ── Section: Copyright ─────────────────────────────────────────────────── */
	add_settings_section(
		'cb_footer_bottom',
		__( 'Bottom Bar', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'The small text shown at the very bottom of the footer.', 'styrk-blocks' )
		),
		'cb-footer-settings'
	);

	add_settings_field(
		'cb_footer_copyright',
		__( 'Copyright Text', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_bottom',
		[ 'key' => 'copyright', 'type' => 'text' ]
	);

	add_settings_field(
		'cb_footer_credits',
		__( 'Credits', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_bottom',
		[ 'key' => 'credits', 'type' => 'text' ]
	);

	add_settings_field(
		'cb_footer_legal_links',
		__( 'Legal Links', 'styrk-blocks' ),
		'cb_footer_render_field',
		'cb-footer-settings',
		'cb_footer_bottom',
		[
			'key'         => 'legal_links',
			'type'        => 'textarea',
			'description' => __(
				'One link per line, in the format "Label|URL". E.g.:<br><code>Personvern|/personvern</code><br><code>Informasjonskapsler|/informasjonskapsler</code><br>Leave empty to hide the legal-nav row.',
				'styrk-blocks'
			),
		]
	);
}
add_action( 'admin_init', 'cb_footer_settings_init' );

/**
 * Social section description — includes a link to manage social links.
 */
function cb_footer_social_section_description(): void {
	$social_url = admin_url( 'edit.php?post_type=social_link' );
	$add_url    = admin_url( 'post-new.php?post_type=social_link' );
	printf(
		'<p>%s</p><p><a href="%s" class="button">%s</a> &nbsp; <a href="%s" class="button button-primary">%s</a></p>',
		esc_html__( 'The social media icons are managed as individual posts. Use the links below to add or edit them.', 'styrk-blocks' ),
		esc_url( $social_url ),
		esc_html__( 'Manage Social Links', 'styrk-blocks' ),
		esc_url( $add_url ),
		esc_html__( '+ Add Social Link', 'styrk-blocks' )
	);
}

/* ── Field renderer ─────────────────────────────────────────────────────────── */

function cb_footer_render_field( array $args ): void {
	$settings    = cb_get_footer_settings();
	$key         = $args['key'];
	$type        = $args['type'];
	$description = $args['description'] ?? '';
	$value       = $settings[ $key ] ?? '';
	$name        = CB_FOOTER_OPTION . "[{$key}]";
	$id          = "cb_footer_{$key}";

	if ( $type === 'textarea' ) {
		printf(
			'<textarea id="%s" name="%s" rows="4" class="large-text" aria-label="%s">%s</textarea>',
			esc_attr( $id ),
			esc_attr( $name ),
			esc_attr( $key ),
			esc_textarea( $value )
		);
	} else {
		printf(
			'<input type="%s" id="%s" name="%s" value="%s" class="regular-text" aria-label="%s"/>',
			esc_attr( $type ),
			esc_attr( $id ),
			esc_attr( $name ),
			esc_attr( $value ),
			esc_attr( $key )
		);
	}

	if ( $description ) {
		// wp_kses_post allows the <br> + <code> tags used in the inline
		// help text without opening up arbitrary markup.
		printf( '<p class="description">%s</p>', wp_kses_post( $description ) );
	}
}

/* ── Media-uploader field ──────────────────────────────────────────────────── */

/**
 * Render the logo-picker (hidden attachment-ID input + preview + upload button).
 * The inline JS on cb_footer_settings_page wires this up to wp.media.
 */
function cb_footer_render_media_field( array $args ): void {
	$settings      = cb_get_footer_settings();
	$key           = $args['key'];
	$description   = $args['description'] ?? '';
	$attachment_id = (int) ( $settings[ $key ] ?? 0 );
	$name          = CB_FOOTER_OPTION . "[{$key}]";
	$field_id      = "cb_footer_{$key}";
	$preview_url   = $attachment_id ? wp_get_attachment_image_url( $attachment_id, 'medium' ) : '';
	// White logo is meant to sit on the navy footer bar — preview on navy so
	// the admin sees what it'll actually look like.
	$bg            = '#00486A';
	?>
	<div class="cb-media-field" id="<?php echo esc_attr( $field_id ); ?>_wrapper">
		<div class="cb-media-preview" style="margin-bottom:10px;padding:16px;background:<?php echo esc_attr( $bg ); ?>;border-radius:8px;display:<?php echo $preview_url ? 'block' : 'none'; ?>;max-width:320px;">
			<img id="<?php echo esc_attr( $field_id ); ?>_preview" src="<?php echo esc_url( $preview_url ); ?>" alt="" style="max-width:100%;max-height:120px;width:auto;height:auto;display:block;" />
		</div>
		<input type="hidden" id="<?php echo esc_attr( $field_id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $attachment_id ); ?>" />
		<button type="button" class="button cb-upload-btn" data-target="<?php echo esc_attr( $field_id ); ?>" data-preview-bg="<?php echo esc_attr( $bg ); ?>">
			<?php echo $preview_url ? esc_html__( 'Change Logo', 'styrk-blocks' ) : esc_html__( 'Upload Logo', 'styrk-blocks' ); ?>
		</button>
		<?php if ( $preview_url ) : ?>
			<button type="button" class="button cb-remove-btn" data-target="<?php echo esc_attr( $field_id ); ?>" style="margin-left:8px;color:#b32d2e;">
				<?php esc_html_e( 'Remove', 'styrk-blocks' ); ?>
			</button>
		<?php endif; ?>
		<?php if ( $description ) : ?>
			<p class="description" style="margin-top:8px;"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

function cb_footer_sanitize( $input ): array {
	$defaults  = cb_footer_defaults();
	$sanitized = [];

	foreach ( $defaults as $key => $default ) {
		if ( ! isset( $input[ $key ] ) ) {
			$sanitized[ $key ] = $default;
			continue;
		}
		$sanitized[ $key ] = match ( $key ) {
			'logo_white_id',
			'cert_1_id',
			'cert_2_id',
			'cert_3_id'     => absint( $input[ $key ] ),
			'email'         => sanitize_email( $input[ $key ] ),
			// Strip anything that isn't a digit. Storing bare digits keeps
			// the display formatter in one place (see cb_format_org_number)
			// and lets admins paste "987 654 321", "987-654-321", or
			// "Org.nr. 987654321" interchangeably.
			'org_number'    => preg_replace( '/\D+/', '', (string) $input[ $key ] ),
			'address',
			'description',
			'legal_links'   => sanitize_textarea_field( $input[ $key ] ),
			default         => sanitize_text_field( $input[ $key ] ),
		};
	}

	return $sanitized;
}

/* ── Page template ──────────────────────────────────────────────────────────── */

function cb_footer_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	// Media modal requires these scripts — enqueue explicitly so the page
	// works even on WP installs where the admin doesn't auto-load them.
	wp_enqueue_media();
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Footer Settings', 'styrk-blocks' ); ?></h1>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'cb_footer_group' );
			do_settings_sections( 'cb-footer-settings' );
			submit_button();
			?>
		</form>
	</div>

	<script>
	(function($){
		'use strict';

		/* ── Media upload ─────────────────────────────────────────────────────
		 * Same pattern as header-settings.php — one wp.media frame per
		 * click, writes the chosen attachment ID to the hidden input and
		 * the preview image to the sibling <img>. */
		$(document).on('click', '.cb-upload-btn', function(e) {
			e.preventDefault();
			var btn      = $(this);
			var targetId = btn.data('target');
			var bgColor  = btn.data('preview-bg') || '#f0f0f1';
			var frame    = wp.media({
				title:    '<?php echo esc_js( __( 'Select Logo', 'styrk-blocks' ) ); ?>',
				button:   { text: '<?php echo esc_js( __( 'Use as Logo', 'styrk-blocks' ) ); ?>' },
				multiple: false,
				library:  { type: ['image', 'image/svg+xml'] }
			});

			frame.on('select', function() {
				var attachment = frame.state().get('selection').first().toJSON();
				var previewUrl = attachment.sizes && attachment.sizes.medium
					? attachment.sizes.medium.url
					: attachment.url;

				$('#' + targetId).val(attachment.id);
				$('#' + targetId + '_preview').attr('src', previewUrl);
				$('#' + targetId + '_wrapper .cb-media-preview')
					.css({ display: 'block', background: bgColor }).show();
				btn.text('<?php echo esc_js( __( 'Change Logo', 'styrk-blocks' ) ); ?>');

				if ( ! btn.siblings('.cb-remove-btn').length ) {
					$('<button type="button" class="button cb-remove-btn" data-target="' + targetId + '" style="margin-left:8px;color:#b32d2e;"><?php echo esc_js( __( 'Remove', 'styrk-blocks' ) ); ?></button>')
						.insertAfter(btn);
				}
			});
			frame.open();
		});

		$(document).on('click', '.cb-remove-btn', function(e) {
			e.preventDefault();
			var targetId = $(this).data('target');
			$('#' + targetId).val('0');
			$('#' + targetId + '_preview').attr('src', '');
			$('#' + targetId + '_wrapper .cb-media-preview').hide();
			$(this).siblings('.cb-upload-btn').text('<?php echo esc_js( __( 'Upload Logo', 'styrk-blocks' ) ); ?>');
			$(this).remove();
		});
	})(jQuery);
	</script>
	<?php
}

/* ── One-shot migration: header.logo_white_id → footer.logo_white_id ─────────
 * Pre-v1.6.5 the white logo lived under Settings → Header. Client sites that
 * had set it there need the value copied into the new footer-settings home.
 * Guard with a marker option so we only run once per site, even if the user
 * deliberately clears the new value later. */
function cb_footer_migrate_white_logo_from_header(): void {
	$marker = 'cb_footer_logo_white_migrated';
	if ( get_option( $marker ) ) {
		return;
	}

	$header = get_option( 'cb_header_settings', [] );
	$source = (int) ( $header['logo_white_id'] ?? 0 );

	if ( $source > 0 ) {
		$footer = get_option( CB_FOOTER_OPTION, [] );
		// Only populate if the target is still empty / unset — never clobber
		// an intentional setting the admin has already made in the new home.
		if ( empty( $footer['logo_white_id'] ) ) {
			$footer['logo_white_id'] = $source;
			update_option( CB_FOOTER_OPTION, $footer );
		}
	}

	update_option( $marker, 1, /* autoload = */ true );
}
add_action( 'admin_init', 'cb_footer_migrate_white_logo_from_header' );

/* ── Seed defaults on first activation ──────────────────────────────────────── */

function cb_footer_seed_defaults(): void {
	if ( get_option( CB_FOOTER_OPTION ) ) {
		return;
	}
	update_option( CB_FOOTER_OPTION, cb_footer_defaults() );
}
add_action( 'admin_init', 'cb_footer_seed_defaults' );
