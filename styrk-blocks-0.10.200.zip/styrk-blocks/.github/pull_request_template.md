## What and why

<!-- One or two sentences. What changes, and what it fixes or enables. -->

## Issues

<!--
REQUIRED if an issue exists. Use a closing keyword so the issue closes itself on
merge — this is the one line that keeps the tracker honest.

    Fixes #123
    Closes #123
    Refs #123        <- use this when the PR advances an issue without finishing it

Why it matters: 40 PRs merged between 13 July and 20 August 2026 and almost none
referenced an issue. Completed work stayed open, a perf regression went
unrecorded, and reconciling it by hand meant re-reading the codebase to find out
what had already been done. See #282.

If no issue exists, say "None" — that is a valid answer, not a skipped field.
-->

Fixes #

## Verification

<!--
What did you actually run or look at? Paste the evidence, not the intention.

Gates run by CI on every PR (13): php -l · security gate · PHP unit · hostile-input
render · render snapshot · tsc · Jest · lint gate · brand gate · raw-hex gate ·
parity gate · perf gate · a11y gate.

CI green is necessary, not sufficient. State separately what you verified in a
BROWSER, on which breakpoints, and on which site. Several past regressions were
green on every automated check and only visible in a screenshot.

`test:visual` cannot be run on a laptop — baselines are recorded on the Linux CI
runner. CI is the only authority for that gate.
-->

- [ ] CI green
- [ ] Verified in a browser (say where, and at which widths)

## Client-visible rendering

<!--
This plugin is COPIED into many client sites. Answer honestly.
-->

- [ ] This changes what already-published pages render
- [ ] This changes a `block.json` default (i.e. what new inserts render)
- [ ] Neither — internal only

If either box is ticked, say which sites you checked and whether this needs to
wait for a freeze window. Do not assume a change is invisible because it was
invisible on the one site you had open — verify on a site that can actually show
the fault.

## Ratchets

<!--
If a ratcheted count moved, say so and lock the win in. Silent movement is how
the debt became invisible: the brand gate quietly went 80 → 78 and nobody
recorded it.
-->

- [ ] No ratchet changed
- [ ] A ratchet went **down** — baseline lowered in the same PR
