<?php
/**
 * Card placeholder image — a single GLOBAL setting under Settings → General.
 *
 * Cards that have no featured image (project cards, article/aktuelt cards)
 * fall back to this image instead of the first-letter monogram. Stored as a
 * standalone option `cb_card_placeholder_id` so it lives with the other global
 * site settings, not buried in the header panel.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_CARD_PLACEHOLDER_LOADED' ) ) {
	return;
}
define( 'CB_CARD_PLACEHOLDER_LOADED', true );

define( 'CB_CARD_PLACEHOLDER_OPTION', 'cb_card_placeholder_id' );

/**
 * Attachment ID of the global card placeholder image (0 when unset).
 */
if ( ! function_exists( 'cb_get_card_placeholder_id' ) ) {
	function cb_get_card_placeholder_id(): int {
		return (int) get_option( CB_CARD_PLACEHOLDER_OPTION, 0 );
	}
}

/* ── Register the setting + field on Settings → General ───────────────────── */
add_action( 'admin_init', function (): void {
	register_setting( 'general', CB_CARD_PLACEHOLDER_OPTION, [
		'type'              => 'integer',
		'sanitize_callback' => 'absint',
		'default'           => 0,
	] );

	add_settings_field(
		'cb_card_placeholder_field',
		__( 'Card placeholder image', 'styrk-blocks' ),
		'cb_card_placeholder_render_field',
		'general',
		'default'
	);
} );

/**
 * Media-picker field renderer (self-contained JS, uses the WP media modal).
 */
if ( ! function_exists( 'cb_card_placeholder_render_field' ) ) {
	function cb_card_placeholder_render_field(): void {
		$id      = cb_get_card_placeholder_id();
		$preview = $id ? wp_get_attachment_image_url( $id, 'medium' ) : '';
		?>
		<div class="cb-card-placeholder-field">
			<div style="margin-bottom:10px;padding:14px;background:#f0f0f1;border-radius:8px;max-width:280px;display:<?php echo $preview ? 'block' : 'none'; ?>;">
				<img id="cb_card_placeholder_preview" src="<?php echo esc_url( $preview ); ?>" alt="" style="max-width:100%;max-height:110px;width:auto;height:auto;display:block;" />
			</div>
			<input type="hidden" id="cb_card_placeholder_id" name="<?php echo esc_attr( CB_CARD_PLACEHOLDER_OPTION ); ?>" value="<?php echo esc_attr( $id ); ?>" />
			<button type="button" class="button" id="cb_card_placeholder_pick">
				<?php echo $preview ? esc_html__( 'Change image', 'styrk-blocks' ) : esc_html__( 'Select image', 'styrk-blocks' ); ?>
			</button>
			<button type="button" class="button" id="cb_card_placeholder_clear" style="margin-left:8px;color:#b32d2e;display:<?php echo $preview ? 'inline-block' : 'none'; ?>;">
				<?php esc_html_e( 'Remove', 'styrk-blocks' ); ?>
			</button>
			<p class="description" style="margin-top:8px;">
				<?php esc_html_e( 'Shown on project and article cards that have no featured image, instead of the first-letter monogram. A square brand mark works best.', 'styrk-blocks' ); ?>
			</p>
		</div>
		<script>
		( function () {
			function init() {
				var pick = document.getElementById( 'cb_card_placeholder_pick' );
				var clear = document.getElementById( 'cb_card_placeholder_clear' );
				var input = document.getElementById( 'cb_card_placeholder_id' );
				var prev = document.getElementById( 'cb_card_placeholder_preview' );
				var frame;
				if ( ! pick ) { return; }
				pick.addEventListener( 'click', function () {
					// Check wp.media at click time — by now the footer media
					// scripts have loaded (they aren't ready when this inline
					// script first parses).
					if ( ! window.wp || ! window.wp.media ) {
						window.alert( 'Media-biblioteket er ikke lastet ennå. Last siden på nytt og prøv igjen.' );
						return;
					}
					if ( frame ) { frame.open(); return; }
					frame = wp.media( { title: 'Card placeholder image', multiple: false, library: { type: 'image' } } );
					frame.on( 'select', function () {
						var a = frame.state().get( 'selection' ).first().toJSON();
						input.value = a.id;
						if ( prev ) {
							prev.src = ( a.sizes && a.sizes.medium ) ? a.sizes.medium.url : a.url;
							prev.parentNode.style.display = 'block';
						}
						pick.textContent = '<?php echo esc_js( __( 'Change image', 'styrk-blocks' ) ); ?>';
						if ( clear ) { clear.style.display = 'inline-block'; }
					} );
					frame.open();
				} );
				if ( clear ) {
					clear.addEventListener( 'click', function () {
						input.value = '';
						if ( prev ) { prev.parentNode.style.display = 'none'; }
						pick.textContent = '<?php echo esc_js( __( 'Select image', 'styrk-blocks' ) ); ?>';
						clear.style.display = 'none';
					} );
				}
			}
			if ( document.readyState === 'loading' ) {
				document.addEventListener( 'DOMContentLoaded', init );
			} else {
				init();
			}
		} )();
		</script>
		<?php
	}
}

/* Ensure the WP media modal scripts are present on Settings → General. */
add_action( 'admin_enqueue_scripts', function ( $hook ): void {
	if ( 'options-general.php' === $hook ) {
		wp_enqueue_media();
	}
} );
