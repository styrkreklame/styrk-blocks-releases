<?php
/**
 * Person schema (JSON-LD) for the `employee` custom post type.
 *
 * Emits structured data so search engines (Google, Bing) can pull
 * each employee as a Person entity tied to the company. Without
 * this, the rendered HTML reads as "name + job title + contact"
 * for humans, but crawlers don't know to treat it as a Person.
 *
 * Three emission contexts:
 *  1. Single employee post page (`is_singular('employee')`) →
 *     emit on `wp_head` exactly once.
 *  2. Employee grid block render (`employee-grid/template.php`) →
 *     emit one Person schema per card, inline.
 *  3. Single employee card block (`employee-card/template.php`) →
 *     emit one Person schema for the chosen employee, inline.
 *
 * Person fields are pulled from the meta keys registered in
 * styrk-blocks.php (`_cb_occupation`, `_cb_email`, `_cb_phone`,
 * `_cb_linkedin`, `_cb_background`) plus the post title and
 * featured image. Each Person is wired to the site Organization
 * via `worksFor` — when Rank Math (or another SEO plugin) emits
 * the canonical Organization/LocalBusiness schema, search
 * engines reconcile by `worksFor.name`.
 *
 * Doesn't conflict with Rank Math's auto-detection: Rank Math
 * looks at standard CPTs (post, page) and explicit schema
 * mappings configured in its UI. Custom CPT employees are NOT
 * auto-handled, which is the whole reason this file exists.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_SCHEMA_PERSON_LOADED' ) ) return;
define( 'CB_SCHEMA_PERSON_LOADED', true );

/**
 * Build a Person schema array for an employee post.
 * Returns null if the post is not a published employee.
 */
function cb_build_person_schema( int $post_id ): ?array {
	$post = get_post( $post_id );
	if ( ! $post || $post->post_type !== 'employee' || $post->post_status !== 'publish' ) {
		return null;
	}

	// SECURITY: every free-text value below is emitted inside a
	// <script type="application/ld+json"> block, and cb_emit_person_schema()
	// encodes it with JSON_UNESCAPED_SLASHES — which disables the `\/` escaping
	// that would normally neutralise a literal `</script>`.
	//
	// So an employee titled `Ola</script><script>alert(1)</script>` would close
	// the data block early and hand the rest to the HTML parser: a stored XSS on
	// the employee page and on every employee-grid / employee-card that renders
	// them. Stripping tags first makes `</script>` unrepresentable.
	//
	// faq-accordion/template.php already does exactly this, which is why it is
	// safe with the same JSON flags. Guarded by the `jsonld_breakout` payload in
	// tests/php/render-security-test.php.
	$name = trim( wp_strip_all_tags( (string) get_the_title( $post ) ) );
	if ( $name === '' ) return null;

	$occupation = trim( wp_strip_all_tags( (string) get_post_meta( $post_id, '_cb_occupation', true ) ) );
	$email      = trim( wp_strip_all_tags( (string) get_post_meta( $post_id, '_cb_email',      true ) ) );
	$phone      = trim( wp_strip_all_tags( (string) get_post_meta( $post_id, '_cb_phone',      true ) ) );
	$linkedin   = trim( wp_strip_all_tags( (string) get_post_meta( $post_id, '_cb_linkedin',   true ) ) );
	$background = trim( wp_strip_all_tags( (string) get_post_meta( $post_id, '_cb_background', true ) ) );
	$photo_id   = (int) get_post_thumbnail_id( $post );
	$photo_url  = $photo_id ? wp_get_attachment_image_url( $photo_id, 'large' ) : '';

	$person = [
		'@context' => 'https://schema.org',
		'@type'    => 'Person',
		'name'     => $name,
		'url'      => (string) get_permalink( $post ),
		'worksFor' => [
			'@type' => 'Organization',
			'name'  => wp_strip_all_tags( (string) get_bloginfo( 'name' ) ),
			'url'   => home_url( '/' ),
		],
	];

	if ( $occupation !== '' ) {
		$person['jobTitle'] = $occupation;
	}
	if ( $email !== '' && is_email( $email ) ) {
		$person['email'] = $email;
	}
	if ( $phone !== '' ) {
		// Strip whitespace; keep + and digits — produces e.g. "+4774839090".
		$tel = preg_replace( '/[^\d+]/', '', $phone );
		if ( $tel !== '' ) {
			$person['telephone'] = $tel;
		}
	}
	if ( $linkedin !== '' && filter_var( $linkedin, FILTER_VALIDATE_URL ) ) {
		// `sameAs` is the canonical home for external profile URLs.
		$person['sameAs'] = [ $linkedin ];
	}
	if ( $photo_url ) {
		$person['image'] = $photo_url;
	}
	if ( $background !== '' ) {
		// A short bio doubles nicely as Person.description.
		$person['description'] = $background;
	}

	/**
	 * Filter the Person schema before emission.
	 *
	 * @param array $person   Schema array.
	 * @param int   $post_id  Employee post ID.
	 */
	return (array) apply_filters( 'cb_person_schema', $person, $post_id );
}

/**
 * Render a JSON-LD <script> tag for an employee post. Returns an
 * empty string if no schema applies — safe to echo unconditionally.
 */
function cb_emit_person_schema( int $post_id ): string {
	$person = cb_build_person_schema( $post_id );
	if ( $person === null ) return '';

	$json = wp_json_encode( $person, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
	if ( $json === false ) return '';

	return '<script type="application/ld+json">' . $json . '</script>' . "\n";
}

/**
 * Emit Person schema in <head> on single employee pages.
 * Block renderers (employee-grid / employee-card) emit their own
 * schemas inline, so this hook only fires for the singular case.
 */
add_action( 'wp_head', function () {
	if ( ! is_singular( 'employee' ) ) return;
	$id = (int) get_the_ID();
	if ( $id <= 0 ) return;
	echo cb_emit_person_schema( $id ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
} );
