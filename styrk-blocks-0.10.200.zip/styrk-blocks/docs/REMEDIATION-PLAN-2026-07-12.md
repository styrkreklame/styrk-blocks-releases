# Styrk Blocks — remediation plan

**Date:** 2026-07-12
**Status:** proposed, not started. No code written.
**Author:** Claude (audit session), for review by @ALorentzen

---

## 0. Why this document exists

The QA gate in `CLAUDE.md` lists 16 steps. **Five of them exist. Nine were
never built.** CI enforces two:

```
CI = pnpm exec tsc --noEmit  +  pnpm build
```

No tests. No lint gate. No a11y. No fixtures. No `fallow`. `composer.json` has
no dev dependencies, so PHPUnit isn't even installed. ~145 releases have
shipped through a typecheck and a webpack run.

The practical consequence: every session (including the one that produced this
document) has substituted *"tsc passes and it looks right in Playwright"* for
QA, and reported that as "all gates green." A stored XSS in
`call-card/template.php` survived in `main` until it was found **by reading the
file**, not by any gate. That is the failure this plan is meant to end.

**This plan's premise:** stop hunting bugs one at a time. Build the gates that
make each *class* of bug impossible to reintroduce, then fix the backlog behind
them.

---

## 1. Work method (the sequence)

Every phase below runs the same loop. No phase starts until the previous one's
exit gate is green.

```
  1. ANALYSE     Reproduce the issue. Read the code. Prove it is real.
  2. GRADE       Assign severity (§2) from evidence, not intuition.
  3. GATE FIRST  Write the failing test/lint rule that catches this class.
  4. FIX         Make the gate pass. Smallest change that does it.
  5. VERIFY      Gate green + build + browser-verify the actual behaviour.
  6. RATCHET     Wire the gate into CI so it can never regress.
```

Two rules that this codebase's history shows are non-negotiable:

- **Gate before fix.** A fix without a gate is a fix that gets undone. The
  escaping bug is the proof: it was *correct on two lines and wrong on two
  others in the same file*. Only a test can hold that line.
- **No "verified" without an artefact.** "Looks fine in Playwright" is not
  verification. A verification claim must cite a command and its output, or a
  test name. If it cannot, say "unverified."

### Verification status vocabulary (used in §3)

| Tag | Meaning |
|---|---|
| **CONFIRMED** | Read the code and reproduced/proved the defect. |
| **MEASURED** | Produced by a tool run, output recorded. |
| **SUSPECTED** | Strong signal, not yet proven. Must be confirmed before fixing. |

---

## 2. Severity rubric

Graded by *blast radius on a live client site*, not by how ugly the code is.
This plugin is **copied into many client sites**, so "leaks across clients" is
its own severity class — a bug here is multiplied by the number of sites.

| Grade | Definition | Response |
|---|---|---|
| **S0** | Exploitable security defect, or data loss. | Stop. Fix now. Hotfix release. |
| **S1** | Visitor-facing breakage, or **cross-client contamination** (one client's brand/copy rendering on another's site). | Fix this sprint. |
| **S2** | Standards violation with legal/《WCAG》exposure (AA contrast, ARIA, keyboard). | Fix this sprint. |
| **S3** | Maintainability: duplication, complexity, dead code. Slows everything, breaks nothing. | Scheduled, behind a ratchet. |
| **S4** | Hygiene: repo cruft, docs, version drift. | Opportunistic. |

**Missing test infrastructure is not itself an S-grade — it is the multiplier on
every other grade.** It is why an S0 lived in `main`. It is therefore Phase 1,
ahead of the backlog.

---

## 3. Issue register

### S0 — security

| # | Issue | Evidence | Status |
|---|---|---|---|
| S0-1 | Stored XSS: `$card_color` echoed raw into `style="…"` at `call-card/template.php:130,157` while escaped at `:98,143`. Source is `style.color.text`, free-form, never hex-validated. | Read + traced. Payload `red;"><script>` closes the attribute. | **FIXED** in PR #275. **No test guards it.** |

> S0-1 is fixed but **ungated**. Phase 1 exists to gate it. Until then the class
> is still open — nothing stops the next block from doing the same thing.

### S1 — cross-client contamination

The dominant finding of the audit. This plugin is shared; per-client skins and
copy have been committed into it as preset **fallbacks** and block **defaults**.
On any site whose `theme.json` omits a preset, the fallback fires — and it
carries *another client's brand*.

| # | Issue | Evidence | Status |
|---|---|---|---|
| S1-1 | **Second token namespace unfixed.** PR #275 repaired `--cb-*`, but a `--accent` / `--primary` namespace (from `design-system/colors_and_type.css`) is also in use with wrong fallbacks, e.g. `style.css:6716` `var(--accent, #aa6486)` — mauve. | grep. `--cb-*` fix does **not** cover these. | CONFIRMED, **open** |
| S1-2 | ~116 off-brand hex fallbacks / 38 distinct values: `#1E5BD8` (blue) and `#aa6486` (mauve) as `accent` (should be `#F5833C`); `#0f1b2d`, `#00354f` as `primary` (should be `#00486A`). | Audit sweep of `src/`. | CONFIRMED, open |
| S1-3 | 5 foreign font families in fallbacks: Josefin Sans, Lato, Oswald, Arial Narrow, Montserrat. Same leak mechanism. | grep, 14 occurrences. | CONFIRMED, open |
| S1-4 | `cta-band/block.json` hardcodes client name **"Hywer"** and is written in **nynorsk**, not bokmål. | Read. | CONFIRMED, open |
| S1-5 | `faq-accordion/block.json` ships **English** defaults to the front end ("Frequently asked questions", "What services do you offer?"). | Read. | CONFIRMED, open |
| S1-6 | 5 further `block.json` files carry candidate English/nynorsk defaults (`call-card`, `contact-section`, `process`, `services-editorial`, `video-reels`). | Crude regex — **not yet read**. | SUSPECTED |

### S2 — accessibility / standards

| # | Issue | Evidence | Status |
|---|---|---|---|
| S2-1 | White text on `--accent` — fails WCAG AA (~2.8:1), an explicit CLAUDE.md hard rule. Live at `style.css:6716`, `:6735`, and ~3 more. | grep + rubric. | CONFIRMED, open |
| S2-2 | `react-header/view.tsx` — `role="menu"` at `:408` and `:584`; the only two `role="menuitem"` are at `:341,:372`, i.e. **before** both containers, so neither menu appears to have menuitem children. Invalid ARIA in **shipped frontend** code. | grep. Structure not yet traced. | SUSPECTED — confirm before fixing |
| S2-3 | Unguarded motion: ~42 `transition:` selectors with no `prefers-reduced-motion` killswitch; 79 bare `ease` vs the mandated `cubic-bezier(0.4,0,0.2,1)`. Vestibular-disorder exposure. | Audit sweep. | CONFIRMED, open |
| S2-4 | Assorted: `label` with no control (`media-grid`), redundant `role`, click-handlers on non-interactive elements. | eslint jsx-a11y. | MEASURED, open |

### S3 — maintainability

| # | Issue | Evidence | Status |
|---|---|---|---|
| S3-1 | **`hero/edit.tsx`: 3,684 LOC, one `Edit()` at cognitive complexity 153.** The single worst artefact in the repo. | `fallow health`. | MEASURED, open |
| S3-2 | Duplication 8.0% / 47 clone groups. **Not** missing components — `StandardSectionControls` is used by 24 blocks, `useDragSort` by 12. What is duplicated is the *wiring*: repeated attribute type declarations, repeated `useBlockProps`+`useSettings` setup, repeated colour-chip JSX plumbing. `aktuelt` ↔ `featured-projects` share a 147-line run. | `fallow dupes`. | MEASURED, open |
| S3-3 | `react-header/view.tsx` 1,989 LOC; `contact-section/edit.tsx` 1,616 LOC. | `wc -l`. | MEASURED, open |

### S4 — hygiene

| # | Issue | Status |
|---|---|---|
| S4-1 | 24 QA screenshots (~15 MB) tracked at repo root; `.distignore` had no image rule, so they shipped **inside the release zip** to every client. | FIXED in PR #275 |
| S4-2 | Dead files/exports; `package.json` version drift; emoji in editor UI; stale CLAUDE.md claims. | FIXED in PR #275 |

### Non-issues — do not "fix" these

Recorded so a future session doesn't burn a day on them:

- **`fallow` "11 unlisted dependencies"** — the `@wordpress/*` packages are
  runtime externals. `wp-scripts` compiles them to `wp-blocks`, `wp-components`
  … which WordPress provides on the page (see any `index.asset.php`). Listing
  them in `package.json` would be the actual bug. **Suppress in `.fallowrc.json`.**
- **`fallow` "unused file: `video-reels/view.js`"** — it is a real `viewScript`
  declared in `block.json`. `fallow` does not parse `block.json`. **Suppress.**
- **`fallow` "134 functions above threshold"** — inflated by CRAP score
  (`complexity × (1 − coverage)²`). With **zero tests**, coverage is 0 and CRAP
  explodes for every function regardless of quality. The honest signals are
  healthy: avg cyclomatic **2.5**, p90 **4**, maintainability **94.1 (good)**,
  **0** churn hotspots. This number will fall on its own once Phase 1 lands.
  The genuine outlier is S3-1, and only S3-1.

---

## 4. Phased sequence

### Phase 1 — Build the gates *(prerequisite for everything else)*

Nothing else is scheduled until this is green and in CI. It is what converts
"Claude says it's fine" into a machine-checkable claim.

| Step | Gate | Catches |
|---|---|---|
| 1.1 | **PHPUnit** (`wp-env` + `wp-phpunit`). Add dev deps to `composer.json`. | — |
| 1.2 | **Escaping suite**: render every block's `template.php` with a hostile-attribute fixture (`red;"><script>alert(1)</script>`) and assert no raw `<script>`, no attribute breakout. One case per block, table-driven. | **The entire S0 class.** Would have caught S0-1. |
| 1.3 | **Jest** (`wp-scripts test-unit-js`) on pure helpers: `useDragSort`, `useCtas`, `employeeDisplay`, `projectDisplay`, `focusTrap`, `getIcon`, `bgShapePlacement`. | Logic regressions |
| 1.4 | **Block fixtures**: every `block.json` registers; every `save()` returns `null` (or `InnerBlocks.Content`). | Enforces the dynamic-block rule structurally instead of by convention |
| 1.5 | **Playwright + axe**: a11y scan per block; a **contrast assertion** that fails on white-on-accent. | S2-1, S2-2, S2-4 |
| 1.6 | **Token-fallback lint**: a custom check that every `var(--*, <hex>)` fallback is one of the 4 brand hexes (+ sanctioned tints). Fails the build on a foreign hex/font. | **The entire S1 class.** Makes cross-client leakage impossible to merge. |
| 1.7 | **CI**: run 1.1–1.6 + eslint + stylelint + `fallow` on every PR. | The gate becomes real |
| 1.8 | **`fallow` baseline + suppressions**: suppress the two false-positive classes; baseline the rest so CI fails only on **new** debt. Green today, ratchets down. | Debt can't grow |

**Exit gate:** CI red on a deliberately-introduced unescaped echo, a foreign hex
fallback, and a white-on-accent rule. If those three don't fail the build,
Phase 1 isn't done.

### Phase 2 — S1: de-skin the shared plugin

Now safe to do, because 1.6 makes it permanent.

- 2.1 Fix the `--accent`/`--primary` namespace (S1-1) — this was **missed** by
  PR #275, which only repaired `--cb-*`.
- 2.2 Replace all off-brand hex fallbacks with the official palette (S1-2).
- 2.3 Replace foreign font fallbacks with Fraunces/Inter (S1-3).
- 2.4 Strip client-specific + wrong-language `block.json` defaults (S1-4, S1-5);
  **first read all 7 candidates** to resolve S1-6.

**Exit gate:** 1.6 passes with zero suppressions. Visual regression (1.5) shows
no diff on a site that *does* define presets.

### Phase 3 — S2: accessibility

- 3.1 Confirm S2-2 by tracing the ARIA tree; fix `role="menu"` structure.
- 3.2 Remove white-on-accent (S2-1) — navy-on-orange or peach-on-navy per the
  brand rules. `::selection` is the one sanctioned exception.
- 3.3 Reduced-motion killswitch + easing/duration normalisation (S2-3).
- 3.4 Clear the jsx-a11y backlog (S2-4).

**Exit gate:** axe clean; contrast assertion green; `prefers-reduced-motion`
honoured everywhere.

### Phase 4 — S3: structure

Deliberately **last**. It is the largest diff and the lowest blast radius, and
it is far safer once Phases 1–3 can prove nothing broke.

- 4.1 Collapse the wiring duplication (S3-2): a shared attributes
  type/schema, one `useSectionBlockProps()` hook, a config-driven colour-chip
  cluster. Target the 147-line `aktuelt`↔`featured-projects` clone first.
- 4.2 Decompose `hero/edit.tsx` (S3-1) — extract panels/subcomponents until
  `Edit()` is under threshold.
- 4.3 Then `react-header/view.tsx`, `contact-section/edit.tsx` (S3-3).

**Exit gate:** `fallow` passes with the baseline ratcheted to the new, lower
numbers.

---

## 5. Definition of done

1. `fallow` exits 0 in CI (with documented suppressions for the two
   false-positive classes only).
2. A deliberately-introduced unescaped echo **fails CI**.
3. A deliberately-introduced foreign-hex fallback **fails CI**.
4. A deliberately-introduced white-on-accent pairing **fails CI**.
5. `CLAUDE.md`'s QA gate lists only steps that **exist and run**. Any step that
   isn't wired to CI gets deleted from the list — an aspirational gate is worse
   than no gate, because it licenses the "all gates green" claim that got us
   here.

---

## 6. Open decisions for @ALorentzen

1. **Phase 1 is ~all new files** (test suites, CI config, composer dev deps).
   `CLAUDE.md` forbids creating files uninvited — need explicit go-ahead.
2. **`wp-env` vs. existing Local sites** for the PHPUnit/Playwright harness.
   `wp-env` (Docker) is reproducible in CI; Local is not. Recommend `wp-env`.
3. **S2-1 vs. the design system.** `design-system/README.md:78` *blesses*
   white-on-orange for `::selection`, while `CLAUDE.md` forbids white-on-accent
   outright. PR #275 recorded `::selection` as the sanctioned exception — but
   `style.css:6716`/`:6735` are **not** selection, they're chips/buttons, and
   they must change. Confirm.
4. **Phase 4 scope.** Decomposing `hero/edit.tsx` is a large, risky diff with no
   user-visible benefit. It is legitimate to baseline it and never do it.
