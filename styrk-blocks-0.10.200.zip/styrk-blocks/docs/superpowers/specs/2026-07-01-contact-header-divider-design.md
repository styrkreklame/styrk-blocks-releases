# Contact section — optional header divider

Date: 2026-07-01
Block: `styrk-blocks/contact-section`
Repo: `styrkreklame/styrk-blocks`
Driven by: hywer «Kontakt» — the header (eyebrow + heading + subheading) reads as
part of the columns below it; the client wants an optional rule between the
header and the form/info columns to mark the heading as its own section.

## Goal

Add an **optional** full-width divider (line / border / rule) between the
contact section's `<header>` and its two-column `contact-layout__cols` row, with
on/off + colour + thickness control, using the block's existing in-canvas
opt-in affordance chrome (same pattern as the hero's "+ accent line").

## Constraints / context

- `contact-section` is a **dynamic block** (`render: template.php`, no
  `save()`), so all new attributes are additive with defaults — no deprecation,
  no fixture work. Default off ⇒ existing contact sections render unchanged.
- Insertion point is clean: in `template.php` the header closes at `</header>`
  (line ~307) and the columns open at `<div class="contact-layout__cols">`
  (line ~310). The divider goes between them.
- Precedent to mirror: the hero's accent-line affordance — OFF = dashed ghost
  toggle; ON = the real `<hr>` preview + a visible trash to remove — plus the
  eyebrow's popover-chip chrome for the thickness `RangeControl`.

## New attributes (block.json)

| Attribute                | Type    | Default | Meaning |
|--------------------------|---------|---------|---------|
| `showHeaderDivider`      | boolean | `false` | Render the divider between header and columns. |
| `headerDividerColor`     | string  | `""`    | Hex. Empty → the CSS default hairline (see below). |
| `headerDividerThickness` | number  | `1`     | Rule thickness in px. Range 1–6. |

## Rendering — `template.php`

After the header `<?php endif; ?>` (and before `contact-layout__cols`), render
the rule only when enabled **and** the header actually has content (an eyebrow,
heading, or subheading) — a divider with nothing above it is meaningless:

```php
$show_header_divider = ! empty( $attributes['showHeaderDivider'] );
$divider_color       = sanitize_hex_color( (string) ( $attributes['headerDividerColor'] ?? '' ) );
$divider_thickness   = max( 1, min( 6, (int) ( $attributes['headerDividerThickness'] ?? 1 ) ) );
$has_header          = ( $form_eyebrow || $form_heading || $form_subheading );

if ( $show_header_divider && $has_header ) :
    $divider_style = 'border-top-width:' . $divider_thickness . 'px';
    if ( $divider_color ) {
        $divider_style .= ';border-top-color:' . $divider_color;
    }
    ?>
    <hr class="contact-layout__divider" aria-hidden="true" style="<?php echo esc_attr( $divider_style ); ?>" />
    <?php
endif;
```

`aria-hidden` because it's purely decorative. Thickness/colour are applied
inline over the CSS base rule.

## CSS — `src/style.css`

Add a base `.contact-layout__divider` so the element has sane defaults (colour,
full width, and vertical breathing room in the gap the header currently leaves):

```css
.contact-layout__divider {
    width: 100%;
    margin: 1.5rem 0 2rem;      /* sits in the space between header and columns */
    border: 0;
    border-top: 1px solid currentColor;
    opacity: .18;               /* subtle hairline when no explicit colour set */
}
```

When `headerDividerColor` is set, the inline `border-top-color` overrides
`currentColor`; the `.18` opacity keeps an unset divider subtle while still
letting an explicit colour read clearly (explicit colour + low opacity is
acceptable, or drop opacity to 1 when a colour is inline — decide during
implementation; default-subtle is the priority).

## Editor — `edit.tsx`

Inside the `contact-layout__header` block, immediately **after** the subheading
`AlignZone` (so the preview order matches the frontend), add an opt-in
affordance mirroring the hero accent-line:

- **OFF** (`! showHeaderDivider`): a dashed ghost button `+ skillelinje`
  (Tooltip: "Vis en linje mellom overskrift og kolonnene"), full width / left
  aligned to the header.
- **ON**: render the actual `<hr className="contact-layout__divider">` preview
  with the same inline thickness/colour, paired with:
  - an `InlineColorChip` → `headerDividerColor` (label "Linjefarge"),
  - a thickness popover-chip ("Tykkelse" button → `Popover` with a
    `RangeControl` 1–6), mirroring the eyebrow "Radius" popover,
  - a `TrashIcon` remove button that sets `showHeaderDivider: false`.

Reuse the existing shared chrome (`InlineColorChip`, `TrashIcon`, the
`cb-hero__accent-toggle` ghost/active classes or the block's local equivalent) —
no new control patterns.

## Backwards compatibility

Default `showHeaderDivider: false` ⇒ no divider on any existing contact section
until an editor opts in. Dynamic block ⇒ no `save()` diff, no deprecation.

## QA plan

1. `pnpm build`; confirm the change in `build/blocks/contact-section/`.
2. Copy the built bundle into the hywer theme's plugin copy.
3. Browser QA in Local on the «Kontakt» page:
   - toggle divider on/off; verify it appears between the header and the two
     columns and spans the full contact-layout width;
   - test a custom colour and thickness 1 / 3 / 6;
   - verify header-empty case (no eyebrow/heading/subheading) renders no rule;
   - check 1440 / 768 / 375 and an XXL width (≥2560) — the divider should track
     the container width and the column stacking at mobile;
   - zero editor console errors; save + reload, no block-validation error.
4. Screenshots to the user before any git.
5. Bump plugin `version` + CHANGELOG entry.
6. Branch `feat/contact-header-divider` in styrk-blocks; PR; merge only after the
   user approves.

## Out of scope

- Line style variants (dashed/dotted) — solid only unless requested.
- Dividers between the two columns, or anywhere other than header→columns.
- Any change to the contact form, info column, eyebrow, or section controls.
