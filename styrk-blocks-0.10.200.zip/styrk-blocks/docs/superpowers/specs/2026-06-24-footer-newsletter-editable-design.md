# Footer newsletter — admin-editable + optional

**Date:** 2026-06-24
**Repos touched:** `styrkreklame/styrk-blocks` (plugin, primary) + `styrkreklame/hywer` (theme, consumer)
**Status:** Design approved by user; awaiting spec review → implementation plan.

## Problem

The footer newsletter section (heading "Motta vårt nyhetsbrev" + consent paragraph
+ email signup form) is **hardcoded** in the Hywer theme at
`hywer-theme/parts/footer.html` (two block markup blocks + the theme's
`[hywer_newsletter_form]` shortcode defined in `hywer-theme/functions.php`).
None of it is editable from the WordPress admin, and there is no way to turn the
newsletter off.

The user wants it:
1. **Editable** from **Settings → Footer** (the existing admin page).
2. **Optional** — an on/off toggle.

Settings → Footer is owned by the **shared styrk-blocks plugin**
(`includes/footer-settings.php`), used by all 5 sites — not by the theme. The
existing `[footer_certs]` field is the precedent: a plugin-side Settings → Footer
control + a shortcode that renders nothing until configured.

## Decisions (all confirmed with the user)

- **Where:** build it in the shared styrk-blocks plugin, mirroring `[footer_certs]`.
- **Editable fields:** toggle + heading + consent body + privacy link (URL + label) —
  everything, nothing stays hardcoded.
- **Default state:** **OFF** (hidden until an admin enables it). Truly optional by
  default. → Requires a rollout step for hywer (below) so its currently-visible
  newsletter does not silently vanish.
- **Privacy link:** rendered as a **trailing link** built from two fields (URL +
  label), appended after the consent body. No inline-token parser.
- **Email form:** the form markup moves into the plugin shortcode so the plugin is
  self-contained and reusable across sites; the theme's `[hywer_newsletter_form]`
  shortcode is removed (it becomes dead).

## Architecture

Three units, each with one responsibility:

### Unit 1 — Settings fields (`includes/footer-settings.php`)

New settings section `cb_footer_newsletter` ("Newsletter") on the
`cb-footer-settings` page, with fields stored under the existing single
`cb_footer_settings` option (key `CB_FOOTER_OPTION`).

New keys + defaults added to `cb_footer_defaults()`:

| Key | Field type | Default |
|---|---|---|
| `newsletter_enabled` | checkbox | `0` (off) |
| `newsletter_heading` | text | `Motta vårt nyhetsbrev` |
| `newsletter_body` | textarea | current consent sentence (see below) |
| `newsletter_privacy_url` | text (URL) | `/personvern` |
| `newsletter_privacy_label` | text | `personvernerklæringen` |

Default body text:
> Ved å registrere deg samtykker du til at vi kan samle inn og behandle
> opplysninger om deg. Les mer i vår

(The trailing privacy link is appended by the shortcode, so the default body ends
at "vår" + the link label completes the sentence.)

`cb_footer_render_field()` gains a **`checkbox`** branch. It prints a hidden
companion `<input value="0">` immediately before the checkbox so an unticked box
always submits a value (reliable off-persistence), then the visible checkbox with
`value="1"`.

`cb_footer_sanitize()` gains cases:
- `newsletter_enabled` → `(int) ! empty( $input[$key] )` (0/1)
- `newsletter_body` → `sanitize_textarea_field`
- `newsletter_privacy_url` → `esc_url_raw` (allows relative `/personvern` and absolute https; blocks javascript:/data:)
- `newsletter_heading`, `newsletter_privacy_label` → fall through to the `sanitize_text_field` default

### Unit 2 — `[footer_newsletter]` shortcode (`includes/footer-shortcodes.php`)

`cb_footer_newsletter_shortcode()`:
- Reads `cb_get_footer_settings()`.
- If `newsletter_enabled` is falsy → return `''` (invisible by default; matches `[footer_certs]`).
- Else build:
  - `<h2 class="wp-block-heading">{heading}</h2>` — skipped if heading blank.
  - `<p>{body} <a href="{privacy_url}">{privacy_label}</a>.</p>` — body skipped if
    blank; the link is appended only when both URL and label are set. URL via
    `esc_url`, label via `esc_html`.
  - The email form markup (moved verbatim from the theme's
    `hywer_newsletter_form`): `.news-field` wrapper, email `<input>`, arrow-circle
    submit `<button>` with the inline SVG. All strings stay translatable.
- Registered via `add_shortcode( 'footer_newsletter', ... )`.

Note: the form is a non-functional placeholder today (in both theme and plugin —
"until Forminator/Mailchimp"); moving it changes nothing functionally.

### Unit 3 — Theme consumes the shortcode (`hywer-theme/parts/footer.html`)

Replace the inner content of the `footer-col footer-news` group:
- **Before:** `wp:heading` + `wp:paragraph` + `wp:shortcode [hywer_newsletter_form]`.
- **After:** a single `wp:shortcode [footer_newsletter]`.

The wrapping `<div class="wp-block-group footer-col footer-news">` group stays so
column layout/styling is unchanged when the newsletter is enabled.

Remove the now-dead `hywer_newsletter_form` shortcode registration from
`hywer-theme/functions.php` (grep confirms `footer.html` is its only consumer).

## Rollout (default-OFF caveat)

Because the default is OFF, shipping the theme change would hide hywer's
currently-visible newsletter until enabled. Rollout step:
1. On hywer **Local** (`:10003`): set `cb_footer_settings` →
   `newsletter_enabled = 1` with heading/body/privacy pre-filled, via wp-cli, so
   the footer renders identically. Verify in browser.
2. On hywer **prod**: the user enables it under Settings → Footer (or we set it via
   wp-cli) after deploy. Document this in the PR description.
3. The other 4 sites: no action — newsletter stays off (clean), no visible change.

## Backwards compatibility

- New option keys are additive; existing `cb_footer_settings` rows gain defaults on
  next read (`cb_footer_defaults()` is the registered default). No migration needed.
- No `save()`/block-markup changes → no Gutenberg deprecation needed (this is PHP
  shortcode + settings only).
- Existing `[footer_certs]`/other footer shortcodes untouched.

## Testing / QA

- `php -l` on both changed plugin includes.
- Settings → Footer: new Newsletter section renders; toggle, heading, body, URL,
  label all save and round-trip; unticking the toggle persists off.
- Frontend, toggle OFF: `[footer_newsletter]` renders nothing; footer column empty.
- Frontend, toggle ON: heading + consent + trailing privacy link (correct href) +
  email form render; matches the current hardcoded look.
- Privacy URL sanitization: a `javascript:` URL is stripped.
- Other 4 sites unaffected (shortcode absent from their footers, or present-and-off).
- Browser-verify on `:10003` (Playwright, bundled chromium — confirm no Chrome
  hijack first).

## Out of scope

- Wiring the form to a real provider (Forminator/Mailchimp) — still a placeholder.
- Making the other hardcoded footer columns (address/contact/social) editable — the
  hywer theme footer is bespoke; only the newsletter was requested.
- Any styling changes to the newsletter block.
