# Hero subtext + ingress text controls

Date: 2026-07-01
Block: `styrk-blocks/hero`
Repo: `styrkreklame/styrk-blocks`
Driven by: hywer «Tenester» hero — subtext too small / no size / no bg / fixed
width / too much space under the title; ingress needs size + weight controls.

## Goal

Give editors real typographic control over the hero's two body-text elements —
the **subtext** (supporting line under the heading) and the **ingress / lead**
(`leadText`, the optional paragraph pinned to the bottom of the hero) — using
the same in-canvas control chrome the block already uses elsewhere, so the UI
stays uniform and nothing moves to the InspectorControls sidebar.

## Constraints / context

- The hero is a **dynamic block**: `save.tsx` returns `null`, all output comes
  from `template.php`. Therefore every new attribute is additive with a default
  — no `save()` change, no deprecation, no fixture work. Existing published
  heroes render byte-identically except where a default is intentionally
  changed (see `subtextSpacing`).
- Precedents to mirror (already in this block), so we add zero new patterns:
  - **aside stat-label** — `asideStatLabelFontSize` / `asideStatLabelWidth`
    (`fit`/`full`) / `asideStatLabelBgColor` show exactly how to build a
    `$styles[]` array server-side and preset ToggleGroups client-side.
  - **eyebrow** — padded-banner background (`padding` + `border-radius`) and the
    contextual popover-chip (the "Radius" popover) chrome.
- User principles that bind this work:
  - All block options live **in-canvas**, never in the sidebar.
  - Every matching element carries **matching controls** ("so the user never
    has to think").

## New attributes (block.json)

All additive. Subtext:

| Attribute           | Type   | Default | Meaning |
|---------------------|--------|---------|---------|
| `subtextFontSize`   | string | `""`    | Preset px: Standard / 16 / 18 / 20 / 24 / 28 / 32. `""` = inherit `text-hero-sub`. |
| `subtextFontWeight` | string | `""`    | Standard / Normal (400) / Medium (500) / Semibold (600) / Bold (700). `""` = inherit. |
| `subtextBgColor`    | string | `""`    | Hex. When set → padded banner behind the text. |
| `subtextWidth`      | string | `"cap"` | `fit` (hug text) / `cap` (640px reading cap — today's look) / `full` (100%). |
| `subtextSpacing`    | number | `8`     | Space (px) directly above the subtext. Range 0–48. |

Ingress / lead:

| Attribute        | Type   | Default | Meaning |
|------------------|--------|---------|---------|
| `leadFontSize`   | string | `""`    | Same preset px list as `subtextFontSize`. `""` = inherit `cb-hero__lead` CSS. |
| `leadFontWeight` | string | `""`    | Same weight list as `subtextFontWeight`. `""` = inherit. |

### Shared editor constants (`edit.tsx`)

- Reuse / promote the existing `STAT_LABEL_FONT_SIZES` list as the shared font-
  size preset source for subtext + lead (a `HERO_FONT_SIZES` alias with the same
  values is fine — do not change the stat-label behaviour).
- New `HERO_FONT_WEIGHTS`:
  `[ {label:'Standard', value:''}, {label:'Normal', value:'400'},
     {label:'Medium', value:'500'}, {label:'Semibold', value:'600'},
     {label:'Bold', value:'700'} ]`.

## Rendering — `template.php`

### Subtext (currently a `<p class="text-hero-sub … max-w-[640px] …">`)

Build a `$subtext_styles` array, mirroring the stat-label block:

- **Width** — replace the hardcoded `max-w-[640px]` utility with a style:
  - `fit`  → `max-width:fit-content`
  - `cap`  → `max-width:640px`  (default; reproduces today)
  - `full` → `max-width:100%`
  The existing alignment auto-margins (`$subtext_self`: `mr-auto`/`mx-auto`/
  `ml-auto`) still position the `fit`/`cap` box left/center/right.
- **Font size** — `font-size:<n>px` when `subtextFontSize` is numeric.
- **Font weight** — `font-weight:<n>` when `subtextFontWeight` is set.
- **BG banner** — when `subtextBgColor` set: `background-color:<hex>` +
  `padding:.3em .6em` + `border-radius:6px` (same values as the stat-label /
  eyebrow banner).
- **Spacing** — the content stack is `flex flex-col gap-6` (uniform 24px /
  `1.5rem`). To make the heading→subtext gap independently controllable, set the
  subtext's `margin-top: calc(-1.5rem + <spacing>px)`. This cancels the inherited
  24px flex gap and applies the chosen value. Default `8` → effective 8px
  (tightens from 24px, the reported "too much space"); range 0–48 lets the editor
  dial it looser or to 0. (When the accent line is enabled it sits between the
  heading and subtext; `subtextSpacing` then governs the accent-line→subtext gap,
  which is the general "space above the subtext" definition.)

`sanitize_hex_color()` the colour; cast the numeric size/spacing; keep the
existing `wp_kses` allow-list.

### Ingress / lead (currently `<p class="cb-hero__lead …">`)

Add inline `font-size:<n>px` (when `leadFontSize` numeric) and
`font-weight:<n>` (when `leadFontWeight` set) onto the existing lead `<p>`,
merged with the current `color:` inline style. No change to the lead wrap,
bg-colour, or opacity handling.

## Editor — `edit.tsx`

Keep everything in the in-canvas `AlignZone` `colorChips` slot; no sidebar.

**Subtext AlignZone** — extend the `colorChips` with, in order:
1. Text colour chip (existing).
2. Background colour chip (`InlineColorChip` → `subtextBgColor`).
3. Font-size ToggleGroup (`HERO_FONT_SIZES` → `subtextFontSize`).
4. Font-weight ToggleGroup (`HERO_FONT_WEIGHTS` → `subtextFontWeight`).
5. Width toggle Fit / Capped / Full (`subtextWidth`).
6. Spacing popover-chip (a "Avstand" button → `Popover` with a `RangeControl`
   0–48), mirroring the eyebrow "Radius" popover chrome.

To keep the control band from overflowing, group size + weight (and, if needed,
width + spacing) behind compact popover chips ("Aa" / "Oppsett") rather than a
long inline row — matching the eyebrow's popover precedent. Inline ToggleGroups
(stat-label style) are acceptable if they fit; tidiness wins.

Apply the same computed inline styles (size / weight / bg-banner / width /
margin-top) to the subtext `RichText` preview so the editor matches the frontend
1:1.

**Ingress AlignZone** — add to the existing chips (Text / BG / opacity):
- Font-size ToggleGroup (`leadFontSize`).
- Font-weight ToggleGroup (`leadFontWeight`).

Mirror both onto the lead `RichText` preview inline style.

## Backwards compatibility

- Only `subtextSpacing` (default 8) and `subtextWidth` (default `cap`)
  participate in existing-hero rendering; `cap` == the current 640px cap, so the
  sole intentional visual change to old heroes is the tighter title→subtext gap
  the user asked for.
- All other new attributes default to `""` → no effect until an editor opts in.
- Dynamic block → no `save()` diff, no deprecation, no fixture updates.

## QA plan

1. `pnpm build` in `_shared/styrk-blocks`; verify the change lands in
   `build/blocks/hero/`.
2. Copy the built bundle into the hywer theme's plugin copy (per hywer local-dev
   workflow — the plugin is a copy, not a symlink).
3. Browser QA in Local (`:10003`) on the «Tenester» page and a page using the
   ingress:
   - subtext: each width mode, a bg-banner colour, a couple of sizes/weights,
     spacing at 0 / default / max;
   - ingress: size + weight;
   - verify at 1440 / 768 / 375 **and** an XXL width (≥2560);
   - zero editor console errors; save + reload with no block-validation error
     (dynamic, so none expected).
4. Screenshots to the user before any git.
5. Bump plugin `version` + CHANGELOG entry.
6. Branch `feat/hero-subtext-controls` in styrk-blocks; PR; merge only after the
   user approves.

## Out of scope

- Heading typography controls (not requested).
- Width / spacing / bg-banner on the ingress (not requested; ingress already has
  its own bg + opacity panel).
- Any change to the aside stat-label, eyebrow, or CTA controls.
