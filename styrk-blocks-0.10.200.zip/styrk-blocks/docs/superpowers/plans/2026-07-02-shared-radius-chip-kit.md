# Shared RadiusChip Kit + Consistency Fixes — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Consolidate corner-radius controls into one shared `RadiusChip` in the existing in-editor control kit, wire it into `ItemActions`/`MultiCtaRow`, migrate the lone holdout (`contact-section`) off its local chip styling, and add the missing radius controls (hero CTA, stats-row card) — so every block's in-editor controls share one branded, evenly-sized chrome.

**Architecture:** The kit already exists (`EditorPanel`, `ActionButton`, `MediaSetButton`, `InlineColorChip`, `StandardSectionControls`; `.cb-ed-*` + `.cb-feature-card__swatch` styles). Radius was never consolidated — it lives ad-hoc in `SectionHeader` (eyebrow), `contact-section` (local `chipStyle`), and `cta-section`/`rich-text-section` (block-level). Add a `RadiusChip` modeled on `InlineColorChip` (same `cb-feature-card__swatch` pill → Popover with `RangeControl`), then replace ad-hoc radius pills with it and expose it where missing. All changes are additive (new numeric attributes default to current values) — dynamic blocks (`save` returns null), so **no deprecations**.

**Tech Stack:** WordPress Gutenberg, React + TypeScript, `@wordpress/components`, PHP dynamic `template.php`, Tailwind-in-PHP class strings, `pnpm build` (webpack).

**Setup note:** Work in the repo working dir on branch `feat/cta-and-stats-radius` (NOT a separate worktree) — the anleggspartner1 local site symlinks the plugin to this dir, so edits must land here to show in the editor at http://localhost:10033.

**Verification model:** These editor/PHP changes have no jest suite. Each task verifies via: `npx tsc --noEmit` (types), `pnpm build` (compiles), and a visual editor check (screenshot the block's control band + frontend). This mirrors the project's real QA loop, not invented unit tests.

**Pre-existing blocker:** `src/blocks/hero/edit.tsx` already fails the strict eslint config on `main` (experimental-API imports lines 17–18; nested ternaries lines 195, 2498). These are not introduced here. Task 0 records the baseline so we don't get blamed for them and don't attempt risky rewrites mid-refactor.

---

### Task 0: Baseline + branch hygiene

**Files:** none (git + measurement only)

- [ ] **Step 1: Confirm branch + clean state**

Run: `git -C ~/Documents/nettsider/_shared/styrk-blocks status --short | grep -v '\.png$'`
Expected: only the in-flight hero edits (`block.json`, `template.php`, `edit.tsx`) from prior work; no unrelated changes.

- [ ] **Step 2: Record the pre-existing eslint baseline**

Run: `npx eslint src/blocks/hero/edit.tsx --config node_modules/@wordpress/scripts/config/.eslintrc.js --resolve-plugins-relative-to node_modules/@wordpress/scripts 2>&1 | tail -8`
Expected: 4 errors (2 experimental-API, 2 nested-ternary). Note them; do NOT fix in this plan (out of scope, risk of behavior change).

- [ ] **Step 3: Commit the in-flight hero backend work already done**

```bash
git add src/blocks/hero/block.json src/blocks/hero/template.php src/blocks/hero/edit.tsx
git commit -m "feat(hero): add buttonRadius attribute + apply in template (control wired in Task 3)"
```

---

### Task 1: Shared `RadiusChip` component

**Files:**
- Create: `src/components/RadiusChip.tsx`
- Modify: `src/style.css` (append one rule near `.cb-feature-card__swatch`, ~line 2716)

- [ ] **Step 1: Create the component (modeled 1:1 on `InlineColorChip`)**

```tsx
/**
 * RadiusChip — a pill button (rounded-corner glyph + "{n}px" label) that opens
 * a RangeControl popover. The radius counterpart to InlineColorChip: identical
 * `cb-feature-card__swatch` chrome so radius controls read the same size and
 * shape as the colour chips on every band. Use inline in a control band /
 * ItemActions, never in a sidebar.
 */
import { useState } from '@wordpress/element';
import { Popover, RangeControl, Tooltip } from '@wordpress/components';
import { __ } from '@wordpress/i18n';

type Props = {
	value: number;
	onChange: ( v: number ) => void;
	/** Slider bounds. Defaults 0–40; pass max=999 for "pill" (fully rounded). */
	min?: number;
	max?: number;
	/** Pill label prefix, e.g. "Radius" (default) or "Hjørner". */
	label?: string;
	title?: string;
};

export default function RadiusChip( {
	value,
	onChange,
	min = 0,
	max = 40,
	label,
	title,
}: Props ) {
	const [ open, setOpen ] = useState( false );
	const text = `${ label ?? __( 'Radius', 'styrk-blocks' ) }: ${ value }px`;

	return (
		<>
			<Tooltip text={ title ?? text } placement="top">
				<button
					type="button"
					className="cb-feature-card__swatch"
					onClick={ ( e ) => {
						e.stopPropagation();
						setOpen( ! open );
					} }
					onMouseDown={ ( e ) => e.preventDefault() }
					aria-label={ title ?? text }
				>
					<span
						className="cb-radius-chip__glyph"
						aria-hidden="true"
					/>
					{ text }
				</button>
			</Tooltip>
			{ open && (
				<Popover
					placement="bottom-start"
					onClose={ () => setOpen( false ) }
					shift
				>
					<div style={ { padding: 12, width: 220 } }>
						<RangeControl
							__next40pxDefaultSize
							__nextHasNoMarginBottom
							label={ label ?? __( 'Radius', 'styrk-blocks' ) }
							value={ value }
							min={ min }
							max={ max }
							onChange={ ( v ) =>
								onChange( typeof v === 'number' ? v : 0 )
							}
						/>
					</div>
				</Popover>
			) }
		</>
	);
}
```

- [ ] **Step 2: Add the glyph style** (append after the `.cb-feature-card__swatch-dot` rule, ~line 2716 in `src/style.css`)

```css
/* RadiusChip glyph — a small rounded-corner mark so the radius pill reads as a
   sibling of the colour swatch-dot chips (same 12px box, same baseline). */
.cb-radius-chip__glyph {
  display: inline-block;
  width: 12px;
  height: 12px;
  border: 2px solid currentColor;
  border-radius: 5px 0 0 0;
  border-right: 0;
  border-bottom: 0;
  opacity: 0.7;
}
```

- [ ] **Step 3: Types compile**

Run: `npx tsc --noEmit`
Expected: PASS (no errors referencing RadiusChip).

- [ ] **Step 4: Commit**

```bash
git add src/components/RadiusChip.tsx src/style.css
git commit -m "feat(kit): add shared RadiusChip (radius counterpart to InlineColorChip)"
```

---

### Task 2: Give `ItemActions` a first-class `radius` prop

Wires RadiusChip into the shared item chrome so every multi-item block (CTA buttons, cards, etc.) can expose a consistent radius pill next to BG/Tekst.

**Files:**
- Modify: `src/components/ItemActions.tsx`

- [ ] **Step 1: Extend Props** (add after `extraChips?: React.ReactNode;` in the `Props` type)

```tsx
	/** Optional per-item corner radius. When onRadiusChange is provided, a
	 *  RadiusChip renders after the colour chips (before extraChips). */
	radius?: number;
	onRadiusChange?: ( v: number ) => void;
	radiusMax?: number;
```

- [ ] **Step 2: Import RadiusChip + render it** (import at top; render the chip in the swatch row, immediately before `{ extraChips }`)

```tsx
import RadiusChip from './RadiusChip';
// …in the actions row, after the BG/Tekst chips and before extraChips:
{ typeof radius === 'number' && onRadiusChange && (
	<RadiusChip
		value={ radius }
		onChange={ onRadiusChange }
		max={ radiusMax ?? 40 }
	/>
) }
{ extraChips }
```

(Destructure `radius`, `onRadiusChange`, `radiusMax` in the component params alongside `extraChips`.)

- [ ] **Step 3: Types compile**

Run: `npx tsc --noEmit`
Expected: PASS.

- [ ] **Step 4: Commit**

```bash
git add src/components/ItemActions.tsx
git commit -m "feat(kit): ItemActions gains optional radius chip"
```

---

### Task 3: Hero CTA radius — finish the editor control

Backend (attribute + template) already done in Task 0's commit. Now surface a per-CTA radius via `MultiCtaRow` → `ItemActions`, driven by the block-level `buttonRadius` (all CTAs in a hero share one radius, matching cta-section's model).

**Files:**
- Modify: `src/components/MultiCtaRow.tsx` (thread an optional block-level radius through to each ItemActions)
- Modify: `src/blocks/hero/edit.tsx` (pass `buttonRadius` + setter into MultiCtaRow)

- [ ] **Step 1: Add optional radius props to MultiCtaRow** (in its `Props`)

```tsx
	/** Block-level button radius (px) + setter. When provided, each CTA's
	 *  ItemActions shows the shared RadiusChip; all CTAs share this value. */
	buttonRadius?: number;
	onButtonRadiusChange?: ( v: number ) => void;
```

- [ ] **Step 2: Forward to ItemActions** (in the per-CTA `<ItemActions … />`, add)

```tsx
	radius={ buttonRadius }
	onRadiusChange={ onButtonRadiusChange }
```

- [ ] **Step 3: Pass from hero edit** (in `src/blocks/hero/edit.tsx`, the `<MultiCtaRow … />` around line 1864)

```tsx
	buttonRadius={ attributes.buttonRadius ?? 8 }
	onButtonRadiusChange={ ( v ) =>
		setAttributes( { buttonRadius: v } )
	}
```

- [ ] **Step 4: Build**

Run: `pnpm build 2>&1 | tail -5`
Expected: "compiled … with N warnings" (warnings only, no errors); postbuild copies templates.

- [ ] **Step 5: Visual verify**

Reload http://localhost:10033/wp-admin/post.php?post=23614&action=edit (Cmd+Shift+R). Select a hero CTA. Expected: a "Radius: 8px" pill next to BG/Tekst; dragging it rounds/squares the button live; frontend at `/` reflects it.

- [ ] **Step 6: Commit**

```bash
git add src/components/MultiCtaRow.tsx src/blocks/hero/edit.tsx
git commit -m "feat(hero): per-CTA radius control via shared RadiusChip"
```

---

### Task 4: Stats-row card radius

Add a `cardRadius` attribute + control + apply to the stat card. Default matches the current rendered radius (inspect `stats-row/template.php` for the current card `border-radius`; use that as the default so existing rows are unchanged — likely `16`).

**Files:**
- Modify: `src/blocks/stats-row/block.json` (add attribute)
- Modify: `src/blocks/stats-row/template.php` (read + apply)
- Modify: `src/blocks/stats-row/edit.tsx` (RadiusChip in the section band; import RadiusChip)

- [ ] **Step 1: Add attribute** (in `block.json` `attributes`)

```json
"cardRadius": { "type": "number", "default": 16 }
```

- [ ] **Step 2: Apply in template** (read near the other attribute reads; add to the card wrapper inline style)

```php
$card_radius = max( 0, min( 999, (int) ( $attributes['cardRadius'] ?? 16 ) ) );
// …on the stats card element style attr:
style="<?php echo esc_attr( 'border-radius:' . $card_radius . 'px;' . $existing ); ?>"
```

(First confirm the card element + any existing hardcoded radius class; remove a hardcoded `rounded-*` if it would override, mirroring the hero fix.)

- [ ] **Step 3: Add control** (in `stats-row/edit.tsx`, inside the existing section-controls band, add)

```tsx
<RadiusChip
	value={ attributes.cardRadius ?? 16 }
	onChange={ ( v ) => setAttributes( { cardRadius: v } ) }
	label={ __( 'Kort-radius', 'styrk-blocks' ) }
/>
```

Add `import RadiusChip from '../../components/RadiusChip';` and `cardRadius: number;` to the block's attribute type.

- [ ] **Step 4: Build + verify**

Run: `pnpm build 2>&1 | tail -3` then reload editor; select stats-row → "Kort-radius" pill changes the card corners live.

- [ ] **Step 5: Commit**

```bash
git add src/blocks/stats-row/
git commit -m "feat(stats-row): card corner-radius control via shared RadiusChip"
```

---

### Task 5: Migrate `contact-section` onto the shared chip + fix the broken pill radius

`contact-section/edit.tsx` defines a local `chipStyle` (~line 152) and popover state for `eyebrowRadius`/`formRadius`/`infoRadius`. Replace those local radius pills with `RadiusChip`, and fix the eyebrow ("pill") radius that "doesn't apply" — verify the template actually consumes the attribute.

**Files:**
- Modify: `src/blocks/contact-section/edit.tsx` (swap local radius pills → RadiusChip; keep color chips as InlineColorChip)
- Modify: `src/blocks/contact-section/template.php` (fix eyebrow radius application)

- [ ] **Step 1: Diagnose the broken pill radius**

Run: `grep -n "eyebrowRadius\|eyebrow_radius\|border-radius" src/blocks/contact-section/template.php`
Expected: identify whether `eyebrowRadius` is read and applied to the eyebrow element. If missing/overridden by a hardcoded `border-radius`/`rounded-*`, that's the bug.

- [ ] **Step 2: Fix the template** — ensure the eyebrow inline style consumes the attribute (mirror `rich-text-section/template.php:28` pattern):

```php
$eyebrow_radius = max( 0, min( 999, (int) ( $attributes['eyebrowRadius'] ?? 50 ) ) );
$eyebrow_style .= 'border-radius:' . $eyebrow_radius . 'px;';
```

Remove any hardcoded eyebrow `border-radius` that overrides it.

- [ ] **Step 3: Replace local radius pills with RadiusChip** — for each of `eyebrowRadius`/`formRadius`/`infoRadius`, replace the local-`chipStyle` button+popover with:

```tsx
<RadiusChip value={ attributes.formRadius ?? 16 } onChange={ ( v ) => setAttributes( { formRadius: v } ) } label={ __( 'Skjema-radius', 'styrk-blocks' ) } />
```

(and analogously for `infoRadius`, `eyebrowRadius`). Delete the now-unused `chipStyle` const + radius popover state. Import RadiusChip.

- [ ] **Step 4: Build + verify**

Run: `pnpm build 2>&1 | tail -3`. Reload editor → contact-section: radius pills match sizing of the other bands; eyebrow radius now visibly rounds the eyebrow on the frontend.

- [ ] **Step 5: Commit**

```bash
git add src/blocks/contact-section/
git commit -m "fix(contact-section): use shared RadiusChip + apply eyebrow radius (was ignored)"
```

---

### Task 6: Normalize the bespoke "Aa" typography button (hero)

`hero/edit.tsx:1676` renders a bare "Aa" `cb-feature-card__swatch` with no dot/label, so it reads smaller/inconsistent next to the dotted TEXT/BG chips. Add a leading glyph so its box matches the sibling chips.

**Files:**
- Modify: `src/blocks/hero/edit.tsx` (the "Aa" button, ~line 1676)

- [ ] **Step 1: Match the chip anatomy** — give the Aa button a leading glyph span so its width/baseline match the color chips:

```tsx
<button type="button" className="cb-feature-card__swatch" aria-label={ __( 'Typografi', 'styrk-blocks' ) } onClick={ … } onMouseDown={ ( e ) => e.preventDefault() }>
	<span className="cb-feature-card__swatch-dot" aria-hidden="true" style={ { border: 0, fontWeight: 700, background: 'transparent' } } />
	{ __( 'Aa', 'styrk-blocks' ) }
</button>
```

(There are two such buttons — subtext AND ingress typography popovers per the comment at line 220; apply to both.)

- [ ] **Step 2: Build + verify**

Run: `pnpm build 2>&1 | tail -3`. Reload editor → hero SUBTEXT band: the "Aa" pill is the same height/shape as TEXT/BG.

- [ ] **Step 3: Commit**

```bash
git add src/blocks/hero/edit.tsx
git commit -m "fix(hero): Aa typography chip matches sibling chip sizing"
```

---

### Task 7: Fix uneven control-band placement (services-editorial, split-section)

The user reported the services / split control bands look "uneven." Diagnose against `StandardSectionControls` (used by 23 blocks) — the outliers likely render controls outside the standard band wrapper or with ad-hoc margins.

**Files:**
- Modify: `src/blocks/services-editorial/edit.tsx`
- Modify: `src/blocks/split-section/edit.tsx`

- [ ] **Step 1: Diagnose**

Run: `grep -n "StandardSectionControls\|EditorPanel\|cb-ed-panel\|style={{" src/blocks/services-editorial/edit.tsx src/blocks/split-section/edit.tsx | head -30`
Expected: find controls placed with ad-hoc inline layout instead of the standard band wrapper. Screenshot each block's band in the editor to confirm the misalignment.

- [ ] **Step 2: Wrap stray controls in the standard band** — move the offending controls into the same `StandardSectionControls`/`EditorPanel` wrapper the other blocks use, removing ad-hoc margins so buttons align on one baseline. (Exact edit depends on Step 1 findings; match a known-good block e.g. `feature-cards/edit.tsx` as the reference layout.)

- [ ] **Step 3: Build + visual verify** both bands align like the reference block.

- [ ] **Step 4: Commit**

```bash
git add src/blocks/services-editorial/edit.tsx src/blocks/split-section/edit.tsx
git commit -m "fix(editor): align services-editorial + split-section control bands to the standard band"
```

---

### Task 8: Rollout audit + QA gate

Ensure the RadiusChip is the single radius pattern and nothing regressed on other client sites.

**Files:** none (audit) + any small follow-up edits surfaced

- [ ] **Step 1: Find remaining ad-hoc radius pills**

Run: `grep -rn "Radius: \|chipStyle\|eyebrowRadius" src/blocks --include=*.tsx | grep -v RadiusChip`
Expected: no local radius-pill buttons remain (SectionHeader's eyebrow radius may be migrated in a follow-up; note if deferred).

- [ ] **Step 2: Type + lint gate**

Run: `npx tsc --noEmit` (PASS) and `npx eslint src --ext .ts,.tsx 2>&1 | tail -15`
Expected: no NEW errors beyond the Task 0 baseline (hero's 4 pre-existing). If a new error appears, fix it.

- [ ] **Step 3: Build**

Run: `pnpm build 2>&1 | tail -3`
Expected: compiles (warnings ok).

- [ ] **Step 4: Backwards-compat check (critical — shared plugin)**

Because new attributes default to current values, existing saved blocks must render unchanged. Open one existing page on ANOTHER site that uses these blocks (skotnes-bygg local, or hegbra-bygg) with the branch's build symlinked/copied in, and confirm hero/stats/contact render identically to before. Document the pages checked.

- [ ] **Step 5: Visual verify on anleggspartner1** — all six controls present + consistent sizing: hero CTA radius, stats card radius, contact form/info/eyebrow radius, Aa chip, aligned services/split bands. Screenshot each.

- [ ] **Step 6: Final commit / PR prep**

```bash
git add -A && git commit -m "chore: radius-chip kit rollout audit + QA"
```
Do NOT merge to main or push until the user reviews and approves (per project rules).

---

## Notes / open decisions

- **SectionHeader eyebrow radius:** it predates RadiusChip and works. Migrating it to RadiusChip is a consistency nicety, not a bug fix — deferred to a follow-up unless it looks visibly different from the new chips.
- **Pre-existing hero eslint errors:** left untouched (out of scope; fixing experimental-API usage risks behavior change). Flag to the user separately.
- **cta-section / rich-text-section** already have working block-level radius; optionally re-skin their radius control to RadiusChip for visual parity in a follow-up (not required for the reported bugs).
