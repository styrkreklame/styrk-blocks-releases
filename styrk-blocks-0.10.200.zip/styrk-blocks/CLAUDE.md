# Styrk Blocks — working instructions for Claude Code

## ⚠️ READ THIS FIRST, EVERY SESSION

**Project state lives in GitHub Issues, not in local files.** Sessions get wiped;
the issue tracker does not.

    gh issue view 282            # 📌 TRACKER — state of play. Start here.
    gh issue list --label frozen # known fixes deliberately NOT applied, and why

Issue #282 records what was fixed, what is deliberately left alone, which CI
gates exist, and — importantly — the mistakes made in previous sessions so they
are not repeated. Update it when the state changes.

Do not trust a local STATUS/handoff markdown file over the tracker.

---

## Design system

The folder [design-system/](design-system/) is the visual source of
truth for this plugin.

**Before making UI changes, read:**

- [design-system/README.md](design-system/README.md) — brand
  fundamentals, tokens, iconography
- [design-system/SKILL.md](design-system/SKILL.md) — content rules +
  hard rules for production code
- [design-system/colors_and_type.css](design-system/colors_and_type.css) —
  canonical tokens (colors, type, spacing, shadows, radii)
- [design-system/assets/icons.js](design-system/assets/icons.js) — the
  27 Feather-style stroke icons. **Never invent new icon SVGs.**
- [design-system/ui_kits/website/](design-system/ui_kits/website/) —
  hi-fi component specs (the 17 blocks as they should render, as JSX)
- [design-system/preview/](design-system/preview/) — per-token
  specimens (buttons, eyebrows, colors, type, etc.)

When building or editing a block, **mirror the matching preview /
ui_kit component in look and behavior.**

---

## Official palette (from the brand book)

All four hex values are fixed by the designer. **Do not invent new
brand colors** — use tints 100 / 80 / 50 only.

| Role           | Hex       | CMYK              | RGB             |
|----------------|-----------|-------------------|-----------------|
| Logofarge      | `#00486A` | 100, 40, 15, 50   | 0, 72, 106      |
| Støttefarge 1  | `#0084AF` | 100, 6, 7, 25     | 0, 132, 175     |
| Støttefarge 2  | `#5DB6CF` | 60, 10, 14, 0     | 93, 182, 207    |
| Støttefarge 3  | `#F5833C` | 0, 60, 85, 0      | 245, 131, 60    |

Tint tokens already in `colors_and_type.css`:
`--primary-80 / -50`, `--secondary-80 / -50`, `--light-teal-80 / -50`,
`--accent-80 / -50`.

---

## Typography

Two families only — **Fraunces** (display serif) and **Inter** (sans).
Fonts are self-hosted in `design-system/fonts/` (latin subsets, Bunny
CDN origin). **Do not substitute.**

---

## Contrast

Every fg/bg combination must pass WCAG AA. Specifically:

- **Never white text on `--accent` (#F5833C)** — fails AA at **2.56:1**
  (measured, not estimated; pinned by `tests/php/unit/ContrastTest.php`). It
  does not even clear the 3:1 large-text bar. Use navy text on orange, or
  **soft peach (`#FCE6D3`) with navy text**.
  - *Sanctioned exception:* the global `::selection` highlight is white
    on `#F5833C` (see `design-system/README.md`). WCAG does not apply a
    contrast minimum to selection highlights, and it is transient rather
    than content. This is the **only** permitted white-on-orange pairing.
- **Primary CTA** = navy `#00486A` with white text (AAA).
- **Accent CTA** = soft peach fill with navy text.
- Orange is a **decorative accent color** (icons, underlines, dots), not
  a body-text color.

---

## Hard rules for production code (`src/`)

- **Dynamic blocks only.** `save()` must return `null` — all markup comes
  from the PHP render callback in `template.php`. A `save.tsx` file may
  exist, but only as a `return null` stub (or, where a block hosts
  InnerBlocks, `return <InnerBlocks.Content />` to persist the inner
  content the callback receives as `$content`). Never emit block markup
  from `save()`; that is what forces deprecations.
- **Additive schema changes.** Never rename / remove block attributes.
- **Escape everything in `template.php`:** `esc_html`, `esc_attr`,
  `esc_url`, `wp_kses_post`. Inline styles go through `esc_attr`.
  Escape-on-assignment is the house style — if a variable is escaped
  where it is built, do not double-escape it at the echo site.
- **Theme colors** reference `theme.json` via
  `var(--wp--preset--color--<slug>, #hex-fallback)` — always include
  the fallback, and the fallback must be an **official brand hex**. This
  plugin is copied into many client sites; a fallback carrying another
  client's colour is how one brand leaks into another.
- **Build output (`build/`) is NOT committed** — `build/` is gitignored
  (see the rationale in `.gitignore`). Client sites update from the
  release zip, and both `release-zip.js` and the release workflow run
  `pnpm build` before packing. After cloning, run `pnpm build` once.
- **Edit `src/`, never `build/`.**

---

## Content rules

- **Norwegian bokmål** everywhere in rendered copy. Sentence case (no
  title casing).
- Use **"du"**, never "De". Decimal comma, space thousand-separator.
- **No emoji. No hand-drawn SVG. No illustrations** — use the
  StyrkIcons catalog.

---

## Motion

- **0.15 s / 0.25 s / 0.4 s** transitions with
  `cubic-bezier(0.4, 0, 0.2, 1)`.
- **Always wrap animation in `@media (prefers-reduced-motion: reduce)`
  killswitches.**
- Button hover = subtle lift + shadow increase, **never darker fill**.

---

## Video

Any block that takes a video (`hero` bg video, `video-section`, `video-reels`,
`media-grid`) requires optimized source. Follow
[docs/VIDEO-REQUIREMENTS.md](docs/VIDEO-REQUIREMENTS.md): MP4/H.264, 1080p max,
`yuv420p`, `+faststart`, poster image, 5–10 MB (≤ 25 MB cap). **Background loops
strip audio and go smaller; watch-video keeps audio (mono for speech).** Provide
a WebM/VP9 sibling where the block has a `videoWebm` slot (`hero`).

---

## Not shipped

`design-system/` is listed in `.distignore` and **must stay there** —
it's dev-time reference, never goes in the release zip.
