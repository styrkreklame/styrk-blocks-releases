<?php
/**
 * Search Settings — admin page for the search results hero + copy.
 *
 * Settings → Search lets admins manage the editable Norwegian copy
 * surfaced by `[styrk_search_results]` (see search-render.php):
 *  - Eyebrow text above the heading
 *  - Heading templates (with-query / no-query)
 *  - Empty-state copy
 *  - Form placeholder + button label
 *  - Number of results per page
 *
 * Deliberately content-only — no color or typography pickers. The
 * hero's visual style (navy bg, Fraunces display, orange accent)
 * comes from the design system tokens in theme.json + style.css and
 * applies globally. Per-instance styling controls would encourage
 * brand drift; copy-only keeps the page brand-locked.
 *
 * Mirrors the structure of header-settings.php / footer-settings.php
 * so the three "global" settings pages (Header, Footer, Search) stay
 * consistent under WP's Settings menu.
 *
 * @package StyrkBlocks
 */

defined( 'ABSPATH' ) || exit;

if ( defined( 'CB_SEARCH_SETTINGS_LOADED' ) ) return;
define( 'CB_SEARCH_SETTINGS_LOADED', true );

/* ── Option key ─────────────────────────────────────────────────────────────── */
define( 'CB_SEARCH_OPTION', 'cb_search_settings' );

/**
 * Default values for search settings. The {query} token in heading
 * and empty-line templates is replaced at render time with the
 * user's actual search term (already escaped).
 */
function cb_search_defaults(): array {
	return [
		'eyebrow_text'        => 'SØKERESULTATER',
		'heading_with_query'  => 'Søkeresultater for «{query}»',
		'heading_no_query'    => 'Søk på siden',
		'hint_no_query'       => 'Skriv et søkeord over for å finne sider, ansatte eller innlegg.',
		'empty_line'          => 'Ingen treff for «{query}».',
		'empty_hint'          => 'Sjekk stavemåten eller prøv et annet søkeord.',
		'empty_back_label'    => 'gå tilbake til forsiden',
		'form_placeholder'    => 'Søk på siden…',
		'form_button'         => 'Søk',
		'posts_per_page'      => 20,

		/* Overlay (the dropdown panel that opens from the header search icon).
		   Neutral defaults — admins override in Settings → Search with the
		   child theme's brand palette. */
		'overlay_panel_bg'              => '#FFFFFF',
		'overlay_panel_text'            => '#1F2937',
		'overlay_panel_muted'           => '#6B7280',
		'overlay_panel_placeholder'     => '#9CA3AF',
		'overlay_icon_color'            => '#6B7280',
		'overlay_close_hover_bg'        => '#F3F4F6',
		'overlay_result_hover_bg'       => '#F3F4F6',
		'overlay_all_results_color'     => '#1F2937',
		'overlay_all_results_hover_bg'  => '#F3F4F6',
		'overlay_backdrop_color'        => '#111827',
		'overlay_backdrop_opacity'      => 55,

		/* Standalone search results page (/?s=…). Neutral defaults. */
		'results_eyebrow_color'      => '#6B7280',
		'results_heading_color'      => '#1F2937',
		'results_text'               => '#1F2937',
		'results_muted'              => '#6B7280',
		'results_input_bg'           => '#FFFFFF',
		'results_input_text'         => '#1F2937',
		'results_input_border'       => '#D1D5DB',
		'results_link_hover'         => '#2563EB',
		'results_submit_bg'          => '#2563EB',
		'results_submit_text'        => '#FFFFFF',
		'results_submit_hover_bg'    => '#1D4ED8',
	];
}

/**
 * Optional palette of preset swatches surfaced in the WP color picker for
 * the search-settings page. Empty in baseline — child themes can register
 * their brand colors via the `styrk_blocks_search_palette` filter:
 *
 *   add_filter( 'styrk_blocks_search_palette', fn( $palette ) =>
 *       [ '#0F1B2D', '#1E5BD8', '#F4F5F7', '#FFFFFF', '#000000' ]
 *   );
 */
function cb_search_palette(): array {
	return (array) apply_filters( 'styrk_blocks_search_palette', [] );
}

/**
 * Return merged (saved + defaults) search settings.
 */
function cb_get_search_settings(): array {
	$saved = get_option( CB_SEARCH_OPTION, [] );
	return wp_parse_args( $saved, cb_search_defaults() );
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_search_settings_menu(): void {
	add_options_page(
		__( 'Search Settings', 'styrk-blocks' ),
		__( 'Search', 'styrk-blocks' ),
		'manage_options',
		'cb-search-settings',
		'cb_search_settings_page'
	);
}
add_action( 'admin_menu', 'cb_search_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

function cb_search_settings_init(): void {
	register_setting( 'cb_search_group', CB_SEARCH_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_search_sanitize',
		'default'           => cb_search_defaults(),
	] );

	/* ── Section: Heading & eyebrow ──────────────────────────────────────────── */
	add_settings_section(
		'cb_search_heading',
		__( 'Heading & eyebrow', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Copy shown in the navy hero band at the top of the search results page. Use {query} as a placeholder for the user\'s search term — it is replaced safely at render time.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_eyebrow_text', __( 'Eyebrow text', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'eyebrow_text', 'description' => __( 'Small all-caps label above the heading.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_heading_with_query', __( 'Heading (with query)', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'heading_with_query', 'description' => __( 'Shown when the visitor has a search term. Use {query} for the term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_heading_no_query', __( 'Heading (no query)', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'heading_no_query', 'description' => __( 'Shown when the visitor lands on /?s= with no term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_hint_no_query', __( 'Hint (no query)', 'styrk-blocks' ), 'cb_search_render_textarea_field', 'cb-search-settings', 'cb_search_heading',
		[ 'key' => 'hint_no_query', 'description' => __( 'Helper paragraph below the heading when no term is entered yet.', 'styrk-blocks' ) ] );

	/* ── Section: Empty state ────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_empty',
		__( 'No-results state', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Copy shown when the search returns zero results. Keep it warm — visitors are mid-task.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_empty_line', __( 'Headline', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_line', 'description' => __( 'Use {query} for the searched term.', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_empty_hint', __( 'Hint', 'styrk-blocks' ), 'cb_search_render_textarea_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_hint', 'description' => __( 'Suggestion paragraph (without the home link — that is rendered separately).', 'styrk-blocks' ) ] );

	add_settings_field( 'cb_search_empty_back_label', __( 'Back-to-home link label', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_empty',
		[ 'key' => 'empty_back_label', 'description' => __( 'Visible label of the inline link back to the home page.', 'styrk-blocks' ) ] );

	/* ── Section: Search form ────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_form',
		__( 'Search form', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Strings shown inside the inline search-again form in the hero.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_form_placeholder', __( 'Input placeholder', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_form',
		[ 'key' => 'form_placeholder' ] );

	add_settings_field( 'cb_search_form_button', __( 'Button label', 'styrk-blocks' ), 'cb_search_render_text_field', 'cb-search-settings', 'cb_search_form',
		[ 'key' => 'form_button' ] );

	/* ── Section: Behaviour ──────────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_behaviour',
		__( 'Behaviour', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Pagination size and other non-content options.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);

	add_settings_field( 'cb_search_posts_per_page', __( 'Results per page', 'styrk-blocks' ), 'cb_search_render_number_field', 'cb-search-settings', 'cb_search_behaviour',
		[ 'key' => 'posts_per_page', 'min' => 1, 'max' => 100, 'description' => __( 'How many hits to show per results page (1–100).', 'styrk-blocks' ) ] );

	/* ── Section: Overlay colors ───────────────────────────────────────────────── */
	add_settings_section(
		'cb_search_overlay_colors',
		__( 'Overlay colors (header search dropdown)', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Colors used inside the search dropdown that opens when a visitor clicks the header search icon. Hex or rgba(...) accepted.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);
	add_settings_field( 'cb_search_overlay_panel_bg', __( 'Panel background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_panel_bg', 'description' => __( 'Background of the white search card.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_panel_text', __( 'Panel text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_panel_text', 'description' => __( 'Text color for the input, status line and result titles inside the panel.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_panel_muted', __( 'Panel muted text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_panel_muted', 'description' => __( 'Secondary text inside the panel — type label, excerpts.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_panel_placeholder', __( 'Input placeholder', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_panel_placeholder', 'description' => __( 'Color of the placeholder text inside the search input.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_icon_color', __( 'Icon color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_icon_color', 'description' => __( 'Color of the magnifying-glass icon (left of the input) and the close button icon (right of the input).', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_close_hover_bg', __( 'Close button hover background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_close_hover_bg', 'description' => __( 'Tint shown behind the close button on hover/focus.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_result_hover_bg', __( 'Result row hover background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_result_hover_bg', 'description' => __( 'Background tint shown when a result row is hovered or keyboard-focused (arrow keys).', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_all_results_color', __( '"See all results" link color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_all_results_color', 'description' => __( 'Color of the "See all results for X →" link at the bottom of the dropdown.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_all_results_hover_bg', __( '"See all results" hover background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_all_results_hover_bg', 'description' => __( 'Background tint behind the "See all results" link on hover/focus.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_backdrop_color', __( 'Backdrop color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_backdrop_color', 'description' => __( 'Color of the translucent layer behind the panel.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_overlay_backdrop_opacity', __( 'Backdrop opacity', 'styrk-blocks' ), 'cb_search_render_opacity_field', 'cb-search-settings', 'cb_search_overlay_colors',
		[ 'key' => 'overlay_backdrop_opacity', 'description' => __( '0 = fully transparent, 100 = solid. The panel sits on top of this.', 'styrk-blocks' ) ] );

	/* ── Section: Results-page colors ──────────────────────────────────────────── */
	add_settings_section(
		'cb_search_results_colors',
		__( 'Results page colors', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Colors on the standalone search results page (/?s=…). Sits on the dark site body by default.', 'styrk-blocks' )
		),
		'cb-search-settings'
	);
	add_settings_field( 'cb_search_results_eyebrow_color', __( 'Eyebrow color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_eyebrow_color', 'description' => __( 'The small label above the heading ("SØKERESULTATER").', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_heading_color', __( 'Heading color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_heading_color', 'description' => __( 'The big H1 ("Søkeresultater for X"). Make sure it contrasts the page background.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_text', __( 'Body text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_text', 'description' => __( 'Hit titles + excerpts + empty-state copy.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_muted', __( 'Muted text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_muted', 'description' => __( 'Type chip, counts and helper copy.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_input_bg', __( 'Search input background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_input_bg' ] );
	add_settings_field( 'cb_search_results_input_text', __( 'Search input text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_input_text', 'description' => __( 'Text typed into the search field on the results page.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_input_border', __( 'Search input border', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_input_border' ] );
	add_settings_field( 'cb_search_results_submit_bg', __( 'Submit button background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_submit_bg' ] );
	add_settings_field( 'cb_search_results_submit_text', __( 'Submit button text', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_submit_text' ] );
	add_settings_field( 'cb_search_results_submit_hover_bg', __( 'Submit button hover background', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_submit_hover_bg', 'description' => __( 'Submit button background on hover/focus.', 'styrk-blocks' ) ] );
	add_settings_field( 'cb_search_results_link_hover', __( 'Hit title hover color', 'styrk-blocks' ), 'cb_search_render_color_field', 'cb-search-settings', 'cb_search_results_colors',
		[ 'key' => 'results_link_hover' ] );
}
add_action( 'admin_init', 'cb_search_settings_init' );

/* ── Field renderers ────────────────────────────────────────────────────────── */

function cb_search_render_text_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<input type="text" id="%s" name="%s" value="%s" class="regular-text" style="max-width:520px;" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_attr( $value )
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

function cb_search_render_textarea_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<textarea id="%s" name="%s" rows="3" class="large-text" style="max-width:520px;">%s</textarea>',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_textarea( $value )
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

function cb_search_render_color_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';
	$defaults    = cb_search_defaults();
	$default     = (string) ( $defaults[ $key ] ?? '' );
	$palette     = wp_json_encode( cb_search_palette() );

	/* WP color picker (Iris) — palette swatches + freeform wheel. The
	   inline init script runs once per page in cb_search_enqueue_picker(). */
	printf(
		'<input type="text" id="%s" name="%s" value="%s" data-default-color="%s" data-palettes=\'%s\' class="cb-color-picker" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_attr( $value ),
		esc_attr( $default ),
		esc_attr( $palette )
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

function cb_search_render_opacity_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (int) ( $settings[ $key ] ?? 0 );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';

	printf(
		'<input type="range" id="%1$s" name="%2$s" value="%3$d" min="0" max="100" step="1" oninput="document.getElementById(\'%1$s-val\').textContent=this.value+\'%%\'" style="vertical-align:middle;width:240px;" />'
		. ' <output id="%1$s-val" style="margin-left:8px;font-variant-numeric:tabular-nums;">%3$d%%</output>',
		esc_attr( $field_id ),
		esc_attr( $name ),
		$value
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/**
 * Enqueue WP's bundled color picker (Iris) on the search settings screen
 * only — no need to load it on every admin page. Inline init wires every
 * .cb-color-picker input + applies the configured theme palette.
 */
function cb_search_enqueue_picker( $hook ): void {
	if ( $hook !== 'settings_page_cb-search-settings' ) return;
	wp_enqueue_style( 'wp-color-picker' );
	wp_enqueue_script( 'wp-color-picker' );
	wp_add_inline_script(
		'wp-color-picker',
		"jQuery(function($){"
		. "$('.cb-color-picker').each(function(){"
		. "var palettes = []; try { palettes = JSON.parse($(this).attr('data-palettes') || '[]'); } catch(e){}"
		. "$(this).wpColorPicker({ palettes: palettes });"
		. "});"
		. "});"
	);
}
add_action( 'admin_enqueue_scripts', 'cb_search_enqueue_picker' );

function cb_search_render_number_field( array $args ): void {
	$settings    = cb_get_search_settings();
	$key         = $args['key'];
	$value       = (int) ( $settings[ $key ] ?? 0 );
	$name        = CB_SEARCH_OPTION . "[{$key}]";
	$field_id    = "cb_search_{$key}";
	$description = $args['description'] ?? '';
	$min         = (int) ( $args['min'] ?? 1 );
	$max         = (int) ( $args['max'] ?? 100 );

	printf(
		'<input type="number" id="%s" name="%s" value="%d" min="%d" max="%d" step="1" style="width:90px;" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		$value,
		$min,
		$max
	);
	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

function cb_search_sanitize( $input ): array {
	$defaults  = cb_search_defaults();
	$sanitized = [];

	$text_keys = [
		'eyebrow_text', 'heading_with_query', 'heading_no_query',
		'empty_line', 'empty_back_label', 'form_placeholder', 'form_button',
	];
	foreach ( $text_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) $input[ $k ] : '';
		$clean = sanitize_text_field( wp_unslash( $raw ) );
		$sanitized[ $k ] = $clean !== '' ? $clean : $defaults[ $k ];
	}

	$textarea_keys = [ 'hint_no_query', 'empty_hint' ];
	foreach ( $textarea_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) $input[ $k ] : '';
		$clean = sanitize_textarea_field( wp_unslash( $raw ) );
		$sanitized[ $k ] = $clean !== '' ? $clean : $defaults[ $k ];
	}

	$ppp = isset( $input['posts_per_page'] ) ? (int) $input['posts_per_page'] : $defaults['posts_per_page'];
	$sanitized['posts_per_page'] = max( 1, min( 100, $ppp ) );

	/* Color keys — hex only (#RGB / #RRGGBB). WP's color picker always
	   emits hex; anything else gets ignored and falls back to default. */
	$color_keys = [
		'overlay_panel_bg', 'overlay_panel_text', 'overlay_panel_muted',
		'overlay_panel_placeholder', 'overlay_icon_color',
		'overlay_close_hover_bg', 'overlay_result_hover_bg',
		'overlay_all_results_color', 'overlay_all_results_hover_bg',
		'overlay_backdrop_color',
		'results_eyebrow_color', 'results_heading_color',
		'results_text', 'results_muted',
		'results_input_bg', 'results_input_text', 'results_input_border',
		'results_submit_bg', 'results_submit_text', 'results_submit_hover_bg',
		'results_link_hover',
	];
	foreach ( $color_keys as $k ) {
		$raw = isset( $input[ $k ] ) ? (string) $input[ $k ] : '';
		$raw = trim( wp_unslash( $raw ) );
		$clean = sanitize_hex_color( $raw );
		$sanitized[ $k ] = $clean ?: $defaults[ $k ];
	}

	$op_raw = isset( $input['overlay_backdrop_opacity'] ) ? (int) $input['overlay_backdrop_opacity'] : $defaults['overlay_backdrop_opacity'];
	$sanitized['overlay_backdrop_opacity'] = max( 0, min( 100, $op_raw ) );

	return $sanitized;
}

/* ── Frontend CSS injector ──────────────────────────────────────────────────── */

/**
 * Emit a <style> block in <head> that publishes the configured colors as
 * CSS custom properties on :root. The theme's stylesheet reads these vars
 * (--cb-search-panel-bg, --cb-search-panel-text, etc.) so the admin's
 * picks become the live values without touching the stylesheet.
 */
function cb_search_emit_css_vars(): void {
	$s = cb_get_search_settings();
	// Compose the translucent backdrop from hex color + 0–100 opacity.
	$bd = ltrim( (string) $s['overlay_backdrop_color'], '#' );
	if ( strlen( $bd ) === 3 ) {
		$bd = $bd[0] . $bd[0] . $bd[1] . $bd[1] . $bd[2] . $bd[2];
	}
	$r = strlen( $bd ) === 6 ? hexdec( substr( $bd, 0, 2 ) ) : 0;
	$g = strlen( $bd ) === 6 ? hexdec( substr( $bd, 2, 2 ) ) : 0;
	$b = strlen( $bd ) === 6 ? hexdec( substr( $bd, 4, 2 ) ) : 0;
	$a = number_format( ( (int) $s['overlay_backdrop_opacity'] ) / 100, 2, '.', '' );
	$backdrop_rgba = "rgba({$r},{$g},{$b},{$a})";

	$css = ':root{'
		. '--cb-search-panel-bg:' . $s['overlay_panel_bg'] . ';'
		. '--cb-search-panel-text:' . $s['overlay_panel_text'] . ';'
		. '--cb-search-panel-muted:' . $s['overlay_panel_muted'] . ';'
		. '--cb-search-panel-placeholder:' . $s['overlay_panel_placeholder'] . ';'
		. '--cb-search-icon-color:' . $s['overlay_icon_color'] . ';'
		. '--cb-search-close-hover-bg:' . $s['overlay_close_hover_bg'] . ';'
		. '--cb-search-result-hover-bg:' . $s['overlay_result_hover_bg'] . ';'
		. '--cb-search-all-results-color:' . $s['overlay_all_results_color'] . ';'
		. '--cb-search-all-results-hover-bg:' . $s['overlay_all_results_hover_bg'] . ';'
		. '--cb-search-backdrop-bg:' . $backdrop_rgba . ';'
		. '--cb-search-results-eyebrow:' . $s['results_eyebrow_color'] . ';'
		. '--cb-search-results-heading:' . $s['results_heading_color'] . ';'
		. '--cb-search-results-text:' . $s['results_text'] . ';'
		. '--cb-search-results-muted:' . $s['results_muted'] . ';'
		. '--cb-search-results-input-bg:' . $s['results_input_bg'] . ';'
		. '--cb-search-results-input-text:' . $s['results_input_text'] . ';'
		. '--cb-search-results-input-border:' . $s['results_input_border'] . ';'
		. '--cb-search-results-submit-bg:' . $s['results_submit_bg'] . ';'
		. '--cb-search-results-submit-text:' . $s['results_submit_text'] . ';'
		. '--cb-search-results-submit-hover-bg:' . $s['results_submit_hover_bg'] . ';'
		. '--cb-search-results-link-hover:' . $s['results_link_hover'] . ';'
		. '}';
	printf( '<style id="cb-search-vars">%s</style>', $css ); // values sanitized in cb_search_sanitize
}
add_action( 'wp_head', 'cb_search_emit_css_vars', 5 );

/* ── Admin page template ────────────────────────────────────────────────────── */

function cb_search_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) return;
	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Search Settings', 'styrk-blocks' ); ?></h1>
		<p class="description" style="max-width:720px;">
			<?php esc_html_e( 'These strings appear on the /?s= search results page. Visual styling (navy hero, Fraunces display heading, orange button) comes from the design system and is intentionally not editable here — keep brand consistency.', 'styrk-blocks' ); ?>
		</p>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'cb_search_group' );
			do_settings_sections( 'cb-search-settings' );
			submit_button();
			?>
		</form>
	</div>
	<?php
}

/* ── Seed defaults on first load ────────────────────────────────────────────── */

function cb_search_seed_defaults(): void {
	if ( get_option( CB_SEARCH_OPTION ) ) return;
	update_option( CB_SEARCH_OPTION, cb_search_defaults() );
}
add_action( 'admin_init', 'cb_search_seed_defaults' );
