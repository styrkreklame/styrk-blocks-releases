<?php
/**
 * Header Settings — admin page for logo + header appearance.
 *
 * Settings → Header lets admins manage:
 *  - Logo uploads (main header logo + white footer variant)
 *  - Header background mode (transparent overlay or solid color)
 *  - Header background color (when solid)
 *  - Header text / nav link color
 *
 * On save, the main logo also updates the `custom_logo` theme mod
 * so wp:site-logo blocks work out of the box.
 *
 * @package CustomBlocks
 */

defined( 'ABSPATH' ) || exit;

// File-level idempotency guard: if this file somehow gets included twice
// (symlink setups, mu-plugins double-load, etc.) the `function` declarations
// below would fatal with "Cannot redeclare". Bail early on the second include.
if ( defined( 'CB_HEADER_SETTINGS_LOADED' ) ) return;
define( 'CB_HEADER_SETTINGS_LOADED', true );

/* ── Option key ─────────────────────────────────────────────────────────────── */
define( 'CB_HEADER_OPTION', 'cb_header_settings' );

/**
 * Default values for header settings.
 */
function cb_header_defaults(): array {
	return [
		'logo_id'        => 0,              // attachment ID — main/color logo
		// NOTE: logo_white_id USED to live here. As of v1.6.5 the white
		// (footer) logo is managed under Settings → Footer → Logo so the
		// setting sits with the rest of the footer fields (address, email,
		// credits, legal links). The key is intentionally kept in the
		// defaults array, set to 0, so any callsite that still reads it
		// gets a falsy default — the footer-logo shortcode falls through
		// to the new footer-settings key first, then header for back-compat,
		// then the theme asset.
		'logo_white_id'  => 0,
		'bg_mode'        => 'transparent',  // 'transparent' | 'solid'
		'bg_color'       => '#0a2020',      // solid background color
		'text_color'     => '#ffffff',      // header text / nav link color
		'position'       => 'relative',     // 'relative' | 'sticky'
		'hide_on_scroll' => '0',            // '0' | '1' — only effective with sticky
		'ssr'            => '0',            // '0' | '1' — server-rendered header (beta)
		// How the header row distributes logo / nav / controls. Default '' =
		// INHERIT: emit nothing, so the per-block `navLayout` attribute set in
		// the template part wins. A value chosen here overrides the block
		// globally — 'spread' pushes the search + CTA cluster to the far-right
		// edge (via the flex spacer in view.tsx), 'compact' groups everything
		// on the left.
		// Header alignment — the ONE control that frames the header. 'content' =
		// the header rail matches the page content column (logo lines up with the
		// content's left edge, search/CTA with its right edge); 'full' = edge to
		// edge; 'custom' = fall back to the advanced Content width + Side padding
		// controls below. Default 'custom' so existing sites keep whatever
		// content_width/side_pad they saved (back-compat).
		'header_align'   => 'custom',       // 'content' | 'full' | 'custom'
		// Header AND footer width — one switch that frames both bands. '' = not
		// set: the header follows "Header alignment" below and the footer keeps
		// its own theme width, so existing sites render exactly as before.
		//   'full'    = both stretch to the device width (small edge gutter)
		//   'content' = both follow the page content column
		//   'wide'    = both use a wider 1600px rail
		'frame_width'    => '',             // '' (not set) | 'full' | 'content' | 'wide'
		'nav_layout'     => '',             // '' (inherit) | 'compact' | 'spread' — legacy, only under 'custom'
		// Horizontal alignment of the desktop nav LINKS within the header row,
		// independent of nav_layout: 'start' = grouped next to the logo
		// (historical default), 'center' = centered in the header, 'end' =
		// pushed to the right next to the search / CTA cluster (matches designs
		// that group the menu with the header utilities).
		'nav_align'      => 'start',        // 'start' | 'center' | 'end'
		// What the DESKTOP header shows for navigation. Historical behaviour =
		// 'nav' (inline links on desktop, hamburger/megamenu only on mobile).
		// 'nav_toggle' also surfaces the hamburger/megamenu icon on desktop
		// ALONGSIDE the inline nav; 'toggle' hides the inline nav entirely and
		// shows ONLY the hamburger/megamenu icon at every width. Default 'nav'
		// keeps existing sites unchanged.
		'nav_mode'       => 'nav',          // 'nav' | 'nav_toggle' | 'toggle'
		// How the site logo renders while the megamenu is OPEN (the header sits
		// on the dark navy overlay then). 'white' = the historical CSS-mask
		// white logo; 'black' = the same mask filled black; 'colored' = the
		// real colour logo (no recolour). Default 'white' = unchanged.
		// Optional dedicated megamenu logo image (e.g. a ready-made white
		// version). When set, render.php emits its URL and view.tsx renders it
		// as a real <img> in the open megamenu (no CSS mask). Default 0 = none,
		// so the megamenu_logo_color CSS-mask fallback below is used and
		// existing sites render exactly as before.
		'megamenu_logo_id'    => 0,         // attachment ID — uploaded megamenu logo
		'megamenu_logo_color' => 'white',   // 'colored' | 'white' | 'black'
		// Mobile hamburger button + mobile menu colours, stored as theme
		// palette SLUGS (resolved to `var(--wp--preset--color--{slug})` in
		// render.php). Default '' = INHERIT: emit nothing, so view.tsx keeps
		// its historical hardcoded look (teal button, icon = nav colour, menu
		// bg = primary, menu text = white). Existing sites stay unchanged
		// until an admin picks a colour here.
		'hamburger_bg'     => '',           // '' (inherit) | palette slug → button background
		'hamburger_icon'   => '',           // '' (inherit) | palette slug → hamburger icon colour
		'mobile_menu_bg'   => '',           // '' (inherit) | palette slug → mobile menu panel bg
		'mobile_menu_text' => '',           // '' (inherit) | palette slug → mobile menu link/text colour
		// Header content rail width + side gutters. These let an admin line
		// the logo/nav/CTA row up with the page's content band (which varies
		// per theme). Default '' = INHERIT: emit no CSS var, so the per-block
		// `contentWidth` attribute set in the template part (e.g. hywer's
		// 1440) and the historical 1280px/52px fallback in view.tsx still win.
		// Only a value explicitly chosen here overrides the block.
		'content_width'  => '',             // '' (inherit) | '1180' | '1280' | '1440' | 'full'
		'side_pad'       => '',             // '' (inherit) | px gutter 0–120
		// Optional header CTA — when set, the theme's header script
		// renders this label/URL as a button next to the search icon.
		// Default `cta_show='1'` so existing live sites keep their
		// button even before an admin visits this page; unchecking the
		// box hides it. Label/URL empty = script falls back to its own
		// historical defaults ("Ta kontakt" → "/kontakt/").
		'cta_label'      => '',
		'cta_url'        => '',
		'cta_show'       => '1',
		// CTA button colours — palette slugs (resolved to CSS vars in render.php).
		// '' = inherit: keep the historical accent bg + white text.
		'cta_bg'         => '',
		'cta_text'       => '',
		// Corner radius in px. 6 is the value the button was hardcoded to before
		// this became a setting, so an untouched site renders unchanged.
		'cta_radius'     => 6,
	];
}

/**
 * Return merged (saved + defaults) header settings.
 */
function cb_get_header_settings(): array {
	$saved = get_option( CB_HEADER_OPTION, [] );
	return wp_parse_args( $saved, cb_header_defaults() );
}

/* ── Admin page registration ────────────────────────────────────────────────── */

function cb_header_settings_menu(): void {
	add_options_page(
		__( 'Header Settings', 'styrk-blocks' ),
		__( 'Header', 'styrk-blocks' ),
		'manage_options',
		'cb-header-settings',
		'cb_header_settings_page'
	);
}
add_action( 'admin_menu', 'cb_header_settings_menu' );

/* ── Settings API ───────────────────────────────────────────────────────────── */

function cb_header_settings_init(): void {
	register_setting( 'cb_header_group', CB_HEADER_OPTION, [
		'type'              => 'array',
		'sanitize_callback' => 'cb_header_sanitize',
		'default'           => cb_header_defaults(),
	] );

	/* ── Section: Logo ────────────────────────────────────────────────────────
	 * Only the header logo lives on this page now. The white footer logo is
	 * managed under Settings → Footer so it groups with the rest of the
	 * footer fields (address, email, copyright, legal links). */
	add_settings_section(
		'cb_header_logos',
		__( 'Logo', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Upload your site logo. SVG or PNG recommended.', 'styrk-blocks' )
		),
		'cb-header-settings'
	);

	add_settings_field(
		'cb_header_logo',
		__( 'Main Logo (header)', 'styrk-blocks' ),
		'cb_header_render_media_field',
		'cb-header-settings',
		'cb_header_logos',
		[ 'key' => 'logo_id', 'description' => __( 'Displayed in the site header. Use a white/light version if your header background is dark.', 'styrk-blocks' ) ]
	);

	/* ── Section: Appearance ─────────────────────────────────────────────────── */
	add_settings_section(
		'cb_header_appearance',
		__( 'Header Appearance', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Control how the header looks across the site. These settings apply globally.', 'styrk-blocks' )
		),
		'cb-header-settings'
	);

	add_settings_field(
		'cb_header_bg_mode',
		__( 'Background Mode', 'styrk-blocks' ),
		'cb_header_render_bg_mode_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_bg_color',
		__( 'Background Color', 'styrk-blocks' ),
		'cb_header_render_color_field',
		'cb-header-settings',
		'cb_header_appearance',
		[
			'key'         => 'bg_color',
			'description' => __( 'Used when Background Mode is set to "Solid color".', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_text_color',
		__( 'Text / Nav Color', 'styrk-blocks' ),
		'cb_header_render_color_field',
		'cb-header-settings',
		'cb_header_appearance',
		[
			'key'         => 'text_color',
			'description' => __( 'Color for the site name, navigation links, and hamburger icon.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_hamburger_bg',
		__( 'Hamburger button background (mobile)', 'styrk-blocks' ),
		'cb_header_render_palette_field',
		'cb-header-settings',
		'cb_header_appearance',
		[
			'key'         => 'hamburger_bg',
			'description' => __( 'Background colour of the mobile menu (hamburger) button. "Default" keeps the current teal.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_hamburger_icon',
		__( 'Hamburger icon color (mobile)', 'styrk-blocks' ),
		'cb_header_render_palette_field',
		'cb-header-settings',
		'cb_header_appearance',
		[
			'key'         => 'hamburger_icon',
			'description' => __( 'Colour of the three lines inside the hamburger button. "Default" follows the header text colour.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_mobile_menu_bg',
		__( 'Mobile menu background', 'styrk-blocks' ),
		'cb_header_render_palette_field',
		'cb-header-settings',
		'cb_header_appearance',
		[
			'key'         => 'mobile_menu_bg',
			'description' => __( 'Background of the full-screen mobile menu panel. "Default" uses the theme primary colour.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_mobile_menu_text',
		__( 'Mobile menu text / links', 'styrk-blocks' ),
		'cb_header_render_palette_field',
		'cb-header-settings',
		'cb_header_appearance',
		[
			'key'         => 'mobile_menu_text',
			'description' => __( 'Link and text colour inside the mobile menu. "Default" keeps white.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_position',
		__( 'Position', 'styrk-blocks' ),
		'cb_header_render_position_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_hide_on_scroll',
		__( 'Hide on scroll down', 'styrk-blocks' ),
		'cb_header_render_hide_on_scroll_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_ssr',
		__( 'Server-rendered header (beta)', 'styrk-blocks' ),
		'cb_header_render_ssr_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_frame_width',
		__( 'Header and footer width', 'styrk-blocks' ),
		'cb_header_render_frame_width_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_align',
		__( 'Header alignment', 'styrk-blocks' ),
		'cb_header_render_header_align_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_nav_align',
		__( 'Menu position', 'styrk-blocks' ),
		'cb_header_render_nav_align_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_nav_mode',
		__( 'Desktop navigation', 'styrk-blocks' ),
		'cb_header_render_nav_mode_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_megamenu_logo_id',
		__( 'Megamenu logo (white)', 'styrk-blocks' ),
		'cb_header_render_media_field',
		'cb-header-settings',
		'cb_header_appearance',
		[
			'key'         => 'megamenu_logo_id',
			'description' => __( 'Upload a ready-made megamenu logo (e.g. a white version). If left empty, the colour option below is used.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_megamenu_logo_color',
		__( 'Megamenu logo color', 'styrk-blocks' ),
		'cb_header_render_megamenu_logo_color_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_content_width',
		__( 'Content width', 'styrk-blocks' ),
		'cb_header_render_content_width_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	add_settings_field(
		'cb_header_side_pad',
		__( 'Side padding', 'styrk-blocks' ),
		'cb_header_render_side_pad_field',
		'cb-header-settings',
		'cb_header_appearance'
	);

	/* ── Section: Header CTA ─────────────────────────────────────────────────
	 * Optional button next to the search icon — label + URL configurable from
	 * the admin so the editor doesn't have to touch theme JS. */
	add_settings_section(
		'cb_header_cta',
		__( 'Header CTA', 'styrk-blocks' ),
		fn() => printf(
			'<p>%s</p>',
			esc_html__( 'Optional button shown next to the search icon on every page. Leave blank to hide.', 'styrk-blocks' )
		),
		'cb-header-settings'
	);

	add_settings_field(
		'cb_header_cta_show',
		__( 'Show CTA button', 'styrk-blocks' ),
		'cb_header_render_cta_show_field',
		'cb-header-settings',
		'cb_header_cta'
	);

	add_settings_field(
		'cb_header_cta_label',
		__( 'Label', 'styrk-blocks' ),
		'cb_header_render_text_field',
		'cb-header-settings',
		'cb_header_cta',
		[
			'key'         => 'cta_label',
			'placeholder' => 'Ta kontakt',
			'description' => __( 'Button text. Default: "Ta kontakt".', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_cta_url',
		__( 'URL', 'styrk-blocks' ),
		'cb_header_render_text_field',
		'cb-header-settings',
		'cb_header_cta',
		[
			'key'         => 'cta_url',
			'placeholder' => '/kontakt/',
			'description' => __( 'Where the button links. Use a relative path or full URL.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_cta_bg',
		__( 'Button background', 'styrk-blocks' ),
		'cb_header_render_palette_field',
		'cb-header-settings',
		'cb_header_cta',
		[
			'key'         => 'cta_bg',
			'description' => __( 'Background colour of the CTA button. "Default" keeps the theme accent.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_cta_text',
		__( 'Button text colour', 'styrk-blocks' ),
		'cb_header_render_palette_field',
		'cb-header-settings',
		'cb_header_cta',
		[
			'key'         => 'cta_text',
			'description' => __( 'Text colour of the CTA button. "Default" keeps white.', 'styrk-blocks' ),
		]
	);

	add_settings_field(
		'cb_header_cta_radius',
		__( 'Corner radius (px)', 'styrk-blocks' ),
		'cb_header_render_cta_radius_field',
		'cb-header-settings',
		'cb_header_cta'
	);
}

/**
 * CTA corner-radius field. Range is capped at 50px: past roughly half the
 * button's height the shape stops changing, so a larger number would look
 * broken rather than rounder.
 */
function cb_header_render_cta_radius_field(): void {
	$settings = cb_get_header_settings();
	$current  = (int) ( $settings['cta_radius'] ?? 6 );
	$name     = CB_HEADER_OPTION . '[cta_radius]';

	printf(
		'<input type="number" name="%s" value="%d" min="0" max="50" step="1" class="small-text" />',
		esc_attr( $name ),
		esc_attr( $current )
	);
	echo '<p class="description">'
		. esc_html__( '0 = square corners, 50 = pill. Default: 6.', 'styrk-blocks' )
		. '</p>';
}
add_action( 'admin_init', 'cb_header_settings_init' );

/* ── Field renderers ────────────────────────────────────────────────────────── */

/**
 * Media uploader field (for logos).
 */
function cb_header_render_media_field( array $args ): void {
	$settings      = cb_get_header_settings();
	$key           = $args['key'];
	$attachment_id = (int) ( $settings[ $key ] ?? 0 );
	$name          = CB_HEADER_OPTION . "[{$key}]";
	$field_id      = "cb_header_{$key}";
	$preview_url   = $attachment_id ? wp_get_attachment_image_url( $attachment_id, 'medium' ) : '';
	$description   = $args['description'] ?? '';
	$bg            = in_array( $key, [ 'logo_white_id', 'megamenu_logo_id' ], true ) ? '#0a2020' : '#f0f0f1';

	?>
	<div class="cb-media-field" id="<?php echo esc_attr( $field_id ); ?>_wrapper">
		<div class="cb-media-preview" style="margin-bottom:10px;padding:16px;background:<?php echo esc_attr( $bg ); ?>;border-radius:8px;display:<?php echo $preview_url ? 'block' : 'none'; ?>;max-width:320px;">
			<img id="<?php echo esc_attr( $field_id ); ?>_preview" src="<?php echo esc_url( $preview_url ); ?>" alt="" style="max-width:100%;max-height:120px;width:auto;height:auto;display:block;" />
		</div>
		<input type="hidden" id="<?php echo esc_attr( $field_id ); ?>" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( $attachment_id ); ?>" />
		<button type="button" class="button cb-upload-btn" data-target="<?php echo esc_attr( $field_id ); ?>" data-preview-bg="<?php echo esc_attr( $bg ); ?>">
			<?php echo $preview_url ? esc_html__( 'Change Logo', 'styrk-blocks' ) : esc_html__( 'Upload Logo', 'styrk-blocks' ); ?>
		</button>
		<?php if ( $preview_url ) : ?>
			<button type="button" class="button cb-remove-btn" data-target="<?php echo esc_attr( $field_id ); ?>" style="margin-left:8px;color:#b32d2e;">
				<?php esc_html_e( 'Remove', 'styrk-blocks' ); ?>
			</button>
		<?php endif; ?>
		<?php if ( $description ) : ?>
			<p class="description" style="margin-top:8px;"><?php echo esc_html( $description ); ?></p>
		<?php endif; ?>
	</div>
	<?php
}

/**
 * Background mode radio buttons.
 */
function cb_header_render_bg_mode_field(): void {
	$settings = cb_get_header_settings();
	$current  = $settings['bg_mode'] ?? 'transparent';
	$name     = CB_HEADER_OPTION . '[bg_mode]';

	$options = [
		'transparent' => __( 'Transparent (overlays hero/content)', 'styrk-blocks' ),
		'solid'       => __( 'Solid color', 'styrk-blocks' ),
	];

	echo '<fieldset>';
	foreach ( $options as $value => $label ) {
		printf(
			'<label style="display:block;margin-bottom:8px;"><input type="radio" name="%s" value="%s" %s /> %s</label>',
			esc_attr( $name ),
			esc_attr( $value ),
			checked( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</fieldset>';
	echo '<p class="description">' . esc_html__( 'Transparent works best when the first block is a hero with a dark background image.', 'styrk-blocks' ) . '</p>';
}

/**
 * Position radio buttons — relative (scrolls with the page) vs sticky
 * (pins to the top of the viewport on scroll).
 */
function cb_header_render_position_field(): void {
	$settings = cb_get_header_settings();
	$current  = $settings['position'] ?? 'relative';
	$name     = CB_HEADER_OPTION . '[position]';

	$options = [
		'relative' => __( 'Relative — scrolls away with the page', 'styrk-blocks' ),
		'sticky'   => __( 'Sticky — pins to the top of the viewport on scroll', 'styrk-blocks' ),
	];

	echo '<fieldset>';
	foreach ( $options as $value => $label ) {
		printf(
			'<label style="display:block;margin-bottom:8px;"><input type="radio" name="%s" value="%s" %s /> %s</label>',
			esc_attr( $name ),
			esc_attr( $value ),
			checked( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</fieldset>';
	echo '<p class="description">' . esc_html__( 'Sticky keeps the same starting position as relative — it only changes behaviour once the page scrolls past the header.', 'styrk-blocks' ) . '</p>';
}

/**
 * Hide-on-scroll-down toggle. Only effective when Position is "sticky" —
 * the header slides out of view as the visitor scrolls down and slides
 * back in as they scroll up. Common pattern (Medium, GitHub) that gives
 * mobile/tablet visitors more reading space.
 */
function cb_header_render_hide_on_scroll_field(): void {
	$settings = cb_get_header_settings();
	$current  = ! empty( $settings['hide_on_scroll'] ) ? '1' : '0';
	$name     = CB_HEADER_OPTION . '[hide_on_scroll]';

	printf(
		'<label><input type="checkbox" name="%s" value="1" %s /> %s</label>',
		esc_attr( $name ),
		checked( $current, '1', false ),
		esc_html__( 'Slide the header out when scrolling down, slide it back in when scrolling up', 'styrk-blocks' )
	);
	echo '<p class="description">' . esc_html__( 'Only takes effect when Position is set to "Sticky".', 'styrk-blocks' ) . '</p>';
}

/**
 * Server-rendered header toggle. The same header, built in PHP instead of in
 * the browser: no pop-in after load, menu links in the HTML for crawlers and
 * no-JS visitors, ~3 KB of JS instead of React.
 */
function cb_header_render_ssr_field(): void {
	$settings = cb_get_header_settings();
	printf(
		'<label><input type="checkbox" name="%s" value="1" %s /> %s</label>',
		esc_attr( CB_HEADER_OPTION . '[ssr]' ),
		checked( ! empty( $settings['ssr'] ) ? '1' : '0', '1', false ),
		esc_html__( 'Build the header on the server (no pop-in on load)', 'styrk-blocks' )
	);
	echo '<p class="description">' . esc_html__( 'Beta. Looks and behaves like the current header; turn it off to go back.', 'styrk-blocks' ) . '</p>';
}

/**
 * Header-and-footer width select — one switch for how wide BOTH bands run, so
 * the header and the footer always share the same left and right edges.
 *
 *  - Not set      : nothing changes; "Header alignment" below decides the
 *                   header and the footer keeps the theme's own width.
 *  - Full width   : logo and buttons sit at the screen edges (with a small
 *                   gutter), and the footer does the same.
 *  - Page content : both follow the page content column.
 *  - Wide         : both use a 1600px rail, between the two.
 */
function cb_header_render_frame_width_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['frame_width'] ?? '' );
	$name     = CB_HEADER_OPTION . '[frame_width]';

	$options = [
		''        => __( 'Not set — use "Header alignment" below, footer unchanged', 'styrk-blocks' ),
		'full'    => __( 'Full width — header and footer stretch to the screen edges', 'styrk-blocks' ),
		'content' => __( 'Page content — header and footer follow the content column', 'styrk-blocks' ),
		'wide'    => __( 'Wide — header and footer use a wider 1600px frame', 'styrk-blocks' ),
	];

	echo '<select name="' . esc_attr( $name ) . '">';
	foreach ( $options as $value => $label ) {
		printf(
			'<option value="%s" %s>%s</option>',
			esc_attr( $value ),
			selected( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'One switch for both bands. When set, it replaces "Header alignment" and the footer gets the same left and right edges as the header at every screen size.', 'styrk-blocks' ) . '</p>';
}

/**
 * Header-alignment select — the single control that frames the header row.
 *
 *  - Match page content : the header rail uses the SAME max-width + side gutter
 *    as the page content, so the logo lines up with the content's left edge and
 *    the search / CTA cluster with its right edge. Recommended.
 *  - Full width : the header stretches edge to edge (only the gutter inset).
 *  - Custom : fall back to the advanced "Content width" + "Side padding" fields
 *    below (legacy behaviour).
 */
function cb_header_render_header_align_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['header_align'] ?? 'custom' );
	$name     = CB_HEADER_OPTION . '[header_align]';

	$options = [
		'content' => __( 'Match page content — logo & CTA line up with the content column', 'styrk-blocks' ),
		'full'    => __( 'Full width — edge to edge', 'styrk-blocks' ),
		'custom'  => __( 'Custom — set the width & side padding manually (advanced)', 'styrk-blocks' ),
	];

	echo '<select name="' . esc_attr( $name ) . '">';
	foreach ( $options as $value => $label ) {
		printf(
			'<option value="%s" %s>%s</option>',
			esc_attr( $value ),
			selected( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( '"Match page content" is the easy choice: the logo, menu and buttons frame the same column as the page below, no manual numbers. Use "Custom" only if you need a bespoke width.', 'styrk-blocks' ) . '</p>';
}

/**
 * Element-alignment select — controls how the header row distributes the
 * logo, navigation and the search/CTA controls.
 *
 *  - Inherit : emit nothing; the per-block `navLayout` attribute set in the
 *              template part wins (back-compat).
 *  - Compact : logo, nav and controls grouped together on the left.
 *  - Spread  : a flex spacer (added in view.tsx) pushes the search icon and
 *              CTA button hard to the right edge of the header.
 *
 * This is the global override for the same compact/spread switch that also
 * exists as a block attribute — set it here once and every page's header
 * follows, no template editing required.
 */
function cb_header_render_nav_layout_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['nav_layout'] ?? '' );
	$name     = CB_HEADER_OPTION . '[nav_layout]';

	$options = [
		''        => __( 'Inherit — use the header block setting', 'styrk-blocks' ),
		'compact' => __( 'Compact — logo, menu and buttons grouped on the left', 'styrk-blocks' ),
		'spread'  => __( 'Spread — push search / CTA buttons to the far-right edge', 'styrk-blocks' ),
	];

	echo '<select name="' . esc_attr( $name ) . '">';
	foreach ( $options as $value => $label ) {
		printf(
			'<option value="%s" %s>%s</option>',
			esc_attr( $value ),
			selected( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'How the header row lines up its elements. "Spread" pushes the search icon and CTA button to the far right; "Compact" keeps the logo, menu and buttons together on the left.', 'styrk-blocks' ) . '</p>';
}

/**
 * Menu-alignment select — where the desktop nav links sit horizontally in the
 * header row. Independent of the compact/spread element-alignment above:
 *
 *  - Start  : links grouped right after the logo (historical default).
 *  - Center : links centered in the header row.
 *  - End    : links pushed to the right, next to the search / CTA cluster.
 */
function cb_header_render_nav_align_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['nav_align'] ?? 'start' );
	$name     = CB_HEADER_OPTION . '[nav_align]';

	$options = [
		'start'  => __( 'Start — menu next to the logo (left)', 'styrk-blocks' ),
		'center' => __( 'Center — menu centered in the header', 'styrk-blocks' ),
		'end'    => __( 'End — menu on the right, next to search / CTA', 'styrk-blocks' ),
	];

	echo '<select name="' . esc_attr( $name ) . '">';
	foreach ( $options as $value => $label ) {
		printf(
			'<option value="%s" %s>%s</option>',
			esc_attr( $value ),
			selected( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'Horizontal position of the navigation links. "End" groups the menu with the search and CTA on the right (matches the Hywer design).', 'styrk-blocks' ) . '</p>';
}

/**
 * Desktop navigation mode — what the header shows on wide screens.
 *   nav        → inline links only (hamburger/megamenu stays mobile-only) [default]
 *   nav_toggle → inline links AND the hamburger/megamenu icon, both on desktop
 *   toggle     → hamburger/megamenu icon only, no inline links at any width
 */
function cb_header_render_nav_mode_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['nav_mode'] ?? 'nav' );
	$name     = CB_HEADER_OPTION . '[nav_mode]';

	$options = [
		'nav'        => __( 'Standard menu only — inline links on desktop', 'styrk-blocks' ),
		'nav_toggle' => __( 'Menu + megamenu icon — show both on desktop', 'styrk-blocks' ),
		'toggle'     => __( 'Megamenu icon only — no inline links', 'styrk-blocks' ),
	];

	echo '<select name="' . esc_attr( $name ) . '">';
	foreach ( $options as $value => $label ) {
		printf(
			'<option value="%s" %s>%s</option>',
			esc_attr( $value ),
			selected( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'Controls the desktop header. The hamburger icon opens the full-screen megamenu. On narrow screens the header always collapses to the megamenu icon regardless of this setting.', 'styrk-blocks' ) . '</p>';
}

/**
 * Megamenu-open logo color — how the logo renders while the megamenu is open
 * (the header is on the dark navy overlay then). colored = real colour logo,
 * white / black = the CSS-mask single-colour logo.
 */
function cb_header_render_megamenu_logo_color_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['megamenu_logo_color'] ?? 'white' );
	$name     = CB_HEADER_OPTION . '[megamenu_logo_color]';

	$options = [
		'colored' => __( 'Colored — the original logo', 'styrk-blocks' ),
		'white'   => __( 'White', 'styrk-blocks' ),
		'black'   => __( 'Black', 'styrk-blocks' ),
	];

	echo '<select name="' . esc_attr( $name ) . '">';
	foreach ( $options as $value => $label ) {
		printf(
			'<option value="%s" %s>%s</option>',
			esc_attr( $value ),
			selected( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'How the site logo appears while the megamenu is open. White or Black recolor the logo via a CSS mask; Colored shows the original logo as-is.', 'styrk-blocks' ) . '</p>';
}

/**
 * Theme-palette dropdown. Stores a palette SLUG (or '' for "keep the current
 * look"). render.php turns the slug into `var(--wp--preset--color--{slug})`,
 * so the colour tracks the theme palette instead of a frozen hex. Options are
 * built from the active theme palette, so each site shows its own colours.
 */
/**
 * Shared visual swatch picker — renders the theme palette as clickable colour
 * squares (radio inputs, no JS, no hex typing). Used by every colour field on
 * this page so they all look + behave the same.
 *
 * $value_mode:
 *   'slug' → each swatch submits the palette slug (resolved to a CSS var later)
 *   'hex'  → each swatch submits the literal hex
 * $has_default adds a leading "Default / current look" swatch (value '').
 *
 * A hidden input mirrors the current value first; the checked radio (later in
 * the DOM) overrides it on submit. So picking nothing keeps the current value
 * — even a legacy off-palette hex — instead of silently resetting it.
 */
function cb_header_render_swatches( string $name, string $current, string $value_mode, bool $has_default ): void {
	static $css_printed = false;
	if ( ! $css_printed ) {
		$css_printed = true;
		echo '<style>'
			. '.cb-swatches{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:2px 0}'
			. '.cb-swatch{position:relative;display:inline-flex;cursor:pointer;line-height:0}'
			. '.cb-swatch input{position:absolute;inset:0;width:100%;height:100%;margin:0;opacity:0;cursor:pointer}'
			. '.cb-swatch__box{display:block;width:30px;height:30px;border-radius:6px;border:1px solid rgba(0,0,0,.18);box-sizing:border-box}'
			. '.cb-swatch input:checked+.cb-swatch__box{box-shadow:0 0 0 2px #fff,0 0 0 4px #2271b1}'
			. '.cb-swatch input:focus-visible+.cb-swatch__box{box-shadow:0 0 0 2px #fff,0 0 0 4px #2271b1}'
			. '.cb-swatch--default .cb-swatch__box{background:repeating-linear-gradient(135deg,#fff 0 6px,#d63638 6px 8px)}'
			. '</style>';
	}

	// Hidden fallback so an off-palette current value survives a save.
	printf( '<input type="hidden" name="%s" value="%s" />', esc_attr( $name ), esc_attr( $current ) );

	echo '<div class="cb-swatches">';

	if ( $has_default ) {
		printf(
			'<label class="cb-swatch cb-swatch--default" title="%1$s"><input type="radio" name="%2$s" value="" %3$s aria-label="%1$s" /><span class="cb-swatch__box"></span></label>',
			esc_attr__( 'Default (current look)', 'styrk-blocks' ),
			esc_attr( $name ),
			checked( $current, '', false )
		);
	}

	foreach ( cb_header_theme_palette() as $sw ) {
		$slug  = (string) ( $sw['slug'] ?? '' );
		$color = (string) ( $sw['color'] ?? '' );
		$value = 'slug' === $value_mode ? $slug : $color;
		if ( '' === $value || '' === $color ) {
			continue;
		}
		$label = (string) ( $sw['name'] ?? $slug ) . ' — ' . $color;
		printf(
			'<label class="cb-swatch" title="%1$s"><input type="radio" name="%2$s" value="%3$s" %4$s aria-label="%1$s" /><span class="cb-swatch__box" style="background:%5$s"></span></label>',
			esc_attr( $label ),
			esc_attr( $name ),
			esc_attr( $value ),
			checked( strcasecmp( $current, $value ) === 0, true, false ),
			esc_attr( $color )
		);
	}

	echo '</div>';
}

/**
 * Theme-palette swatch picker (stores a palette slug → CSS var). "Default"
 * keeps the historical hardcoded look for that element.
 */
function cb_header_render_palette_field( array $args ): void {
	$settings    = cb_get_header_settings();
	$key         = $args['key'];
	$current     = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_HEADER_OPTION . "[{$key}]";
	$description = $args['description'] ?? '';

	cb_header_render_swatches( $name, $current, 'slug', true );

	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/**
 * Content-width select — the max width of the logo/nav/CTA rail. Line this
 * up with the page's content band so the logo sits flush with the content
 * below it. "Full width" stretches edge to edge (gutters only).
 */
function cb_header_render_content_width_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['content_width'] ?? '' );
	$name     = CB_HEADER_OPTION . '[content_width]';

	$options = [
		''     => __( 'Inherit — use the block/theme setting', 'styrk-blocks' ),
		'1180' => __( 'Narrow — 1180px', 'styrk-blocks' ),
		'1280' => __( 'Standard — 1280px', 'styrk-blocks' ),
		'1440' => __( 'Wide — 1440px', 'styrk-blocks' ),
		'full' => __( 'Full width — edge to edge', 'styrk-blocks' ),
	];

	echo '<select name="' . esc_attr( $name ) . '">';
	foreach ( $options as $value => $label ) {
		printf(
			'<option value="%s" %s>%s</option>',
			esc_attr( $value ),
			selected( $current, $value, false ),
			esc_html( $label )
		);
	}
	echo '</select>';
	echo '<p class="description">' . esc_html__( 'Advanced — only used when Header alignment is set to "Custom". Max width of the header content rail.', 'styrk-blocks' ) . '</p>';
}

/**
 * Side-padding number field — the gutter on each side of the header rail.
 * Match it to the page section gutter for pixel-perfect logo alignment.
 */
function cb_header_render_side_pad_field(): void {
	$settings = cb_get_header_settings();
	$current  = (string) ( $settings['side_pad'] ?? '' );
	$name     = CB_HEADER_OPTION . '[side_pad]';

	printf(
		'<input type="number" name="%s" value="%s" min="0" max="120" step="1" placeholder="%s" style="width:90px;" /> <span>px</span>',
		esc_attr( $name ),
		esc_attr( $current ),
		esc_attr__( 'inherit', 'styrk-blocks' )
	);
	echo '<p class="description">' . esc_html__( 'Advanced — only used when Header alignment is set to "Custom". Horizontal gutter on each side of the header (blank = 52px default).', 'styrk-blocks' ) . '</p>';
}

/**
 * Theme colour palette (from theme.json / global settings) as a flat list of
 * { color, name } for the admin swatch picker — same palette the in-canvas
 * block colour pickers use.
 */
function cb_header_theme_palette(): array {
	$out = array();
	if ( function_exists( 'wp_get_global_settings' ) ) {
		$palette = wp_get_global_settings( array( 'color', 'palette' ) );
		$list    = array();
		if ( ! empty( $palette['theme'] ) ) {
			$list = $palette['theme'];
		} elseif ( ! empty( $palette['default'] ) ) {
			$list = $palette['default'];
		} elseif ( is_array( $palette ) && isset( $palette[0] ) ) {
			$list = $palette;
		}
		foreach ( (array) $list as $c ) {
			if ( ! empty( $c['color'] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $c['color'] ) ) {
				$out[] = array(
					'color' => $c['color'],
					'name'  => $c['name'] ?? ( $c['slug'] ?? $c['color'] ),
					'slug'  => $c['slug'] ?? '',
				);
			}
		}
	}
	return $out;
}

/**
 * Color picker field.
 */
function cb_header_render_color_field( array $args ): void {
	$settings    = cb_get_header_settings();
	$key         = $args['key'];
	$value       = (string) ( $settings[ $key ] ?? '' );
	$name        = CB_HEADER_OPTION . "[{$key}]";
	$description = $args['description'] ?? '';

	// Swatch-only (stores the chosen theme colour's hex). Same visual picker as
	// every other colour field — no hex typing.
	cb_header_render_swatches( $name, $value, 'hex', false );

	if ( $description ) {
		printf( '<p class="description" style="margin-top:8px;">%s</p>', esc_html( $description ) );
	}
}

/**
 * Generic text input — driven by `key`, `placeholder`, `description` args.
 */
function cb_header_render_text_field( array $args ): void {
	$settings    = cb_get_header_settings();
	$key         = $args['key'];
	$value       = $settings[ $key ] ?? '';
	$placeholder = $args['placeholder'] ?? '';
	$description = $args['description'] ?? '';
	$name        = CB_HEADER_OPTION . "[{$key}]";
	$field_id    = "cb_header_{$key}";

	printf(
		'<input type="text" id="%s" name="%s" value="%s" placeholder="%s" class="regular-text" />',
		esc_attr( $field_id ),
		esc_attr( $name ),
		esc_attr( $value ),
		esc_attr( $placeholder )
	);
	if ( $description ) {
		printf( '<p class="description">%s</p>', esc_html( $description ) );
	}
}

/**
 * CTA show-toggle — same checkbox pattern as hide_on_scroll above.
 */
function cb_header_render_cta_show_field(): void {
	$settings = cb_get_header_settings();
	$current  = ! empty( $settings['cta_show'] ) ? '1' : '0';
	$name     = CB_HEADER_OPTION . '[cta_show]';

	printf(
		'<label><input type="checkbox" name="%s" value="1" %s /> %s</label>',
		esc_attr( $name ),
		checked( $current, '1', false ),
		esc_html__( 'Render the CTA button in the header', 'styrk-blocks' )
	);
}

/* ── Sanitise ───────────────────────────────────────────────────────────────── */

function cb_header_sanitize( $input ): array {
	$defaults  = cb_header_defaults();
	$sanitized = [];

	/* Logos — integer IDs */
	$sanitized['logo_id']       = isset( $input['logo_id'] )       ? absint( $input['logo_id'] )       : $defaults['logo_id'];
	$sanitized['logo_white_id'] = isset( $input['logo_white_id'] ) ? absint( $input['logo_white_id'] ) : $defaults['logo_white_id'];
	$sanitized['megamenu_logo_id'] = isset( $input['megamenu_logo_id'] ) ? absint( $input['megamenu_logo_id'] ) : $defaults['megamenu_logo_id'];

	/* Background mode — whitelist */
	$sanitized['bg_mode'] = isset( $input['bg_mode'] ) && in_array( $input['bg_mode'], [ 'transparent', 'solid' ], true )
		? $input['bg_mode']
		: $defaults['bg_mode'];

	/* Position — whitelist */
	$sanitized['position'] = isset( $input['position'] ) && in_array( $input['position'], [ 'relative', 'sticky' ], true )
		? $input['position']
		: $defaults['position'];

	/* Hide-on-scroll — checkbox is "1" when present, absent when off */
	$sanitized['hide_on_scroll'] = ! empty( $input['hide_on_scroll'] ) ? '1' : '0';
	$sanitized['ssr']            = ! empty( $input['ssr'] ) ? '1' : '0';

	/* Header and footer width — whitelist, fall back to '' (not set). */
	$sanitized['frame_width'] = isset( $input['frame_width'] ) && in_array( $input['frame_width'], [ 'full', 'content', 'wide' ], true )
		? $input['frame_width']
		: '';

	/* Header alignment — whitelist, fall back to 'custom' (back-compat). */
	$sanitized['header_align'] = isset( $input['header_align'] ) && in_array( $input['header_align'], [ 'content', 'full', 'custom' ], true )
		? $input['header_align']
		: $defaults['header_align'];

	/* Element alignment (legacy, Custom only) — no longer has its own field, so
	   PRESERVE whatever value was saved when it isn't in the submitted form
	   (otherwise saving the page would silently wipe an existing 'spread'). */
	$existing_layout = (string) ( get_option( CB_HEADER_OPTION, [] )['nav_layout'] ?? '' );
	$sanitized['nav_layout'] = isset( $input['nav_layout'] ) && in_array( $input['nav_layout'], [ 'compact', 'spread' ], true )
		? $input['nav_layout']
		: $existing_layout;

	/* Menu alignment — whitelist start/center/end, fall back to historical 'start'. */
	$sanitized['nav_align'] = isset( $input['nav_align'] ) && in_array( $input['nav_align'], [ 'start', 'center', 'end' ], true )
		? $input['nav_align']
		: $defaults['nav_align'];

	/* Desktop nav mode — whitelist, fall back to historical 'nav'. */
	$sanitized['nav_mode'] = isset( $input['nav_mode'] ) && in_array( $input['nav_mode'], [ 'nav', 'nav_toggle', 'toggle' ], true )
		? $input['nav_mode']
		: $defaults['nav_mode'];

	/* Megamenu logo color — whitelist, fall back to historical 'white'. */
	$sanitized['megamenu_logo_color'] = isset( $input['megamenu_logo_color'] ) && in_array( $input['megamenu_logo_color'], [ 'colored', 'white', 'black' ], true )
		? $input['megamenu_logo_color']
		: $defaults['megamenu_logo_color'];

	/* Content width — whitelist of presets, fall back to historical 1280 */
	/* Content width — '' (inherit) or a whitelisted preset. Inherit means
	   "don't emit a CSS var", so the block/template value wins. */
	$sanitized['content_width'] = isset( $input['content_width'] ) && in_array( $input['content_width'], [ '1180', '1280', '1440', 'full' ], true )
		? $input['content_width']
		: '';

	/* Side padding — '' (inherit) or integer px clamped to 0–120. A blank
	   field stays blank (inherit) rather than snapping to 0. */
	$sanitized['side_pad'] = ( isset( $input['side_pad'] ) && '' !== trim( (string) $input['side_pad'] ) )
		? (string) max( 0, min( 120, absint( $input['side_pad'] ) ) )
		: '';

	/* Header CTA — label/url plain text, show toggle as "1"/"0". */
	$sanitized['cta_label'] = isset( $input['cta_label'] ) ? sanitize_text_field( (string) $input['cta_label'] ) : $defaults['cta_label'];
	$sanitized['cta_url']   = isset( $input['cta_url'] )   ? esc_url_raw( (string) $input['cta_url'] )           : $defaults['cta_url'];
	$sanitized['cta_show']  = ! empty( $input['cta_show'] ) ? '1' : '0';

	/* Colors — must be valid hex */
	foreach ( [ 'bg_color', 'text_color' ] as $color_key ) {
		if ( isset( $input[ $color_key ] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $input[ $color_key ] ) ) {
			$sanitized[ $color_key ] = $input[ $color_key ];
		} else {
			$sanitized[ $color_key ] = $defaults[ $color_key ];
		}
	}

	/* Mobile hamburger + menu colours — '' (inherit) or a slug that exists in
	   the current theme palette. Anything else falls back to '' so a stale or
	   spoofed slug can never reach render.php. */
	$palette_slugs = array_filter( array_map(
		static fn( $sw ) => (string) ( $sw['slug'] ?? '' ),
		cb_header_theme_palette()
	) );
	foreach ( [ 'hamburger_bg', 'hamburger_icon', 'mobile_menu_bg', 'mobile_menu_text', 'cta_bg', 'cta_text' ] as $palette_key ) {
		$val = isset( $input[ $palette_key ] ) ? sanitize_key( (string) $input[ $palette_key ] ) : '';
		$sanitized[ $palette_key ] = ( '' !== $val && in_array( $val, $palette_slugs, true ) ) ? $val : '';
	}

	/* CTA corner radius. `max` on a number input is advisory — a crafted POST
	   submits anything — so clamp on the way in. */
	$sanitized['cta_radius'] = isset( $input['cta_radius'] )
		? max( 0, min( 50, (int) $input['cta_radius'] ) )
		: $defaults['cta_radius'];

	/* Sync main logo to the custom_logo theme mod so wp:site-logo works */
	if ( ! empty( $sanitized['logo_id'] ) ) {
		set_theme_mod( 'custom_logo', $sanitized['logo_id'] );
	}

	return $sanitized;
}

/* ── Admin page template ────────────────────────────────────────────────────── */

/**
 * Collapsible-section CSS for this page (cards + chevron + schematic preview
 * beside the intro copy). Mirrors the Search Settings page so the three admin
 * screens look identical. Printed once, inline.
 */
function cb_header_print_admin_css(): void {
	echo '<style>'
		. '.cb-header-settings-wrap .cb-header-section{background:#fff;border:1px solid #c3c4c7;border-radius:6px;margin:0 0 14px;padding:0}'
		. '.cb-header-settings-wrap .cb-header-section__summary{list-style:none;cursor:pointer;padding:14px 18px;display:flex;align-items:center;justify-content:space-between;gap:12px;user-select:none}'
		. '.cb-header-settings-wrap .cb-header-section__summary::-webkit-details-marker{display:none}'
		. '.cb-header-settings-wrap .cb-header-section__title{font-size:14px;font-weight:600;color:#1d2327}'
		. '.cb-header-settings-wrap .cb-header-section__chevron{font-size:12px;color:#646970;transition:transform .15s ease}'
		. '.cb-header-settings-wrap .cb-header-section[open] .cb-header-section__chevron{transform:rotate(180deg)}'
		. '.cb-header-settings-wrap .cb-header-section__body{padding:4px 18px 18px;border-top:1px solid #f0f0f1}'
		. '.cb-header-settings-wrap .cb-header-section__intro{display:flex;gap:20px;align-items:flex-start;justify-content:space-between}'
		. '.cb-header-settings-wrap .cb-header-section__intro-text{flex:1 1 auto;min-width:0}'
		. '.cb-header-settings-wrap .cb-header-section__intro-text>p{color:#50575e;margin:12px 0 4px;max-width:720px}'
		. '.cb-header-settings-wrap .cb-header-preview{flex:0 0 116px;width:116px;margin:14px 2px 0 0;padding:0}'
		. '.cb-header-settings-wrap .cb-header-preview svg{display:block;width:100%;height:auto}'
		. '@media screen and (max-width:782px){.cb-header-settings-wrap .cb-header-section__intro{flex-direction:column;gap:6px}.cb-header-settings-wrap .cb-header-preview{order:-1;margin:12px 0 0}}'
		. '.cb-header-settings-wrap .cb-header-section .form-table th{padding-top:12px;padding-bottom:12px;width:200px}'
		. '.cb-header-settings-wrap .cb-header-section .form-table td{padding-top:8px;padding-bottom:8px}'
		. '</style>';
}

/**
 * Tiny schematic SVG preview per header section — same visual language as the
 * Search Settings previews (grey = neutral chrome, WP-admin blue = the region
 * this section controls; colour sections add a swatch trio). All markup is
 * hardcoded, so it is emitted verbatim.
 */
function cb_header_section_preview_svg( string $id ): string {
	$frame = '<rect x="1.5" y="1.5" width="129" height="93" rx="7" fill="#fff" stroke="#c3c4c7" stroke-width="1.5"/>';
	$open  = '<svg viewBox="0 0 132 96" role="img" focusable="false" aria-label="%s">' . $frame;

	switch ( $id ) {
		case 'cb_header_logos': // Logo block on the left of the header bar.
			return sprintf( $open, esc_attr__( 'Preview: site logo at the left of the header bar', 'styrk-blocks' ) )
				. '<rect x="10" y="14" width="112" height="22" rx="4" fill="#f0f0f1"/>'
				. '<rect x="16" y="20" width="30" height="10" rx="2" fill="#2271b1"/>'
				. '<rect x="66" y="23" width="14" height="4" rx="2" fill="#c9c9ce"/>'
				. '<rect x="84" y="23" width="14" height="4" rx="2" fill="#c9c9ce"/>'
				. '<rect x="102" y="23" width="12" height="4" rx="2" fill="#c9c9ce"/>'
				. '<rect x="16" y="52" width="100" height="5" rx="2.5" fill="#dcdcde"/>'
				. '<rect x="16" y="64" width="100" height="5" rx="2.5" fill="#dcdcde"/>'
				. '<rect x="16" y="76" width="64" height="5" rx="2.5" fill="#dcdcde"/>'
				. '</svg>';

		case 'cb_header_appearance': // Whole header bar + colours (swatch trio).
			return sprintf( $open, esc_attr__( 'Preview: header bar colours, navigation and mobile menu', 'styrk-blocks' ) )
				. '<rect x="10" y="12" width="112" height="20" rx="4" fill="#e7f0f8" stroke="#2271b1"/>'
				. '<rect x="16" y="18" width="24" height="8" rx="2" fill="#2271b1"/>'
				. '<rect x="66" y="20" width="12" height="4" rx="2" fill="#9cb8d4"/>'
				. '<rect x="82" y="20" width="12" height="4" rx="2" fill="#9cb8d4"/>'
				. '<rect x="98" y="20" width="12" height="4" rx="2" fill="#9cb8d4"/>'
				. '<rect x="16" y="46" width="100" height="4" rx="2" fill="#dcdcde"/>'
				. '<rect x="16" y="56" width="80" height="4" rx="2" fill="#dcdcde"/>'
				. '<circle cx="20" cy="84" r="4" fill="#2271b1"/>'
				. '<circle cx="31" cy="84" r="4" fill="#9cb8d4"/>'
				. '<circle cx="42" cy="84" r="4" fill="#dcdcde"/>'
				. '</svg>';

		case 'cb_header_cta': // Highlighted CTA button at the right of the bar.
			return sprintf( $open, esc_attr__( 'Preview: call-to-action button at the right of the header', 'styrk-blocks' ) )
				. '<rect x="10" y="14" width="112" height="20" rx="4" fill="#f0f0f1"/>'
				. '<rect x="16" y="20" width="24" height="8" rx="2" fill="#c9c9ce"/>'
				. '<rect x="60" y="22" width="12" height="4" rx="2" fill="#c9c9ce"/>'
				. '<rect x="76" y="22" width="12" height="4" rx="2" fill="#c9c9ce"/>'
				. '<rect x="94" y="18" width="24" height="12" rx="6" fill="#2271b1"/>'
				. '<rect x="99" y="23" width="14" height="3" rx="1.5" fill="#fff"/>'
				. '<rect x="16" y="52" width="100" height="5" rx="2.5" fill="#dcdcde"/>'
				. '<rect x="16" y="64" width="100" height="5" rx="2.5" fill="#dcdcde"/>'
				. '<rect x="16" y="76" width="64" height="5" rx="2.5" fill="#dcdcde"/>'
				. '</svg>';
	}

	return '';
}

/**
 * Drop-in replacement for do_settings_sections() that wraps each section in a
 * collapsible card with its schematic preview beside the intro copy. All
 * sections open by default (the page is short); the chevron collapses them.
 */
function cb_header_render_collapsible_sections( string $page ): void {
	global $wp_settings_sections, $wp_settings_fields;
	if ( ! isset( $wp_settings_sections[ $page ] ) ) {
		return;
	}
	foreach ( (array) $wp_settings_sections[ $page ] as $section ) {
		$id    = (string) ( $section['id'] ?? '' );
		$intro = '';
		if ( ! empty( $section['callback'] ) ) {
			ob_start();
			call_user_func( $section['callback'], $section );
			$intro = (string) ob_get_clean();
		}
		?>
		<details class="cb-header-section" open>
			<summary class="cb-header-section__summary">
				<span class="cb-header-section__title"><?php echo esc_html( (string) $section['title'] ); ?></span>
				<span class="cb-header-section__chevron" aria-hidden="true">▾</span>
			</summary>
			<div class="cb-header-section__body">
				<?php if ( $intro !== '' || $preview !== '' ) : ?>
					<div class="cb-header-section__intro">
						<div class="cb-header-section__intro-text"><?php echo $intro; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped — section callback output ?></div>
						<?php if ( $preview !== '' ) : ?>
							<figure class="cb-header-preview"><?php echo cb_header_section_preview_svg( $id ); ?></figure>
						<?php endif; ?>
					</div>
				<?php endif; ?>
				<?php
				if ( isset( $wp_settings_fields[ $page ][ $id ] ) ) {
					echo '<table class="form-table" role="presentation">';
					do_settings_fields( $page, $id );
					echo '</table>';
				}
				?>
			</div>
		</details>
		<?php
	}
}

function cb_header_settings_page(): void {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	wp_enqueue_media();
	cb_header_print_admin_css();
	?>
	<div class="wrap cb-header-settings-wrap">
		<h1><?php esc_html_e( 'Header Settings', 'styrk-blocks' ); ?></h1>
		<p class="description" style="max-width:720px;">
			<?php esc_html_e( 'Logo, layout and colours for the site header and its mobile menu. Every colour picker is locked to the active theme palette — add new colours in theme.json.', 'styrk-blocks' ); ?>
		</p>
		<form method="post" action="options.php">
			<?php
			settings_fields( 'cb_header_group' );
			cb_header_render_collapsible_sections( 'cb-header-settings' );
			submit_button();
			?>
		</form>
	</div>

	<script>
	(function($){
		'use strict';

		/* ── Media upload ───────────────────────────────────────────────────── */
		$(document).on('click', '.cb-upload-btn', function(e) {
			e.preventDefault();
			var btn      = $(this);
			var targetId = btn.data('target');
			var bgColor  = btn.data('preview-bg') || '#f0f0f1';
			var frame    = wp.media({
				title:    '<?php echo esc_js( __( 'Select Logo', 'styrk-blocks' ) ); ?>',
				button:   { text: '<?php echo esc_js( __( 'Use as Logo', 'styrk-blocks' ) ); ?>' },
				multiple: false,
				library:  { type: ['image', 'image/svg+xml'] }
			});

			frame.on('select', function() {
				var attachment = frame.state().get('selection').first().toJSON();
				var previewUrl = attachment.sizes && attachment.sizes.medium
					? attachment.sizes.medium.url
					: attachment.url;

				$('#' + targetId).val(attachment.id);
				$('#' + targetId + '_preview').attr('src', previewUrl);
				$('#' + targetId + '_wrapper .cb-media-preview')
					.css({ display: 'block', background: bgColor }).show();
				btn.text('<?php echo esc_js( __( 'Change Logo', 'styrk-blocks' ) ); ?>');

				if ( ! btn.siblings('.cb-remove-btn').length ) {
					$('<button type="button" class="button cb-remove-btn" data-target="' + targetId + '" style="margin-left:8px;color:#b32d2e;"><?php echo esc_js( __( 'Remove', 'styrk-blocks' ) ); ?></button>')
						.insertAfter(btn);
				}
			});
			frame.open();
		});

		$(document).on('click', '.cb-remove-btn', function(e) {
			e.preventDefault();
			var targetId = $(this).data('target');
			$('#' + targetId).val('0');
			$('#' + targetId + '_preview').attr('src', '');
			$('#' + targetId + '_wrapper .cb-media-preview').hide();
			$(this).siblings('.cb-upload-btn').text('<?php echo esc_js( __( 'Upload Logo', 'styrk-blocks' ) ); ?>');
			$(this).remove();
		});

		/* ── Sync color picker → hex text ───────────────────────────────────── */
		$('input[type="color"]').on('input change', function() {
			$('#' + this.id + '_hex').val(this.value);
		});

		/* ── Theme-palette swatch → set colour + hex ────────────────────────── */
		$(document).on('click', '.cb-theme-swatch', function(e) {
			e.preventDefault();
			var targetId = $(this).data('target');
			var color    = String($(this).data('color'));
			$('#' + targetId).val(color);
			$('#' + targetId + '_hex').val(color);
		});
	})(jQuery);
	</script>
	<?php
}

/* ── Seed defaults on first load ────────────────────────────────────────────── */

function cb_header_seed_defaults(): void {
	if ( get_option( CB_HEADER_OPTION ) ) {
		return;
	}
	update_option( CB_HEADER_OPTION, cb_header_defaults() );
}
add_action( 'admin_init', 'cb_header_seed_defaults' );

/* ── Output header CSS vars to <head> ───────────────────────────────────────── */

function cb_header_output_css_vars(): void {
	$s = cb_get_header_settings();

	$bg_mode    = $s['bg_mode'] ?? 'transparent';
	$bg_color   = $s['bg_color'] ?? '#0a2020';
	$text_color = $s['text_color'] ?? '#ffffff';

	$bg_value = $bg_mode === 'solid' ? $bg_color : 'transparent';

	$vars  = '--cb-header-bg:' . esc_attr( $bg_value ) . ';';
	$vars .= '--cb-header-text:' . esc_attr( $text_color ) . ';';
	$vars .= '--cb-header-bg-mode:' . esc_attr( $bg_mode ) . ';';

	// Header rail width + side gutter → CSS vars consumed by the React header
	// (view.tsx). Driven by the single "Header alignment" control:
	$header_align = (string) ( $s['header_align'] ?? 'custom' );
	$side_css     = '';

	// "Header and footer width" outranks "Header alignment": it sets the same
	// two header vars AND frames the footer with them, so both bands share
	// their edges. Printed here (not in style.css) so it applies only when an
	// admin chose a value; !important because companion themes pin their own
	// footer width.
	$frame_width = (string) ( $s['frame_width'] ?? '' );
	$frames      = [
		// Capped at 2560px like the hero and full-bleed sections (see .cb-hero).
		'full'    => [ '2560px', 'clamp(16px,2vw,40px)' ],
		'content' => [ 'var(--cb-content-max,1280px)', 'var(--cb-rail,3.25rem)' ],
		'wide'    => [ '1600px', 'var(--cb-rail,3.25rem)' ],
	];

	if ( isset( $frames[ $frame_width ] ) ) {
		$vars     .= '--cb-header-max-width:' . $frames[ $frame_width ][0] . ';';
		$vars     .= '--cb-header-side-pad:' . $frames[ $frame_width ][1] . ';';
		$side_css  = '.site-footer__inner,.site-footer__bar{box-sizing:border-box!important;width:100%!important;max-width:var(--cb-header-max-width)!important;margin-left:auto!important;margin-right:auto!important;padding-left:var(--cb-header-side-pad)!important;padding-right:var(--cb-header-side-pad)!important}';
		$side_css .= '.site-footer__bar>.wp-block-group{max-width:none!important;padding-left:0!important;padding-right:0!important}';
		// Themes give the footer band its own side padding on small screens,
		// which would push the footer further in than the header.
		$side_css .= '.site-footer{padding-left:0!important;padding-right:0!important}';
	} elseif ( 'content' === $header_align ) {
		// Match the page content column: reuse the SAME max-width + rail gutter
		// every section uses, so the logo lines up with the content's left edge
		// and the search / CTA cluster with its right edge — no manual numbers.
		$vars .= '--cb-header-max-width:var(--cb-content-max,1280px);';
		$vars .= '--cb-header-side-pad:var(--cb-rail,3.25rem);';
	} elseif ( 'full' === $header_align ) {
		// Border to border WITH the hero. The hero and full-bleed sections cap at
		// max-width:2560px centred (see .cb-hero in style.css); a raw 100vw header
		// overhangs them on ultra-wide screens. Match that exact 2560px box with
		// no side gutter, so the logo and search/CTA sit on the hero image's
		// left/right edges at every width, with a small 16px breathing gutter so
		// the logo/CTA aren't jammed against the edge. (Keep the 2560 in sync
		// with .cb-hero max-width.)
		$vars .= '--cb-header-max-width:2560px;';
		$vars .= '--cb-header-side-pad:16px;';
	} else {
		// Custom / legacy: honour the explicit Content width + Side padding
		// controls exactly as before. Emitted ONLY when a value is set, so a
		// per-block contentWidth attribute and view.tsx's 1280/52 fallback still
		// win when left on "Inherit".
		$content_width = (string) ( $s['content_width'] ?? '' );
		if ( in_array( $content_width, [ '1180', '1280', '1440', 'full' ], true ) ) {
			$max_width = $content_width === 'full' ? 'none' : $content_width . 'px';
			$vars .= '--cb-header-max-width:' . esc_attr( $max_width ) . ';';
		}
		// Admin side gutter is the DESKTOP value; cap it to the shared section
		// rail on smaller screens (32px tablet, 16px mobile) via media queries
		// emitted AFTER the base rule so they win by source order.
		$side_pad = (string) ( $s['side_pad'] ?? '' );
		if ( '' !== $side_pad && is_numeric( $side_pad ) ) {
			$pad       = (int) $side_pad;
			$vars     .= '--cb-header-side-pad:' . esc_attr( $pad . 'px' ) . ';';
			$side_css  = sprintf( '@media (max-width:1023px){:root{--cb-header-side-pad:min(%dpx,2rem)}}', $pad );
			$side_css .= sprintf( '@media (max-width:639px){:root{--cb-header-side-pad:min(%dpx,1rem)}}', $pad );
		}
	}

	// wp_strip_all_tags() so a value can never close the <style> element.
	printf( '<style id="cb-header-vars">:root{%s}%s</style>' . "\n", wp_strip_all_tags( $vars ), wp_strip_all_tags( $side_css ) );
}
add_action( 'wp_head', 'cb_header_output_css_vars', 1 );
